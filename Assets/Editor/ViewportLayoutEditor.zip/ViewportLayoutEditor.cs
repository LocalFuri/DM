using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using DM.Dungeon;
using DM.Rendering;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

// CHATGPT_BUILD_F1_MINIMAP_ALGORITHM_STAGE1_20260830_AA
public class ViewportLayoutEditor : EditorWindow
{
  private static readonly int[] SnapValues = { 1, 8 };

  private const string PrefsLayoutGuidKey = "ViewportLayoutEditor.LayoutGuid";
  private const string PrefsGraphicsGuidKey =
      "ViewportLayoutEditor.GraphicsGuid";
  private const string PrefsPreviewXKey = "ViewportLayoutEditor.PreviewX";
  private const string PrefsPreviewYKey = "ViewportLayoutEditor.PreviewY";
  private const string PrefsPreviewFacingKey =
      "ViewportLayoutEditor.PreviewFacing";
  private const string PrefsSelectedPieceIndexKey =
      "ViewportLayoutEditor.SelectedPieceIndex";
  private const string SearchPiecesControlName =
      "ViewportLayoutEditor.SearchPieces";
  private const string PreviewLevelJumpControlName =
      "ViewportLayoutEditor.PreviewLevelJump";

  private const string HallOfChampionsMapPath =
      "Assets/Data/Maps/HallOfChampions.json";
  private static readonly string[] PreviewLevelMapPaths =
  {
    HallOfChampionsMapPath,
    "Assets/Data/Maps/DungeonMaster_Level01.json",
    "Assets/Data/Maps/DungeonMaster_Level02.json",
    "Assets/Data/Maps/DungeonMaster_Level03.json",
    "Assets/Data/Maps/DungeonMaster_Level04.json",
    "Assets/Data/Maps/DungeonMaster_Level05.json",
    "Assets/Data/Maps/DungeonMaster_Level06.json",
    "Assets/Data/Maps/DungeonMaster_Level07.json",
    "Assets/Data/Maps/DungeonMaster_Level08.json",
    "Assets/Data/Maps/DungeonMaster_Level09.json",
    "Assets/Data/Maps/DungeonMaster_Level10.json",
    "Assets/Data/Maps/DungeonMaster_Level11.json",
    "Assets/Data/Maps/DungeonMaster_Level12.json",
    "Assets/Data/Maps/DungeonMaster_Level13.json"
  };
  private const string DungeonFeaturePlacementsPath =
      "Assets/Data/Features/DungeonFeaturePlacements.json";
  private const int PreviewDungeonLevel = 0;

  // Hall of Champions special entrance Black Door. Regular Door tiles elsewhere
  // in the map must never select the Black Door renderer.
  private const int HallOfChampionsBlackDoorX = 1;
  private const int HallOfChampionsBlackDoorY = 2;

  private const string PrefsPreviewLevelKey =
      "ViewportLayoutEditor.PreviewLevel";

  private const string ChampionArtFolder =
      "Assets/Art/Champions";
  private const string ChampionMirrorSideAssetPath =
      "Assets/Art/Champions/Champion_Mirror_Side_16x35.png";
  private const string ChampionMirrorFrontAssetPath =
      "Assets/Art/Champions/Champion_Mirror_Front_48x43.png";

  private const string OrnamentArtFolder =
      "Assets/Art/Ornaments";

  // First loose-floor-item calibration. The original Level 0 DUNGEON.DAT
  // places an Apple at map (4,9), sub-square N. Apple_19x13 is the
  // authoritative ground/world artwork; Apple_16x16 is inventory-only.
  private const string AppleGroundAssetPath =
      "Assets/Art/Items/Apple_19x13.png";
  private const int Level0AppleTestX = 4;
  private const int Level0AppleTestY = 9;
  private const string Level0AppleTestCell = "N";

  // Initial loose-floor-item calibration slots. X/Y are deliberately isolated
  // from the authoritative DUNGEON.DAT map coordinates so we can tune screen
  // projection without ever moving the object in map space. The original DOS
  // reference shows the 19x13 Apple artwork on the floor.
  private int appleF1PreviewX = 104;
  private int appleF1PreviewScreenTop = 144;
  private int appleF0RightPreviewX = 150;
  private int appleF0RightPreviewScreenTop = 152;
  // Same-tile front sub-square. From the original 4,9 North reference the
  // native 19x13 apple begins at approximately X=56, screen-top=150.
  private int appleF0FrontPreviewX = 56;
  private int appleF0FrontPreviewScreenTop = 150;

  // F2 is generated from the single authoritative F1 ground sprite.
  // Floor-item perspective is steeper than the wall-piece F1->F2 ratio.
  // Calibrated against the original 5,9 West screenshot: Apple_19x13 is
  // reduced to 9x6 and moved farther into the corridor.
  private const int AppleF2Width = 12;
  private const int AppleF2Height = 8;

  // One-tile-ahead item sub-square projection.
  // Right-hand is verified from (5,9) West. The same N corner slot projects
  // left-hand when viewed from (4,10) North.
  private int appleF2RightPreviewX = 136;
  private int appleF2RightPreviewScreenTop = 124;

  // Mirror the verified right-hand F2 slot across the 224px dungeon viewport:
  // 224 - 136 - 12 = 76.
  private int appleF2LeftPreviewX = 76;
  private int appleF2LeftPreviewScreenTop = 124;

  // F3 is two map steps ahead, generated from the same Apple_19x13 source.
  // Measured on the original (4,11) North viewport: left edge X=89,
  // screen top Y=106, size 6x5. Right-hand is the mirror of that slot.
  private const int AppleF3Width = 6;
  private const int AppleF3Height = 5;
  private int appleF3LeftPreviewX = 89;
  private int appleF3LeftPreviewScreenTop = 106;
  private int appleF3RightPreviewX = 129;
  private int appleF3RightPreviewScreenTop = 106;

  // Second loose-floor-item calibration. Original Level 0 DUNGEON.DAT places
  // Bread at map (5,11), sub-square E. Bread_27x16 is the ground/world
  // artwork; Bread_16x16 is inventory/icon only.
  private const string BreadGroundAssetPath =
      "Assets/Art/Items/Bread_27x16.png";
  private const int Level0BreadTestX = 5;
  private const int Level0BreadTestY = 11;
  private const string Level0BreadTestCell = "E";

  // Compact read-only X/Y boxes for floor-item rows in ViewEdit. Sized for
  // a single visible digit so ground items do not waste horizontal space.
  private const float FloorItemMapCoordFieldWidth = 28f;

  // Shared description column for Champion Mirror and the ornament rows
  // under it, so Enabled starts on the same x for every feature row.
  private const float FeatureDescriptionWidth = 210f;

  // Same-tile F0-forward calibration for pose (5,11) facing East. Keep these
  // as render-only values while deriving the generic floor-item projection.
  [System.NonSerialized]
  private int breadF0LeftPreviewX = 50;
  [System.NonSerialized]
  private int breadF0LeftPreviewScreenTop = 150;

  // Same-tile F0 right slot. Stored sub-square E at (5,11) facing North
  // projects here. Measured from that original: X=141, screen top Y=150.
  [System.NonSerialized]
  private int breadF0RightPreviewX = 141;
  [System.NonSerialized]
  private int breadF0RightPreviewScreenTop = 150;

  // One-tile-ahead bread. Measured on the original (4,11) East view:
  // stored E projects left, X=72, screen top Y=121, size 17x10.
  // Right-hand is the 224px mirror: 224 - 72 - 17 = 135.
  private const int BreadF2Width = 17;
  private const int BreadF2Height = 10;
  [System.NonSerialized]
  private int breadF2LeftPreviewX = 72;
  [System.NonSerialized]
  private int breadF2LeftPreviewScreenTop = 121;
  [System.NonSerialized]
  private int breadF2RightPreviewX = 135;
  [System.NonSerialized]
  private int breadF2RightPreviewScreenTop = 121;

  // Original DOS Hall of Champions VI Altar: native 96x56 graphic.
  // Adjusted 5 px down: screen top-left (64,69), framebuffer bottom-left (64,75).
  // The texture is located by name/dimensions so either
  // Altar_of_Vi_96,56.png or Altar_of_Vi_96x56.png works.
  private const int ViAltarD1FrontX = 64;
  private const int ViAltarD1FrontY = 75;
  private const int ViAltarS1RightX = 168;
  private const int ViAltarS1Y = 81;

  // Vi Altar S2 uses the pixel-exact reference asset directly at 1:1.
  // Verified native S2 side image. Used generically for every Vi Altar that
  // resolves to an S2 left/right side projection; this is not pose-specific.
  private const string ViAltarS2AssetPath =
      "Assets/Art/Ornaments/Altar_of_Vi_S2_Ref_12x31.png";
  private const int ViAltarS2RightX = 148;
  private const int ViAltarS2Y = 98;

  // Vi Altar S3 uses the exact 6x19 reference crop from the original.
  // The 1,17 East / anchor 4,17 East pose calibrated this generic S3 slot.
  // Apply the same S3 projection to every visible Vi Altar resolved at depth 3;
  // there is no player-coordinate or altar-coordinate special case here.
  // Original-screen top-left is X=140, Y=81, so framebuffer Y is 108.
  private const string ViAltarS3AssetPath =
      "Assets/Art/Ornaments/Altar_of_Vi_S3_Ref_6x19.png";
  private const int ViAltarS3RightX = 140;
  private const int ViAltarS3Y = 108;

  // F2 and F3 are scaled from the 96x56 F1 graphic. These are the
  // measured destination slots, not separate captured pictures.
  private const int ViAltarD2GeneratedFrontX = 80;
  private const int ViAltarD2GeneratedFrontY = 92;
  private const int ViAltarD3GeneratedFrontX = 91;
  private const int ViAltarD3GeneratedFrontY = 105;

  // Engine-slot test sizes. F2 is the original 64x37 center slot.
  // F3 uses the measured 42x24 slot that matches the original crop.
  // Framebuffer Y is bottom-left in the 200-tall preview.
  private const int ViAltarEngineF2Width = 64;
  private const int ViAltarEngineF2Height = 37;
  private const int ViAltarEngineF2FrontX = 80;
  private const int ViAltarEngineF2FrontY = 93;
  private const int ViAltarEngineF3Width = 42;
  private const int ViAltarEngineF3Height = 24;
  private const int ViAltarEngineF3FrontX = 91;
  private const int ViAltarEngineF3FrontY = 105;
  private const string HookFrontAssetPath =
      "Assets/Art/Ornaments/Hook_Front_28x28.png";
  private const string ManaclesF1AssetPath =
      "Assets/Art/Ornaments/Manacles_F1.png";
  private const string ManaclesS1AssetPath =
      "Assets/Art/Ornaments/Manacles_S1.png";

  // D1 side manacles use the native 32x42 S1 graphic 1:1.
  // Measured on the original (4,10) North left wall, then shifted
  // +2 px on X: screen top-left (30, 74), framebuffer bottom-left
  // Y = 200 - 74 - 42 = 84.
  // The right slot mirrors that across the 224px viewport.
  private const int ManaclesD1SideWidth = 32;
  private const int ManaclesD1SideHeight = 42;
  private const int ManaclesD1SideLeftX = 30;
  private const int ManaclesD1SideRightX =
      DungeonViewportWidth - ManaclesD1SideLeftX - ManaclesD1SideWidth;
  private const int ManaclesD1SideY = 84;

  // D2 side manacles are scaled from Manacles_S1 with the medium palette.
  // Measured on the original (4,11) North left wall, then shifted
  // +2 px on X: screen top-left (57, 73), size 20x26, framebuffer
  // bottom-left Y = 200 - 73 - 26 = 101.
  private const int ManaclesD2SideWidth = 20;
  private const int ManaclesD2SideHeight = 26;
  private const int ManaclesD2SideLeftX = 57;
  private const int ManaclesD2SideRightX =
      DungeonViewportWidth - ManaclesD2SideLeftX - ManaclesD2SideWidth;
  private const int ManaclesD2SideY = 101;

  // F2 manacles are generated from the 92x52 F1 source.
  // Measured on the original (5,9) West view: centered on the 224px
  // viewport, screen top-left (83, 76), so framebuffer bottom-left
  // Y = 200 - 76 - 31 = 93.
  private const int ManaclesD2FrontX = 83;
  private const int ManaclesD2FrontY = 93;
  private const int ManaclesD2FrontWidth = 58;
  private const int ManaclesD2FrontHeight = 31;

  // F3 manacles are generated from the same 92x52 F1 source.
  // Measured on the original (6,9) West view: screen top-left (93, 73),
  // size 38x20, framebuffer bottom-left Y = 200 - 73 - 20 = 107.
  private const int ManaclesD3FrontX = 93;
  private const int ManaclesD3FrontY = 107;
  private const int ManaclesD3FrontWidth = 38;
  private const int ManaclesD3FrontHeight = 20;
  private const string GrateFrontAssetPath =
      "Assets/Art/Ornaments/Grate_Front_32x28.png";
  private const string GrateSide1AssetPath =
      "Assets/Art/Ornaments/Grate_Side1_16x19.png";
  private const string HookSideAssetPath =
      "Assets/Art/Ornaments/Hook_Side_16x19.png";
  private const string SlimeSide1AssetPath =
      "Assets/Art/Ornaments/Slime_Side_16x10.png";
  private const string PuddleF1AssetPath =
      "Assets/Art/Ornaments/Puddle_F1.png";
  private const string PuddleF1SideAssetPath =
      "Assets/Art/Ornaments/Puddle_F1_Side_9x7.png";
  private const string PuddleF2AssetPath =
      "Assets/Art/Ornaments/Puddle_F2.png";
  private const string PuddleF3AssetPath =
      "Assets/Art/Ornaments/Puddle_F3.png";
  private const string PuddleS1AssetPath =
      "Assets/Art/Ornaments/Puddle_S1.png";
  private const string PuddleS2AssetPath =
      "Assets/Art/Ornaments/Puddle_S2.png";

  // Blue floor puddle. Hall of Champions puddles are resolved from the
  // original deterministic random floor-ornament rule (local ordinal 2).
  // Puddle_F1 is the D1 center graphic. D1-left/right use the dedicated
  // Puddle_F1_Side_9x7 source; the left placement keeps the verified +1 px
  // right / +1 px up adjustment from the original comparison.
  private const int PuddleF1ScreenTop = 132;
  private const int PuddleF2ScreenTop = 108;
  private const int PuddleF3ScreenTop = 94;
  private const int PuddleS2ScreenTop = 102;
  private const int PuddleS2LeftScreenX = 66;

  // Original DOS Hook front placement on the wall immediately in front of
  // the party. Measured from the supplied 320x200 original screenshot:
  // source = 28x28, screen top-left ~= (98,72), therefore framebuffer
  // bottom-left Y = 200 - 72 - 28 = 100.
  private const int HookD1FrontX = 98;
  private const int HookD1FrontY = 100;

  // Hook / coordinate-set-0 front at distance 2.
  // The original slot is 22x18 for a 32x28 source. Our Hook_Front_28x28
  // asset is the tight crop of that source (2 transparent columns removed
  // on each side), so its visible F2 result is 19x18 and starts one pixel
  // inside the original slot.
  private const int HookD2FrontX = 103;
  private const int HookD2FrontY = 108;
  private const int HookD2FrontWidth = 19;
  private const int HookD2FrontHeight = 18;

  // Coordinate-set-0 front at distance 3. The original box is 16x12.
  // The 28-wide F1 crop drops one pixel on each side, so the drawn
  // result is 14x12. Screen top-left (105, 75), framebuffer bottom-left
  // Y = 200 - 75 - 12 = 113.
  private const int HookD3FrontX = 105;
  private const int HookD3FrontY = 113;
  private const int HookD3FrontWidth = 14;
  private const int HookD3FrontHeight = 12;

  // Original DOS Grate front placement on the wall immediately in front of
  // the party. Measured from the supplied 320x200 original screenshot:
  // source = 32x28, screen top-left = (96,125), therefore framebuffer
  // bottom-left Y = 200 - 125 - 28 = 47.
  private const int GrateD1FrontX = 96;
  private const int GrateD1FrontY = 47;

  // Original DOS Grate front at distance 2. In the supplied (16,8) West
  // screenshot Grate_Front2_21x13.png is an exact pixel match at screen
  // top-left (102,113). The wall is two steps ahead, (14,8) East.
  // Framebuffer Y = 200 - 113 - 13 = 74.
  private const int GrateD2FrontX = 102;
  private const int GrateD2FrontY = 74;

  // Original DOS Grate front at distance 3. In the supplied (17,8) West
  // screenshot Grate_Front3_14x9.png is an exact pixel match at screen
  // top-left (105,99). The wall is three steps ahead, (14,8) East.
  // Framebuffer Y = 200 - 99 - 9 = 92.
  private const int GrateD3FrontX = 105;
  private const int GrateD3FrontY = 92;

  // Original DOS Grate D1 side placement. In the supplied (14,9) West
  // original screenshot Grate_Side1_16x19.png occupies the left D1 side
  // slot with framebuffer bottom-left X=47, Y=63. The right slot is the
  // exact dungeon-viewport mirror of the same 16x19 sprite.
  private const int GrateD1SideLeftX = 47;
  private const int GrateD1SideRightX =
      224 - GrateD1SideLeftX - 16;
  private const int GrateD1SideY = 63;

  // Original DOS Grate D2 side placement. In the supplied (15,9) West
  // original screenshot Grate_Side2_6x11.png occupies the left D2 side
  // slot at screen top-left (66,106). Texture2D framebuffer Y is therefore
  // 200 - 106 - 11 = 83. The right slot is the exact 224px viewport mirror.
  private const int GrateD2SideLeftX = 66;
  private const int GrateD2SideRightX =
      DungeonViewportWidth - GrateD2SideLeftX - 6;
  private const int GrateD2SideY = 83;

  // Original DOS Grate D3 side. In the supplied (16,9) West screenshot
  // Grate_Side3_4x4.png occupies the left D3 side slot at screen top-left
  // (81,96). That face is wall tile (13,10) North. The art is the left-wall
  // perspective, so only the right blit is mirrored.
  // Framebuffer Y = 200 - 96 - 4 = 100.
  private const int GrateD3SideLeftX = 81;
  private const int GrateD3SideRightX =
      DungeonViewportWidth - GrateD3SideLeftX - 4;
  private const int GrateD3SideY = 100;

  // Original DOS coordinate-set-0 D1 side placement (Hook / Wood Ring family).
  // The original D1 side box is 16x19 at left screen X=48 (right = 224-48-16).
  // Hook now uses native Hook_Side_16x19.png 1:1 in that box.
  // Wood Ring still uses the 14x19 cutout centered one pixel inside it.
  // Texture2D framebuffer Y = 200 - 74 - 19 = 107.
  // Dungeon viewport is X=0..223. Every left/right wall-ornament pair is the
  // same sprite mirrored around that width: rightX = 224 - leftX - spriteWidth.
  private const int DungeonViewportWidth = 224;

  // Front view of the Hall/level staircase when a Stairs tile is one cell
  // directly ahead. The 152x92 source was cropped from the original at
  // dungeon-view X=36, Y=44. The dungeon viewport begins at full-screen Y=33,
  // so full preview display Y is 77 and framebuffer Y is 31.
  private const string StairsDownF1AssetPath =
      "Assets/Art/Walls/Stairs/Stairs_Down_F1_152x92.png";
  private const int StairsDownF1X = 36;
  private const int StairsDownF1DisplayY = 50;

  // Original DOS near-right wall when a down-stairs tile is immediately to
  // the player's right. The source is an exact 32x91 crop from the original
  // 320x200 frame at screen X=192, top Y=33. It replaces normal RightF0.
  private const string StairsDownRightD1AssetPath =
      "Assets/Art/Walls/Stairs/Stairs_Down_Front_D1_32x91.png";
  private const int StairsDownRightD1X = 192;
  private const int StairsDownRightD1DisplayY = 33;
  // This crop lives inside the 224x136 dungeon viewport, not the full
  // 320x200 output. topY 33 with height 91 => framebuffer Y 12.
  private const int StairsDownRightD1FramebufferY = 12;

  // ViewEdit controls for the down-stairs overlay. These are intentionally
  // editor-preview values (like the live wall controls) so the sprite can be
  // enabled/disabled and aligned without changing the map data.
  [SerializeField] private bool stairsDownF1PreviewEnabled = true;
  [SerializeField] private int stairsDownF1PreviewX = StairsDownF1X;
  [SerializeField] private int stairsDownF1PreviewDisplayY = StairsDownF1DisplayY;

  // Dynamic geometry can change which wall card is authoritative without the
  // player pose changing (for example after a script/domain reload). Keep a
  // tiny signature so ViewEdit rebuilds instead of continuing to show the
  // wall list from the previous renderer version.
  private bool dynamicGeometrySignatureInitialized;
  private bool cachedStairsDownRightD1Active;

  private const int DungeonViewportHeight = 136;

  // Original Dungeon Master / CSBwin viewport lighting palettes.
  // Six discrete 16-colour states, decoded from asciidump.txt.
  // Stage 1 is full light; Stage 6 is the darkest no-light state.
  private static readonly Color32[][] DungeonViewportLightPalettes =
  {
    new[]
    {
      new Color32(0, 0, 0, 255),
      new Color32(109, 109, 109, 255),
      new Color32(146, 146, 146, 255),
      new Color32(109, 36, 0, 255),
      new Color32(0, 219, 219, 255),
      new Color32(146, 73, 0, 255),
      new Color32(0, 146, 0, 255),
      new Color32(0, 219, 0, 255),
      new Color32(255, 0, 0, 255),
      new Color32(255, 182, 0, 255),
      new Color32(219, 146, 109, 255),
      new Color32(255, 255, 0, 255),
      new Color32(73, 73, 73, 255),
      new Color32(182, 182, 182, 255),
      new Color32(0, 0, 255, 255),
      new Color32(255, 255, 255, 255)
    },
    new[]
    {
      new Color32(0, 0, 0, 255),
      new Color32(73, 73, 73, 255),
      new Color32(109, 109, 109, 255),
      new Color32(109, 36, 0, 255),
      new Color32(0, 219, 219, 255),
      new Color32(146, 36, 0, 255),
      new Color32(0, 109, 0, 255),
      new Color32(0, 182, 0, 255),
      new Color32(219, 0, 0, 255),
      new Color32(219, 146, 0, 255),
      new Color32(182, 109, 73, 255),
      new Color32(255, 219, 0, 255),
      new Color32(36, 36, 36, 255),
      new Color32(146, 146, 146, 255),
      new Color32(0, 0, 219, 255),
      new Color32(219, 219, 219, 255)
    },
    new[]
    {
      new Color32(0, 0, 0, 255),
      new Color32(36, 36, 36, 255),
      new Color32(73, 73, 73, 255),
      new Color32(73, 36, 0, 255),
      new Color32(0, 219, 219, 255),
      new Color32(109, 36, 0, 255),
      new Color32(0, 73, 0, 255),
      new Color32(0, 146, 0, 255),
      new Color32(182, 0, 0, 255),
      new Color32(182, 109, 0, 255),
      new Color32(146, 73, 36, 255),
      new Color32(255, 182, 0, 255),
      new Color32(0, 0, 0, 255),
      new Color32(109, 109, 109, 255),
      new Color32(0, 0, 182, 255),
      new Color32(182, 182, 182, 255)
    },
    new[]
    {
      new Color32(0, 0, 0, 255),
      new Color32(0, 0, 0, 255),
      new Color32(36, 36, 36, 255),
      new Color32(36, 0, 0, 255),
      new Color32(0, 219, 219, 255),
      new Color32(73, 36, 0, 255),
      new Color32(0, 36, 0, 255),
      new Color32(0, 109, 0, 255),
      new Color32(146, 0, 0, 255),
      new Color32(146, 73, 0, 255),
      new Color32(109, 36, 0, 255),
      new Color32(219, 146, 0, 255),
      new Color32(0, 0, 0, 255),
      new Color32(73, 73, 73, 255),
      new Color32(0, 0, 146, 255),
      new Color32(146, 146, 146, 255)
    },
    new[]
    {
      new Color32(0, 0, 0, 255),
      new Color32(0, 0, 0, 255),
      new Color32(0, 0, 0, 255),
      new Color32(0, 0, 0, 255),
      new Color32(0, 219, 219, 255),
      new Color32(36, 0, 0, 255),
      new Color32(0, 0, 0, 255),
      new Color32(0, 73, 0, 255),
      new Color32(109, 0, 0, 255),
      new Color32(109, 36, 0, 255),
      new Color32(73, 0, 0, 255),
      new Color32(182, 109, 0, 255),
      new Color32(0, 0, 0, 255),
      new Color32(36, 36, 36, 255),
      new Color32(0, 0, 109, 255),
      new Color32(109, 109, 109, 255)
    },
    new[]
    {
      new Color32(0, 0, 0, 255),
      new Color32(0, 0, 0, 255),
      new Color32(0, 0, 0, 255),
      new Color32(0, 0, 0, 255),
      new Color32(0, 219, 219, 255),
      new Color32(0, 0, 0, 255),
      new Color32(0, 0, 0, 255),
      new Color32(0, 36, 0, 255),
      new Color32(73, 0, 0, 255),
      new Color32(73, 0, 0, 255),
      new Color32(36, 0, 0, 255),
      new Color32(109, 73, 0, 255),
      new Color32(0, 0, 0, 255),
      new Color32(0, 0, 0, 255),
      new Color32(0, 0, 73, 255),
      new Color32(73, 73, 73, 255)
    }
  };

  private const int HookD1SideLeftX = 48;
  private const int HookD1SideRightX =
      DungeonViewportWidth - HookD1SideLeftX - 16;
  private const int HookD1SideY = 107;
  private const int WoodRingD1SideLeftX = 49;
  private const int WoodRingD1SideRightX =
      DungeonViewportWidth - WoodRingD1SideLeftX - 14;
  private const int WoodRingD1SideY = 108;

  // Original DOS D1 side Slime placement. In the supplied (4,6) North
  // original screenshot the mirrored right-wall Slime_Side_16x10 sprite
  // is an exact pixel match at screen top-left (161,127). Left slot is
  // that same 16px box mirrored. Framebuffer Y = 200 - 127 - 10 = 63.
  private const int SlimeD1SideLeftX = 47;
  private const int SlimeD1SideRightX =
      DungeonViewportWidth - SlimeD1SideLeftX - 16;
  private const int SlimeD1SideY = 63;

  // Original DOS Wood Ring side2 placement at D2. The supplied native
  // Wood_Ring_Side2_5x10.png matches the original (4,6) North screenshot
  // exactly at screen top-left (66,73). Framebuffer Y = 200 - 73 - 10.
  private const int WoodRingD2SideLeftX = 66;
  private const int WoodRingD2SideRightX =
      DungeonViewportWidth - WoodRingD2SideLeftX - 5;
  private const int WoodRingD2SideY = 117;

  // Original DOS D2 side Slime placement. The supplied (4,7) North original
  // uses native Slime_Side_4x3.png as an exact right-wall crop at screen
  // top-left (154,114). Store the mirrored left slot; the 4x3 PNG is already
  // the right-wall facing, so only the left blit is flipped.
  // Framebuffer Y = 200 - 114 - 3 = 83.
  private const int SlimeD2SideLeftX = 66;
  private const int SlimeD2SideRightX =
      DungeonViewportWidth - SlimeD2SideLeftX - 4;
  private const int SlimeD2SideY = 83;

  // Original DOS Wood Ring distant side placement at D3. The supplied native
  // Wood_Ring_Side_3x5.png is an exact pixel match in the original
  // (4,7) North screenshot at screen top-left (82,73).
  // Framebuffer Y = 200 - 73 - 5 = 122.
  private const int WoodRingD3SideLeftX = 82;
  private const int WoodRingD3SideRightX =
      DungeonViewportWidth - WoodRingD3SideLeftX - 3;
  private const int WoodRingD3SideY = 122;

  // Hook D2 blits native Hook_Side2_5x10.png 1:1. The file is 6x10 and is the
  // right-wall crop from player pose (15,9) West (wall tile (13,8) South),
  // so the right slot is unflipped and the left slot is mirrored. Left X and
  // framebuffer Y match the Wood Ring D2 column (screen top-left 73). Right X
  // is the 224px viewport mirror.
  // Hook D3 blits native Hook_Side3_5x10.png 1:1. The file is 3x5 and is also
  // a right-wall crop, placed in the Wood Ring D3 box. Same mirror rule.
  private const int HookD2SideWidth = 6;
  private const int HookD2SideHeight = 10;
  private const int HookD2SideLeftX = WoodRingD2SideLeftX;
  private const int HookD2SideRightX =
      DungeonViewportWidth - HookD2SideLeftX - HookD2SideWidth;
  private const int HookD2SideY = WoodRingD2SideY;
  private const int HookD3SideWidth = 3;
  private const int HookD3SideHeight = 5;
  private const int HookD3SideLeftX = WoodRingD3SideLeftX;
  private const int HookD3SideRightX =
      DungeonViewportWidth - HookD3SideLeftX - HookD3SideWidth;
  private const int HookD3SideY = WoodRingD3SideY;

  // Original DOS Champion front-mirror placement for a D1 center wall.
  // Measured from the original 320x200 (10,5) South ZED view:
  // screen top-left = (88,62), source = 48x43, therefore framebuffer Y=95.
  private const int ChampionMirrorD1FrontX = 88;
  private const int ChampionMirrorD1FrontY = 95;

  // The 32x29 Champion portrait occupies the mirror's inner opening.
  // In the 48x43 source the opening is X=8..39, top Y=6..34.
  // In framebuffer coordinates that is +8 from the frame bottom.
  private const int ChampionPortraitD1FrontOffsetX = 8;
  private const int ChampionPortraitD1FrontOffsetY = 8;

  // Original DOS Champion side-mirror placement for the D1 corridor walls.
  // Screen-space original top-left Y=64 for a 35px source becomes framebuffer
  // bottom-left Y=101 in the 320x200 Texture2D.
  private const int ChampionMirrorD1LeftX = 41;
  private const int ChampionMirrorD1RightX =
      DungeonViewportWidth - ChampionMirrorD1LeftX - 16;
  private const int ChampionMirrorD1Y = 101;

  // D0/F0 screen-right Champion mirror. The original uses the FRONT mirror
  // perspective family here, generated from the 48x43 F1 source at F3 size,
  // then clipped by the near RightF0 wall. Keep the horizontal anchor at the
  // measured original position; the vertical anchor uses the generated F3
  // front-mirror slot.
  private const int ChampionMirrorD0RightX = 185;
  private const int ChampionMirrorD0RightY = ChampionMirrorD3FrontY;

  // Temporary ViewEdit calibration for the F0-right Champion Mirror projection.
  // These values are pose-local inspection controls and reset when the pose changes.
  private int championMirrorD0RightPreviewX = ChampionMirrorD0RightX;
  private int championMirrorD0RightPreviewVisibleWidth = 7;
  private bool championMirrorD0RightPreviewMirror;

  // Original DOS Champion front-mirror placement for a D2 center wall.
  // Measured from the original 320x200 (10,4) South ZED view:
  // screen top-left = (97,67), visible size = 29x27, therefore framebuffer
  // bottom-left Y = 200 - 67 - 27 = 106. At D2 the original shows only
  // the reduced mirror/frame; the Champion portrait is no longer drawn.
  // D2 front-facing Champion mirrors use the same 29x27 point-scaled frame
  // in all three projected lanes. The lateral lanes are mostly outside the
  // 224px dungeon viewport: at X=-10 only source columns 10..28 remain, and
  // at X=205 only source columns 0..18 remain. This exactly matches the
  // original clipped 19px-wide mirror visible at (10,9) South on D2-left.
  private const int ChampionMirrorD2FrontLeftX = -10;
  private const int ChampionMirrorD2FrontX = 97;
  private const int ChampionMirrorD2FrontRightX = 205;
  private const int ChampionMirrorD2FrontY = 106;
  private const int ChampionMirrorD2FrontWidth = 29;
  private const int ChampionMirrorD2FrontHeight = 27;

  // Original DOS Champion front-mirror placement for a D3 center wall.
  // Verified from the original (9,7) South SYRA view.
  private const int ChampionMirrorD3FrontX = 102;
  private const int ChampionMirrorD3FrontY = 114;
  private const int ChampionMirrorD3FrontWidth = 20;
  private const int ChampionMirrorD3FrontHeight = 19;

  // Original DOS Champion side mirror at D2 on the screen-right wall.
  // Measured from the original 320x200 (9,5) South ELIJA view:
  // screen top-left approximately (148,67), visible size 10x23, therefore
  // framebuffer bottom-left Y = 200 - 67 - 23 = 110.
  private const int ChampionMirrorD2LeftX = 66;
  private const int ChampionMirrorD2RightX =
      DungeonViewportWidth - ChampionMirrorD2LeftX - 10;
  private const int ChampionMirrorD2SideY = 110;
  private const int ChampionMirrorD2SideWidth = 10;
  private const int ChampionMirrorD2SideHeight = 23;

  // Original DOS D3-left F3 corridor slot. Verified from (9,9) East LINFLAS:
  // Mirror_Side_7x15.png matches screen X=78..84, Y=69..83, then nudged
  // +2px toward corridor center. Framebuffer Y = 200 - 69 - 15 = 116.
  // F3-right is only the viewport mirror of that left slot (not another +2).
  private const int ChampionMirrorD3LeftX = 80;
  private const int ChampionMirrorD3LeftY = 116;
  private const int ChampionMirrorD3RightF3X =
      DungeonViewportWidth - ChampionMirrorD3LeftX - 7;
  private const int ChampionMirrorD3RightF3Y = ChampionMirrorD3LeftY;

  // Original DOS D3L2/D3R2 oblique slots. All Champion side-mirror source
  // artwork is now stored in canonical LEFT orientation. The right slot mirrors
  // the source at render time. Same +2 center-nudge as F3-left, then mirror.
  private const int ChampionMirrorD3LeftL2X = 17;
  private const int ChampionMirrorD3LeftL2Y = 116;
  private const int ChampionMirrorD3RightX =
      DungeonViewportWidth - ChampionMirrorD3LeftL2X - 15;
  private const int ChampionMirrorD3RightY = ChampionMirrorD3LeftL2Y;

  private const string DefaultViewportLayoutPath =
      "Assets/Dungeon Master/ViewportLayout.asset";

  private const int PreviewWidth = 320;
  private const int PreviewHeight = 200;

  // NORMAL-WALL REBOOT:
  // Until the new geometry renderer is built, old normal-wall rendering is
  // completely disconnected. Only the relative geometry snapshot is active.
  private const bool GeometryFoundationOnly = false;
  private static readonly string[] PieceSearchFamilyOptions =
  {
    "",
    "Front",
    "Left",
    "Right",
    "LeftD3",
    "RightD3",
    "Black Door",
    "Active",
  };

  /// <summary>
  /// Locked (1,2) South kit Enabled baseline for ViewportLayout.asset disk writes.
  /// Source: LockedBackup/ViewportLayout_1_2_South.asset + walls.txt.
  /// </summary>
  private static readonly (string Name, bool Enabled)[] KitBaselineEnabled =
  {
    ("Ceiling", true),
    ("Ceiling Strip 84", false),
    ("Ceiling Strip 85", false),
    ("Floor", true),
    ("Front Wall F3", false),
    ("Wall F3Left", true),
    ("Wall F3Right", true),
    ("Wall D3L2", false),
    ("Wall D3R2", false),
    ("Front Wall F2", false),
    ("Wall F2Left", true),
    ("Wall F2Right", false),
    ("Front Wall F1", false),
    ("Wall F1Left", true),
    ("Wall F1Right", true),
    ("Wall F0Left", true),
    ("Wall F0Right", true),
    ("Movement Arrows", true),
    ("Champion Status Slot 1", true),
    ("Champion Status Slot 2", true),
    ("Champion Status Slot 3", true),
    ("Champion Status Slot 4", true),
    // Door Enabled is pose-authored; kit default is off.
    ("Black Door Frame Left F1", false),
    ("Black Door Frame Left F2", false),
    ("Black Door Frame Right F1", false),
    ("Black Door Frame Right F2", false),
    ("BlackDoorF1", false),
  };

  [System.NonSerialized]
  private ViewportLayout layout;
  [System.NonSerialized]
  private DungeonGraphics graphics;
  [System.NonSerialized]
  private Texture2D cachedNativeFrontF1ReadableCopy;
  private const string NativeFrontF1AssetPath =
      DungeonGraphics.FrontWallF1NativeAssetPath;

  [System.NonSerialized]
  private Texture2D cachedNativeFrontF2ReadableCopy;
  private const string NativeFrontF2AssetPath =
      DungeonGraphics.FrontWallF2NativeAssetPath;

  [System.NonSerialized]
  private Texture2D cachedNativeFrontF3ReadableCopy;
  private const string NativeFrontF3AssetPath =
      DungeonGraphics.FrontWallF3NativeAssetPath;
  private Vector2 editorScroll;
  private bool scrollToBottomOnNextRepaint;
  private int lastPlayModeScrollX = int.MinValue;
  private int lastPlayModeScrollY = int.MinValue;
  private DungeonFacing lastPlayModeScrollFacing = (DungeonFacing)(-1);
  private int pieceSearchFamilyIndex;
  private bool showWallsActivFilter;
  private bool showOnlyWallsNeededForCurrentPose;
  private bool previewDisableAllWalls;

  // A wall card that the user touches in ViewEdit stays listed for the whole
  // current pose, even if its Enabled toggle is turned OFF and geometry would
  // otherwise remove it from the needed-walls list. Store the V17 family name
  // so alias cards such as RightD3 / Wall D3R2 and LeftD3 / Wall D3L2 share
  // the same sticky row state. The set is discarded automatically on any
  // X/Y/facing/level change.
  private readonly HashSet<string> previewStickyVisibleWallFamilies =
      new HashSet<string>(System.StringComparer.Ordinal);
  private int previewStickyPoseLevel = int.MinValue;
  private int previewStickyPoseX = int.MinValue;
  private int previewStickyPoseY = int.MinValue;
  private DungeonFacing previewStickyPoseFacing = (DungeonFacing)(-1);

  // Edit-mode Champion state calibration. The wall mirror remains present
  // after a Champion has been resurrected/recruited; only the portrait is
  // removed. This set lets ViewEdit verify that generic rendering rule now.
  // When the gameplay party/recruitment state is wired into this renderer,
  // IsPreviewChampionTaken() is the single hook to replace/extend.
  private readonly HashSet<string> previewTakenChampionKeys =
      new HashSet<string>(System.StringComparer.OrdinalIgnoreCase);
  // Legacy Stage 6P calibration constants. V17 production rendering no longer
  // uses the old 32px crop from the 141x49 FrontF3 composite.
  private const int Viewport17D3SideLockedSourceX = 64;
  private const bool Viewport17D3LeftLockedMirror = false;
  // D3 RIGHT is derived as the symmetric generic candidate: same 32px source
  // window mirrored into destination X=192..223. It remains a candidate until
  // visually verified against an original-game D3 RIGHT case.
  private const bool Viewport17D3RightCandidateMirror = true;
  // Native DOS LeftF3 destination X. The dest-X gutter to the left of this
  // (X=0 .. NativeD3LeftF3DestX-1) is the visible FrontF3 sliver when an
  // open left corridor meets a full D3 L+C+R plane behind a nearer center.
  // Original-game comparison shows that this gutter uses a 14px FrontF3 crop
  // starting at X=-7, so only source columns 7..13 remain visible at X=0..6.
  private const int NativeD3LeftF3DestX = 7;
  private const int NativeD3LeftFrontGutterWidth = NativeD3LeftF3DestX * 2;
  private const int NativeD3LeftFrontGutterX = -NativeD3LeftF3DestX;
  // Verified 9,4-East-class right-edge gutter. RightF3 ends at X=216 and
  // original DM exposes the first few pixels of the full 141px FrontF3
  // source beyond it. Drawing the full source at X=216 (Mirror OFF) lets
  // viewport clipping keep only X=216..223.
  private const int NativeD3RightFrontGutterX = 216;
  private const int NativeD3RightFrontGutterWidth = 141;

  // Verified 10,5-West-class D3 right-front placement. The matching manual
  // ViewEdit recipe uses the full authored FrontF3 source at X=185, Y=58,
  // Mirror OFF. Keep the full 141px width; viewport clipping preserves only
  // the visible part at the far-right edge exactly as in the verified view.
  private const int NativeD3RightOpenSlitFrontX = 185;
  private const int NativeD3RightOpenSlitFrontWidth = 141;
  // RightD3 horizontal calibrations for two geometry-only sliver classes.
  // 7,11-South: the D3 center terminates while the right lane stays open.
  // 9,9-East: center/right stay open through D3 and the outer-right D3 wall
  // remains visible behind the nearer RightF0.
  private const int NativeD3RightF0SliverX = 178;
  private const int NativeD3RightOuterCorridorSliverX = 180;
  private string pieceSearchText = string.Empty;
  private bool openSearchPiecesPopup;
  private bool focusSearchPieces;
  private GUIStyle searchPiecesLabelStyle;
  private GUIStyle pieceFamilyHeaderStyle;
  private int snap = 1;
  private bool fitWidthToContent;
  private float fittedContentRight;

  private bool hookedViewEditGlobalNavigation;

  private static int s_viewEditGlobalNavOwners;
  private static bool s_viewEditGlobalNavCallbackAdded;
  private static bool s_viewEditGlobalNavDispatch;
  // End/PageDown are dispatched before the focused Unity control sees the
  // key. While that turn is in progress, never repaint GameView explicitly:
  // Unity can transfer EditorWindow focus during GameView.Repaint().
  private static bool s_viewEditDirectTurnDispatch;
  private static KeyCode s_lastPreprocessedTurnKey = KeyCode.None;
  private static double s_lastPreprocessedTurnTime = -1.0;
  private static readonly EditorApplication.CallbackFunction
      ViewEditGlobalNavHandler = HandleViewEditGlobalNavigationEvent;
  private static System.Delegate s_viewEditBeforeEventProcessedHandler;
  private static readonly UnityEngine.UIElements.EventCallback<
      UnityEngine.UIElements.PointerDownEvent>
      GameViewPointerDownHandler = HandleGameViewPointerDown;
  private static EditorWindow s_hookedGameView;
  private static bool s_gameViewPointerCallbackAdded;
  private static bool s_gameViewPointerUpdateAdded;
  private static double s_lastGameViewClickTime;

  // BlackDoorF1 layout Enabled is initialized once for the verified 1,3 North pose.
  // After initialization, the visible BlackDoorF1 checkbox remains authoritative.
  private bool blackDoorF1EnabledInitialized;
  private bool blackDoorFrameLeftF1EnabledInitialized;
  private bool blackDoorFrameRightF1EnabledInitialized;

  // ViewEdit-only BlackDoorF2 card controls. Do not write layout/pose and
  // do not drive rendering; F2 still uses the existing pose exception.
  private bool blackDoorF2CardInitialized;
  private bool blackDoorF2CardEnabled;
  private bool blackDoorF2CardMirror;
  private DungeonGraphicType blackDoorF2CardGraphic =
      DungeonGraphicType.BlackDoor;

  private bool blackDoorF3CardInitialized;
  private bool blackDoorF3CardEnabled;
  private bool blackDoorF3CardMirror;
  private DungeonGraphicType blackDoorF3CardGraphic =
      DungeonGraphicType.BlackDoor;
  private int blackDoorF3CardX;
  private int blackDoorF3CardY;

  private bool blackDoorFrameLeftF3EnabledInitialized;
  private bool blackDoorFrameRightF3EnabledInitialized;
  private bool blackDoorFrameLeftF3CardEnabled = true;
  private bool blackDoorFrameLeftF3CardMirror;
  private int blackDoorFrameLeftF3CardX;
  private int blackDoorFrameLeftF3CardY;

  private bool blackDoorFrameRightF3CardEnabled = true;
  private int blackDoorFrameRightF3CardX;
  private int blackDoorFrameRightF3CardY;

  private Texture2D blackDoorFrameF3SourceTexture;
  private Texture2D blackDoorFrameLeftF1SourceTexture;
  private Texture2D blackDoorF1SourceTexture;
  private Texture2D blackDoorF3SourceTexture;
  private Texture2D blackDoorF2SourceTexture;
  private Texture2D right2SSourceTexture;
  [System.NonSerialized]
  private Texture2D cachedRight2SReadableCopy;

  // Single source of truth for selection.
  private int selectedPieceIndex;
  private bool selectionChangedThisFrame;

  private RawImage cachedViewportImage;

  private Texture2D editModePreviewTexture;
  private Texture savedViewportTexture;
  private bool viewportTextureStolen;

  // Edit Mode map-pose preview (Hall of Champions).
  // previewFacing is the single source of truth for viewport compose, minimap
  // arrow, and Console — keep all three on this field only.
  // RestoreSessionPrefs restores last EditorPrefs pose, or map start.
  private int previewX;
  private int previewY;
  private DungeonFacing previewFacing = DungeonFacing.South;
  private int previewDungeonLevel = PreviewDungeonLevel;
  private string previewLevelJumpText = string.Empty;
  private DungeonMap previewMiniMap;
  private readonly HashSet<Vector2Int> previewDoorTiles =
      new HashSet<Vector2Int>();
  private string previewMiniMapLoadError;
  private Vector2 previewMiniMapScroll;
  private bool previewMiniMapMuted;

  [System.Serializable]
  private sealed class ChampionMirrorMapRoot
  {
    public ChampionMirrorPlacement[] championMirrors;
    public WallOrnamentPlacement[] wallOrnaments;
  }

  [System.Serializable]
  private sealed class ChampionMirrorPlacement
  {
    public string champion;
    public int x;
    public int y;
    public string wall;
  }

  [System.Serializable]
  private sealed class WallOrnamentPlacement
  {
    public string type;

    // IMPORTANT: for explicit DUNGEON.DAT Sensor mechanisms this is the
    // LEVEL-LOCAL 1-based wall ornament ordinal, not the global ornament ID.
    // Hall of Champions local ordinal 4, for example, resolves through the
    // level WallOrnate table to global source ID 6 = Wood Ring.
    public int ornamentOrdinal;
    public int x;
    public int y;
    public string wall;

    // false: x/y are the passable cell carrying an explicit wall mechanism.
    // true:  x/y are the solid wall tile itself and wall is that tile's
    //        physical decorated face (the random-decoration CELLFLAG case).
    public bool wallTilePlacement;
  }

  [System.Serializable]
  private sealed class FloorItemPlacement
  {
    public string type;
    public int x;
    public int y;
    public string cell;
  }

  // Loose items are map-space records. Rendering never keys off a player
  // pose; it projects each record from its absolute map X/Y and sub-square
  // against the current preview position/facing. Add future items here (or
  // replace this source with parsed DUNGEON.DAT data) without adding pose
  // exceptions to the renderer.
  private static readonly FloorItemPlacement[] HallOfChampionsFloorItems =
  {
    new FloorItemPlacement
    {
      type = "Apple",
      x = Level0AppleTestX,
      y = Level0AppleTestY,
      cell = Level0AppleTestCell
    },
    new FloorItemPlacement
    {
      type = "Bread",
      x = Level0BreadTestX,
      y = Level0BreadTestY,
      cell = Level0BreadTestCell
    }
  };

  // Hall of Champions level-local wall ornament table extracted from
  // DUNGEON.DAT. OrnamentOrdinal is 1-based, so index = ordinal - 1.
  // WallOrnate: 4, 33, 34, 6, 2, 59, 38, 46, 36, 43
  // Relevant entries here:
  //   local 1  -> global 4  = Hook
  //   local 4  -> global 6  = Wood Ring
  //   local 10 -> global 43 = Champion Mirror
  private static readonly int[] HallOfChampionsWallOrnamentSourceIds =
      { 4, 33, 34, 6, 2, 59, 38, 46, 36, 43 };

  // Original Hall of Champions random wall-ornament rules. The low four bits
  // of a wall tile allow a random ornament independently on its physical
  // West/South/East/North faces. Only the first four level-local WallOrnate
  // entries participate in the random selection. The original engine uses a
  // deterministic 16-bit hash with dungeon seed/sentinel 99 and modulo 30.
  private const int HallOfChampionsRandomWallOrnamentCount = 4;
  private const int HallOfChampionsRandomFloorOrnamentCount = 3;
  private const int HallOfChampionsPuddleFloorOrnamentOrdinal = 2;
  private const int HallOfChampionsRandomOrnamentModulo = 30;
  private const int HallOfChampionsDungeonSeed = 99;

  private static readonly Regex DoorTileRegex =
      new Regex(
          @"\{\s*""x""\s*:\s*(?<x>-?\d+)\s*,\s*""y""\s*:\s*(?<y>-?\d+)\s*,[^{}]*?""type""\s*:\s*""Door""",
          RegexOptions.Compiled);

  private static readonly Regex HallOfChampionsRawWallTileRegex =
      new Regex(
          @"\{\s*""x""\s*:\s*(?<x>-?\d+)\s*,\s*""y""\s*:\s*(?<y>-?\d+)\s*,\s*""raw""\s*:\s*(?<raw>\d+)\s*,[^{}]*?""type""\s*:\s*""Wall""",
          RegexOptions.CultureInvariant);

  // Hall of Champions ornament fallback content currently covers the current
  // D1 front cases already verified from the original data:
  //
  // 1) Explicit Sensor seen from passable cell (6,9), North, local ordinal 4.
  //    For map/editor placement we normalize it onto the physical solid wall
  //    tile immediately north: (6,8), South face. The level WallOrnate table
  //    resolves local ordinal 4 to global ID 6 = Wood Ring.
  // 2) Random wall-decoration flag on solid wall tile (13,8), South face.
  //    This one is the Hook seen from player pose (13,9) North.
  //
  // Neither entry is a camera-pose rendering exception; both describe map
  // content and are projected by the ornament overlay renderer.
  private static readonly WallOrnamentPlacement[]
      FallbackHallOfChampionsWallOrnaments =
      {
        new WallOrnamentPlacement
        {
          type = "WoodRing",
          ornamentOrdinal = 4,
          x = 6,
          y = 8,
          wall = "South",
          wallTilePlacement = true
        },
        new WallOrnamentPlacement
        {
          type = "Hook",
          ornamentOrdinal = -1,
          x = 13,
          y = 8,
          wall = "South",
          wallTilePlacement = true
        },
        new WallOrnamentPlacement
        {
          type = "WoodRing",
          ornamentOrdinal = -1,
          x = 3,
          y = 4,
          wall = "East",
          wallTilePlacement = true
        },
        new WallOrnamentPlacement
        {
          type = "Slime",
          ornamentOrdinal = -1,
          x = 5,
          y = 5,
          wall = "West",
          wallTilePlacement = true
        }
      };

  private ChampionMirrorPlacement[] previewChampionMirrors =
      new ChampionMirrorPlacement[0];
  private WallOrnamentPlacement[] previewWallOrnaments =
      FallbackHallOfChampionsWallOrnaments;
  private readonly HashSet<int> previewPuddleFloors = new HashSet<int>();

  // Temporary per-pose ViewEdit feature visibility overrides. These are never
  // written to map/JSON data. Leaving the current pose clears the set so every
  // feature returns to the renderer's code-assigned default state.
  private readonly HashSet<string> previewDisabledFeatureKeys =
      new HashSet<string>(System.StringComparer.OrdinalIgnoreCase);
  // Temporary per-pose ViewEdit overrides for non-wall feature render placement.
  // Keys are the same stable feature keys used by Enabled. They are cleared
  // whenever the pose changes, so these are calibration/inspection controls only.
  private readonly Dictionary<string, Vector2Int> previewFeaturePositionOverrides =
      new Dictionary<string, Vector2Int>(System.StringComparer.OrdinalIgnoreCase);
  private readonly Dictionary<string, bool> previewFeatureMirrorOverrides =
      new Dictionary<string, bool>(System.StringComparer.OrdinalIgnoreCase);
  [System.NonSerialized]
  private Texture2D cachedChampionMirrorSideTexture;
  [System.NonSerialized]
  private Texture2D cachedChampionMirrorSideDistantTexture;
  [System.NonSerialized]
  private Texture2D cachedChampionMirrorSideDistantLeftTexture;
  [System.NonSerialized]
  private Texture2D cachedChampionMirrorSideD2Texture;
  [System.NonSerialized]
  private Texture2D cachedChampionMirrorFrontTexture;
  [System.NonSerialized]
  private Texture2D cachedChampionMirrorGeneratedF2Texture;
  [System.NonSerialized]
  private Texture2D cachedChampionMirrorFrontF3Texture;
  [System.NonSerialized]
  private Texture2D cachedViAltarFrontTexture;
  private Texture2D cachedViAltarS1Texture;
  private Texture2D cachedViAltarS2Texture;
  private Texture2D cachedViAltarS3Texture;
  [System.NonSerialized]
  private Texture2D cachedViAltarGeneratedF2TestTexture;
  private Texture2D cachedViAltarGeneratedF3TestTexture;
  private Texture2D cachedViAltarEngineF2TestTexture;
  private Texture2D cachedViAltarEngineF3TestTexture;

  // Separate ViewEdit test. Builds F2/F3 from the 96x56 extract at the
  // engine slot sizes instead of the measured 63x37 and 42x24 slots.
  private bool previewUseEngineViAltarSlots;
  private int previewDungeonLightStage = 1;
  [System.NonSerialized]
  private Texture2D cachedHookFrontTexture;
  private Texture2D cachedManaclesF1Texture;
  [System.NonSerialized]
  private Texture2D cachedManaclesS1Texture;
  [System.NonSerialized]
  private Texture2D cachedManaclesGeneratedD2SideTexture;
  [System.NonSerialized]
  private Texture2D cachedManaclesGeneratedF2FrontTexture;
  [System.NonSerialized]
  private Texture2D cachedManaclesGeneratedF3FrontTexture;
  [System.NonSerialized]
  private Texture2D cachedHookGeneratedF2FrontTexture;
  [System.NonSerialized]
  private Texture2D cachedGrateFrontTexture;
  [System.NonSerialized]
  private Texture2D cachedGrateFront2Texture;
  [System.NonSerialized]
  private Texture2D cachedGrateFront3Texture;
  [System.NonSerialized]
  private Texture2D cachedGrateSide1Texture;
  [System.NonSerialized]
  private Texture2D cachedGrateSide2Texture;
  [System.NonSerialized]
  private Texture2D cachedGrateSide3Texture;
  [System.NonSerialized]
  private Texture2D cachedHookSideTexture;
  [System.NonSerialized]
  private Texture2D cachedHookSide2Texture;
  [System.NonSerialized]
  private Texture2D cachedHookSide3Texture;
  [System.NonSerialized]
  private Texture2D cachedWoodRingFrontTexture;
  [System.NonSerialized]
  private Texture2D cachedWoodRingGeneratedF2FrontTexture;
  [System.NonSerialized]
  private Texture2D cachedWoodRingGeneratedF3FrontTexture;
  [System.NonSerialized]
  private Texture2D cachedWoodRingSideTexture;
  [System.NonSerialized]
  private Texture2D cachedWoodRingSide2Texture;
  [System.NonSerialized]
  private Texture2D cachedWoodRingSide3Texture;
  [System.NonSerialized]
  private Texture2D cachedSlimeFrontTexture;
  [System.NonSerialized]
  private Texture2D cachedSlimeSide1Texture;
  [System.NonSerialized]
  private Texture2D cachedSlimeSide2Texture;
  [System.NonSerialized]
  private Texture2D cachedPuddleF1Texture;
  private Texture2D cachedPuddleF1SideTexture;
  [System.NonSerialized]
  private Texture2D cachedPuddleF2Texture;
  [System.NonSerialized]
  private Texture2D cachedPuddleF3Texture;
  [System.NonSerialized]
  private Texture2D cachedPuddleS1Texture;
  [System.NonSerialized]
  private Texture2D cachedPuddleS2Texture;
  [System.NonSerialized]
  private Texture2D cachedAppleGroundTexture;
  [System.NonSerialized]
  private Texture2D cachedBreadGroundTexture;
  private readonly Dictionary<string, Texture2D> cachedChampionPortraitTextures =
      new Dictionary<string, Texture2D>(System.StringComparer.OrdinalIgnoreCase);

  // New normal-wall pipeline foundation:
  // pose-store data may still exist, but normal-wall placement is restored from
  // one clean baseline before the relative-geometry resolver runs.
  private readonly Dictionary<string, NormalWallBaseline> normalWallBaselineByName =
      new Dictionary<string, NormalWallBaseline>();

  private struct NormalWallBaseline
  {
    public DungeonGraphicType Graphic;
    public int X;
    public int Y;
    public bool Mirror;
    public int FrontF1Width;
    public int FrontF2Width;
  }

  // Per-pose, transient normal-wall result. Never written to the layout asset
  // or pose store. This is the render-time assembly produced from map geometry.
  private readonly Dictionary<ViewportPiece, ResolvedNormalWallState>
      resolvedNormalWallByPiece =
          new Dictionary<ViewportPiece, ResolvedNormalWallState>();

  // ViewEdit-only normal-wall Mirror overrides. These exist only while the
  // current preview pose is stationary. They are never written to the layout
  // asset or pose store and are cleared on every pose/facing change.
  private readonly Dictionary<ViewportPiece, bool> previewMirrorOverrideByPiece =
      new Dictionary<ViewportPiece, bool>();

  // ViewEdit-only FrontF1 width overrides. Like the Mirror test, these exist
  // only while the current X/Y/Facing is unchanged and are never persisted.
  private readonly Dictionary<ViewportPiece, int> previewFrontF1WidthOverrideByPiece =
      new Dictionary<ViewportPiece, int>();

  // ViewEdit-only FrontF3 width override. FrontF3 is normally rendered by the
  // V17 D3 lane compositor, so this is deliberately a temporary inspection
  // control: touching Width draws exactly that many pixels from the full
  // FrontF3 source at the live FrontF3 destination for the stationary pose.
  private readonly Dictionary<ViewportPiece, int> previewFrontF3WidthOverrideByPiece =
      new Dictionary<ViewportPiece, int>();

  // ViewEdit-only normal-wall X/Y overrides. Like the temporary Mirror test,
  // these affect only the stationary preview pose and are discarded whenever
  // X/Y/Facing changes. They are never written to the layout asset/pose store.
  private readonly Dictionary<ViewportPiece, Vector2Int> previewPositionOverrideByPiece =
      new Dictionary<ViewportPiece, Vector2Int>();
  // Snapshot of the automatic/code Ref X/Y shown when the user first edits
  // a piece at the current pose. Manual X/Y changes must never move Ref X/Y.
  // Values are display/top-origin coordinates and are cleared on pose change.
  private readonly Dictionary<ViewportPiece, Vector2Int> previewPositionReferenceByPiece =
      new Dictionary<ViewportPiece, Vector2Int>();

  // ViewEdit-only Enabled override for exception pieces. This lets the user hide
  // an automatically active exception without fighting the exception rule.
  private readonly Dictionary<ViewportPiece, bool> previewEnabledOverrideByPiece =
      new Dictionary<ViewportPiece, bool>();
  private readonly Dictionary<ViewportPiece, DungeonGraphicType>
      previewGraphicOverrideByPiece =
          new Dictionary<ViewportPiece, DungeonGraphicType>();
  private bool previewMirrorChangedThisFrame;
  private bool previewFrontF1WidthChangedThisFrame;
  private bool previewFrontF3WidthChangedThisFrame;
  private bool previewPositionChangedThisFrame;
  private bool previewEnabledChangedThisFrame;
  private bool previewGraphicChangedThisFrame;

  private struct ResolvedNormalWallState
  {
    public bool Enabled;
    public DungeonGraphicType Graphic;
    public int X;
    public int Y;
    public bool Mirror;
    public int FrontF1Width;
    public int FrontF2Width;
    public int FrontF3Width;
  }

  // Temporary 320×200 presentation (restored on close / Play Mode).
  private bool presentationOverrideActive;
  private bool canvasScalerStateSaved;
  private CanvasScaler.ScaleMode savedScalerMode;
  private float savedScalerScaleFactor;
  private Vector2 savedScalerReferenceResolution;
  private float savedScalerMatchWidthOrHeight;
  private bool viewportRectSaved;
  private RectTransformSnapshot savedViewportRect;
  private bool gameplayRootRectSaved;
  private RectTransformSnapshot savedGameplayRootRect;
  private RectTransform cachedGameplayRoot;

  private Image cachedMovementArrows;
  private bool movementArrowsStateSaved;
  private bool savedMovementArrowsActive;
  private Transform savedMovementArrowsParent;
  private int savedMovementArrowsSiblingIndex;
  private RectTransformSnapshot savedMovementArrowsRect;
  private bool savedMovementArrowsPreserveAspect;
  private FilterMode savedMovementArrowsFilterMode;
  private bool movementArrowsFilterSaved;
  private Texture savedMovementArrowsFilterTexture;

  private struct RectTransformSnapshot
  {
    public Vector2 AnchorMin;
    public Vector2 AnchorMax;
    public Vector2 Pivot;
    public Vector2 AnchoredPosition;
    public Vector2 SizeDelta;
    public Vector3 LocalScale;
    public Quaternion LocalRotation;
    public Vector2 OffsetMin;
    public Vector2 OffsetMax;

    public static RectTransformSnapshot Capture(RectTransform rect)
    {
      return new RectTransformSnapshot
      {
        AnchorMin = rect.anchorMin,
        AnchorMax = rect.anchorMax,
        Pivot = rect.pivot,
        AnchoredPosition = rect.anchoredPosition,
        SizeDelta = rect.sizeDelta,
        LocalScale = rect.localScale,
        LocalRotation = rect.localRotation,
        OffsetMin = rect.offsetMin,
        OffsetMax = rect.offsetMax
      };
    }

    public void Apply(RectTransform rect)
    {
      rect.localRotation = LocalRotation;
      rect.localScale = LocalScale;
      rect.anchorMin = AnchorMin;
      rect.anchorMax = AnchorMax;
      rect.pivot = Pivot;
      rect.anchoredPosition = AnchoredPosition;
      rect.sizeDelta = SizeDelta;
      // Stretch layouts need offsets restored after sizeDelta.
      if (AnchorMin != AnchorMax)
      {
        rect.offsetMin = OffsetMin;
        rect.offsetMax = OffsetMax;
      }
    }
  }

  [MenuItem("Tools/ViewEdit &v")]
  public static void Open()
  {
    EditorWindow inspector = FindInspectorWindow();
    OpenCoveringInspector(inspector != null ? inspector.position : default);
  }

  /// <summary>
  /// Open ViewEdit over the Inspector, only as wide as the widest row.
  /// GetWindow restores the last saved rect, which is the full 1920x1080
  /// display, so the content width is applied again after Unity shows it.
  /// </summary>
  private static void OpenCoveringInspector(Rect inspectorRect)
  {
    if (inspectorRect.width < 1f || inspectorRect.height < 1f)
    {
      EditorWindow inspector = FindInspectorWindow();
      if (inspector != null)
        inspectorRect = inspector.position;
    }

    if (inspectorRect.width < 1f || inspectorRect.height < 1f)
      inspectorRect = new Rect(80f, 80f, 420f, 640f);

    ViewportLayoutEditor window =
        GetWindow<ViewportLayoutEditor>("ViewEdit");
    window.fitWidthToContent = true;
    window.fittedContentRight = 0f;
    Rect contentRect = ContentRectOverInspector(window, inspectorRect);
    CoverInspector(window, contentRect);

    Rect capturedInspector = inspectorRect;
    EditorApplication.delayCall += () =>
    {
      if (window == null)
        return;

      Rect again = ContentRectOverInspector(window, capturedInspector);
      CoverInspector(window, again);
      EditorApplication.delayCall += () =>
      {
        if (window == null)
          return;

        CoverInspector(window, ContentRectOverInspector(window, capturedInspector));
      };
    };
  }

  /// <summary>
  /// Keep the Inspector's vertical span. Horizontally, fit the widest
  /// ViewEdit row and right-align to the Inspector so the game view is not
  /// resized to 1920.
  /// </summary>
  private static Rect ContentRectOverInspector(
      ViewportLayoutEditor window,
      Rect inspectorRect)
  {
    float width = window != null
        ? window.MeasureViewEditContentWidth()
        : 560f;
    float x = inspectorRect.xMax - width;
    if (x < 0f)
      x = inspectorRect.x;

    // ViewEdit always spans the full monitor height: top Y = 0 and the
    // bottom edge at the monitor maximum. Keep only the fitted content width.
    return new Rect(x, 0f, width, GetViewEditMonitorHeight());
  }

  /// <summary>
  /// Return the real desktop-monitor height used by a floating Unity editor
  /// window. Screen.currentResolution is intentionally not used here: inside
  /// the editor it can describe the Game display / a scaled resolution and can
  /// therefore leave ViewEdit short of the physical monitor bottom.
  /// </summary>
  private static float GetViewEditMonitorHeight()
  {
#if UNITY_EDITOR_WIN
    // Unity editor windows use desktop screen coordinates on Windows. Query the
    // monitor containing the centre of ViewEdit and use the monitor rectangle,
    // not the work area, so Y=0 + height reaches the true bottom of the screen.
    ViewportLayoutEditor existing = FindOpenViewEditWindow();

    Rect r = existing != null ? existing.position : new Rect(0f, 0f, 1f, 1f);
    POINT pt = new POINT
    {
      x = Mathf.RoundToInt(r.x + Mathf.Max(1f, r.width) * 0.5f),
      y = Mathf.RoundToInt(r.y + Mathf.Max(1f, r.height) * 0.5f)
    };

    System.IntPtr monitor = MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST);
    if (monitor != System.IntPtr.Zero)
    {
      MONITORINFO info = new MONITORINFO();
      info.cbSize = Marshal.SizeOf(typeof(MONITORINFO));
      if (GetMonitorInfo(monitor, ref info))
      {
        int monitorHeight = info.rcMonitor.bottom - info.rcMonitor.top;
        if (monitorHeight > 0)
          return monitorHeight;
      }
    }

    int systemHeight = GetSystemMetrics(SM_CYSCREEN);
    if (systemHeight > 0)
      return systemHeight;
#endif

    if (Screen.currentResolution.height > 0)
      return Screen.currentResolution.height;

    ViewportLayoutEditor fallback = FindOpenViewEditWindow();
    if (fallback != null && fallback.position.height > 1f)
      return fallback.position.height;

    return 1080f;
  }

#if UNITY_EDITOR_WIN
  private const uint MONITOR_DEFAULTTONEAREST = 2;
  private const int SM_CYSCREEN = 1;

  [StructLayout(LayoutKind.Sequential)]
  private struct POINT
  {
    public int x;
    public int y;
  }

  [StructLayout(LayoutKind.Sequential)]
  private struct RECT
  {
    public int left;
    public int top;
    public int right;
    public int bottom;
  }

  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
  private struct MONITORINFO
  {
    public int cbSize;
    public RECT rcMonitor;
    public RECT rcWork;
    public uint dwFlags;
  }

  [DllImport("user32.dll")]
  private static extern System.IntPtr MonitorFromPoint(
      POINT pt, uint dwFlags);

  [DllImport("user32.dll", CharSet = CharSet.Auto)]
  [return: MarshalAs(UnmanagedType.Bool)]
  private static extern bool GetMonitorInfo(
      System.IntPtr hMonitor, ref MONITORINFO lpmi);

  [DllImport("user32.dll")]
  private static extern int GetSystemMetrics(int nIndex);
#endif

  /// <summary>
  /// Width of the widest fixed ViewEdit row, including the minimap and the
  /// help-box padding around a piece card. Rows use fixed control widths, so
  /// this is the window width that shows every control without a horizontal
  /// scrollbar.
  /// </summary>
  private float MeasureViewEditContentWidth()
  {
    float enabledWidth =
        EditorStyles.label.CalcSize(new GUIContent("Enabled")).x + 18f;
    float mirrorWidth =
        EditorStyles.label.CalcSize(new GUIContent("Mirror")).x + 18f;

    // Black Door frame header: 180 name + 135 graphic + Enabled + Mirror.
    float frameHeader =
        180f + 135f + enabledWidth + 10f + mirrorWidth + 10f;

    // FrontF1 row: Width popup + X stepper + Y stepper + Ref.
    const float StepperWidth = 12f + 36f + 36f + 36f;
    float frontF1Row =
        38f + 52f + 4f + StepperWidth + StepperWidth + 10f + 125f;

    // Second Snap toolbar: All Walls, algorithm toggle, L1–L6.
    float toolbarRow = 90f + 8f + 140f + 8f + 174f;

    float featureRow = 48f + 48f + 210f + enabledWidth;

    float mapWidth = 0f;
    if (previewMiniMap != null && !previewMiniMapMuted)
      mapWidth = 18f + previewMiniMap.Width * 14f;

    float content = Mathf.Max(
        frameHeader,
        frontF1Row,
        toolbarRow,
        featureRow,
        mapWidth);

    RectOffset helpPad = EditorStyles.helpBox.padding;
    RectOffset helpMargin = EditorStyles.helpBox.margin;
    // Help-box chrome, gaps between fixed-width controls, and the vertical
    // scrollbar that appears once the piece list is taller than the window.
    float chrome = helpPad.left + helpPad.right
        + helpMargin.left + helpMargin.right
        + 40f
        + 16f;
    return content + chrome - 50f;
  }

  private void NoteContentRight()
  {
    if (Event.current == null)
      return;

    NoteContentRight(GUILayoutUtility.GetLastRect());
  }

  /// <summary>
  /// Record the right edge of a fixed-width control. Expanded groups report
  /// the whole window, which is the empty area that should not set the width.
  /// </summary>
  private void NoteContentRight(Rect rect)
  {
    if (!fitWidthToContent
        || Event.current == null
        || Event.current.type != EventType.Repaint)
    {
      return;
    }

    if (rect.width < 1f || rect.xMax < 1f)
      return;

    if (rect.xMax >= position.width - 4f && rect.width > position.width * 0.85f)
      return;

    if (rect.xMax > fittedContentRight)
      fittedContentRight = rect.xMax;
  }

  private void FinishContentWidthFit()
  {
    if (!fitWidthToContent
        || Event.current == null
        || Event.current.type != EventType.Repaint
        || fittedContentRight < 100f)
    {
      return;
    }

    fitWidthToContent = false;
    float contentRight = fittedContentRight;
    EditorApplication.delayCall += () => ApplyFittedContentWidth(contentRight);
  }

  private void ApplyFittedContentWidth(float contentRight)
  {
    if (this == null)
      return;

    float pad = EditorStyles.helpBox.padding.right
        + EditorStyles.helpBox.margin.right
        + 8f;
    float width = Mathf.Ceil(contentRight + pad) - 50f;
    Rect current = position;
    if (width < 1f || Mathf.Abs(current.width - width) < 2f)
      return;

    if (maximized)
      maximized = false;

    if (minSize.x > width)
      minSize = new Vector2(width, Mathf.Min(minSize.y, current.height));

    position = new Rect(current.x, current.y, width, current.height);
  }

  private static void CoverInspector(EditorWindow window, Rect inspectorRect)
  {
    if (window == null || inspectorRect.width < 1f || inspectorRect.height < 1f)
      return;

    UndockIfShared(window);

    if (window.maximized)
      window.maximized = false;

    Vector2 min = window.minSize;
    if (min.x > inspectorRect.width || min.y > inspectorRect.height)
    {
      window.minSize = new Vector2(
          Mathf.Min(min.x, inspectorRect.width),
          Mathf.Min(min.y, inspectorRect.height));
    }

    window.position = inspectorRect;
    window.Focus();
  }

  /// <summary>
  /// A pane shared with other tabs must be pulled out before its rect is set,
  /// otherwise the position write resizes that whole dock.
  /// </summary>
  private static void UndockIfShared(EditorWindow window)
  {
    object parent = GetEditorWindowParent(window);
    if (parent == null)
      return;

    BindingFlags flags =
        BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
    FieldInfo panesField = parent.GetType().GetField("m_Panes", flags);
    System.Collections.IList panes = panesField != null
        ? panesField.GetValue(parent) as System.Collections.IList
        : null;
    if (panes == null || panes.Count <= 1)
      return;

    MethodInfo removeTab = parent.GetType().GetMethod(
        "RemoveTab",
        flags,
        null,
        new System.Type[] { typeof(EditorWindow), typeof(bool) },
        null);
    if (removeTab == null)
      return;

    removeTab.Invoke(parent, new object[] { window, true });
    window.Show();
  }

  private static object GetEditorWindowParent(EditorWindow window)
  {
    if (window == null)
      return null;

    FieldInfo parentField = typeof(EditorWindow).GetField(
        "m_Parent",
        BindingFlags.Instance | BindingFlags.NonPublic);
    if (parentField == null)
      return null;

    return parentField.GetValue(window);
  }

  private static EditorWindow FindInspectorWindow()
  {
    if (IsInspectorWindow(mouseOverWindow))
      return mouseOverWindow;

    EditorWindow[] windows = Resources.FindObjectsOfTypeAll<EditorWindow>();
    EditorWindow fallback = null;
    for (int i = 0; i < windows.Length; ++i)
    {
      EditorWindow candidate = windows[i];
      if (!IsInspectorWindow(candidate))
        continue;

      if (candidate.hasFocus)
        return candidate;

      if (fallback == null)
        fallback = candidate;
    }

    return fallback;
  }

  private static bool IsInspectorWindow(EditorWindow window)
  {
    return window != null
        && window.GetType().FullName == "UnityEditor.InspectorWindow";
  }

  [InitializeOnLoadMethod]
  private static void RegisterInspectorRightClickOpen()
  {
    EditorApplication.CallbackFunction handler = HandleInspectorRightClickOpen;
    RemoveViewEditGlobalEventHandler(handler);
    AddViewEditGlobalEventHandler(handler);

    // When ViewEdit and Dungeon Features are both open, a right-click anywhere
    // inside the Dungeon Features editor closes Dungeon Features.  Keep this
    // in ViewportLayoutEditor.cs so no DungeonFeatureEditor source change is
    // required.
    EditorApplication.CallbackFunction closeDungeonFeaturesHandler =
        HandleDungeonFeaturesRightClickClose;
    RemoveViewEditGlobalEventHandler(closeDungeonFeaturesHandler);
    AddViewEditGlobalEventHandler(closeDungeonFeaturesHandler);
  }

  private static void HandleDungeonFeaturesRightClickClose()
  {
    TryCloseDungeonFeaturesUnderMouse();
  }

  /// <summary>
  /// Close Dungeon Features when a right-click's screen position lies inside
  /// that window's screen rectangle. The event may be delivered to ViewEdit
  /// when ViewEdit overlaps Dungeon Features, so the test uses screen space
  /// rather than which pane received the event.
  /// </summary>
  private static bool TryCloseDungeonFeaturesUnderMouse()
  {
    if (!HasOpenInstances<ViewportLayoutEditor>())
      return false;

    Event current = Event.current;
    if (current == null)
      return false;

    // Unity can turn the RMB event into ContextClick before a later handler
    // sees it. rawType keeps the original mouse event. ContextClick does not
    // always report button 1.
    bool rightClick =
        ((current.type == EventType.MouseDown
            || current.rawType == EventType.MouseDown)
            && current.button == 1)
        || current.type == EventType.ContextClick
        || current.rawType == EventType.ContextClick;
    if (!rightClick)
      return false;

    Vector2 screenMouse = GUIUtility.GUIToScreenPoint(current.mousePosition);

    EditorWindow dungeonFeatures = null;
    EditorWindow[] windows = Resources.FindObjectsOfTypeAll<EditorWindow>();
    for (int i = 0; i < windows.Length; ++i)
    {
      EditorWindow candidate = windows[i];
      if (!IsDungeonFeaturesWindow(candidate))
        continue;

      if (candidate.position.Contains(screenMouse))
      {
        dungeonFeatures = candidate;
        break;
      }
    }

    if (dungeonFeatures == null)
      return false;

    current.Use();
    EditorWindow windowToClose = dungeonFeatures;
    EditorApplication.delayCall += () =>
    {
      if (windowToClose != null)
        windowToClose.Close();
    };
    return true;
  }

  private static bool IsDungeonFeaturesWindow(EditorWindow window)
  {
    if (window == null)
      return false;

    string typeName = window.GetType().Name;
    string title = window.titleContent != null
        ? window.titleContent.text
        : string.Empty;

    return string.Equals(typeName, "DungeonFeatureEditor",
               System.StringComparison.Ordinal)
        || typeName.IndexOf("DungeonFeature",
               System.StringComparison.OrdinalIgnoreCase) >= 0
        || string.Equals(title, "Dungeon Features",
               System.StringComparison.Ordinal);
  }

  private static void HandleInspectorRightClickOpen()
  {
    Event current = Event.current;
    if (current == null
        || current.type != EventType.MouseDown
        || current.button != 1)
    {
      return;
    }

    EditorWindow hovered = mouseOverWindow;
    if (!IsInspectorWindow(hovered))
      return;

    current.Use();
    OpenCoveringInspector(hovered.position);
  }

  private void ReapplyCurrentPoseToWallRendererAfterReload()
  {
    if (this == null || Application.isPlaying)
      return;

    // A script/domain reload must return the current saved X/Y/Facing to the
    // automatic wall renderer, never to a temporary Hide Walls / manual test.
    previewEnabledOverrideByPiece.Clear();
    previewMirrorOverrideByPiece.Clear();
    previewPositionOverrideByPiece.Clear();
    previewFrontF1WidthOverrideByPiece.Clear();
    previewFrontF3WidthOverrideByPiece.Clear();
    previewGraphicOverrideByPiece.Clear();
    previewDisableAllWalls = false;
    dynamicGeometrySignatureInitialized = false;

    showOnlyWallsNeededForCurrentPose = true;
    showWallsActivFilter = true;

    ReloadLayoutFromDisk();
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap != null)
      previewMiniMap.SetPlayerPose(previewX, previewY, previewFacing);

    CaptureNormalWallBaselinesFromLayout();
    ApplyCurrentPoseVisibilityToLayout();

    ResetEditModeViewportLogCache();
    DestroyEditModePreviewTextureOnly();
    RefreshEditModePreview();
    RepaintGameViews();
    Repaint();
  }

  private void OnEnable()
  {
    titleContent = new GUIContent("ViewEdit");
    wantsMouseMove = true;

    RestorePersistedAssets();
    ReloadLayoutFromDisk();
    RestoreSessionPrefs();
    showOnlyWallsNeededForCurrentPose = true;
    showWallsActivFilter = true;
    StripObsoleteFrontWallF1ABPieces();
    EnsureLeftS3AndRightS3Pieces();
    CaptureNormalWallBaselinesFromLayout();
    ApplyCurrentPoseVisibilityToLayout();
    EditorApplication.playModeStateChanged += HandlePlayModeStateChanged;
    // Force a fresh compose from the current pose's Enabled flags.
    DestroyEditModePreviewTextureOnly();
    RefreshEditModePreview();

    // Domain reload can invoke OnEnable before the editor hierarchy/assets are
    // fully restored. Re-run the CURRENT saved pose one editor tick later so
    // the wall renderer is always authoritative after code changes.
    EditorApplication.delayCall -= ReapplyCurrentPoseToWallRendererAfterReload;
    EditorApplication.delayCall += ReapplyCurrentPoseToWallRendererAfterReload;

    if (!hookedViewEditGlobalNavigation)
    {
      RegisterViewEditGlobalNavigation();
      hookedViewEditGlobalNavigation = true;
    }
  }

  private void OnDisable()
  {
    EditorApplication.delayCall -= ReapplyCurrentPoseToWallRendererAfterReload;

    if (hookedViewEditGlobalNavigation)
    {
      UnregisterViewEditGlobalNavigation();
      hookedViewEditGlobalNavigation = false;
    }
    StripObsoleteFrontWallF1ABPieces();
    SaveAssetGuid(PrefsLayoutGuidKey, layout);
    SaveAssetGuid(PrefsGraphicsGuidKey, graphics);
    SaveSessionPrefs();

    EditorApplication.playModeStateChanged -= HandlePlayModeStateChanged;

    if (cachedNativeFrontF2ReadableCopy != null)
    {
      DestroyImmediate(cachedNativeFrontF2ReadableCopy);
      cachedNativeFrontF2ReadableCopy = null;
    }

    if (cachedNativeFrontF3ReadableCopy != null)
    {
      DestroyImmediate(cachedNativeFrontF3ReadableCopy);
      cachedNativeFrontF3ReadableCopy = null;
    }

    if (cachedRight2SReadableCopy != null)
    {
      DestroyImmediate(cachedRight2SReadableCopy);
      cachedRight2SReadableCopy = null;
    }

    if (cachedViAltarGeneratedF2TestTexture != null)
    {
      DestroyImmediate(cachedViAltarGeneratedF2TestTexture);
      cachedViAltarGeneratedF2TestTexture = null;
    }
    if (cachedViAltarGeneratedF3TestTexture != null)
    {
      DestroyImmediate(cachedViAltarGeneratedF3TestTexture);
      cachedViAltarGeneratedF3TestTexture = null;
    }
    if (cachedViAltarEngineF2TestTexture != null)
    {
      DestroyImmediate(cachedViAltarEngineF2TestTexture);
      cachedViAltarEngineF2TestTexture = null;
    }
    if (cachedViAltarEngineF3TestTexture != null)
    {
      DestroyImmediate(cachedViAltarEngineF3TestTexture);
      cachedViAltarEngineF3TestTexture = null;
    }
    cachedViAltarS2Texture = null;
    cachedViAltarS3Texture = null;

    RepaintGameViews();
  }

  private void HandlePlayModeStateChanged(PlayModeStateChange state)
  {
    cachedViewportImage = null;

    if (state == PlayModeStateChange.ExitingEditMode
        || state == PlayModeStateChange.EnteredPlayMode)
    {
      // Hand the RawImage back to the scene RenderTexture before Play runs.
      RestoreViewportTextureAndDestroyPreview();
    }

    if (state == PlayModeStateChange.EnteredPlayMode)
    {
      // In Play Mode, ViewEdit becomes a live "what is actually active" wall view.
      // Clear list filters and show only wall pieces whose runtime Enabled flag is on.
      showOnlyWallsNeededForCurrentPose = true;
      pieceSearchFamilyIndex = 0;
      pieceSearchText = string.Empty;

      // Request a one-shot scroll-to-bottom after the Play Mode UI has
      // completed a real repaint. Setting the scroll position only here is too
      // early because Unity has not calculated the final content height yet.
      scrollToBottomOnNextRepaint = true;
      editorScroll = new Vector2(0f, float.MaxValue);

      Repaint();
    }

    if (state == PlayModeStateChange.EnteredEditMode)
    {
      // Re-apply preview pose after Play mutated live layout Enabled flags.
      StripObsoleteFrontWallF1ABPieces();
      ApplyCurrentPoseVisibilityToLayout();
      RefreshEditModePreview();
    }

    if (state == PlayModeStateChange.ExitingPlayMode)
      RepaintGameViews();
  }

  private void RefreshViewEditIfDynamicGeometryChanged()
  {
    if (Application.isPlaying)
      return;

    bool stairsDownRightD1Active =
        IsStairsDownRightD1ForCurrentPose();

    if (dynamicGeometrySignatureInitialized
        && cachedStairsDownRightD1Active == stairsDownRightD1Active)
    {
      return;
    }

    dynamicGeometrySignatureInitialized = true;
    cachedStairsDownRightD1Active = stairsDownRightD1Active;

    // Rebuild the wall visibility/list and the 320x200 preview from the same
    // current renderer state. This is especially important after recompiles:
    // the pose did not change, so the normal pose-change refresh would never
    // run and ViewEdit could otherwise keep stale RightF0 geometry.
    ApplyCurrentPoseVisibilityToLayout();
    ResetEditModeViewportLogCache();
    DestroyEditModePreviewTextureOnly();
    RefreshEditModePreview();
    RepaintGameViews();
    Repaint();
  }

  private void OnInspectorUpdate()
  {
    if (Application.isPlaying)
    {
      Repaint();
      return;
    }

    RefreshViewEditIfDynamicGeometryChanged();

    // Dungeon Features shares level/X/Y/facing through EditorPrefs. Apply a
    // requested level first so the following pose sync runs against the correct
    // map instead of the map from the previous level.
    int requestedLevel = Mathf.Clamp(
        EditorPrefs.GetInt(PrefsPreviewLevelKey, previewDungeonLevel),
        0,
        PreviewLevelMapPaths.Length - 1);
    if (requestedLevel != previewDungeonLevel)
    {
      previewLevelJumpText = requestedLevel.ToString();
      TryJumpToPreviewLevelFromField();
    }

    // Dungeon Features uses the existing preview X/Y EditorPrefs as a small
    // editor-to-editor bridge. If another editor requests a different tile,
    // apply it through the normal ViewEdit pose path so all geometry, walls,
    // preview texture, and per-pose state are refreshed exactly as usual.
    int requestedX = EditorPrefs.GetInt(PrefsPreviewXKey, previewX);
    int requestedY = EditorPrefs.GetInt(PrefsPreviewYKey, previewY);
    DungeonFacing requestedFacing = (DungeonFacing)EditorPrefs.GetInt(
        PrefsPreviewFacingKey,
        (int)previewFacing);

    if (requestedX != previewX
        || requestedY != previewY
        || requestedFacing != previewFacing)
    {
      SwitchPreviewPose(
          requestedX,
          requestedY,
          requestedFacing);

      // SwitchPreviewPose refuses non-enterable cells. In that case restore
      // the shared prefs to the real ViewEdit pose so Dungeon Features snaps
      // back to the valid highlighted tile instead of drifting out of sync.
      if (previewX != requestedX
          || previewY != requestedY
          || previewFacing != requestedFacing)
      {
        SaveSessionPrefs();
      }
    }
  }

  /// <summary>
  /// Pressing the rear thumb/side mouse button (XButton1 / IMGUI button 3)
  /// anywhere in ViewEdit opens Dungeon Features and maximizes that editor
  /// window. The previous left-button double-click shortcut is intentionally
  /// disabled.
  /// </summary>
  private bool HandleViewEditRearMouseButton()
  {
    Event current = Event.current;
    if (current == null
        || current.type != EventType.MouseDown
        || current.button != 3)
    {
      return false;
    }

    current.Use();
    EditorApplication.delayCall += OpenDungeonFeaturesMaximized;
    return true;
  }

  private static void OpenDungeonFeaturesMaximized()
  {
    DungeonFeatureEditor.Open();

    // DungeonFeatureEditor.Open may create/show the window at the end of this
    // editor update. Maximize it on the next update after Unity has attached
    // the new window to its host view.
    EditorApplication.delayCall += MaximizeDungeonFeaturesWindow;
  }

  private static void MaximizeDungeonFeaturesWindow()
  {
    EditorWindow[] windows = Resources.FindObjectsOfTypeAll<EditorWindow>();
    for (int i = 0; i < windows.Length; ++i)
    {
      EditorWindow candidate = windows[i];
      if (!IsDungeonFeaturesWindow(candidate))
        continue;

      candidate.Focus();
      if (!candidate.maximized)
        candidate.maximized = true;
      return;
    }
  }

  /// <summary>
  /// Right-clicking anywhere inside ViewEdit toggles the minimap on/off.
  /// </summary>
  private bool HandleViewEditRightClick()
  {
    Event current = Event.current;
    if (current == null
        || current.type != EventType.MouseDown
        || current.button != 1)
    {
      return false;
    }

    previewMiniMapMuted = !previewMiniMapMuted;
    current.Use();
    Repaint();
    return true;
  }

  private void OnGUI()
  {
    // Keep ViewEdit pinned to the full monitor height even if Unity restores an
    // older floating-window position or the user drags/resizes the window.
    // Top is always Y=0 and bottom is always the monitor maximum.
    Rect currentWindowRect = position;
    float monitorHeight = GetViewEditMonitorHeight();
    if (!maximized
        && (Mathf.Abs(currentWindowRect.y) > 0.01f
            || Mathf.Abs(currentWindowRect.height - monitorHeight) > 0.5f))
      position = new Rect(
          currentWindowRect.x,
          0f,
          currentWindowRect.width,
          monitorHeight);

    if (HandleViewEditRearMouseButton())
      return;

    if (HandleViewEditRightClick())
      return;

    selectionChangedThisFrame = false;

    if (Application.isPlaying
        && (previewX != lastPlayModeScrollX
            || previewY != lastPlayModeScrollY
            || previewFacing != lastPlayModeScrollFacing))
    {
      lastPlayModeScrollX = previewX;
      lastPlayModeScrollY = previewY;
      lastPlayModeScrollFacing = previewFacing;
      scrollToBottomOnNextRepaint = true;
    }

    // Claim EditorWindow focus on click so existing keyboard nav can run.
    // Do not clear GUI.FocusControl here — a TextField/IntField on this
    // same MouseDown still needs to receive it.
    if (Event.current.type == EventType.MouseDown && Event.current.button == 0)
      Focus();

    // Arrow Up/Down must be handled before BeginScrollView — otherwise the
    // scroll view consumes them for scrolling and HandlePreviewMoveKeyboard
    // never sees a usable KeyDown (Left/Right strafe is unaffected).
    // Facing keys run here too so EnumPopup cannot override the same KeyDown.
    if (layout != null && !Application.isPlaying)
    {
      HandlePreviewMoveKeyboard();
      HandlePreviewFacingKeyboard();
      HandlePreviewStrafeKeyboard();
    }

    if (layout == null)
    {
      EditorGUILayout.HelpBox("Select a ViewportLayout asset.", MessageType.Info);
      return;
    }

    if (graphics == null)
    {
      EditorGUILayout.HelpBox(
          "Select a DungeonGraphics asset (textures for the Edit Mode preview).",
          MessageType.Warning);
    }

    bool layoutEditable = !Application.isPlaying;
    if (!layoutEditable)
    {
      EditorGUILayout.HelpBox(
          "ViewportLayout.asset is read-only in Play Mode. "
              + "Stop Play to edit and save layout coordinates/visibility.",
          MessageType.Warning);
    }

    ClampSelectedPieceIndex();

    // Keep the complete minimap outside the controls scroll area. The map is
    // always visible as one fixed ViewEdit header; only the wall/feature rows
    // below it scroll when the window eventually needs more vertical room.
    if (fitWidthToContent && Event.current.type == EventType.Repaint)
      fittedContentRight = 0f;

    DrawMapPosePreviewControls();

    editorScroll = EditorGUILayout.BeginScrollView(editorScroll);

    // Run the global ViewEdit right-click action only after DrawPreviewMiniMap
    // has had a chance to consume a right-click inside the minimap. This keeps
    // the existing "right-click anywhere else -> Search/top" behavior without
    // overruling the minimap mute toggle.
    HandleViewEditRightClickHome();

    using (new EditorGUI.DisabledScope(!layoutEditable))
    {
      EditorGUI.BeginChangeCheck();

      if (layoutEditable)
        Undo.RecordObject(layout, "Viewport Layout Change");

      DrawSnapToolbar();

      string currentFrontChampion;
      if (TryGetCurrentD1FrontChampion(out currentFrontChampion))
      {
        string currentChampionKey = NormalizeChampionAssetKey(currentFrontChampion);
        bool taken = previewTakenChampionKeys.Contains(currentChampionKey);

        EditorGUILayout.BeginHorizontal();
        GUILayout.Space(4f);
        GUILayout.Label("Champion Mirror", EditorStyles.miniLabel, GUILayout.Width(96f));
        bool newTaken = GUILayout.Toggle(
            taken,
            currentFrontChampion + " Taken",
            EditorStyles.miniButton,
            GUILayout.Width(130f));
        if (newTaken != taken)
        {
          if (newTaken)
            previewTakenChampionKeys.Add(currentChampionKey);
          else
            previewTakenChampionKeys.Remove(currentChampionKey);

          RefreshEditModePreview();
          RepaintGameViews();
          Repaint();
        }
        EditorGUILayout.EndHorizontal();
      }

      EditorGUILayout.BeginHorizontal();
      EditorGUILayout.PrefixLabel(
          "Search Pieces",
          EditorStyles.popup,
          GetSearchPiecesLabelStyle());

      GUIStyle searchPoseStyle = new GUIStyle(EditorStyles.boldLabel);
      Color brightBlue = new Color(0.2f, 0.7f, 1.0f);
      searchPoseStyle.normal.textColor = brightBlue;
      searchPoseStyle.hover.textColor = brightBlue;
      searchPoseStyle.focused.textColor = brightBlue;
      searchPoseStyle.active.textColor = brightBlue;
      GUILayout.Label(
          previewX + "/" + previewY + " " + previewFacing,
          searchPoseStyle,
          GUILayout.Width(78f));

      bool guiChangedBeforeSearch = GUI.changed;
      Rect searchPiecesPopupRect = EditorGUILayout.GetControlRect(
          GUILayout.Width(135f),
          GUILayout.ExpandWidth(false));
      Event searchEvent = Event.current;
      if (searchEvent.type == EventType.MouseDown
          && searchEvent.button == 0
          && searchPiecesPopupRect.Contains(searchEvent.mousePosition))
      {
        openSearchPiecesPopup = true;
        focusSearchPieces = true;
      }
      GUI.SetNextControlName(SearchPiecesControlName);
      pieceSearchText = EditorGUI.TextField(
          searchPiecesPopupRect,
          pieceSearchText ?? string.Empty);
      if (focusSearchPieces && Event.current.type == EventType.Repaint)
      {
        GUI.FocusControl(SearchPiecesControlName);
        EditorGUI.FocusTextInControl(SearchPiecesControlName);
        focusSearchPieces = false;
      }
      // Search is a list filter only — never treat it as a layout persist.
      GUI.changed = guiChangedBeforeSearch;
      if (openSearchPiecesPopup && Event.current.type != EventType.Layout)
      {
        openSearchPiecesPopup = false;
        bool previousEnabled = GUI.enabled;
        GUI.enabled = true;
        ShowSearchPiecesFamilyMenu(searchPiecesPopupRect);
        GUI.enabled = previousEnabled;
      }

      EditorGUILayout.EndHorizontal();
      ClampSearchFamilyToEnabledPieces();
      HandlePieceSearchKeyboard();

      if (layoutEditable)
      {
        StripObsoleteFrontWallF1ABPieces();
        EnsureLeftS3AndRightS3Pieces();
      }

      bool changed = false;

      List<int> displayIndices = new List<int>();
      for (int i = 0; i < layout.Pieces.Count; i++)
      {
        ViewportPiece piece = layout.Pieces[i];
        if (IsHiddenFromEditorPieceList(piece))
          continue;

        if (!PieceMatchesSearchFilter(piece))
          continue;

        displayIndices.Add(i);
      }

      displayIndices.Sort(CompareViewEditPieceDisplayOrder);

      for (int n = 0; n < displayIndices.Count; n++)
      {
        int i = displayIndices[n];
        ViewportPiece piece = layout.Pieces[i];
        bool isSelected = i == selectedPieceIndex;
        DrawPieceCard(i, piece, isSelected, ref changed);
      }

      // Non-wall map features are always listed directly below the wall rows
      // for the current pose. X/Y come first and the temporary Enabled switch
      // stays on the far right, so ViewEdit can be used as a visual checklist.
      DrawCurrentPoseFeatureRows();

      bool editorChanged = EditorGUI.EndChangeCheck();
      if ((editorChanged || changed)
          && !previewMirrorChangedThisFrame
          && !previewFrontF1WidthChangedThisFrame
          && !previewFrontF3WidthChangedThisFrame
          && !previewPositionChangedThisFrame
          && !previewEnabledChangedThisFrame
          && !previewGraphicChangedThisFrame)
        PersistChanges();
      previewMirrorChangedThisFrame = false;
      previewFrontF1WidthChangedThisFrame = false;
      previewFrontF3WidthChangedThisFrame = false;
      previewPositionChangedThisFrame = false;
      previewEnabledChangedThisFrame = false;
      previewGraphicChangedThisFrame = false;
    }

    EditorGUILayout.EndScrollView();

    if (scrollToBottomOnNextRepaint
        && Event.current.type == EventType.Repaint)
    {
      editorScroll = new Vector2(0f, float.MaxValue);
      scrollToBottomOnNextRepaint = false;
      Repaint();
    }

    // Click on empty / non-control area: release leftover text-field focus
    // so keyboard nav works. Controls that consume MouseDown (TextField,
    // IntField, buttons) are left alone here.
    if (Event.current.type == EventType.MouseDown && Event.current.button == 0)
    {
      GUI.FocusControl(null);
      Focus();
    }

    if (selectionChangedThisFrame)
    {
      RefreshEditModePreview();
      Repaint();
    }

    FinishContentWidthFit();
  }

  /// <summary>
  /// Muted investigation pieces stay in the layout asset but are not listed.
  /// Disabled pieces for the current pose are also omitted from ViewEdit.
  /// </summary>
  private void EnsurePreviewStickyWallPose()
  {
    if (previewStickyPoseLevel == previewDungeonLevel
        && previewStickyPoseX == previewX
        && previewStickyPoseY == previewY
        && previewStickyPoseFacing == previewFacing)
    {
      return;
    }

    previewStickyVisibleWallFamilies.Clear();
    previewStickyPoseLevel = previewDungeonLevel;
    previewStickyPoseX = previewX;
    previewStickyPoseY = previewY;
    previewStickyPoseFacing = previewFacing;
  }

  private void KeepWallCardVisibleForCurrentPose(ViewportPiece piece)
  {
    if (piece == null)
      return;

    EnsurePreviewStickyWallPose();

    string family = GetViewport17NormalWallFamily(piece);
    if (string.IsNullOrEmpty(family))
      family = piece.Name ?? string.Empty;

    if (!string.IsNullOrEmpty(family))
      previewStickyVisibleWallFamilies.Add(family);
  }

  private bool IsWallCardStickyVisibleForCurrentPose(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    EnsurePreviewStickyWallPose();

    string family = GetViewport17NormalWallFamily(piece);
    if (string.IsNullOrEmpty(family))
      family = piece.Name ?? string.Empty;

    return !string.IsNullOrEmpty(family)
        && previewStickyVisibleWallFamilies.Contains(family);
  }

  private bool IsHiddenFromEditorPieceList(ViewportPiece piece)
  {
    if (piece == null || piece.Name == null)
      return false;

    // Permanent ViewEdit exclusions.
    if (piece.Name == "Front Wall F1"
        || piece.Name == "Ceiling"
        || piece.Name == "Floor"
        || piece.Graphic == DungeonGraphicType.Ceiling
        || piece.Graphic == DungeonGraphicType.Floor
        || piece.Name == "Movement Arrows"
        || piece.Graphic == DungeonGraphicType.MovementArrows
        || piece.Name == "Champion Status Slot 1"
        || piece.Name == "Champion Status Slot 2"
        || piece.Name == "Champion Status Slot 3"
        || piece.Name == "Champion Status Slot 4"
        || piece.Name == "Ceiling Strip 84"
        || piece.Name == "Ceiling Strip 85")
    {
      return true;
    }

    // Generic stairs-down rule: when the near-center relative cell is a
    // down-stair, FrontF2 is replaced by the stair opening and is not a
    // comparison card for this pose.
    if (IsViewport17NearCenterStairsDown()
        && (IsFrontWallF2Card(piece)
            || FrontWallF2Logic.IsFrontWallF2Graphic(piece.Graphic)))
    {
      return true;
    }

    // Black Door handling in ViewEdit:
    // - In normal/needed-only mode, show only Black Door pieces required by
    //   the current pose.
    // - In All Walls mode, expose the Black Door FRAME wall components so
    //   oblique/side scenes can be inspected and adjusted manually.
    // - Keep the solid BlackDoorF1/F2/F3 front images out of All Walls; they
    //   remain available only in their actual front-door poses.
    if (IsBlackDoorEditorPiece(piece))
    {
      bool blackDoorFrontImage = IsBlackDoorFrontImagePiece(piece);

      if (!showOnlyWallsNeededForCurrentPose)
      {
        if (blackDoorFrontImage)
          return true;
        // Frame components stay available in All Walls, including after a
        // temporary Enabled=OFF click at the current pose.
      }
      else if (!IsWallNeededForCurrentPose(piece))
      {
        return true;
      }
    }

    // Manual inspection cards may remain reachable only while the user is in
    // Show All Walls mode on the current pose. In the normal geometry-filtered
    // mode (including immediately after any pose change), disabled walls must
    // not leak into the ViewEdit list.
    if (!showOnlyWallsNeededForCurrentPose
        && (IsBlackDoorF1ManualSideWallCandidate(piece)
            || piece.Name == "LeftS3"))
      return false;

    if (showOnlyWallsNeededForCurrentPose
        && (IsWallEditorPiece(piece) || IsBlackDoorEditorPiece(piece)))
    {
      // Edit Mode: show walls required by the preview geometry.
      // Play Mode: show the walls the runtime renderer has actually enabled.
      bool wallIsActive =
          Application.isPlaying
          ? piece.Enabled
          : IsWallNeededForCurrentPose(piece);

      // Any temporary ViewEdit interaction with a piece must keep its card
      // visible for the rest of the current pose, even when Enabled was turned
      // OFF. The temporary override dictionaries are cleared on pose/facing
      // change, so the card naturally disappears/resets when leaving the pose.
      if (HasPreviewEnabledOverrideForPieceOrFamily(piece)
          || previewMirrorOverrideByPiece.ContainsKey(piece)
          || previewPositionOverrideByPiece.ContainsKey(piece)
          || IsWallCardStickyVisibleForCurrentPose(piece))
      {
        wallIsActive = true;
      }

      if (!wallIsActive)
        return true;
    }

    return false;
  }

  private void EnableAllWallsNeededForCurrentPose()
  {
    if (layout == null || layout.Pieces == null)
      return;

    Undo.RecordObject(layout, "Enable Walls Needed For Current Pose");

    bool changed = false;
    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null
          || (!IsWallEditorPiece(piece) && !IsBlackDoorEditorPiece(piece)))
        continue;

      bool needed = IsWallNeededForCurrentPose(piece);
      if (needed && !piece.Enabled)
      {
        piece.Enabled = true;
        changed = true;
      }
    }

    if (!changed)
      return;

    EditorUtility.SetDirty(layout);

    RefreshEditModePreview();
  }

  private static bool IsWallEditorPiece(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    if (IsWallF0LeftPiece(piece)
        || IsWallF0RightPiece(piece)
        || IsWallF1LeftPiece(piece)
        || IsWallF1RightPiece(piece)
        || IsWallF2LeftPiece(piece)
        || IsWallF2RightPiece(piece)
        || IsWallF3LeftPiece(piece)
        || IsWallF3RightPiece(piece)
        || IsFrontWallF1Card(piece)
        || IsFrontWallF2Card(piece)
        || IsFrontWallF3Card(piece))
    {
      return true;
    }

    string name = piece.Name ?? string.Empty;
    return name == "LeftD3"
        || name == "RightD3"
        || name == "LeftS3"
        || name == "RightS3"
        || name == "Wall D3L2"
        || name == "Wall D3R2"
        || name == "Black Door Frame Left F1"
        || name == "Black Door Frame Right F1"
        || name == "Black Door Frame Left F2"
        || name == "Black Door Frame Right F2"
        || name == "BlackDoorF1";
  }

  private static bool IsBlackDoorFrontImagePiece(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    string name = piece.Name ?? string.Empty;
    return name == "BlackDoorF1"
        || name == "BlackDoorF2"
        || name == "BlackDoorF3";
  }

  private static bool IsBlackDoorEditorPiece(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    string name = piece.Name ?? string.Empty;
    return name == "BlackDoorF1"
        || name == "BlackDoorF2"
        || name == "BlackDoorF3"
        || name == "Black Door Frame Left F1"
        || name == "Black Door Frame Right F1"
        || name == "Black Door Frame Left F2"
        || name == "Black Door Frame Right F2"
        || name == "Black Door Frame Left F3"
        || name == "Black Door Frame Right F3";
  }

  private bool IsViewport17NearCenterStairsDown()
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null)
      return false;

    // Generic relative-cell rule: a down-stair directly ahead occupies the
    // D2 center opening. Map coordinates never participate in this decision.
    return SampleViewport17Cell(0, 1).IsStairsDown;
  }

  /// <summary>
  /// True only for the Hall of Champions special entrance Black Door.
  /// Regular Door tiles elsewhere must use their normal door renderer and must
  /// never activate the BlackDoorF1/F2/F3 family.
  /// </summary>
  private bool IsHallOfChampionsBlackDoorCell(Viewport17Cell cell)
  {
    return cell.IsInside
        && previewDungeonLevel == PreviewDungeonLevel
        && cell.MapX == HallOfChampionsBlackDoorX
        && cell.MapY == HallOfChampionsBlackDoorY
        && previewDoorTiles.Contains(new Vector2Int(cell.MapX, cell.MapY));
  }

  /// <summary>
  /// Player-relative center test for the special Black Door.
  /// Depth 1 = F1, 2 = F2, 3 = F3.
  /// </summary>
  private bool IsDoorAtViewportCenterDepth(int depth)
  {
    if (depth < 1)
      return false;

    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null)
      return false;

    return IsHallOfChampionsBlackDoorCell(SampleViewport17Cell(0, depth));
  }

  private bool IsDoorF1FrontView()
  {
    return IsDoorAtViewportCenterDepth(1);
  }

  private bool IsDoorF2FrontView()
  {
    return IsDoorAtViewportCenterDepth(2);
  }

  private bool IsDoorF3FrontView()
  {
    return IsDoorAtViewportCenterDepth(3);
  }

  /// <summary>
  /// Player-relative D3-right oblique test for the special Black Door.
  /// It occupies the cell one lane right and three cells forward.
  /// </summary>
  private bool IsDoorF3RightObliqueView()
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null)
      return false;

    return IsHallOfChampionsBlackDoorCell(SampleViewport17Cell(1, 3));
  }


  private bool IsWallNeededForCurrentPose(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    EnsurePreviewMiniMapLoaded();

    // If the minimap cannot be read, do not hide wall cards.
    if (previewMiniMap == null)
      return true;

    string name = piece.Name ?? string.Empty;
    bool doorAtF1 = IsDoorF1FrontView();
    bool doorAtF2 = IsDoorF2FrontView();
    bool doorAtF3 = IsDoorF3FrontView();

    // A door directly ahead occupies the F1 center opening, so the normal
    // FrontF2 wall behind it is not needed. Player-relative; no map coordinate.
    if (IsDoorF1FrontView()
        && (IsFrontWallF2Card(piece)
            || FrontWallF2Logic.IsFrontWallF2Graphic(piece.Graphic)))
    {
      return false;
    }

    // Generic stairs-down rule: a down-stair in the near-center relative
    // cell occupies the FrontF2 center band, so FrontF2 is not needed.
    if (IsViewport17NearCenterStairsDown()
        && (IsFrontWallF2Card(piece)
            || FrontWallF2Logic.IsFrontWallF2Graphic(piece.Graphic)))
    {
      return false;
    }

    // Black Door editor cards must be decided BEFORE the generic normal-wall
    // resolver. Some Black Door pieces are classified as normal wall pieces,
    // so the old ordering returned their resolved Enabled=false before these
    // dedicated door-pose rules were ever reached.
    if (IsBlackDoorEditorPiece(piece))
    {
      if (doorAtF1)
      {
        return name == "Black Door Frame Left F1"
            || name == "Black Door Frame Right F1"
            || name == "BlackDoorF1";
      }

      if (doorAtF2)
      {
        return name == "Black Door Frame Left F2"
            || name == "Black Door Frame Right F2"
            || name == "BlackDoorF2";
      }

      if (doorAtF3)
      {
        return name == "Black Door Frame Left F3"
            || name == "Black Door Frame Right F3"
            || name == "BlackDoorF3";
      }

      if (IsDoorF3RightObliqueView())
      {
        return name == "Black Door Frame Right F3"
            || name == "BlackDoorF3";
      }

      return false;
    }

    if (IsNormalWallPiece(piece)
        && TryGetResolvedNormalWallState(
            piece, out ResolvedNormalWallState resolvedNeededState))
    {
      return resolvedNeededState.Enabled;
    }

    // LeftS3 is a ViewEdit-only geometry piece, so it is not classified as a
    // normal wall. Use the same resolved strict-geometry state for the needed
    // walls filter instead of falling through to the default-visible path.
    if (name == "LeftS3")
    {
      if (TryGetResolvedNormalWallState(
              piece, out ResolvedNormalWallState leftS2NeededState))
      {
        return leftS2NeededState.Enabled;
      }

      return false;
    }

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    bool TileIsWallOrOutside(int x, int y)
    {
      return !previewMiniMap.IsInside(x, y)
          || previewMiniMap.GetTile(x, y).Type == DungeonTileType.Wall;
    }

    int f1X = previewX + forwardX;
    int f1Y = previewY + forwardY;
    int f2X = previewX + forwardX * 2;
    int f2Y = previewY + forwardY * 2;
    int f3X = previewX + forwardX * 3;
    int f3Y = previewY + forwardY * 3;

    bool f1CenterWall = TileIsWallOrOutside(f1X, f1Y);
    bool f2CenterWall = TileIsWallOrOutside(f2X, f2Y);
    bool f3CenterWall = TileIsWallOrOutside(f3X, f3Y);

    if (IsWallF0LeftPiece(piece))
      return TileIsWallOrOutside(previewX - rightX, previewY - rightY);

    if (IsWallF0RightPiece(piece))
      return TileIsWallOrOutside(previewX + rightX, previewY + rightY);

    if (IsWallF1LeftPiece(piece))
      return !f1CenterWall
          && TileIsWallOrOutside(f1X - rightX, f1Y - rightY);

    if (IsWallF1RightPiece(piece))
      return !f1CenterWall
          && TileIsWallOrOutside(f1X + rightX, f1Y + rightY);

    if (IsWallF2LeftPiece(piece))
      return !f1CenterWall
          && !f2CenterWall
          && TileIsWallOrOutside(f2X - rightX, f2Y - rightY);

    if (IsWallF2RightPiece(piece))
      return !f1CenterWall
          && !f2CenterWall
          && TileIsWallOrOutside(f2X + rightX, f2Y + rightY);

    if (IsWallF3LeftPiece(piece))
      return !f1CenterWall
          && !f2CenterWall
          && !f3CenterWall
          && TileIsWallOrOutside(f3X - rightX, f3Y - rightY);

    if (IsWallF3RightPiece(piece))
      return !f1CenterWall
          && !f2CenterWall
          && !f3CenterWall
          && TileIsWallOrOutside(f3X + rightX, f3Y + rightY);

    if (IsFrontWallF1Card(piece))
      return f1CenterWall;

    if (IsFrontWallF3Card(piece))
    {
      if (IsDoorF2FrontView())
        return false;

      return !f1CenterWall && !f2CenterWall && f3CenterWall;
    }

    if (name == "LeftD3" || name == "Wall D3L2")
    {
      return !f1CenterWall
          && !f2CenterWall
          && !f3CenterWall
          && TileIsWallOrOutside(f3X - rightX, f3Y - rightY);
    }

    if (name == "RightD3" || name == "Wall D3R2")
    {
      // RightD3 visibility is geometry-driven only. If the generic resolver
      // has no state for this piece, it is not needed at the current pose.
      if (TryGetResolvedNormalWallState(
              piece, out ResolvedNormalWallState rightD3State))
      {
        return rightD3State.Enabled;
      }

      return false;
    }

    // Other Black Door cards are hidden unless one of the exact views above needs them.
    if (name == "Black Door Frame Left F1"
        || name == "Black Door Frame Right F1"
        || name == "Black Door Frame Left F2"
        || name == "Black Door Frame Right F2"
        || name == "BlackDoorF1")
    {
      return false;
    }

    return true;
  }

  /// <summary>
  /// Live editor cards come from layout.Pieces. Obsolete A/B pieces must be
  /// removed here so Unity in-memory state cannot write them back to disk.
  /// </summary>
  private void StripObsoleteFrontWallF1ABPieces()
  {
    if (layout == null || layout.Pieces == null)
      return;

    bool hasFrontWallF1 = false;
    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null)
        continue;

      if (piece.Name == "Front Wall F1"
          || piece.Graphic == DungeonGraphicType.FrontWallF1)
      {
        hasFrontWallF1 = true;
        break;
      }
    }

    int insertAt = -1;
    int keepX = 40;
    int keepY = 47;
    bool removed = false;

    for (int i = layout.Pieces.Count - 1; i >= 0; i--)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null)
        continue;

      if (piece.Name != "Front Wall F1 A"
          && piece.Name != "Front Wall F1 B")
      {
        continue;
      }

      keepX = piece.X;
      keepY = piece.Y;
      insertAt = i;
      layout.Pieces.RemoveAt(i);
      removed = true;
    }

    if (!hasFrontWallF1)
    {
      if (insertAt < 0)
        insertAt = layout.Pieces.Count;

      layout.Pieces.Insert(
          insertAt,
          new ViewportPiece
          {
            Name = "Front Wall F1",
            Graphic = DungeonGraphicType.FrontWallF1,
            X = keepX,
            Y = keepY,
            Enabled = false,
            MirrorHorizontally = false,
            FrontWallF1Width = StraightF1WallLogic.DefaultFrontWallF1Width
          });
      removed = true;
    }

    if (!removed)
      return;

    EditorUtility.SetDirty(layout);
    ClampSelectedPieceIndex();
  }


  private bool PieceMatchesSearchFilter(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    if (showOnlyWallsNeededForCurrentPose && showWallsActivFilter)
    {
      // Active-wall view normally follows the current resolved draw set.
      // Exception: once the user touches a wall card at this pose, keep that
      // card/family visible even after Enabled is turned OFF so it can be
      // switched back ON. This is especially important for LeftD3/RightD3,
      // whose visible card can be backed by Wall D3L2/Wall D3R2 aliases.
      return IsWallCardStickyVisibleForCurrentPose(piece)
          || MatchesShowWallsActivFilter(piece);
    }

    string search = (pieceSearchText ?? string.Empty).Trim();
    if (search.Length > 0)
    {
      string name = piece != null ? piece.Name ?? string.Empty : string.Empty;
      return name.IndexOf(search, System.StringComparison.OrdinalIgnoreCase) >= 0;
    }

    if (pieceSearchFamilyIndex <= 0
        || pieceSearchFamilyIndex >= PieceSearchFamilyOptions.Length)
    {
      return !IsOnDemandSearchPiece(piece);
    }

    string selectedFamily =
        PieceSearchFamilyOptions[pieceSearchFamilyIndex];
    return PieceMatchesSearchFamily(piece, selectedFamily);
  }

  /// <summary>
  /// Movement Arrows, Champion Status Slots, Ceiling, and Floor stay off the
  /// unfiltered ViewEdit list; Search Pieces text/family can still reveal them.
  /// </summary>
  private static bool IsOnDemandSearchPiece(ViewportPiece piece)
  {
    return PieceMatchesSearchFamily(piece, "Arrows")
        || PieceMatchesSearchFamily(piece, "Champion Slot 1")
        || PieceMatchesSearchFamily(piece, "Champion Slot 2")
        || PieceMatchesSearchFamily(piece, "Champion Slot 3")
        || PieceMatchesSearchFamily(piece, "Champion Slot 4")
        || PieceMatchesSearchFamily(piece, "Ceiling")
        || PieceMatchesSearchFamily(piece, "Floor");
  }

  /// <summary>
  /// Show Walls Activ: only wall images the loaded map's current view has
  /// resolved as enabled. Ceiling, Floor, and unmatched catalog images are
  /// excluded. Family and text search are not applied.
  /// </summary>
  private bool MatchesShowWallsActivFilter(ViewportPiece piece)
  {
    if (piece == null || IsFloorOrCeiling(piece))
      return false;

    if (IsBlackDoorEditorPiece(piece))
      return IsWallNeededForCurrentPose(piece);

    if (!IsWallEditorPiece(piece) && !IsNormalWallPiece(piece))
      return false;

    if (!TryGetResolvedNormalWallState(
            piece, out ResolvedNormalWallState resolvedState))
    {
      return false;
    }

    return resolvedState.Enabled;
  }

  /// <summary>
  /// Exact family filters for the Search Pieces dropdown. Prefixes use FrontF /
  /// LeftF / RightF so LeftD3 and RightD3 are not included in Left / Right.
  /// </summary>
  private static bool PieceMatchesSearchFamily(
      ViewportPiece piece,
      string family)
  {
    if (piece == null)
      return false;

    string name = piece.Name ?? string.Empty;
    switch (family)
    {
      case "Front":
        return name.StartsWith("FrontF", System.StringComparison.Ordinal)
            || name.StartsWith("Front Wall F", System.StringComparison.Ordinal);
      case "Left":
        return name.StartsWith("LeftF", System.StringComparison.Ordinal);
      case "Right":
        return name.StartsWith("RightF", System.StringComparison.Ordinal);
      case "LeftD3":
        return name == "LeftD3";
      case "RightD3":
        return name == "RightD3";
      case "Black Door":
        return name.IndexOf("Black Door", System.StringComparison.OrdinalIgnoreCase) >= 0
            || string.Equals(
                name,
                "BlackDoorF1",
                System.StringComparison.OrdinalIgnoreCase);
      case "Active":
        return piece.Enabled;
      case "Arrows":
        return name == "Movement Arrows"
            || piece.Graphic == DungeonGraphicType.MovementArrows;
      case "Champion Slot 1":
        return name == "Champion Status Slot 1";
      case "Champion Slot 2":
        return name == "Champion Status Slot 2";
      case "Champion Slot 3":
        return name == "Champion Status Slot 3";
      case "Champion Slot 4":
        return name == "Champion Status Slot 4";
      case "Ceiling":
        return name == "Ceiling"
            || piece.Graphic == DungeonGraphicType.Ceiling;
      case "Floor":
        return name == "Floor"
            || piece.Graphic == DungeonGraphicType.Floor;
      default:
        return true;
    }
  }

  private GUIStyle GetSearchPiecesLabelStyle()
  {
    if (searchPiecesLabelStyle == null)
    {
      searchPiecesLabelStyle = new GUIStyle(EditorStyles.label)
      {
        fontStyle = FontStyle.Bold
      };
      Color brightGreen = new Color(0.2f, 1.0f, 0.2f);
      searchPiecesLabelStyle.normal.textColor = brightGreen;
      searchPiecesLabelStyle.hover.textColor = brightGreen;
      searchPiecesLabelStyle.focused.textColor = brightGreen;
      searchPiecesLabelStyle.active.textColor = brightGreen;
    }

    return searchPiecesLabelStyle;
  }

  private GUIStyle GetPieceFamilyHeaderStyle(Color color)
  {
    if (pieceFamilyHeaderStyle == null)
    {
      pieceFamilyHeaderStyle = new GUIStyle(EditorStyles.boldLabel)
      {
        fontStyle = FontStyle.Bold
      };
    }

    pieceFamilyHeaderStyle.normal.textColor = color;
    pieceFamilyHeaderStyle.hover.textColor = color;
    pieceFamilyHeaderStyle.focused.textColor = color;
    pieceFamilyHeaderStyle.active.textColor = color;
    return pieceFamilyHeaderStyle;
  }
  /// <summary>
  /// Right-click anywhere in ViewEdit scrolls to the top and focuses the
  /// Search Pieces text field. Does not open a popup or change Enabled flags.
  /// </summary>
  private void HandleViewEditRightClickHome()
  {
    Event current = Event.current;
    if (current == null)
      return;

    bool rightPressed =
        current.type == EventType.MouseDown && current.button == 1;
    if (!rightPressed && current.type != EventType.ContextClick)
      return;

    editorScroll = Vector2.zero;
    pieceSearchFamilyIndex = 0;
    focusSearchPieces = true;
    current.Use();
    Repaint();
  }

  private void ShowSearchPiecesFamilyMenu(Rect popupRect)
  {
    GenericMenu menu = new GenericMenu();
    for (int i = 0; i < PieceSearchFamilyOptions.Length; i++)
    {
      string label = PieceSearchFamilyOptions[i];
      if (string.IsNullOrEmpty(label))
        continue;

      int index = i;
      menu.AddItem(
          new GUIContent(label),
          false,
          () =>
          {
            pieceSearchFamilyIndex = index;
            showWallsActivFilter = false;
            pieceSearchText = string.Empty;
            editorScroll = Vector2.zero;
            GUI.FocusControl(null);
            Repaint();
          });
    }

    menu.DropDown(popupRect);
  }

  private void ClampSearchFamilyToEnabledPieces()
  {
    if (pieceSearchFamilyIndex <= 0)
      return;

    if (pieceSearchFamilyIndex >= PieceSearchFamilyOptions.Length)
    {
      pieceSearchFamilyIndex = 0;
      return;
    }

    string family = PieceSearchFamilyOptions[pieceSearchFamilyIndex];
    if (string.IsNullOrEmpty(family))
    {
      pieceSearchFamilyIndex = 0;
      return;
    }

    // Keep the selected family even when all of its pieces are disabled.
    // This lets ViewEdit show those disabled pieces so they can be enabled again.
  }

  private static bool IsPermanentSearchFamily(string family)
  {
    return family == "Arrows"
        || family == "Champion Slot 1"
        || family == "Champion Slot 2"
        || family == "Champion Slot 3"
        || family == "Champion Slot 4"
        || family == "Ceiling"
        || family == "Floor";
  }

  private bool FamilyHasEnabledPiece(string family)
  {
    if (layout == null || layout.Pieces == null || string.IsNullOrEmpty(family))
      return false;

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null || !piece.Enabled)
        continue;

      if (PieceMatchesSearchFamily(piece, family))
        return true;
    }

    return false;
  }

  private void HandlePieceSearchKeyboard()
  {
    Event current = Event.current;
    if (current.type != EventType.KeyDown)
      return;

    if (focusedWindow != this)
      return;

    if (current.keyCode != KeyCode.Escape)
      return;

    if (pieceSearchFamilyIndex == 0)
      return;

    pieceSearchFamilyIndex = 0;
    current.Use();
    GUI.FocusControl(null);
    Repaint();
  }

  /// <summary>
  /// Piece-card checkbox that toggles only from mouse clicks. Keyboard
  /// events are ignored and the control is not allowed to keep focus, so
  /// End/Page Down/arrows/Space cannot change Enabled or Mirror.
  /// </summary>
  private static bool DrawMouseOnlyToggle(
      string label,
      bool value,
      bool pieceEnabled,
      params GUILayoutOption[] options)
  {
    Rect rowRect = EditorGUILayout.GetControlRect(
        true,
        EditorGUIUtility.singleLineHeight,
        options);
    Rect toggleRect = EditorGUI.PrefixLabel(rowRect, new GUIContent(label));
    toggleRect.width = 16f;

    Event current = Event.current;
    bool isMirror = label == "Mirror" || label == "Mirror Horizontally";
    if (current != null
        && current.type == EventType.MouseDown
        && current.button == 0
        && toggleRect.Contains(current.mousePosition))
    {
      value = !value;
      GUI.changed = true;
      current.Use();
    }

    // Shared Unity checkbox chrome. Colored fills are
    // inset so they cannot cover the PrefixLabel or change hit-testing.
    GUI.Toggle(toggleRect, false, GUIContent.none, EditorStyles.toggle);

    Color checkColor = new Color(0.2f, 1.0f, 0.2f);
    bool showChecked = value;
    if (pieceEnabled && showChecked && isMirror)
    {
      EditorGUI.DrawRect(InsetToggleFillRect(toggleRect), new Color(1f, 140f / 255f, 0f));
      checkColor = Color.black;
    }

    if (showChecked)
    {
      GUIStyle checkStyle = new GUIStyle(EditorStyles.label)
      {
        alignment = TextAnchor.MiddleCenter,
        fontStyle = FontStyle.Bold,
        fontSize = 13,
        padding = new RectOffset(0, 0, 0, 1)
      };
      checkStyle.normal.textColor = checkColor;
      GUI.Label(toggleRect, "✓", checkStyle);
    }

    // This custom toggle never takes keyboard focus, preserving ViewEdit's
    // End/Page Down/arrows/Space navigation behavior.
    return value;
  }

  /// <summary>
  /// Compact mouse-only toggle for feature rows. The checkbox is placed
  /// immediately after its caption instead of using Unity's global prefix
  /// label width. This keeps rows visually tight: Enabled [ ] Mirror [ ].
  /// </summary>
  private static bool DrawCompactMouseOnlyToggle(
      string label,
      bool value,
      bool isMirror)
  {
    float labelWidth = EditorStyles.label.CalcSize(new GUIContent(label)).x;
    GUILayout.Label(label, GUILayout.Width(labelWidth));

    Rect toggleRect = GUILayoutUtility.GetRect(
        16f,
        EditorGUIUtility.singleLineHeight,
        GUILayout.Width(16f),
        GUILayout.ExpandWidth(false));

    Event current = Event.current;
    if (current != null
        && current.type == EventType.MouseDown
        && current.button == 0
        && toggleRect.Contains(current.mousePosition))
    {
      value = !value;
      GUI.changed = true;
      current.Use();
    }

    GUI.Toggle(toggleRect, false, GUIContent.none, EditorStyles.toggle);

    if (value)
    {
      Color checkColor = new Color(0.2f, 1.0f, 0.2f);
      if (isMirror)
      {
        EditorGUI.DrawRect(
            InsetToggleFillRect(toggleRect),
            new Color(1f, 140f / 255f, 0f));
        checkColor = Color.black;
      }

      GUIStyle checkStyle = new GUIStyle(EditorStyles.label)
      {
        alignment = TextAnchor.MiddleCenter,
        fontStyle = FontStyle.Bold,
        fontSize = 13,
        padding = new RectOffset(0, 0, 0, 1)
      };
      checkStyle.normal.textColor = checkColor;
      GUI.Label(toggleRect, "✓", checkStyle);
    }

    GUILayout.Space(6f);
    return value;
  }

  private static Rect InsetToggleFillRect(Rect toggleRect)
  {
    const float inset = 2f;
    return new Rect(
        toggleRect.x + inset,
        toggleRect.y + inset,
        toggleRect.width - inset * 2f,
        toggleRect.height - inset * 2f);
  }

  /// <summary>
  /// ViewEdit card list only. Does not change layout.Pieces or draw order.
  /// Front, then Left, then Right, then all remaining pieces in original order.
  /// </summary>
  private int CompareViewEditPieceDisplayOrder(int indexA, int indexB)
  {
    ViewportPiece pieceA = layout.Pieces[indexA];
    ViewportPiece pieceB = layout.Pieces[indexB];
    int groupA = GetViewEditDisplayFamilyGroup(pieceA);
    int groupB = GetViewEditDisplayFamilyGroup(pieceB);
    if (groupA != groupB)
      return groupA.CompareTo(groupB);

    int distanceA = GetViewEditDisplayDistanceOrder(pieceA);
    int distanceB = GetViewEditDisplayDistanceOrder(pieceB);
    if (distanceA != distanceB)
      return distanceA.CompareTo(distanceB);

    return indexA.CompareTo(indexB);
  }

  private static int GetViewEditDisplayFamilyGroup(ViewportPiece piece)
  {
    if (piece == null)
      return 3;

    if (IsFrontWallF1Card(piece)
        || IsFrontWallF2Card(piece)
        || IsFrontWallF3Card(piece))
    {
      return 0;
    }

    if (IsWallF0LeftPiece(piece)
        || IsWallF1LeftPiece(piece)
        || IsWallF2LeftPiece(piece)
        || IsWallF3LeftPiece(piece)
        || piece.Name == "LeftD3"
        || piece.Name == "Wall D3L2"
        || piece.Name == "LeftS3")
    {
      return 1;
    }

    if (IsWallF0RightPiece(piece)
        || IsWallF1RightPiece(piece)
        || IsWallF2RightPiece(piece)
        || IsWallF3RightPiece(piece)
        || piece.Name == "RightD3"
        || piece.Name == "Wall D3R2"
        || piece.Name == "RightS3")
    {
      return 2;
    }

    return 3;
  }

  private static int GetViewEditDisplayDistanceOrder(ViewportPiece piece)
  {
    if (piece == null)
      return 0;

    if (IsFrontWallF1Card(piece)
        || IsWallF0LeftPiece(piece)
        || IsWallF0RightPiece(piece))
    {
      return 0;
    }

    if (IsFrontWallF2Card(piece)
        || IsWallF1LeftPiece(piece)
        || IsWallF1RightPiece(piece))
    {
      return 1;
    }

    if (IsFrontWallF3Card(piece)
        || IsWallF2LeftPiece(piece)
        || IsWallF2RightPiece(piece))
    {
      return 2;
    }

    if (IsWallF3LeftPiece(piece) || IsWallF3RightPiece(piece))
      return 3;

    if (piece.Name == "LeftD3"
        || piece.Name == "Wall D3L2"
        || piece.Name == "RightD3"
        || piece.Name == "Wall D3R2")
    {
      return 4;
    }

    return 0;
  }

  /// <summary>
  /// Read-only canonical ViewEdit X/Y by piece name. Display only.
  /// One entry per wall piece. Null X/Y means not yet defined (Ref X/Y - / -).
  /// </summary>
  private static readonly (string Name, int? X, int? Y)[] CanonicalReferenceXYByName =
  {
    // Front
    ("FrontF0", null, null),
    ("FrontF1", 32, 42),
    ("FrontF2", 59, 52),
    ("FrontF3", 77, 58),
    ("Front Wall F1", null, null),
    ("Front Wall F2", null, null),
    ("Front Wall F3", null, null),

    // Left
    ("LeftF0", 0, 33),
    ("LeftF1", 0, 42),
    ("LeftF2", 0, 52),
    ("LeftF3", 7, 58),
    ("Wall F0Left", null, null),
    ("Wall F1Left", null, null),
    ("Wall F2Left", null, null),
    ("Wall F3Left", null, null),

    // Right
    ("RightF0", 191, 33),
    ("RightF1", 164, 42),
    ("RightF2", 146, 52),
    ("RightF3", 134, 58),
    ("Wall F0Right", null, null),
    ("Wall F1Right", null, null),
    ("Wall F2Right", null, null),
    ("Wall F3Right", null, null),

    // LeftD3
    ("LeftD3", 0, 58),
    ("Wall D3L2", null, null),

    // RightD3
    ("RightD3", 190, 58),
    ("Wall D3R2", null, null),

    // 2S (ViewEdit list only; no geometry yet)
    ("LeftS3", 0, 57),
    ("RightS3", 216, 57),

    // Black Door
    ("BlackDoorF1", 63, 47),
    ("BlackDoorF2", 79, 27),
    ("BlackDoorF3", 88, 63),
    ("Black Door Frame Left F1", 44, 46),
    ("Black Door Frame Left F2", 64, 54),
    ("Black Door Frame Left F3", 79, 102),
    ("Black Door Frame Right F1", 154, 46),
    ("Black Door Frame Right F2", 140, 54),
    ("Black Door Frame Right F3", 132, 103),
  };

  /// <summary>
  /// Runtime Adjust Ref overrides. Checked before the static table.
  /// Stores non-mirrored Ref X and Ref Y.
  /// </summary>
  private static readonly Dictionary<string, Vector2Int> CanonicalReferenceXYOverrides =
      new Dictionary<string, Vector2Int>();

  /// <summary>
  /// Read-only canonical ViewEdit X/Y by piece name. Display only.
  /// </summary>
  private static bool TryGetCanonicalReferenceXY(
      string pieceName,
      out int x,
      out int y)
  {
    x = 0;
    y = 0;
    if (string.IsNullOrEmpty(pieceName))
      return false;

    if (CanonicalReferenceXYOverrides.TryGetValue(
            pieceName, out Vector2Int overridden))
    {
      x = overridden.x;
      y = overridden.y;
      return true;
    }

    for (int i = 0; i < CanonicalReferenceXYByName.Length; i++)
    {
      (string Name, int? X, int? Y) entry = CanonicalReferenceXYByName[i];
      if (entry.Name != pieceName)
        continue;

      if (!entry.X.HasValue || !entry.Y.HasValue)
        return false;

      x = entry.X.Value;
      y = entry.Y.Value;
      return true;
    }

    return false;
  }

  private static void SetCanonicalReferenceXY(string pieceName, int x, int y)
  {
    if (string.IsNullOrEmpty(pieceName))
      return;

    CanonicalReferenceXYOverrides[pieceName] = new Vector2Int(x, y);
  }

  private static bool TryGetSideWallCanonicalName(
      ViewportPiece piece,
      out string name)
  {
    name = null;
    if (piece == null)
      return false;

    if (IsWallF0LeftPiece(piece))
    {
      name = "LeftF0";
      return true;
    }
    if (IsWallF1LeftPiece(piece))
    {
      name = "LeftF1";
      return true;
    }
    if (IsWallF2LeftPiece(piece))
    {
      name = "LeftF2";
      return true;
    }
    if (IsWallF3LeftPiece(piece))
    {
      name = "LeftF3";
      return true;
    }
    if (IsWallF0RightPiece(piece))
    {
      name = "RightF0";
      return true;
    }
    if (IsWallF1RightPiece(piece))
    {
      name = "RightF1";
      return true;
    }
    if (IsWallF2RightPiece(piece))
    {
      name = "RightF2";
      return true;
    }
    if (IsWallF3RightPiece(piece))
    {
      name = "RightF3";
      return true;
    }

    return false;
  }

  private static bool TryGetActiveCanonicalReferenceXY(
      ViewportPiece piece,
      bool mirror,
      out int x,
      out int y)
  {
    x = 0;
    y = 0;
    if (piece == null || string.IsNullOrEmpty(piece.Name))
      return false;

    string referenceName = piece.Name;
    if (TryGetSideWallCanonicalName(piece, out string canonicalName))
      referenceName = canonicalName;

    if (!TryGetCanonicalReferenceXY(referenceName, out x, out y))
      return false;

    // Mirror flips only the side-wall pixels. It never changes canonical X/Y.
    return true;
  }

  private static void SetActiveCanonicalReferenceXY(
      ViewportPiece piece,
      bool mirror,
      int x,
      int y)
  {
    if (piece == null || string.IsNullOrEmpty(piece.Name))
      return;

    SetCanonicalReferenceXY(piece.Name, x, y);
  }

  private static string GetViewEditDisplayName(ViewportPiece piece)
  {
    if (piece == null)
      return string.Empty;

    switch (piece.Name)
    {
      case "Black Door Frame Left F1": return "Door Frame Left F1";
      case "Black Door Frame Right F1": return "Door Frame Right F1";
      case "Black Door Frame Left F2": return "Door Frame Left F2";
      case "Black Door Frame Right F2": return "Door Frame Right F2";
      case "Black Door Frame Left F3": return "Door Frame Left F3";
      case "Black Door Frame Right F3": return "Door Frame Right F3";
      default: return piece.Name ?? string.Empty;
    }
  }

  private bool IsShowAllWallsPreview()
  {
    return !Application.isPlaying && !showOnlyWallsNeededForCurrentPose;
  }

  private void DrawPieceCard(
      int index,
      ViewportPiece piece,
      bool isSelected,
      ref bool changed)
  {
    Color previousBg = GUI.backgroundColor;
    if (isSelected)
      GUI.backgroundColor = new Color(0.2f, 0.55f, 1f, 1f);

    EditorGUILayout.BeginVertical(EditorStyles.helpBox);
    GUI.backgroundColor = previousBg;

    DungeonGraphicType graphicBeforePopup = piece.Graphic;
    if (previewGraphicOverrideByPiece.TryGetValue(
            piece, out DungeonGraphicType graphicOverride))
    {
      graphicBeforePopup = graphicOverride;
      piece.Graphic = graphicOverride;
    }

    bool compactFrontWallHeader =
        IsFrontWallF1Card(piece)
        || IsFrontWallF2Card(piece)
        || IsFrontWallF3Card(piece);
    bool compactBlackDoorFrontHeader =
        piece.Name == "BlackDoorF1"
        || piece.Name == "BlackDoorF2"
        || piece.Name == "BlackDoorF3";
    bool compactBlackDoorF1FrameHeader =
        piece.Name == "Black Door Frame Left F1"
        || piece.Name == "Black Door Frame Right F1"
        || piece.Name == "Black Door Frame Left F2"
        || piece.Name == "Black Door Frame Right F2"
        || piece.Name == "Black Door Frame Left F3"
        || piece.Name == "Black Door Frame Right F3";
    bool isLeftD3Card =
        piece.Name == "LeftD3"
        || piece.Name == "Wall D3L2"
        || piece.Name == "WallD3L2";
    bool compactD3Header =
        !isLeftD3Card
        && piece.Name != "RightD3"
        && (piece.Name == "Wall D3R2"
            || piece.Graphic == DungeonGraphicType.WallD3L2
            || piece.Graphic == DungeonGraphicType.WallD3R2);
    bool compactSideWallHeader =
        IsWallF0LeftPiece(piece)
        || IsWallF0RightPiece(piece)
        || IsWallF1LeftPiece(piece)
        || IsWallF1RightPiece(piece)
        || IsWallF2LeftPiece(piece)
        || IsWallF2RightPiece(piece)
        || IsWallF3LeftPiece(piece)
        || IsWallF3RightPiece(piece)
        || isLeftD3Card
        || piece.Name == "LeftS3"
        || piece.Name == "RightS3"
        || piece.Name == "RightD3";
    bool hideNameForWall = IsWallEditorPiece(piece);

    if (!compactFrontWallHeader
        && !compactBlackDoorFrontHeader
        && !compactBlackDoorF1FrameHeader
        && !compactD3Header
        && !compactSideWallHeader)
    {
      EditorGUILayout.BeginHorizontal();
      string displayName = GetViewEditDisplayName(piece);
      string headerText = isSelected ? $"▶ {displayName}" : displayName;
      if (TryGetPieceFamilyLabelColor(piece, out Color familyColor))
      {
        EditorGUILayout.LabelField(
            headerText,
            GetPieceFamilyHeaderStyle(familyColor));
      }
      else
      {
        EditorGUILayout.LabelField(headerText, EditorStyles.label);
      }
      EditorGUILayout.EndHorizontal();
    }

    EditorGUI.BeginChangeCheck();
    EditorGUILayout.BeginHorizontal();
    float savedNameLabelWidth = EditorGUIUtility.labelWidth;
    if (compactFrontWallHeader || compactBlackDoorFrontHeader)
    {
      string displayName = GetViewEditDisplayName(piece);
      string headerText = isSelected ? $"▶ {displayName}" : displayName;
      if (TryGetPieceFamilyLabelColor(piece, out Color familyColor))
      {
        EditorGUILayout.LabelField(
            headerText,
            GetPieceFamilyHeaderStyle(familyColor),
            GUILayout.Width(110f));
      }
      else
      {
        EditorGUILayout.LabelField(
            headerText,
            EditorStyles.label,
            GUILayout.Width(110f));
      }

      EditorGUIUtility.labelWidth = 0f;
      if (IsFrontWallF1Card(piece))
      {
        // FrontF1 has exactly one valid graphic. Do not expose the full
        // DungeonGraphicType enum (doors, ornaments, obsolete F1_A/F1_B, etc.).
        if (piece.Graphic != DungeonGraphicType.FrontWallF1)
        {
          piece.Graphic = DungeonGraphicType.FrontWallF1;
          GUI.changed = true;
        }

        EditorGUILayout.Popup(
            0,
            new[] { "Front Wall F1" },
            GUILayout.Width(135f));
      }
      else if (IsFrontWallF2Card(piece))
      {
        if (piece.Graphic != DungeonGraphicType.FrontWallF2)
        {
          piece.Graphic = DungeonGraphicType.FrontWallF2;
          GUI.changed = true;
        }

        EditorGUILayout.Popup(
            0,
            new[] { "Front Wall F2" },
            GUILayout.Width(135f));
      }
      else if (IsFrontWallF3Card(piece))
      {
        // FrontF3 is the native 70x49 center (plus optional 32px L/R strips).
        // An authored Front Wall F2 graphic on this card would show the wrong
        // name and feed the wrong height into ViewEdit Y.
        if (piece.Graphic != DungeonGraphicType.FrontWallF3)
        {
          piece.Graphic = DungeonGraphicType.FrontWallF3;
          GUI.changed = true;
        }

        EditorGUILayout.Popup(
            0,
            new[] { "Front Wall F3" },
            GUILayout.Width(135f));
      }
      else
      {
        piece.Graphic = (DungeonGraphicType)EditorGUILayout.EnumPopup(
            GUIContent.none, piece.Graphic, GUILayout.Width(135f));
      }

      // Front pieces use two compact rows:
      // row 1 = name + Graphic + Enabled + Mirror
      // row 2 = Width (when applicable) + X + Y + Ref.
    }
    else if (compactBlackDoorF1FrameHeader)
    {
      string displayName = GetViewEditDisplayName(piece);
      string headerText = isSelected ? $"▶ {displayName}" : displayName;
      if (TryGetPieceFamilyLabelColor(piece, out Color familyColor))
      {
        EditorGUILayout.LabelField(
            headerText,
            GetPieceFamilyHeaderStyle(familyColor),
            GUILayout.Width(180f));
      }
      else
      {
        EditorGUILayout.LabelField(
            headerText,
            EditorStyles.label,
            GUILayout.Width(180f));
      }

      EditorGUIUtility.labelWidth = 0f;
      piece.Graphic = (DungeonGraphicType)EditorGUILayout.EnumPopup(
          GUIContent.none, piece.Graphic, GUILayout.Width(135f));

      // Black Door elements use the same compact arrangement as the normal
      // Left/Right wall cards: name + Graphic + Enabled + Mirror on row 1,
      // then X / Y on row 2.
    }
    else if (compactD3Header)
    {
      string displayName = GetViewEditDisplayName(piece);
      string headerText = isSelected ? $"▶ {displayName}" : displayName;
      if (TryGetPieceFamilyLabelColor(piece, out Color familyColor))
      {
        EditorGUILayout.LabelField(
            headerText,
            GetPieceFamilyHeaderStyle(familyColor),
            GUILayout.Width(110f));
      }
      else
      {
        EditorGUILayout.LabelField(
            headerText,
            EditorStyles.label,
            GUILayout.Width(110f));
      }

      EditorGUIUtility.labelWidth = 0f;
      piece.Graphic = (DungeonGraphicType)EditorGUILayout.EnumPopup(
          GUIContent.none, piece.Graphic, GUILayout.Width(135f));

      // Match FrontF1's compact card layout: title + Graphic on row 1,
      // Enabled / Mirror / Ref on row 2, then X / Y on row 3.
      EditorGUILayout.EndHorizontal();
      EditorGUILayout.BeginHorizontal();
    }
    else if (compactSideWallHeader)
    {
      string displayName = GetViewEditDisplayName(piece);
      string headerText = isSelected ? $"▶ {displayName}" : displayName;
      if (TryGetPieceFamilyLabelColor(piece, out Color familyColor))
      {
        EditorGUILayout.LabelField(
            headerText,
            GetPieceFamilyHeaderStyle(familyColor),
            GUILayout.Width(110f));
      }
      else
      {
        EditorGUILayout.LabelField(
            headerText,
            EditorStyles.label,
            GUILayout.Width(110f));
      }

      EditorGUIUtility.labelWidth = 0f;
      if (piece.Name == "RightS3")
      {
        // RightS3 uses its dedicated extracted source texture through
        // GetRight2STexture().  There is no reliable DungeonGraphicType enum
        // value for this source, so show the real source name instead of the
        // misleading "None" enum popup.
        EditorGUILayout.Popup(
            0,
            new[] { "Right S3" },
            GUILayout.Width(135f));
      }
      else
      {
        piece.Graphic = (DungeonGraphicType)EditorGUILayout.EnumPopup(
            GUIContent.none, piece.Graphic, GUILayout.Width(135f));
      }

      // Keep side-wall Enabled and Mirror on the same first row.
    }
    else if (!hideNameForWall)
    {
      float nameLabelWidth =
          EditorStyles.label.CalcSize(new GUIContent("Name")).x;
      EditorGUIUtility.labelWidth = nameLabelWidth;
      piece.Name = EditorGUILayout.TextField("Name", piece.Name);
      EditorGUILayout.EndHorizontal();
      EditorGUILayout.BeginHorizontal();
    }
    EditorGUIUtility.labelWidth = savedNameLabelWidth;

    float previousLabelWidth = EditorGUIUtility.labelWidth;
    const float ToggleBoxWidth = 18f;
    const float ToggleGroupGap = 10f;

    const string EnabledLabel = "Enabled";
    float enabledLabelWidth =
        EditorStyles.label.CalcSize(new GUIContent(EnabledLabel)).x;
    EditorGUIUtility.labelWidth = enabledLabelWidth;

    bool wallViewEditPreview = IsWallRenderingPiece(piece);
    bool isBlackDoorF3Required =
        piece.Name == "BlackDoorF3"
        && IsDoorF3FrontView();
    bool isBlackDoorF3FrameRequired =
        (piece.Name == "Black Door Frame Left F3"
         || piece.Name == "Black Door Frame Right F3")
        && IsDoorF3FrontView();
    bool wallRenderingPreview = wallViewEditPreview;
    bool usePreviewEnabledOverride =
        wallViewEditPreview
        || isBlackDoorF3Required
        || isBlackDoorF3FrameRequired
        || (previewDisableAllWalls && wallRenderingPreview);

    bool enabledBefore = piece.Enabled;
    if (wallViewEditPreview
        && TryGetResolvedNormalWallState(
            piece, out ResolvedNormalWallState enabledPreviewState))
    {
      enabledBefore = enabledPreviewState.Enabled;
    }

    // When a door is directly ahead at F1 the center FrontF1 is replaced by the door,
    // but the normal LeftF1/RightF1 side walls are part of the automatic view.
    // Manual ViewEdit overrides below can still turn either side off again.
    if (IsBlackDoorF1ManualSideWallCandidate(piece))
      enabledBefore = true;

    bool viewport17LiveFields =
        IsViewport17WallAuthorityActive() && IsNormalWallPiece(piece);

    // Disable Walls blanks every wall, but an explicit ViewEdit Enabled toggle
    // may turn an individual wall back on while the hard geometry block remains.
    if (previewDisableAllWalls
        && wallRenderingPreview
        && !IsDisableWallsKeeper(piece))
    {
      enabledBefore = false;
    }

    if (usePreviewEnabledOverride
        && TryGetPreviewEnabledOverrideForPieceOrFamily(
            piece, out bool manualPreviewEnabled))
    {
      // A manual ViewEdit Enabled toggle must remain visible even while V17
      // owns the automatic wall selection for this stationary pose.
      enabledBefore = manualPreviewEnabled;
    }
    else if (isBlackDoorF3FrameRequired || isBlackDoorF3Required)
    {
      // At (1,5) North BlackDoorF3 and its F3 frames default ON in ViewEdit.
      // An explicit ViewEdit toggle is stored in the temporary preview
      // override above and can still turn any of them OFF.
      enabledBefore = true;
    }

    bool enabledAfter = DrawMouseOnlyToggle(
        EnabledLabel,
        enabledBefore,
        enabledBefore,
        GUILayout.Width(enabledLabelWidth + ToggleBoxWidth),
        GUILayout.ExpandWidth(false));
    bool nameOrEnabledChanged = EditorGUI.EndChangeCheck();

    if (usePreviewEnabledOverride
        && enabledAfter != enabledBefore)
    {
      // ViewEdit-only stationary-pose test, identical in lifetime to X/Y/Mirror.
      // Geometry remains authoritative after X/Y/Facing changes.
      previewEnabledOverrideByPiece[piece] = enabledAfter;
      KeepWallCardVisibleForCurrentPose(piece);

      // FrontF3 can legitimately have no automatic FINAL DRAW lane while the
      // resolved ViewEdit card still describes a useful visible gutter (for
      // example X=0, Width=7 at 6,1 West).  If the user manually enables the
      // card, seed the temporary X/Y/Width/Mirror overrides from exactly the
      // values currently shown in ViewEdit.  Otherwise the native D3 fallback
      // would invent a 70px center draw at X=77, making the Enabled checkbox
      // appear ineffective even though the card says X=0 / Width=7.
      if (enabledAfter
          && IsFrontWallF3Card(piece)
          && TryGetResolvedNormalWallState(
              piece, out ResolvedNormalWallState manualFrontF3State))
      {
        if (!previewPositionOverrideByPiece.ContainsKey(piece))
        {
          previewPositionOverrideByPiece[piece] = new Vector2Int(
              manualFrontF3State.X, manualFrontF3State.Y);
        }

        if (!previewFrontF3WidthOverrideByPiece.ContainsKey(piece))
        {
          int manualFrontF3Width = manualFrontF3State.FrontF3Width > 0
              ? manualFrontF3State.FrontF3Width
              : GetFrontF3FullSourceWidthForViewEdit();
          previewFrontF3WidthOverrideByPiece[piece] = manualFrontF3Width;
        }

        if (!previewMirrorOverrideByPiece.ContainsKey(piece))
          previewMirrorOverrideByPiece[piece] = manualFrontF3State.Mirror;
      }

      previewEnabledChangedThisFrame = true;
      RefreshTemporaryNormalWallPreview();
    }
    else if (!usePreviewEnabledOverride)
    {
      piece.Enabled = enabledAfter;
    }

    // Wall Mirror is a temporary ViewEdit override only. Geometry remains
    // authoritative and the override is discarded as soon as the preview pose
    // changes.
    bool normalWallMirrorPreview = wallViewEditPreview;
    bool mirrorBefore = piece.MirrorHorizontally;

    // The Black Door F1 right frame is rendered from the same left-frame
    // source mirrored horizontally. Reflect that real automatic default in
    // ViewEdit instead of showing Mirror OFF while the renderer uses ON.
    if (IsVerifiedBlackDoorF1Pose()
        && piece.Name == "Black Door Frame Right F1")
    {
      mirrorBefore = true;
    }

    if (normalWallMirrorPreview
        && TryGetResolvedNormalWallState(
            piece, out ResolvedNormalWallState mirrorPreviewState))
    {
      mirrorBefore = mirrorPreviewState.Mirror;
    }

    // Every wall image remains manually mirrorable in ViewEdit even while
    // V17 supplies its automatic live state. Keep the stationary-pose preview
    // override visible so the checkbox never snaps back on repaint.
    if (normalWallMirrorPreview
        && previewMirrorOverrideByPiece.TryGetValue(piece, out bool previewMirror))
    {
      // Mirror is a per-image ViewEdit test. V17 still supplies the default,
      // but once the user clicks the checkbox the manual value must stay put.
      mirrorBefore = previewMirror;
    }

    GUILayout.Space(ToggleGroupGap);
    const string MirrorLabel = "Mirror";
    float mirrorLabelWidth =
        EditorStyles.label.CalcSize(new GUIContent(MirrorLabel)).x;
    EditorGUIUtility.labelWidth = mirrorLabelWidth;
    bool mirrorAfter = DrawMouseOnlyToggle(
        MirrorLabel,
        mirrorBefore,
        true,
        GUILayout.Width(mirrorLabelWidth + ToggleBoxWidth),
        GUILayout.ExpandWidth(false));
    NoteContentRight();
    EditorGUIUtility.labelWidth = previousLabelWidth;
    GUILayout.Space(ToggleGroupGap);

    bool hasPieceCardReference = TryGetPieceCardReferenceXY(
        piece, mirrorAfter, out int canonicalRefX, out int canonicalRefY);

    if (compactD3Header)
    {
      string refLabel = hasPieceCardReference
          ? $"Ref X {canonicalRefX} / Y {canonicalRefY}"
          : "Ref X - / Y -";
      EditorGUILayout.LabelField(
          refLabel,
          GUILayout.ExpandWidth(false));
      NoteContentRight();
    }

    EditorGUILayout.EndHorizontal();

    EditorGUI.BeginChangeCheck();
    if (!compactFrontWallHeader
        && !compactBlackDoorFrontHeader
        && !compactBlackDoorF1FrameHeader
        && !compactD3Header
        && !compactSideWallHeader)
    {
      EditorGUILayout.BeginHorizontal();

      piece.Graphic = (DungeonGraphicType)EditorGUILayout.EnumPopup(
          "Graphic",
          piece.Graphic);

      string refLabel = hasPieceCardReference
          ? $"Ref X {canonicalRefX} / Y {canonicalRefY}"
          : "Ref X - / Y -";
      EditorGUILayout.LabelField(
          refLabel,
          GUILayout.ExpandWidth(false));
      EditorGUILayout.EndHorizontal();
    }
    if (EditorGUI.EndChangeCheck() || nameOrEnabledChanged)
    {
      SelectPiece(index);
      changed = true;
    }

    if (piece.Graphic != graphicBeforePopup)
    {
      previewGraphicOverrideByPiece[piece] = piece.Graphic;
      previewGraphicChangedThisFrame = true;
      RefreshTemporaryNormalWallPreview();
    }

    if (piece.Name == "BlackDoorF1")
    {
      EditorGUILayout.BeginHorizontal();
      EditorGUILayout.PrefixLabel("Size");
      using (new EditorGUI.DisabledScope(true))
      {
        EditorGUILayout.IntField(96, GUILayout.Width(50));
        EditorGUILayout.LabelField("x", GUILayout.Width(12));
        EditorGUILayout.IntField(88, GUILayout.Width(50));
      }
      EditorGUILayout.EndHorizontal();
    }

    if (StraightF1WallLogic.IsFloorOrCeilingGraphic(piece.Graphic))
    {
      EditorGUILayout.HelpBox(
          "Ceiling/Floor Mirror is the per-pose Mirror Horizontally flag "
              + "(Edit Mode and Play/Build).",
          MessageType.None);
    }

    if (mirrorAfter != mirrorBefore)
    {
      if (normalWallMirrorPreview)
      {
        previewMirrorOverrideByPiece[piece] = mirrorAfter;
        previewMirrorChangedThisFrame = true;
        RefreshTemporaryNormalWallPreview();
      }
      else
      {
        piece.MirrorHorizontally = mirrorAfter;
        changed = true;
        ApplyMirrorHorizontallyChangeForCurrentPose();
      }
    }

    bool hasFrontF1Width = IsFrontWallF1Card(piece);
    int frontF1WidthBefore = 0;
    if (hasFrontF1Width)
    {
      frontF1WidthBefore =
          StraightF1WallLogic.NormalizeFrontWallF1Width(
              piece.FrontWallF1Width);

      if (TryGetResolvedNormalWallState(
              piece, out ResolvedNormalWallState resolvedF1WidthState)
          && resolvedF1WidthState.FrontF1Width > 0)
      {
        frontF1WidthBefore =
            StraightF1WallLogic.NormalizeFrontWallF1Width(
                resolvedF1WidthState.FrontF1Width);
      }

      if (previewFrontF1WidthOverrideByPiece.TryGetValue(
              piece, out int previewF1Width)
          && !viewport17LiveFields)
      {
        frontF1WidthBefore =
            StraightF1WallLogic.NormalizeFrontWallF1Width(previewF1Width);
      }
    }

    // FrontF3 gets its own Width row so the control cannot be pushed off
    // the compact X/Y row in a narrow ViewEdit window. This is a temporary
    // live preview crop only; V17 geometry and the authored layout stay intact.
    if (IsFrontWallF3Card(piece))
    {
      int fullFrontF3Width = GetFrontF3FullSourceWidthForViewEdit();
      int frontF3Width = fullFrontF3Width;

      // Verified 10,5-West-class automatic recipe is geometry-owned. Keep
      // ViewEdit in lockstep with the full authored 141px FrontF3 width.
      bool autoD3RightOpenSlitFront = IsViewport17D3RightOpenSlitFront();
      if (autoD3RightOpenSlitFront)
      {
        frontF3Width = Mathf.Clamp(
            NativeD3RightOpenSlitFrontWidth,
            1,
            Mathf.Max(1, fullFrontF3Width));
        previewFrontF3WidthOverrideByPiece[piece] = frontF3Width;
      }
      else if (previewFrontF3WidthOverrideByPiece.TryGetValue(
                   piece, out int previewFrontF3Width))
      {
        frontF3Width = Mathf.Clamp(
            previewFrontF3Width, 1, Mathf.Max(1, fullFrontF3Width));
      }
      else if (TryGetResolvedNormalWallState(
                   piece, out ResolvedNormalWallState resolvedFrontF3Width)
               && resolvedFrontF3Width.FrontF3Width > 0)
      {
        frontF3Width = Mathf.Clamp(
            resolvedFrontF3Width.FrontF3Width, 1, Mathf.Max(1, fullFrontF3Width));
      }

      EditorGUILayout.BeginHorizontal();
      int frontF3WidthBefore = frontF3Width;
      bool frontF3WidthChanged = DrawIntStepperInline(
          "Width",
          ref frontF3Width,
          snap,
          false,
          true);
      EditorGUILayout.LabelField(
          $"Full {fullFrontF3Width}",
          GUILayout.Width(60f));
      EditorGUILayout.EndHorizontal();

      frontF3Width = Mathf.Clamp(
          frontF3Width, 1, Mathf.Max(1, fullFrontF3Width));

      if (frontF3WidthChanged && frontF3Width != frontF3WidthBefore)
      {
        previewFrontF3WidthOverrideByPiece[piece] = frontF3Width;
        previewFrontF3WidthChangedThisFrame = true;
        RefreshTemporaryNormalWallPreview();
      }
    }

    EditorGUILayout.BeginHorizontal();

    if (hasFrontF1Width)
    {
      EditorGUILayout.LabelField("Width", GUILayout.Width(38f));
      int widthSelected = EditorGUILayout.IntPopup(
          frontF1WidthBefore,
          new[] { "160", "192", "224" },
          new[]
          {
            StraightF1WallLogic.CompositeWidth160,
            StraightF1WallLogic.CompositeWidth191,
            StraightF1WallLogic.CompositeWidth
          },
          GUILayout.Width(52f));

      widthSelected =
          StraightF1WallLogic.NormalizeFrontWallF1Width(widthSelected);

      if (widthSelected != frontF1WidthBefore)
      {
        previewFrontF1WidthOverrideByPiece[piece] = widthSelected;
        previewFrontF1WidthChangedThisFrame = true;
        RefreshTemporaryNormalWallPreview();
      }

      GUILayout.Space(4f);
    }

    float savedXyLabelWidth = EditorGUIUtility.labelWidth;
    EditorGUIUtility.labelWidth =
        EditorStyles.label.CalcSize(new GUIContent("X")).x;

    bool normalWallPositionPreview = wallViewEditPreview;
    bool blackDoorF3PositionPreview =
        piece.Name == "BlackDoorF3"
        && IsDoorF3FrontView();
    bool blackDoorF3FramePositionPreview =
        piece.Name == "Black Door Frame Left F3"
        || piece.Name == "Black Door Frame Right F3";
    bool temporaryPositionPreview =
        normalWallPositionPreview
        || blackDoorF3PositionPreview
        || blackDoorF3FramePositionPreview;

    int editX = piece.X;
    int editUnityY = piece.Y;
    if (temporaryPositionPreview
        && TryGetResolvedNormalWallState(piece, out ResolvedNormalWallState xyState))
    {
      editX = xyState.X;
      editUnityY = xyState.Y;
    }

    // BlackDoorF3 is an exact exception at 1,5 North. Its default ViewEdit
    // position is always the canonical Ref X/Y, without writing those values
    // back into the layout asset. A manual ViewEdit X/Y override may still win.
    if (blackDoorF3PositionPreview
        && TryGetCanonicalReferenceXY("BlackDoorF3", out int f3RefX, out int f3RefY))
    {
      editX = f3RefX;
      editUnityY = DisplayYToUnityY(
          f3RefY,
          GetPieceHeightForEditorY(piece));
    }

    // Every wall image remains manually movable in ViewEdit even while V17
    // supplies its geometry. The manual position is a stationary-pose preview
    // override and is cleared on pose change, just like Enabled/Mirror.
    if (temporaryPositionPreview
        && previewPositionOverrideByPiece.TryGetValue(piece, out Vector2Int previewPosition))
    {
      editX = previewPosition.x;
      editUnityY = previewPosition.y;
    }

    int xBefore = editX;
    bool hasCanonicalRef = TryGetPieceCardReferenceXY(
        piece, mirrorAfter, out canonicalRefX, out canonicalRefY);
    int pieceHeightForY = GetPieceHeightForEditorY(piece);
    int displayYForRef = UnityYToDisplayY(editUnityY, pieceHeightForY);
    bool xChanged = DrawIntStepperInline(
        "X",
        ref editX,
        snap,
        hasCanonicalRef && editX != canonicalRefX,
        true);
    if (xChanged && editX != xBefore)
    {
      SelectPiece(index);
      if (temporaryPositionPreview)
      {
        if (hasCanonicalRef
            && !previewPositionReferenceByPiece.ContainsKey(piece))
        {
          previewPositionReferenceByPiece[piece] =
              new Vector2Int(canonicalRefX, canonicalRefY);
        }

        previewPositionOverrideByPiece[piece] = new Vector2Int(editX, editUnityY);

        previewPositionChangedThisFrame = true;
        RefreshTemporaryNormalWallPreview();
      }
      else
      {
        piece.X = editX;
        changed = true;
      }
    }

    EditorGUIUtility.labelWidth =
        EditorStyles.label.CalcSize(new GUIContent("Y")).x;
    int yBefore = editUnityY;
    bool yChanged = DrawTopDownYStepperInline(
        ref editUnityY,
        pieceHeightForY,
        snap,
        hasCanonicalRef && displayYForRef != canonicalRefY,
        true);
    if (yChanged && editUnityY != yBefore)
    {
      SelectPiece(index);
      if (temporaryPositionPreview)
      {
        if (hasCanonicalRef
            && !previewPositionReferenceByPiece.ContainsKey(piece))
        {
          previewPositionReferenceByPiece[piece] =
              new Vector2Int(canonicalRefX, canonicalRefY);
        }

        previewPositionOverrideByPiece[piece] = new Vector2Int(editX, editUnityY);
        previewPositionChangedThisFrame = true;
        RefreshTemporaryNormalWallPreview();
      }
      else
      {
        piece.Y = editUnityY;
        changed = true;
      }
    }
    EditorGUIUtility.labelWidth = savedXyLabelWidth;

    if (compactSideWallHeader
        || compactFrontWallHeader
        || compactBlackDoorFrontHeader
        || compactBlackDoorF1FrameHeader)
    {
      string refLabel = hasCanonicalRef
          ? $"Ref X {canonicalRefX} / Y {canonicalRefY}"
          : "Ref X - / Y -";
      GUILayout.Space(10f);
      EditorGUILayout.LabelField(
          refLabel,
          GUILayout.Width(125f),
          GUILayout.ExpandWidth(false));
      NoteContentRight();
    }

    EditorGUILayout.EndHorizontal();

    if (piece.Name == "BlackDoorF1")
    {
      bool showBlackDoorF2EditorCards = IsDoorF2FrontView();
      bool showBlackDoorF3EditorCards = IsDoorF3FrontView();

      if (showBlackDoorF2EditorCards)
      {
        if (!blackDoorF2CardInitialized)
        {
          blackDoorF2CardEnabled = true;
          blackDoorF2CardMirror = piece.MirrorHorizontally;
          blackDoorF2CardGraphic = DungeonGraphicType.BlackDoor;
          blackDoorF2CardInitialized = true;
        }

        EditorGUILayout.Space(4f);
        EditorGUILayout.BeginVertical(EditorStyles.helpBox);

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("BlackDoorF2", EditorStyles.label);
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.TextField("Name", "BlackDoorF2");

        EditorGUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        float f2PreviousLabelWidth = EditorGUIUtility.labelWidth;
        EditorGUIUtility.labelWidth = 55f;
        blackDoorF2CardEnabled = DrawMouseOnlyToggle(
            "Enabled",
            blackDoorF2CardEnabled,
            blackDoorF2CardEnabled,
            GUILayout.Width(72));
        GUILayout.FlexibleSpace();
        const string F2MirrorLabel = "Mirror Horizontally";
        float f2MirrorLabelWidth =
            EditorStyles.label.CalcSize(new GUIContent(F2MirrorLabel)).x;
        EditorGUIUtility.labelWidth = f2MirrorLabelWidth;
        blackDoorF2CardMirror = DrawMouseOnlyToggle(
            F2MirrorLabel,
            blackDoorF2CardMirror,
            blackDoorF2CardEnabled,
            GUILayout.Width(f2MirrorLabelWidth + 18f),
            GUILayout.ExpandWidth(false));
        EditorGUIUtility.labelWidth = f2PreviousLabelWidth;
        EditorGUILayout.EndHorizontal();

        blackDoorF2CardGraphic =
            (DungeonGraphicType)EditorGUILayout.EnumPopup(
                "Graphic",
                blackDoorF2CardGraphic);

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.PrefixLabel("Size");
        using (new EditorGUI.DisabledScope(true))
        {
          EditorGUILayout.IntField(63, GUILayout.Width(50));
          EditorGUILayout.LabelField("x", GUILayout.Width(12));
          EditorGUILayout.IntField(59, GUILayout.Width(50));
        }
        EditorGUILayout.EndHorizontal();

        int f2X = piece.ResolvedBlackDoorF2X;
        int f2Y = piece.ResolvedBlackDoorF2Y;
        int f2XBefore = f2X;
        int f2YBefore = f2Y;
        DrawIntStepper("X", ref f2X, snap);
        DrawIntStepper("Y", ref f2Y, snap);
        if (f2X != f2XBefore || f2Y != f2YBefore)
        {
          piece.BlackDoorF2X = f2X;
          piece.BlackDoorF2Y = f2Y;
          changed = true;
        }

        EditorGUILayout.EndVertical();
      }

      if (showBlackDoorF3EditorCards)
      {
        if (!blackDoorF3CardInitialized)
        {
          blackDoorF3CardEnabled = false;
          blackDoorF3CardMirror = piece.MirrorHorizontally;
          blackDoorF3CardGraphic = DungeonGraphicType.BlackDoor;
          blackDoorF3CardInitialized = true;
        }

        EditorGUILayout.Space(4f);
        EditorGUILayout.BeginVertical(EditorStyles.helpBox);

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("BlackDoorF3", EditorStyles.label);
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.TextField("Name", "BlackDoorF3");

        EditorGUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        float f3PreviousLabelWidth = EditorGUIUtility.labelWidth;
        EditorGUIUtility.labelWidth = 55f;
        blackDoorF3CardEnabled = DrawMouseOnlyToggle(
            "Enabled",
            blackDoorF3CardEnabled,
            blackDoorF3CardEnabled,
            GUILayout.Width(72));
        GUILayout.FlexibleSpace();
        const string F3MirrorLabel = "Mirror Horizontally";
        float f3MirrorLabelWidth =
            EditorStyles.label.CalcSize(new GUIContent(F3MirrorLabel)).x;
        EditorGUIUtility.labelWidth = f3MirrorLabelWidth;
        blackDoorF3CardMirror = DrawMouseOnlyToggle(
            F3MirrorLabel,
            blackDoorF3CardMirror,
            blackDoorF3CardEnabled,
            GUILayout.Width(f3MirrorLabelWidth + 18f),
            GUILayout.ExpandWidth(false));
        EditorGUIUtility.labelWidth = f3PreviousLabelWidth;
        EditorGUILayout.EndHorizontal();

        blackDoorF3CardGraphic =
            (DungeonGraphicType)EditorGUILayout.EnumPopup(
                "Graphic",
                blackDoorF3CardGraphic);

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.PrefixLabel("Size");
        using (new EditorGUI.DisabledScope(true))
        {
          EditorGUILayout.IntField(45, GUILayout.Width(50));
          EditorGUILayout.LabelField("x", GUILayout.Width(12));
          EditorGUILayout.IntField(39, GUILayout.Width(50));
        }
        EditorGUILayout.EndHorizontal();

        ViewportPiece doorF3 = FindLayoutPieceByName("BlackDoorF3");
        if (doorF3 == null)
        {
          doorF3 = EnsureBlackDoorF3Piece();
          changed = true;
        }
        int f3X = doorF3 != null ? doorF3.X : blackDoorF3CardX;
        int f3Y = doorF3 != null ? doorF3.Y : blackDoorF3CardY;
        int f3XBefore = f3X;
        int f3YBefore = f3Y;
        DrawIntStepper("X", ref f3X, snap);
        DrawIntStepper("Y", ref f3Y, snap);
        blackDoorF3CardX = f3X;
        blackDoorF3CardY = f3Y;
        if (doorF3 != null && (f3X != f3XBefore || f3Y != f3YBefore))
        {
          doorF3.X = f3X;
          doorF3.Y = f3Y;
          changed = true;
        }

        EditorGUILayout.EndVertical();
      }
    }
    EditorGUILayout.EndVertical();
  }

  private void DrawBlackDoorFrameF3EditorCard(
      string name,
      ref bool initialized,
      ref bool enabled,
      ref bool mirror,
      ref int x,
      ref int y,
      bool defaultMirror)
  {
    if (!initialized)
    {
      enabled = false;
      mirror = defaultMirror;
      initialized = true;
    }

    EditorGUILayout.Space(4f);
    EditorGUILayout.BeginVertical(EditorStyles.helpBox);

    EditorGUILayout.BeginHorizontal();
    EditorGUILayout.LabelField(name, EditorStyles.label);
    EditorGUILayout.EndHorizontal();

    EditorGUILayout.TextField("Name", name);

    EditorGUILayout.BeginHorizontal();
    GUILayout.FlexibleSpace();
    float previousLabelWidth = EditorGUIUtility.labelWidth;
    EditorGUIUtility.labelWidth = 55f;
    enabled = DrawMouseOnlyToggle(
        "Enabled",
        enabled,
        enabled,
        GUILayout.Width(72));
    GUILayout.FlexibleSpace();
    const string MirrorLabel = "Mirror Horizontally";
    float mirrorLabelWidth =
        EditorStyles.label.CalcSize(new GUIContent(MirrorLabel)).x;
    EditorGUIUtility.labelWidth = mirrorLabelWidth;
    mirror = DrawMouseOnlyToggle(
        MirrorLabel,
        mirror,
        enabled,
        GUILayout.Width(mirrorLabelWidth + 18f),
        GUILayout.ExpandWidth(false));
    EditorGUIUtility.labelWidth = previousLabelWidth;
    EditorGUILayout.EndHorizontal();

    EditorGUILayout.BeginHorizontal();
    EditorGUILayout.PrefixLabel("Size");
    using (new EditorGUI.DisabledScope(true))
    {
      EditorGUILayout.IntField(10, GUILayout.Width(50));
      EditorGUILayout.LabelField("x", GUILayout.Width(12));
      EditorGUILayout.IntField(42, GUILayout.Width(50));
    }
    EditorGUILayout.EndHorizontal();

    DrawIntStepper("X", ref x, snap);
    DrawIntStepper("Y", ref y, snap);

    EditorGUILayout.EndVertical();
  }

  private ViewportPiece FindLayoutPieceByName(string name)
  {
    if (layout == null || layout.Pieces == null || string.IsNullOrEmpty(name))
      return null;

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece != null && piece.Name == name)
        return piece;
    }

    return null;
  }

  /// <summary>
  /// ViewEdit list entries only. Separate from LeftF2 / RightF2 / LeftD3 / RightD3.
  /// No geometry or render rules yet.
  /// </summary>
  private void EnsureLeftS3AndRightS3Pieces()
  {
    // Canonical ViewEdit names now describe their real distance: LeftS3 / RightS3.
    // Keep the frozen graphic enum/asset names (Left2S / Right2S.png) unchanged.
    // Existing layout assets are migrated in-place from the older aliases.
    if (layout != null && layout.Pieces != null)
    {
      bool migrated = false;

      ViewportPiece canonicalLeftS3 = FindLayoutPieceByName("LeftS3");
      ViewportPiece oldLeftS2 = FindLayoutPieceByName("LeftS2");
      ViewportPiece oldLeft2S = FindLayoutPieceByName("Left2S");

      ViewportPiece leftSource = oldLeftS2 ?? oldLeft2S;
      if (canonicalLeftS3 == null && leftSource != null)
      {
        leftSource.Name = "LeftS3";
        if (leftSource.Graphic == DungeonGraphicType.None)
          leftSource.Graphic = DungeonGraphicType.Left2S;
        canonicalLeftS3 = leftSource;
        migrated = true;
      }

      if (canonicalLeftS3 != null)
      {
        if (oldLeftS2 != null && oldLeftS2 != canonicalLeftS3)
        {
          layout.Pieces.Remove(oldLeftS2);
          migrated = true;
        }
        if (oldLeft2S != null && oldLeft2S != canonicalLeftS3)
        {
          layout.Pieces.Remove(oldLeft2S);
          migrated = true;
        }
      }

      ViewportPiece canonicalRightS3 = FindLayoutPieceByName("RightS3");
      ViewportPiece oldRightS2 = FindLayoutPieceByName("RightS2");
      ViewportPiece oldRight2S = FindLayoutPieceByName("Right2S");

      ViewportPiece rightSource = oldRightS2 ?? oldRight2S;
      if (canonicalRightS3 == null && rightSource != null)
      {
        rightSource.Name = "RightS3";
        canonicalRightS3 = rightSource;
        migrated = true;
      }

      if (canonicalRightS3 != null)
      {
        if (oldRightS2 != null && oldRightS2 != canonicalRightS3)
        {
          layout.Pieces.Remove(oldRightS2);
          migrated = true;
        }
        if (oldRight2S != null && oldRight2S != canonicalRightS3)
        {
          layout.Pieces.Remove(oldRight2S);
          migrated = true;
        }
      }

      if (migrated)
        EditorUtility.SetDirty(layout);
    }

    EnsureNamedWallListPiece("LeftS3", "LeftF2");
    EnsureNamedWallListPiece("RightS3", "RightF2");
  }

  private ViewportPiece EnsureNamedWallListPiece(
      string name,
      string insertAfterName)
  {
    ViewportPiece existing = FindLayoutPieceByName(name);
    if (existing != null)
    {
      if (name == "LeftS3"
          && existing.Graphic == DungeonGraphicType.None)
      {
        existing.Graphic = DungeonGraphicType.Left2S;
      }

      return existing;
    }

    if (layout == null || layout.Pieces == null)
      return null;

    int insertAt = layout.Pieces.Count;
    if (!string.IsNullOrEmpty(insertAfterName))
    {
      for (int i = 0; i < layout.Pieces.Count; i++)
      {
        ViewportPiece piece = layout.Pieces[i];
        if (piece != null && piece.Name == insertAfterName)
        {
          insertAt = i + 1;
          break;
        }
      }
    }

    ViewportPiece created = new ViewportPiece
    {
      Name = name,
      Graphic = name == "LeftS3"
          ? DungeonGraphicType.Left2S
          : DungeonGraphicType.None,
      X = 0,
      Y = 0,
      Enabled = false,
      MirrorHorizontally = false
    };
    layout.Pieces.Insert(insertAt, created);
    return created;
  }

  /// <summary>
  /// Persistent Left F3 frame X/Y live on this layout piece, same as Left F2.
  /// Hidden from the piece list; nested card edits piece.X / piece.Y.
  /// </summary>
  private ViewportPiece EnsureBlackDoorFrameLeftF3Piece()
  {
    ViewportPiece existing = FindLayoutPieceByName("Black Door Frame Left F3");
    if (existing != null)
      return existing;

    if (layout == null || layout.Pieces == null)
      return null;

    int insertAt = layout.Pieces.Count;
    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece != null && piece.Name == "Black Door Frame Left F2")
      {
        insertAt = i + 1;
        break;
      }
    }

    ViewportPiece created = new ViewportPiece
    {
      Name = "Black Door Frame Left F3",
      Graphic = DungeonGraphicType.None,
      X = blackDoorFrameLeftF3CardX,
      Y = blackDoorFrameLeftF3CardY,
      Enabled = false,
      MirrorHorizontally = false
    };
    layout.Pieces.Insert(insertAt, created);
    return created;
  }

  /// <summary>
  /// Persistent Right F3 frame X/Y live on this layout piece, same as Left F3.
  /// Hidden from the piece list; nested card edits piece.X / piece.Y.
  /// </summary>
  private ViewportPiece EnsureBlackDoorFrameRightF3Piece()
  {
    ViewportPiece existing = FindLayoutPieceByName("Black Door Frame Right F3");
    if (existing != null)
      return existing;

    if (layout == null || layout.Pieces == null)
      return null;

    int insertAt = layout.Pieces.Count;
    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece != null && piece.Name == "Black Door Frame Right F2")
      {
        insertAt = i + 1;
        break;
      }
    }

    ViewportPiece created = new ViewportPiece
    {
      Name = "Black Door Frame Right F3",
      Graphic = DungeonGraphicType.None,
      X = blackDoorFrameRightF3CardX,
      Y = blackDoorFrameRightF3CardY,
      Enabled = false,
      MirrorHorizontally = false
    };
    layout.Pieces.Insert(insertAt, created);
    return created;
  }

  /// <summary>
  /// Persistent BlackDoorF3 X/Y live on this layout piece, same as F3 frames.
  /// Hidden from the piece list; nested card edits piece.X / piece.Y.
  /// </summary>
  private ViewportPiece EnsureBlackDoorF3Piece()
  {
    ViewportPiece existing = FindLayoutPieceByName("BlackDoorF3");
    if (existing != null)
      return existing;

    if (layout == null || layout.Pieces == null)
      return null;

    int insertAt = layout.Pieces.Count;
    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece != null && piece.Name == "BlackDoorF1")
      {
        insertAt = i + 1;
        break;
      }
    }

    ViewportPiece created = new ViewportPiece
    {
      Name = "BlackDoorF3",
      Graphic = DungeonGraphicType.None,
      X = blackDoorF3CardX,
      Y = blackDoorF3CardY,
      Enabled = false,
      MirrorHorizontally = false
    };
    layout.Pieces.Insert(insertAt, created);
    return created;
  }
  private static bool TryGetPieceFamilyLabelColor(
      ViewportPiece piece,
      out Color color)
  {
    color = default;
    if (piece == null || string.IsNullOrEmpty(piece.Name))
      return false;

    switch (piece.Name)
    {
      case "Left0":
      case "LeftF0":
      case "Wall F0Left":
        color = new Color32(0x9D, 0xCA, 0xFF, 0xFF);
        return true;
      case "Left1":
      case "LeftF1":
      case "Wall F1Left":
        color = new Color32(0x7F, 0xD3, 0xFF, 0xFF);
        return true;
      case "Left2":
      case "LeftF2":
      case "Wall F2Left":
        color = new Color32(0x2F, 0xA8, 0xFF, 0xFF);
        return true;
      case "Left3":
      case "LeftF3":
      case "Wall F3Left":
        color = new Color32(0x17, 0x6A, 0xA5, 0xFF);
        return true;
      case "Front1":
      case "FrontF1":
      case "Front Wall F1":
        color = new Color32(0x79, 0xD9, 0x96, 0xFF);
        return true;
      case "Front2":
      case "FrontF2":
      case "Front Wall F2":
        color = new Color32(0x4F, 0xB8, 0x74, 0xFF);
        return true;
      case "Front3":
      case "FrontF3":
      case "Front Wall F3":
        color = new Color32(0x33, 0x89, 0x5A, 0xFF);
        return true;
      case "Right0":
      case "RightF0":
      case "Wall F0Right":
        color = new Color32(0xFF, 0xD1, 0xA1, 0xFF);
        return true;
      case "Right1":
      case "RightF1":
      case "Wall F1Right":
        color = new Color32(0xFF, 0xB8, 0x70, 0xFF);
        return true;
      case "Right2":
      case "RightF2":
      case "Wall F2Right":
        color = new Color32(0xE8, 0x95, 0x45, 0xFF);
        return true;
      case "Right3":
      case "RightF3":
      case "Wall F3Right":
        color = new Color32(0xB9, 0x6A, 0x22, 0xFF);
        return true;
      case "LeftD3":
      case "Wall D3L2":
      case "RightD3":
      case "Wall D3R2":
        color = new Color32(0x9B, 0x6F, 0xD1, 0xFF);
        return true;
      case "LeftS3":
      case "RightS3":
        color = new Color32(0x00, 0xFF, 0xFF, 0xFF);
        return true;
      case "BlackDoorF1":
      case "Black Door Frame Left F1":
      case "Black Door Frame Right F1":
        color = new Color32(0xFF, 0x66, 0xFF, 0xFF);
        return true;
      case "BlackDoorF2":
      case "Black Door Frame Left F2":
      case "Black Door Frame Right F2":
        color = new Color32(0xD8, 0x3F, 0xD8, 0xFF);
        return true;
      case "BlackDoorF3":
      case "Black Door Frame Left F3":
      case "Black Door Frame Right F3":
        color = new Color32(0x9C, 0x2B, 0x9C, 0xFF);
        return true;
      default:
        return false;
    }
  }

  private void SelectPiece(int index)
  {
    if (layout == null || layout.Pieces.Count == 0)
    {
      selectedPieceIndex = 0;
      selectionChangedThisFrame = true;
      SaveSessionPrefs();
      GUI.FocusControl(null);
      return;
    }

    int clamped = Mathf.Clamp(index, 0, layout.Pieces.Count - 1);
    if (clamped != selectedPieceIndex)
      selectionChangedThisFrame = true;

    selectedPieceIndex = clamped;
    SaveSessionPrefs();
    GUI.FocusControl(null);
  }

  private void HandlePreviewFacingKeyboard()
  {
    Event current = Event.current;
    if (current.type != EventType.KeyDown)
      return;

    if (!s_viewEditGlobalNavDispatch && focusedWindow != this)
      return;

    // End/PageDown are reserved ViewEdit turn keys. Do not let a stale
    // TextField/DelayedIntField focus block direction changes.
    DungeonFacing nextFacing;
    KeyCode key = current.keyCode;
    switch (key)
    {
      case KeyCode.End:
        // End is the ViewEdit LEFT-TURN key. Turn 90 degrees left relative
        // to the current facing; do not force an absolute map direction.
        nextFacing = TurnPreviewFacingLeft(previewFacing);
        break;
      case KeyCode.PageDown:
        nextFacing = TurnPreviewFacingRight(previewFacing);
        break;
      default:
        return;
    }

    if (nextFacing != previewFacing)
    {
      // Preserve Preview X / Preview Y; only facing changes.
      SwitchPreviewPose(previewX, previewY, nextFacing);
      // End must not refocus the window. Game View repaint and Focus()
      // were trading the keyboard after this key.
      if (!s_viewEditGlobalNavDispatch && key != KeyCode.End)
        TryRefocusPreviewWindow();
    }

    current.Use();
  }

  private void HandlePreviewStrafeKeyboard()
  {
    Event current = Event.current;
    if (current.type != EventType.KeyDown)
      return;

    if (!s_viewEditGlobalNavDispatch && focusedWindow != this)
      return;

    // ViewEdit reserves Left/Right for player-facing-relative strafe.
    // Left moves 90 degrees to the left of the direction arrow; Right moves
    // 90 degrees to its right. Preview Facing itself does not change.
    int localX;
    switch (current.keyCode)
    {
      case KeyCode.LeftArrow:
        localX = -1;
        break;
      case KeyCode.RightArrow:
        localX = 1;
        break;
      default:
        return;
    }

    current.Use();
    TryPreviewNavigateRelative(localX, 0);

    if (!s_viewEditGlobalNavDispatch)
      TryRefocusPreviewWindow();
  }

  private void HandlePreviewMoveKeyboard()
  {
    Event current = Event.current;
    if (current.type != EventType.KeyDown)
      return;

    if (!s_viewEditGlobalNavDispatch && focusedWindow != this)
      return;

    // Arrow keys are dedicated to ViewEdit navigation. Up moves in the
    // direction of the green facing triangle; Down moves exactly opposite it.
    // Both go through TryPreviewNavigateRelative so a stair destination is
    // accepted the same way as the on-screen pad.
    int localY;
    switch (current.keyCode)
    {
      case KeyCode.UpArrow:
        localY = 1;
        break;
      case KeyCode.DownArrow:
        localY = -1;
        break;
      default:
        return;
    }

    current.Use();
    TryPreviewNavigateRelative(0, localY);
    if (!s_viewEditGlobalNavDispatch)
      TryRefocusPreviewWindow();
  }

  private void TryRefocusPreviewWindow()
  {
    // Refocus synchronously. Do not enqueue delayCall focus requests: repeated
    // navigation used to accumulate callbacks and make ViewEdit/GameView trade
    // focus after End/PageDown.
    EditorApplication.delayCall -= RestoreViewEditKeyboardFocus;
    GUI.FocusControl(null);
    GUIUtility.keyboardControl = 0;
    Focus();
  }

  /// <summary>
  /// Compatibility cleanup for callbacks queued by an older script domain.
  /// New navigation does not schedule this method.
  /// </summary>
  private void RestoreViewEditKeyboardFocus()
  {
    EditorApplication.delayCall -= RestoreViewEditKeyboardFocus;
    if (this == null || EditorGUIUtility.editingTextField)
      return;

    Focus();
  }

  private static void RegisterViewEditGlobalNavigation()
  {
    s_viewEditGlobalNavOwners++;
    if (s_viewEditGlobalNavCallbackAdded)
      return;

    AddViewEditGlobalEventHandler(ViewEditGlobalNavHandler);
    AddViewEditBeforeEventProcessedHandler();
    if (!s_gameViewPointerUpdateAdded)
    {
      EditorApplication.update += EnsureGameViewPointerHook;
      s_gameViewPointerUpdateAdded = true;
    }

    EnsureGameViewPointerHook();
    s_viewEditGlobalNavCallbackAdded = true;
  }

  private static void UnregisterViewEditGlobalNavigation()
  {
    s_viewEditGlobalNavOwners--;
    if (s_viewEditGlobalNavOwners > 0)
      return;

    s_viewEditGlobalNavOwners = 0;
    if (!s_viewEditGlobalNavCallbackAdded)
      return;

    RemoveViewEditGlobalEventHandler(ViewEditGlobalNavHandler);
    RemoveViewEditBeforeEventProcessedHandler();
    if (s_gameViewPointerUpdateAdded)
    {
      EditorApplication.update -= EnsureGameViewPointerHook;
      s_gameViewPointerUpdateAdded = false;
    }

    RemoveGameViewPointerHook();
    s_viewEditGlobalNavCallbackAdded = false;
  }

  private static void AddViewEditGlobalEventHandler(
      EditorApplication.CallbackFunction handler)
  {
    EventInfo evt = typeof(EditorApplication).GetEvent(
        "globalEventHandler",
        BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
    if (evt != null)
    {
      evt.GetAddMethod(true)?.Invoke(null, new object[] { handler });
      return;
    }

    FieldInfo field = typeof(EditorApplication).GetField(
        "globalEventHandler",
        BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
    if (field == null)
      return;

    var value = (EditorApplication.CallbackFunction)field.GetValue(null);
    value -= handler;
    value += handler;
    field.SetValue(null, value);
  }

  private static void RemoveViewEditGlobalEventHandler(
      EditorApplication.CallbackFunction handler)
  {
    EventInfo evt = typeof(EditorApplication).GetEvent(
        "globalEventHandler",
        BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
    if (evt != null)
    {
      evt.GetRemoveMethod(true)?.Invoke(null, new object[] { handler });
      return;
    }

    FieldInfo field = typeof(EditorApplication).GetField(
        "globalEventHandler",
        BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
    if (field == null)
      return;

    var value = (EditorApplication.CallbackFunction)field.GetValue(null);
    value -= handler;
    field.SetValue(null, value);
  }

  private static EventInfo GetGuiViewBeforeEventProcessedEvent()
  {
    System.Type guiViewType = typeof(EditorWindow).Assembly.GetType(
        "UnityEditor.GUIView");
    if (guiViewType == null)
      return null;

    return guiViewType.GetEvent(
        "beforeEventProcessed",
        BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
  }

  private static void AddViewEditBeforeEventProcessedHandler()
  {
    EventInfo evt = GetGuiViewBeforeEventProcessedEvent();
    if (evt == null)
      return;

    MethodInfo method = typeof(ViewportLayoutEditor).GetMethod(
        nameof(HandleViewEditBeforeEventProcessed),
        BindingFlags.Static | BindingFlags.NonPublic);
    if (method == null)
      return;

    s_viewEditBeforeEventProcessedHandler = System.Delegate.CreateDelegate(
        evt.EventHandlerType,
        method,
        false);
    if (s_viewEditBeforeEventProcessedHandler == null)
      return;

    evt.GetAddMethod(true)?.Invoke(
        null,
        new object[] { s_viewEditBeforeEventProcessedHandler });
  }

  private static void RemoveViewEditBeforeEventProcessedHandler()
  {
    EventInfo evt = GetGuiViewBeforeEventProcessedEvent();
    if (evt == null || s_viewEditBeforeEventProcessedHandler == null)
      return;

    evt.GetRemoveMethod(true)?.Invoke(
        null,
        new object[] { s_viewEditBeforeEventProcessedHandler });
    s_viewEditBeforeEventProcessedHandler = null;
  }

  private static void HandleViewEditBeforeEventProcessed(
      EventType type,
      KeyCode keyCode,
      EventModifiers modifiers)
  {
    if (type != EventType.KeyDown)
      return;

    // Fast Game View zoom shortcuts.
    // Ctrl + Numpad+ toggles the Game View between 100% and 300%.
    if ((modifiers & EventModifiers.Control) != 0
        && keyCode == KeyCode.KeypadPlus)
    {
      ToggleGameViewZoom100To300();
      Event current = Event.current;
      if (current != null
          && current.type == EventType.KeyDown
          && current.keyCode == keyCode)
      {
        current.Use();
      }
      return;
    }

    if ((modifiers & EventModifiers.Alt) != 0)
    {
      if (keyCode == KeyCode.KeypadPlus)
      {
        SetGameViewZoomScale(3f);
        return;
      }

      if (keyCode == KeyCode.KeypadMinus)
      {
        SetGameViewZoomScale(1f);
        return;
      }
    }

    if (!IsViewEditNavigationKey(keyCode))
      return;

    // End/PageDown can be consumed by the currently focused IMGUI/UI Toolkit
    // control before ViewEdit's normal OnGUI handler sees them. Dispatch these
    // turn keys directly from GUIView.beforeEventProcessed, which runs before
    // the focused control gets a chance to swallow the key.
    if (keyCode == KeyCode.End || keyCode == KeyCode.PageDown)
    {
      if (TryDispatchViewEditTurnKeyDirect(keyCode))
      {
        s_lastPreprocessedTurnKey = keyCode;
        s_lastPreprocessedTurnTime = EditorApplication.timeSinceStartup;
        Event current = Event.current;
        if (current != null
            && current.type == EventType.KeyDown
            && current.keyCode == keyCode)
        {
          current.Use();
        }
      }
      return;
    }

    TryDispatchViewEditGlobalNavigation();
  }


  private static void HandleViewEditGlobalNavigationEvent()
  {
    // GameView.OnGUI invokes globalEventHandler for MouseDown/MouseUp.
    if (TryDispatchViewEditGameViewOnGuiMouse())
      return;

    Event current = Event.current;
    if (current != null
        && current.type == EventType.KeyDown
        && current.control
        && current.keyCode == KeyCode.KeypadPlus)
    {
      ToggleGameViewZoom100To300();
      current.Use();
      return;
    }

    if (current != null
        && current.type == EventType.KeyDown
        && current.alt)
    {
      if (current.keyCode == KeyCode.KeypadPlus)
      {
        SetGameViewZoomScale(3f);
        current.Use();
        return;
      }

      if (current.keyCode == KeyCode.KeypadMinus)
      {
        SetGameViewZoomScale(1f);
        current.Use();
        return;
      }
    }

    TryDispatchViewEditGlobalNavigation();
  }

  private static double s_lastGameViewZoomToggleTime = -1.0;

  /// <summary>
  /// Ctrl + Numpad+ toggles Game View zoom between 100% (1x) and 300% (3x).
  /// The tiny debounce prevents Unity's two editor event paths from toggling
  /// the same physical key press twice.
  /// </summary>
  private static void ToggleGameViewZoom100To300()
  {
    double now = EditorApplication.timeSinceStartup;
    if (s_lastGameViewZoomToggleTime >= 0.0
        && now - s_lastGameViewZoomToggleTime < 0.08)
    {
      return;
    }

    s_lastGameViewZoomToggleTime = now;

    float currentScale = GetGameViewZoomScale();
    float targetScale = currentScale >= 2f ? 1f : 3f;
    SetGameViewZoomScale(targetScale);
  }

  private static float GetGameViewZoomScale()
  {
    EditorWindow gameView = FindGameViewWindow();
    if (gameView == null)
      return 1f;

    System.Type gameViewType = gameView.GetType();
    FieldInfo zoomAreaField = gameViewType.GetField(
        "m_ZoomArea",
        BindingFlags.Instance | BindingFlags.NonPublic);
    object zoomArea = zoomAreaField != null
        ? zoomAreaField.GetValue(gameView)
        : null;
    if (zoomArea == null)
      return 1f;

    FieldInfo scaleField = zoomArea.GetType().GetField(
        "m_Scale",
        BindingFlags.Instance | BindingFlags.NonPublic);
    if (scaleField == null)
      return 1f;

    object value = scaleField.GetValue(zoomArea);
    if (value is Vector2 scale)
      return scale.x;
    if (value is float scalar)
      return scalar;

    return 1f;
  }

  /// <summary>
  /// Set the Unity Game View zoom slider to an exact scale. Unity 6 keeps
  /// the public UI on an internal ZoomableArea, so use GameView.SnapZoom
  /// when available and fall back to its private scale field.
  /// </summary>
  private static void SetGameViewZoomScale(float scale)
  {
    if (scale <= 0f)
      return;

    EditorWindow gameView = FindGameViewWindow();
    if (gameView == null)
      return;

    System.Type gameViewType = gameView.GetType();

    MethodInfo snapZoom = gameViewType.GetMethod(
        "SnapZoom",
        BindingFlags.Instance | BindingFlags.NonPublic,
        null,
        new[] { typeof(float) },
        null);
    if (snapZoom != null)
    {
      snapZoom.Invoke(gameView, new object[] { scale });
      gameView.Repaint();
      return;
    }

    FieldInfo zoomAreaField = gameViewType.GetField(
        "m_ZoomArea",
        BindingFlags.Instance | BindingFlags.NonPublic);
    object zoomArea = zoomAreaField != null
        ? zoomAreaField.GetValue(gameView)
        : null;
    if (zoomArea == null)
      return;

    FieldInfo scaleField = zoomArea.GetType().GetField(
        "m_Scale",
        BindingFlags.Instance | BindingFlags.NonPublic);
    if (scaleField == null)
      return;

    scaleField.SetValue(zoomArea, Vector2.one * scale);
    gameView.Repaint();
  }

  /// <summary>
  /// GameView.OnGUI mouse path. Unity 6 still draws Game View through IMGUI
  /// OnGUI, which invokes globalEventHandler for left-button down.
  /// </summary>
  private static bool TryDispatchViewEditGameViewOnGuiMouse()
  {
    Event current = Event.current;
    if (current == null
        || current.type != EventType.MouseDown
        || current.button != 0
        || Application.isPlaying)
    {
      return false;
    }

    EditorWindow gameView = GetCurrentExecutingGameView();
    if (gameView == null)
      return false;

    return DispatchGameViewMovementClick(
        gameView,
        current.mousePosition,
        current,
        null);
  }

  private static void EnsureGameViewPointerHook()
  {
    if (Application.isPlaying || s_viewEditGlobalNavOwners <= 0)
    {
      RemoveGameViewPointerHook();
      return;
    }

    EditorWindow gameView = FindGameViewWindow();
    if (gameView == s_hookedGameView && s_gameViewPointerCallbackAdded)
      return;

    RemoveGameViewPointerHook();
    if (gameView == null)
      return;

    UnityEngine.UIElements.VisualElement root = gameView.rootVisualElement;
    if (root == null)
      return;

    root.RegisterCallback(
        GameViewPointerDownHandler,
        UnityEngine.UIElements.TrickleDown.TrickleDown);
    s_hookedGameView = gameView;
    s_gameViewPointerCallbackAdded = true;
  }

  private static void RemoveGameViewPointerHook()
  {
    if (s_gameViewPointerCallbackAdded && s_hookedGameView != null)
    {
      UnityEngine.UIElements.VisualElement root =
          s_hookedGameView.rootVisualElement;
      if (root != null)
      {
        root.UnregisterCallback(
            GameViewPointerDownHandler,
            UnityEngine.UIElements.TrickleDown.TrickleDown);
      }
    }

    s_hookedGameView = null;
    s_gameViewPointerCallbackAdded = false;
  }

  private static void HandleGameViewPointerDown(
      UnityEngine.UIElements.PointerDownEvent evt)
  {
    if (evt == null || evt.button != 0 || Application.isPlaying)
      return;

    EditorWindow gameView = s_hookedGameView;
    if (gameView == null)
      gameView = FindGameViewWindow();
    if (gameView == null)
      return;

    DispatchGameViewMovementClick(
        gameView,
        evt.position,
        null,
        evt);
  }

  private static EditorWindow FindGameViewWindow()
  {
    EditorWindow[] windows = Resources.FindObjectsOfTypeAll<EditorWindow>();
    if (windows == null)
      return null;

    for (int i = 0; i < windows.Length; i++)
    {
      EditorWindow window = windows[i];
      if (window != null && window.GetType().FullName == "UnityEditor.GameView")
        return window;
    }

    return null;
  }

  /// <summary>
  /// Shared Game View click dispatch for both UITK PointerDown and GameView
  /// OnGUI / globalEventHandler. Hit-tests the 320x200 movement pad.
  /// </summary>
  private static bool DispatchGameViewMovementClick(
      EditorWindow gameView,
      Vector2 windowMouse,
      Event imguiEvent,
      UnityEngine.UIElements.PointerDownEvent pointerEvent)
  {
    double now = EditorApplication.timeSinceStartup;
    if (now - s_lastGameViewClickTime < 0.05)
      return false;

    ViewportLayoutEditor window = FindOpenViewEditWindow();
    if (window == null || window.layout == null)
      return false;

    bool hasLogical = window.TryGetLogical320x200FromGameView(
        gameView,
        windowMouse,
        out Vector2 logical);

    string region = "none";
    if (hasLogical)
      region = GetMovementArrowRegionName(logical.x, logical.y);

    if (region == "none")
      return false;

    s_lastGameViewClickTime = now;
    window.InvokeMovementArrowRegion(region);

    if (imguiEvent != null)
      imguiEvent.Use();

    if (pointerEvent != null)
    {
      pointerEvent.StopPropagation();
      UnityEngine.UIElements.VisualElement pointerTarget =
          pointerEvent.currentTarget as UnityEngine.UIElements.VisualElement
          ?? pointerEvent.target as UnityEngine.UIElements.VisualElement;
      if (pointerTarget != null && pointerTarget.focusController != null)
        pointerTarget.focusController.IgnoreEvent(pointerEvent);
    }

    gameView.Repaint();
    window.Repaint();
    RepaintGameViews();
    return true;
  }

  /// <summary>
  /// Returns the EditorWindow whose OnGUI is currently executing.
  /// </summary>
  private static EditorWindow GetCurrentExecutingGameView()
  {
    const BindingFlags flags =
        BindingFlags.Static | BindingFlags.Instance
        | BindingFlags.Public | BindingFlags.NonPublic;

    System.Type guiViewType = typeof(EditorWindow).Assembly.GetType(
        "UnityEditor.GUIView");
    if (guiViewType != null)
    {
      PropertyInfo currentProperty = guiViewType.GetProperty("current", flags);
      object currentGuiView = currentProperty != null
          ? currentProperty.GetValue(null, null)
          : null;

      if (currentGuiView != null)
      {
        PropertyInfo actualViewProperty = null;
        for (System.Type hostType = currentGuiView.GetType();
             hostType != null && actualViewProperty == null;
             hostType = hostType.BaseType)
        {
          actualViewProperty = hostType.GetProperty(
              "actualView",
              BindingFlags.Instance
                  | BindingFlags.Public
                  | BindingFlags.NonPublic
                  | BindingFlags.DeclaredOnly);
        }

        EditorWindow actualView = actualViewProperty != null
            ? actualViewProperty.GetValue(currentGuiView, null) as EditorWindow
            : null;

        if (actualView != null
            && actualView.GetType().FullName == "UnityEditor.GameView")
        {
          return actualView;
        }
      }
    }

    EditorWindow hovered = mouseOverWindow;
    if (hovered != null
        && hovered.GetType().FullName == "UnityEditor.GameView")
    {
      return hovered;
    }

    EditorWindow focused = focusedWindow;
    if (focused != null
        && focused.GetType().FullName == "UnityEditor.GameView")
    {
      return focused;
    }

    return null;
  }

  /// <summary>
  /// Unity's own GameView conversion: window mouse -> camera render pixels.
  /// Does not require the point to be inside the target, so a miss still logs.
  /// </summary>
  private static bool TryGetGameViewRenderMouse(
      EditorWindow gameView,
      Vector2 mousePosition,
      out Vector2 gamePixel,
      out Vector2 targetSize)
  {
    gamePixel = Vector2.zero;
    targetSize = Vector2.zero;
    if (gameView == null)
      return false;

    System.Type type = gameView.GetType();
    const BindingFlags flags =
        BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

    PropertyInfo offsetProperty = type.GetProperty("gameMouseOffset", flags);
    PropertyInfo scaleProperty = type.GetProperty("gameMouseScale", flags);
    PropertyInfo targetSizeProperty = type.GetProperty("targetRenderSize", flags);

    if (offsetProperty == null
        || scaleProperty == null
        || targetSizeProperty == null)
    {
      return false;
    }

    object offsetValue = offsetProperty.GetValue(gameView, null);
    object scaleValue = scaleProperty.GetValue(gameView, null);
    object sizeValue = targetSizeProperty.GetValue(gameView, null);

    if (!(offsetValue is Vector2 mouseOffset)
        || !(sizeValue is Vector2 reflectedTargetSize)
        || reflectedTargetSize.x <= 0f
        || reflectedTargetSize.y <= 0f)
    {
      return false;
    }

    float mouseScale;
    try
    {
      mouseScale = System.Convert.ToSingle(scaleValue);
    }
    catch
    {
      mouseScale = 0f;
    }

    if (mouseScale <= 0f)
      return false;

    gamePixel = (mousePosition + mouseOffset) * mouseScale;
    targetSize = reflectedTargetSize;
    return true;
  }

  /// <summary>
  /// Maps a Game View window click onto the Edit Mode 320x200 GameplayRoot.
  /// Uses Unity's GameView render-pixel conversion, then the live centered
  /// 320x200 rect already applied in Edit Mode.
  /// </summary>
  private bool TryGetLogical320x200FromGameView(
      EditorWindow gameView,
      Vector2 windowMouse,
      out Vector2 logical)
  {
    logical = new Vector2(-1f, -1f);
    if (gameView == null)
      return false;

    if (!TryGetGameViewRenderMouse(
            gameView,
            windowMouse,
            out Vector2 gamePixel,
            out Vector2 targetSize))
    {
      return false;
    }

    // Edit Mode forces GameplayRoot to a centered 320x200 ConstantPixelSize
    // canvas. Camera pixels therefore contain that 320x200 frame with equal
    // letterboxing; Unity's gameMouseOffset already removed toolbar/zoom.
    logical.x = gamePixel.x - (targetSize.x - PreviewWidth) * 0.5f;
    logical.y = gamePixel.y - (targetSize.y - PreviewHeight) * 0.5f;
    return true;
  }

  private static string GetMovementArrowRegionName(float logicalX, float logicalY)
  {
    const float arrowsX = 233f;
    const float arrowsY = 124f;
    const float arrowsWidth = 87f;
    const float arrowsHeight = 45f;

    if (logicalX < arrowsX
        || logicalX >= arrowsX + arrowsWidth
        || logicalY < arrowsY
        || logicalY >= arrowsY + arrowsHeight)
    {
      return "none";
    }

    int column = Mathf.Clamp(
        Mathf.FloorToInt((logicalX - arrowsX) / (arrowsWidth / 3f)),
        0,
        2);
    int rowFromTop = logicalY < arrowsY + arrowsHeight * 0.5f ? 0 : 1;
    int button = rowFromTop * 3 + column;

    switch (button)
    {
      case 0:
        return "turn-left";
      case 1:
        return "move-forward";
      case 2:
        return "turn-right";
      case 3:
        return "strafe-left";
      case 4:
        return "move-backward";
      case 5:
        return "strafe-right";
      default:
        return "none";
    }
  }

  private void InvokeMovementArrowRegion(string region)
  {
    switch (region)
    {
      case "turn-left":
        PreviewNavigateTurnLeft();
        break;
      case "turn-right":
        PreviewNavigateTurnRight();
        break;
      case "move-forward":
        PreviewNavigateMoveForward();
        break;
      case "move-backward":
        PreviewNavigateMoveBackward();
        break;
      case "strafe-left":
        PreviewNavigateStrafeLeft();
        break;
      case "strafe-right":
        PreviewNavigateStrafeRight();
        break;
    }
  }

  private static bool IsViewEditNavigationKey(KeyCode keyCode)
  {
    switch (keyCode)
    {
      case KeyCode.UpArrow:
      case KeyCode.DownArrow:
      case KeyCode.LeftArrow:
      case KeyCode.RightArrow:
      case KeyCode.End:
      case KeyCode.PageDown:
        return true;
      default:
        return false;
    }
  }

  private static bool IsEditorTextOrNumericInputActive()
  {
    if (EditorGUIUtility.editingTextField)
      return true;

    EditorWindow focused = focusedWindow;
    if (focused == null)
      return false;

    UnityEngine.UIElements.VisualElement root = focused.rootVisualElement;
    if (root == null)
      return false;

    UnityEngine.UIElements.Focusable focusedElement =
        root.focusController != null
            ? root.focusController.focusedElement
            : null;
    return IsUiToolkitTextOrNumericInput(focusedElement);
  }

  private static bool IsUiToolkitTextOrNumericInput(
      UnityEngine.UIElements.Focusable focused)
  {
    if (focused == null)
      return false;

    for (System.Type type = focused.GetType(); type != null; type = type.BaseType)
    {
      System.Type check = type.IsGenericType ? type.GetGenericTypeDefinition() : type;
      string name = check.Name;
      if (name == "TextInputBaseField`1"
          || name == "TextField"
          || name == "SearchFieldBase`1"
          || name == "ToolbarSearchField")
      {
        return true;
      }
    }

    return false;
  }

  private static bool TryDispatchViewEditTurnKeyDirect(KeyCode keyCode)
  {
    if (Application.isPlaying)
      return false;

    ViewportLayoutEditor window = FindOpenViewEditWindow();
    if (window == null || window.layout == null)
      return false;

    // Do not call Focus(), FocusControl, or keyboardControl = 0. The key is
    // consumed below so a text field cannot also act on it.
    s_viewEditDirectTurnDispatch = true;
    try
    {
      switch (keyCode)
      {
        case KeyCode.End:
          window.PreviewNavigateTurnLeft();
          break;
        case KeyCode.PageDown:
          window.PreviewNavigateTurnRight();
          break;
        default:
          return false;
      }
    }
    finally
    {
      s_viewEditDirectTurnDispatch = false;
    }

    window.Repaint();
    return true;
  }

  private static void TryDispatchViewEditGlobalNavigation()
  {
    Event current = Event.current;
    if (current == null || current.type != EventType.KeyDown)
      return;

    if (!IsViewEditNavigationKey(current.keyCode))
      return;

    if (Application.isPlaying)
      return;

    if ((current.keyCode == KeyCode.End || current.keyCode == KeyCode.PageDown)
        && current.keyCode == s_lastPreprocessedTurnKey
        && EditorApplication.timeSinceStartup - s_lastPreprocessedTurnTime < 0.1)
    {
      current.Use();
      return;
    }

    // All six navigation keys are reserved for ViewEdit. Do not block the
    // arrows on IMGUI/UI Toolkit text-focus state: that state can remain stale
    // after editing a field and was the cause of apparently dead Up/Down keys.

    ViewportLayoutEditor window = FindOpenViewEditWindow();
    if (window == null || window.layout == null)
      return;

    s_viewEditGlobalNavDispatch = true;
    try
    {
      window.HandlePreviewMoveKeyboard();
      window.HandlePreviewFacingKeyboard();
      window.HandlePreviewStrafeKeyboard();
    }
    finally
    {
      s_viewEditGlobalNavDispatch = false;
    }
  }

  // Unity's focused IMGUI/UI Toolkit control can consume End before the
  // normal ViewEdit event paths see it. Register End with Unity's Shortcut
  // Manager as a final editor-level route so End always means TURN LEFT
  // while ViewEdit is open.
  [UnityEditor.ShortcutManagement.Shortcut(
      "Dungeon Master/ViewEdit Turn Left",
      KeyCode.End)]
  private static void ViewEditTurnLeftShortcut()
  {
    if (Application.isPlaying)
      return;

    ViewportLayoutEditor window = FindOpenViewEditWindow();
    if (window == null || window.layout == null)
      return;

    window.PreviewNavigateTurnLeft();
    window.Repaint();
  }

  private static ViewportLayoutEditor FindOpenViewEditWindow()
  {
    ViewportLayoutEditor[] windows =
        Resources.FindObjectsOfTypeAll<ViewportLayoutEditor>();
    if (windows == null)
      return null;

    for (int i = 0; i < windows.Length; i++)
    {
      ViewportLayoutEditor window = windows[i];
      if (window != null)
        return window;
    }

    return null;
  }

  /// <summary>
  /// Recompose for the current pose and push that Texture2D onto the live
  /// Game View dungeon RawImage. Always re-finds the RawImage (no cache).
  /// </summary>
  private void PresentEditModePreviewToGameView()
  {
    if (Application.isPlaying || layout == null || graphics == null)
      return;

    RawImage dungeonImage = FindLiveDungeonViewportRawImage();
    if (dungeonImage == null)
    {
      Debug.LogWarning(
          "PresentEditModePreviewToGameView: DungeonViewport RawImage not found.");
      return;
    }

    cachedViewportImage = dungeonImage;

    EnsureEditModePreviewTexture();
    if (editModePreviewTexture == null)
      return;

    ComposeEditModePreview();
    if (editModePreviewTexture == null)
      return;

    editModePreviewTexture.Apply(false);

    StealViewportTextureIfNeeded(dungeonImage);
    ApplyExact320x200EditModePresentation(dungeonImage);

    // Presentation may rebuild hierarchy — resolve the live RawImage again.
    dungeonImage = FindLiveDungeonViewportRawImage();
    if (dungeonImage == null)
      return;

    cachedViewportImage = dungeonImage;

    // Force a reference change so RawImage/Canvas pick up in-place pixel updates.
    // Avoid uvRect / SetAllDirty here — those hit NRE when canvas is unset.
    dungeonImage.texture = Texture2D.whiteTexture;
    dungeonImage.texture = editModePreviewTexture;

    if (dungeonImage.canvas != null)
      Canvas.ForceUpdateCanvases();

    MaintainMovementArrowsPreview();
    RepaintGameViews();
  }

  /// <summary>
  /// Fresh lookup of the RawImage actually shown in Game View (by name).
  /// Does not use cachedViewportImage.
  /// </summary>
  private RawImage FindLiveDungeonViewportRawImage()
  {
    RawImage[] images = Object.FindObjectsByType<RawImage>(
        FindObjectsInactive.Exclude);

    foreach (RawImage image in images)
    {
      if (image == null)
        continue;

      if (image.gameObject.name == "DungeonViewport")
        return image;
    }

    // Prefer the RawImage currently displaying our preview texture.
    foreach (RawImage image in images)
    {
      if (image == null)
        continue;

      if (editModePreviewTexture != null
          && image.texture == editModePreviewTexture)
      {
        return image;
      }
    }

    foreach (RawImage image in images)
    {
      if (image == null)
        continue;

      if (image.texture is RenderTexture)
        return image;
    }

    return null;
  }

  private static DungeonFacing TurnPreviewFacingLeft(DungeonFacing facing)
  {
    return facing switch
    {
      DungeonFacing.North => DungeonFacing.West,
      DungeonFacing.West => DungeonFacing.South,
      DungeonFacing.South => DungeonFacing.East,
      DungeonFacing.East => DungeonFacing.North,
      _ => facing
    };
  }

  private static DungeonFacing TurnPreviewFacingRight(DungeonFacing facing)
  {
    return facing switch
    {
      DungeonFacing.North => DungeonFacing.East,
      DungeonFacing.East => DungeonFacing.South,
      DungeonFacing.South => DungeonFacing.West,
      DungeonFacing.West => DungeonFacing.North,
      _ => facing
    };
  }

  private void ClampSelectedPieceIndex()
  {
    if (layout == null || layout.Pieces.Count == 0)
    {
      selectedPieceIndex = 0;
      return;
    }

    selectedPieceIndex = Mathf.Clamp(
        selectedPieceIndex,
        0,
        layout.Pieces.Count - 1);
  }

  private void RestorePersistedAssets()
  {
    string savedLayoutGuid =
        EditorPrefs.GetString(PrefsLayoutGuidKey, string.Empty);

    layout = LoadViewportLayoutByGuid(savedLayoutGuid);

    if (layout == null)
    {
      layout = AssetDatabase.LoadAssetAtPath<ViewportLayout>(
          DefaultViewportLayoutPath);
    }

    if (layout == null)
      layout = FindSingleViewportLayoutAsset();

    if (layout != null)
      SaveAssetGuid(PrefsLayoutGuidKey, layout);

    graphics = LoadDungeonGraphicsByGuid(
        EditorPrefs.GetString(PrefsGraphicsGuidKey, string.Empty));

    if (graphics == null)
      graphics = FindSingleDungeonGraphicsAsset();

    if (graphics != null)
      SaveAssetGuid(PrefsGraphicsGuidKey, graphics);
  }

  /// <summary>
  /// Re-load ViewportLayout from disk so Edit Mode preview matches the .asset
  /// Enabled flags (avoids stale in-memory ScriptableObject state).
  /// </summary>
  private void ReloadLayoutFromDisk()
  {
    if (layout == null)
      return;

    string path = AssetDatabase.GetAssetPath(layout);
    if (string.IsNullOrEmpty(path))
      return;

    AssetDatabase.ImportAsset(
        path,
        ImportAssetOptions.ForceUpdate
            | ImportAssetOptions.ForceSynchronousImport);

    ViewportLayout reloaded =
        AssetDatabase.LoadAssetAtPath<ViewportLayout>(path);
    if (reloaded != null)
      layout = reloaded;
  }

  private void DestroyEditModePreviewTextureOnly()
  {
    if (editModePreviewTexture == null)
      return;

    Object.DestroyImmediate(editModePreviewTexture);
    editModePreviewTexture = null;
  }

  private void RestoreSessionPrefs()
  {
    int savedLevel = EditorPrefs.GetInt(
        PrefsPreviewLevelKey,
        PreviewDungeonLevel);
    if (savedLevel >= 0 && savedLevel < PreviewLevelMapPaths.Length)
      previewDungeonLevel = savedLevel;

    EnsurePreviewMiniMapLoaded();

    bool hasSavedPose =
        EditorPrefs.HasKey(PrefsPreviewXKey)
        && EditorPrefs.HasKey(PrefsPreviewYKey)
        && EditorPrefs.HasKey(PrefsPreviewFacingKey);

    if (hasSavedPose)
    {
      previewX = EditorPrefs.GetInt(PrefsPreviewXKey, 0);
      previewY = EditorPrefs.GetInt(PrefsPreviewYKey, 0);
      int facingInt = EditorPrefs.GetInt(
          PrefsPreviewFacingKey,
          (int)DungeonFacing.South);
      previewFacing = facingInt >= (int)DungeonFacing.North
          && facingInt <= (int)DungeonFacing.West
          ? (DungeonFacing)facingInt
          : DungeonFacing.South;

      if (previewMiniMap != null && !previewMiniMap.CanEnter(previewX, previewY))
      {
        previewX = previewMiniMap.StartX;
        previewY = previewMiniMap.StartY;
        previewFacing = previewMiniMap.StartFacing;
      }
    }
    else if (previewMiniMap != null)
    {
      previewX = previewMiniMap.StartX;
      previewY = previewMiniMap.StartY;
      previewFacing = previewMiniMap.StartFacing;
    }

    selectedPieceIndex = EditorPrefs.GetInt(PrefsSelectedPieceIndexKey, 0);
    ClampSelectedPieceIndex();
  }

  private void SaveSessionPrefs()
  {
    EditorPrefs.SetInt(PrefsPreviewXKey, previewX);
    EditorPrefs.SetInt(PrefsPreviewYKey, previewY);
    EditorPrefs.SetInt(PrefsPreviewFacingKey, (int)previewFacing);
    EditorPrefs.SetInt(PrefsPreviewLevelKey, previewDungeonLevel);
    EditorPrefs.SetInt(PrefsSelectedPieceIndexKey, selectedPieceIndex);
  }

  private static ViewportLayout LoadViewportLayoutByGuid(string guid)
  {
    if (string.IsNullOrEmpty(guid))
      return null;

    string path = AssetDatabase.GUIDToAssetPath(guid);
    if (string.IsNullOrEmpty(path))
      return null;

    ViewportLayout loaded =
        AssetDatabase.LoadAssetAtPath<ViewportLayout>(path);
    if (loaded != null)
      return loaded;

    Object[] assets = AssetDatabase.LoadAllAssetsAtPath(path);
    for (int i = 0; i < assets.Length; i++)
    {
      if (assets[i] is ViewportLayout viewportLayout)
        return viewportLayout;
    }

    return null;
  }

  private static ViewportLayout FindSingleViewportLayoutAsset()
  {
    string[] guids = AssetDatabase.FindAssets("t:ViewportLayout");
    if (guids == null || guids.Length != 1)
      return null;

    string path = AssetDatabase.GUIDToAssetPath(guids[0]);
    if (string.IsNullOrEmpty(path))
      return null;

    return AssetDatabase.LoadAssetAtPath<ViewportLayout>(path);
  }

  private static DungeonGraphics LoadDungeonGraphicsByGuid(string guid)
  {
    if (string.IsNullOrEmpty(guid))
      return null;

    string path = AssetDatabase.GUIDToAssetPath(guid);
    if (string.IsNullOrEmpty(path))
      return null;

    return AssetDatabase.LoadAssetAtPath<DungeonGraphics>(path);
  }

  private static DungeonGraphics FindSingleDungeonGraphicsAsset()
  {
    string[] guids = AssetDatabase.FindAssets("t:DungeonGraphics");
    if (guids == null || guids.Length != 1)
      return null;

    string path = AssetDatabase.GUIDToAssetPath(guids[0]);
    if (string.IsNullOrEmpty(path))
      return null;

    return AssetDatabase.LoadAssetAtPath<DungeonGraphics>(path);
  }

  private static void SaveAssetGuid(string prefsKey, Object asset)
  {
    if (asset == null)
    {
      EditorPrefs.SetString(prefsKey, string.Empty);
      return;
    }

    string path = AssetDatabase.GetAssetPath(asset);
    if (string.IsNullOrEmpty(path))
    {
      EditorPrefs.SetString(prefsKey, string.Empty);
      return;
    }

    string guid = AssetDatabase.AssetPathToGUID(path);
    EditorPrefs.SetString(prefsKey, guid ?? string.Empty);
  }

  private void DrawSnapToolbar()
  {
    EditorGUILayout.BeginHorizontal();
    EditorGUILayout.LabelField("Snap", GUILayout.Width(36));

    foreach (int value in SnapValues)
    {
      bool selected = snap == value;
      GUIStyle style = selected
          ? EditorStyles.miniButtonMid
          : EditorStyles.miniButton;

      Color previousColor = GUI.backgroundColor;
      if (selected)
        GUI.backgroundColor = new Color(0.4f, 0.7f, 1f);

      if (GUILayout.Toggle(selected, value.ToString(), style, GUILayout.Width(28))
          && !selected)
      {
        snap = value;
      }

      GUI.backgroundColor = previousColor;
    }

    GUILayout.Space(8f);
    // Caption is the next action. Hide blanks every wall. Show clears that
    // blank before refresh so the current pose's needed walls come back in
    // both the viewport and the ViewEdit list.
    if (GUILayout.Button(
            previewDisableAllWalls ? "Show Walls" : "Hide Walls",
            GUILayout.Width(90f)))
    {
      if (previewDisableAllWalls)
      {
        previewDisableAllWalls = false;
        showOnlyWallsNeededForCurrentPose = true;
      }
      else
      {
        DisableWallsKeepChrome();
      }

      RefreshEditModePreview();
      RepaintGameViews();
      Repaint();
    }

    // Always-visible minimap collapse toggle. Keep it in the Snap toolbar so
    // the control remains reachable even while the minimap itself is hidden.
    if (GUILayout.Button(
            previewMiniMapMuted ? "Show Map" : "Hide Map",
            GUILayout.Width(72f)))
    {
      previewMiniMapMuted = !previewMiniMapMuted;
      Repaint();
    }

    GUILayout.Space(6f);
    GUILayout.Label("Map", GUILayout.Width(28f));

    int displayedLevel = previewDungeonLevel;
    if (!string.IsNullOrEmpty(previewLevelJumpText))
      int.TryParse(previewLevelJumpText, out displayedLevel);

    if (GUILayout.Button("<", GUILayout.Width(24f)))
    {
      previewLevelJumpText = Mathf.Clamp(
          previewDungeonLevel - 1,
          0,
          PreviewLevelMapPaths.Length - 1).ToString();
      TryJumpToPreviewLevelFromField();
      GUI.FocusControl(null);
    }

    GUI.SetNextControlName(PreviewLevelJumpControlName);
    EditorGUI.BeginChangeCheck();
    int requestedLevel = EditorGUILayout.DelayedIntField(
        displayedLevel,
        GUILayout.Width(34f));
    if (EditorGUI.EndChangeCheck())
    {
      requestedLevel = Mathf.Clamp(
          requestedLevel,
          0,
          PreviewLevelMapPaths.Length - 1);
      previewLevelJumpText = requestedLevel.ToString();
      TryJumpToPreviewLevelFromField();
      GUI.FocusControl(null);
    }

    if (GUILayout.Button(">", GUILayout.Width(24f)))
    {
      previewLevelJumpText = Mathf.Clamp(
          previewDungeonLevel + 1,
          0,
          PreviewLevelMapPaths.Length - 1).ToString();
      TryJumpToPreviewLevelFromField();
      GUI.FocusControl(null);
    }

    NoteContentRight();
    EditorGUILayout.EndHorizontal();

    // Lists every wall card for manual composition/testing. This button is
    // LIST-ONLY: it must never change what is currently rendered. In
    // particular, after Hide Walls the viewport stays blank and the user can
    // enable individual pieces one by one from the expanded ViewEdit list.
    // Show Walls, or a pose change, returns the list to the normal pose view.
    EditorGUILayout.BeginHorizontal();
    if (GUILayout.Button("All Walls", GUILayout.Width(90f)))
    {
      showOnlyWallsNeededForCurrentPose = false;
      showWallsActivFilter = false;
      Repaint();
    }

    GUILayout.Space(8f);
    string engineAltarCaption = previewUseEngineViAltarSlots
        ? "New Algorithm On"
        : "Old Algorithm On";
    if (GUILayout.Button(engineAltarCaption, GUILayout.Width(140f)))
    {
      previewUseEngineViAltarSlots = !previewUseEngineViAltarSlots;
      RefreshEditModePreview();
      RepaintGameViews();
      Repaint();
    }

    GUILayout.Space(8f);
    int selectedLightStage = GUILayout.Toolbar(
        previewDungeonLightStage - 1,
        new[] { "L1", "L2", "L3", "L4", "L5", "L6" },
        GUILayout.Width(174f));
    NoteContentRight();
    int requestedLightStage = selectedLightStage + 1;
    if (requestedLightStage != previewDungeonLightStage)
    {
      previewDungeonLightStage = requestedLightStage;
      RefreshEditModePreview();
      RepaintGameViews();
      Repaint();
    }

    EditorGUILayout.EndHorizontal();
  }

  private bool TryGetViewportRawImage(out RawImage viewportImage)
  {
    if (cachedViewportImage == null)
      cachedViewportImage = FindViewportRawImage();

    // Unity fake-null: drop a destroyed cached reference.
    if (cachedViewportImage == null)
    {
      viewportImage = null;
      return false;
    }

    viewportImage = cachedViewportImage;
    return true;
  }

  private RawImage FindViewportRawImage()
  {
    RawImage[] images = Object.FindObjectsByType<RawImage>(
        FindObjectsInactive.Exclude);

    foreach (RawImage image in images)
    {
      if (image == null)
        continue;

      if (image.gameObject.name == "DungeonViewport")
        return image;
    }

    foreach (RawImage image in images)
    {
      if (image == null)
        continue;

      if (image.texture is RenderTexture)
        return image;

      // After the first steal, the dungeon RawImage holds our preview Texture2D
      // (not a RenderTexture) — still treat it as the viewport target.
      if (editModePreviewTexture != null
          && image.texture == editModePreviewTexture)
      {
        return image;
      }
    }

    return null;
  }

  private static void RepaintGameViews()
  {
    // During direct End/PageDown handling, an explicit GameView.Repaint()
    // can steal EditorWindow focus before the key event finishes. The preview
    // texture is already updated, so let GameView repaint naturally.
    if (s_viewEditDirectTurnDispatch)
      return;

    EditorWindow[] windows =
        Resources.FindObjectsOfTypeAll<EditorWindow>();

    foreach (EditorWindow window in windows)
    {
      if (window != null && window.GetType().Name == "GameView")
        window.Repaint();
    }
  }

  private void DrawMapPosePreviewControls()
  {
    DrawPreviewMiniMap();
  }
  // -------------------------------------------------------------------------
  // Generic original-style viewport inspection model.
  //
  // This is the generic Viewport-17 geometry model used by production wall
  // selection/rendering.
  //
  // 16 sampled map tiles (19-slot viewport = 16 tiles + 3 D0 faces):
  //   D3: [-2,3] [-1,3] [0,3] [1,3] [2,3]
  //   D2: [-2,2] [-1,2] [0,2] [1,2] [2,2]
  //   D1:        [-1,1] [0,1] [1,1]
  //   D0:        [-1,0] [0,0] [1,0]
  //
  // plus 3 D0 face evaluations:
  //   BACK        -> probe [0,-1]
  //   LEFT INNER  -> boundary between party [0,0] and left neighbor [-1,0]
  //   RIGHT INNER -> boundary between party [0,0] and right neighbor [1,0]
  // -------------------------------------------------------------------------
  private enum Viewport17CellState
  {
    Open,
    Wall,
    Outside
  }

  private struct Viewport17Cell
  {
    public int LocalX;
    public int Depth;
    public int MapX;
    public int MapY;
    public bool IsInside;
    public DungeonTileType Type;
    public bool HasStairs;
    public bool StairsUp;
    public bool IsStairsDown;
    public Viewport17CellState State;
  }

  private struct Viewport17FaceEvaluation
  {
    public string Name;
    public string RelativeProbe;
    public bool IsSolid;
    public Viewport17Cell ProbeCell;
  }

  private enum Viewport17SurfaceType
  {
    Front,
    LeftSide,
    RightSide,
    Back,
    LeftInner,
    RightInner
  }

  private struct Viewport17Surface
  {
    public Viewport17SurfaceType Type;
    public int Depth;
    public int LocalX;
    public Viewport17Cell PrimaryCell;
    public Viewport17Cell AdjacentCell;
  }

  // -------------------------------------------------------------------------
  // Stage 6C: generic front-lane projection table + D3 LEFT source-window candidate.
  //
  // A front wall graphic is selected by DEPTH (FrontF1/F2/F3), while its
  // screen projection is selected independently by LANE (LEFT/CENTER/RIGHT).
  // This is deliberately keyed only by relative viewport geometry; map X/Y
  // never appears in the projection table.
  //
  // CENTER slots are already calibrated: they use the canonical ViewEdit Ref
  // position with zero offset and no clipping. Stage 6A additionally calibrates
  // only the D3 LEFT destination band (Y + destination clip X 0..31).
  // Stage 6C locks FrontF3 source X 64..95 into dest X 0..31, mirror OFF.
  // V17 production blits that strip when FINAL DRAW is FrontF3 mask L without C.
  // -------------------------------------------------------------------------
  private struct Viewport17FrontProjectionSlot
  {
    public int Depth;
    public int LocalX;
    public string Lane;
    public string PieceFamily;

    // All slots are defined relative to the canonical family reference.
    // X and Y calibration are independent because a projected lane can have
    // a known vertical band while its source-to-destination X mapping is still
    // unresolved. This is exactly the case for D3 LEFT in Stage 6A.
    public bool UseCanonicalBase;
    public bool HasDisplayXOffset;
    public bool HasDisplayYOffset;
    public int DisplayOffsetX;
    public int DisplayOffsetY;

    // Clip values are DESTINATION framebuffer X bounds. They do not imply
    // which source pixels are sampled from the source texture. Source-window
    // calibration is tracked separately so we never accidentally invent it.
    public bool HasClipWindow;
    public int ClipMinX;
    public int ClipMaxX;
    public string ClipMode;
    public string SourceWindowMode;
    public string GraphicOriginRule;

    public bool HasMirror;
    public bool Mirror;
    public string CalibrationStatus;
  }

  private struct Viewport17RenderCommand
  {
    // Painter-order identity. Two commands may intentionally use the same
    // PieceFamily (for example two FrontF3 projections).
    public int Sequence;
    public string PieceFamily;
    public string Projection;
    public string Lane;
    public Viewport17SurfaceType SurfaceType;
    public int Depth;
    public int LocalX;

    // Stage 6Q: front L/C/R wall cells at the same depth are one composite
    // front-wall decision, not three duplicate FrontF draw instances.
    public bool IsFrontComposite;
    public bool FrontLeft;
    public bool FrontCenter;
    public bool FrontRight;
    public string FrontMask;

    // Stage 5B keeps ViewEdit/display coordinates and framebuffer coordinates
    // separate. Canonical Ref X/Y are top-down ViewEdit coordinates. Buffer Y
    // is the bottom-origin coordinate consumed by the existing blitters.
    public bool HasBaseReference;
    public int BaseReferenceX;
    public int BaseReferenceY;
    public bool HasPieceMetrics;
    public int PieceHeight;
    public bool HasPieceWidth;
    public int PieceWidth;
    public bool HasBaseBufferReference;
    public int BaseBufferX;
    public int BaseBufferY;
    public bool HasDisplayPlacement;
    public int DisplayX;
    public int DisplayY;
    public bool HasBufferPlacement;
    public int BufferX;
    public int BufferY;

    // Stage 6A may know the projected vertical band even when the projected
    // X/source-window mapping is still pending. Keep that partial calibration
    // explicit instead of pretending we have a complete placement.
    public bool HasProjectedDisplayY;
    public int ProjectedDisplayY;
    public bool HasProjectedBufferY;
    public int ProjectedBufferY;
    public bool HasProjectedGraphicOriginX;
    public int ProjectedGraphicOriginX;
    public bool HasSourceWindow;
    public int SourceMinX;
    public int SourceMaxX;
    public string SourceWindowMode;

    // Mirror and clipping remain instance properties. Stage 5 resolves only
    // cases that are already deterministic; unknown projection-specific
    // behaviour stays explicit rather than borrowing a legacy pose exception.
    public bool HasMirror;
    public bool Mirror;
    public string ClipMode;
    public string ResolutionNote;

    public Viewport17Surface SourceSurface;
  }

  private struct Viewport17Inspection
  {
    public List<Viewport17Cell> Cells;
    public Viewport17FaceEvaluation BackFace;
    public Viewport17FaceEvaluation LeftInnerFace;
    public Viewport17FaceEvaluation RightInnerFace;
  }

  private static string DescribeTextureSize(Texture2D texture)
  {
    if (texture == null)
      return "null";

    return texture.width + "x" + texture.height;
  }

  private Viewport17Inspection BuildViewport17Inspection()
  {
    Viewport17Inspection inspection = new Viewport17Inspection
    {
      Cells = new List<Viewport17Cell>(16)
    };

    // The order in the list is not used for visibility. Keeping rows in
    // near-to-far order makes the footprint definition easy to audit.
    // D2/D3 include the outer LL/RR context cells so a corridor and an
    // alcove classify as the same 19-slot geometry anywhere on the map.
    AddViewport17Row(inspection.Cells, 0, -1, 1);
    AddViewport17Row(inspection.Cells, 1, -1, 1);
    AddViewport17Row(inspection.Cells, 2, -2, 2);
    AddViewport17Row(inspection.Cells, 3, -2, 2);

    Viewport17Cell backProbe = SampleViewport17Cell(0, -1);
    Viewport17Cell leftProbe = FindViewport17Cell(inspection.Cells, -1, 0);
    Viewport17Cell rightProbe = FindViewport17Cell(inspection.Cells, 1, 0);

    inspection.BackFace = new Viewport17FaceEvaluation
    {
      Name = "BACK",
      RelativeProbe = "[0,-1]",
      IsSolid = IsViewport17Solid(backProbe),
      ProbeCell = backProbe
    };

    inspection.LeftInnerFace = new Viewport17FaceEvaluation
    {
      Name = "LEFT INNER",
      RelativeProbe = "[-1,0]",
      IsSolid = IsViewport17Solid(leftProbe),
      ProbeCell = leftProbe
    };

    inspection.RightInnerFace = new Viewport17FaceEvaluation
    {
      Name = "RIGHT INNER",
      RelativeProbe = "[1,0]",
      IsSolid = IsViewport17Solid(rightProbe),
      ProbeCell = rightProbe
    };

    return inspection;
  }

  private void AddViewport17Row(
      List<Viewport17Cell> cells,
      int depth,
      int minLocalX,
      int maxLocalX)
  {
    for (int localX = minLocalX; localX <= maxLocalX; localX++)
      cells.Add(SampleViewport17Cell(localX, depth));
  }

  private static void GetViewport17RowLocalXBounds(
      int depth,
      out int minLocalX,
      out int maxLocalX)
  {
    // D0/D1: L / C / R. D2/D3: LL / L / C / R / RR.
    if (depth >= 2)
    {
      minLocalX = -2;
      maxLocalX = 2;
      return;
    }

    minLocalX = -1;
    maxLocalX = 1;
  }

  private static bool IsViewport17DrawableSidePair(int depth, int leftLocalX)
  {
    // D2 outer cells are sampled for 19-slot classification, but CSBWin
    // F2L2/F2R2 are NOP: they do not own a wall bitmap. D3 outer cells
    // map to LeftD3/RightD3 and remain drawable.
    if (depth < 3 && (leftLocalX <= -2 || leftLocalX >= 1))
      return false;

    return true;
  }

  private Viewport17Cell SampleViewport17Cell(int localX, int depth)
  {
    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    int mapX = previewX + forwardX * depth + rightX * localX;
    int mapY = previewY + forwardY * depth + rightY * localX;
    bool isInside = previewMiniMap != null && previewMiniMap.IsInside(mapX, mapY);

    DungeonTileType tileType = default;
    bool hasStairs = false;
    bool stairsUp = false;
    Viewport17CellState state = Viewport17CellState.Outside;

    if (isInside)
    {
      var tile = previewMiniMap.GetTile(mapX, mapY);
      tileType = tile.Type;
      hasStairs = tile.TryGetStairsDirection(out stairsUp);
      state = IsViewport17WallType(tileType)
          ? Viewport17CellState.Wall
          : Viewport17CellState.Open;
    }

    return new Viewport17Cell
    {
      LocalX = localX,
      Depth = depth,
      MapX = mapX,
      MapY = mapY,
      IsInside = isInside,
      Type = tileType,
      HasStairs = hasStairs,
      StairsUp = stairsUp,
      IsStairsDown = hasStairs && !stairsUp,
      State = state
    };
  }

  private static bool IsViewport17WallType(DungeonTileType type)
  {
    string typeName = type.ToString();
    return typeName.IndexOf(
               "STONE",
               System.StringComparison.OrdinalIgnoreCase) >= 0
        || typeName.IndexOf(
               "WALL",
               System.StringComparison.OrdinalIgnoreCase) >= 0;
  }

  private static Viewport17Cell FindViewport17Cell(
      List<Viewport17Cell> cells,
      int localX,
      int depth)
  {
    TryFindViewport17Cell(cells, localX, depth, out Viewport17Cell cell);
    return cell;
  }

  private static bool TryFindViewport17Cell(
      List<Viewport17Cell> cells,
      int localX,
      int depth,
      out Viewport17Cell cell)
  {
    cell = default;
    if (cells == null)
      return false;

    for (int i = 0; i < cells.Count; i++)
    {
      Viewport17Cell candidate = cells[i];
      if (candidate.LocalX == localX && candidate.Depth == depth)
      {
        cell = candidate;
        return true;
      }
    }

    return false;
  }

  private static bool IsViewport17Solid(Viewport17Cell cell)
  {
    return cell.State == Viewport17CellState.Wall
        || cell.State == Viewport17CellState.Outside;
  }

  private static bool IsViewport17LaneOpenAt(
      Viewport17Inspection inspection,
      int localX,
      int depth)
  {
    if (depth < 0)
      return true;

    if (!TryFindViewport17Cell(inspection.Cells, localX, depth, out Viewport17Cell cell))
      return true;

    return !IsViewport17Solid(cell);
  }

  private static bool IsViewport17LeftS3D2FrontEdge(
      Viewport17Inspection inspection)
  {
    if (inspection.Cells == null)
      return false;

    // Verified at 10,5 East: the tiny far-left strip is LeftS3 even though
    // the D3-left lane itself is open. It is the exposed left edge of a D2
    // C+R front block seen through a completely open D1 span. This is a
    // geometry class, not a pose exception.
    return IsViewport17LaneOpenAt(inspection, -1, 0)
        && IsViewport17LaneOpenAt(inspection, -1, 1)
        && IsViewport17LaneOpenAt(inspection, 0, 1)
        && IsViewport17LaneOpenAt(inspection, 1, 1)
        && IsViewport17LaneOpenAt(inspection, -1, 2)
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, 0, 2))
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, 1, 2));
  }

  /// <summary>
  /// Verified original-DM LeftS3 full-D3-front edge geometry (7,13 East class).
  /// The right side is closed at D0/D1, the center corridor remains open
  /// through D2, and D3 is a full L+C+R front plane. Original DM exposes the
  /// tiny LeftS3 strip at X=0/Y=57. This is a geometry rule, not a pose hack.
  /// </summary>
  private static bool IsViewport17LeftS3D3FullFrontEdge(
      Viewport17Inspection inspection)
  {
    if (inspection.Cells == null)
      return false;

    return IsViewport17LaneOpenAt(inspection, -1, 0)
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, 1, 0))
        && IsViewport17LaneOpenAt(inspection, -1, 1)
        && IsViewport17LaneOpenAt(inspection, 0, 1)
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, 1, 1))
        && IsViewport17LaneOpenAt(inspection, -1, 2)
        && IsViewport17LaneOpenAt(inspection, 0, 2)
        && IsViewport17LaneOpenAt(inspection, 1, 2)
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, -1, 3))
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, 0, 3))
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, 1, 3));
  }

  /// <summary>
  /// Verified original-DM LeftS3 strip beside an open left corridor and a
  /// D3 center front (17,8 West class). The left lane stays open through D3,
  /// so this is not the D3-left terminator. The center stays open through D2
  /// and closes at D3. Original DM still draws the 8px strip at X=0, Y=57.
  /// Geometry only.
  /// </summary>
  private static bool IsViewport17LeftS3OpenLeftD3CenterFront(
      Viewport17Inspection inspection)
  {
    if (inspection.Cells == null)
      return false;

    return IsViewport17LaneOpenAt(inspection, -1, 0)
        && IsViewport17LaneOpenAt(inspection, -1, 1)
        && IsViewport17LaneOpenAt(inspection, -1, 2)
        && IsViewport17LaneOpenAt(inspection, -1, 3)
        && IsViewport17LaneOpenAt(inspection, 0, 1)
        && IsViewport17LaneOpenAt(inspection, 0, 2)
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, 0, 3));
  }

  private static bool IsViewport17RightS3D3FrontEdge(
      Viewport17Inspection inspection)
  {
    if (inspection.Cells == null)
      return false;

    // Verified at 11,5 West: the tiny far-right strip is RightS3.  It is the
    // exposed right edge of a D3 L+C front block while the right corridor lane
    // remains open through D3.  D1-left may already be solid; that nearer left
    // wall does not cover the far-right edge.  Geometry only, no pose exception.
    return IsViewport17LaneOpenAt(inspection, 1, 0)
        && IsViewport17LaneOpenAt(inspection, 1, 1)
        && IsViewport17LaneOpenAt(inspection, 1, 2)
        && IsViewport17LaneOpenAt(inspection, 1, 3)
        && IsViewport17LaneOpenAt(inspection, 0, 1)
        && IsViewport17LaneOpenAt(inspection, 0, 2)
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, -1, 3))
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, 0, 3));
  }

  /// <summary>
  /// Open left corridor through D0/D1/D2 into a full D3 L+C+R front plane,
  /// with a nearer center front already occupying D1 or D2. Original DM then
  /// exposes only the dest-X gutter left of native LeftF3. The verified
  /// FrontF3 recipe draws 14px at X=-7, leaving source columns 7..13 visible
  /// at viewport X=0..6; LeftF3 then starts at X=7. LeftS3 is not a side-wall
  /// continuation of this front plane.
  /// </summary>
  /// <summary>
  /// Verified original-DM RightD3 sliver geometry (7,11 South class).
  /// A D0 right inner wall is present, while the center and right corridor
  /// stay open through D2. At D3 the center terminates but the right lane
  /// remains open. The outer RightD3 face must survive behind RightF0.
  /// Manual original-DM calibration for this geometry is X=178, Y=58,
  /// Mirror ON. Geometry only: no map-coordinate exception.
  /// </summary>
  private static bool IsViewport17RightD3F0Sliver(
      Viewport17Inspection inspection)
  {
    if (inspection.Cells == null)
      return false;

    return IsViewport17Solid(FindViewport17Cell(inspection.Cells, 1, 0))
        && IsViewport17LaneOpenAt(inspection, 0, 1)
        && IsViewport17LaneOpenAt(inspection, 1, 1)
        && IsViewport17LaneOpenAt(inspection, 0, 2)
        && IsViewport17LaneOpenAt(inspection, 1, 2)
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, 0, 3))
        && IsViewport17LaneOpenAt(inspection, 1, 3);
  }

  /// <summary>
  /// Verified original-DM outer-corridor RightD3 sliver geometry
  /// (9,9 East class). A nearer RightF0 exists, but the center/right corridor
  /// remains open through D3 while the outer-right context wall continues at
  /// D2/D3. Original DM still exposes the far-right D3 oblique face behind
  /// RightF0. Manual calibration is X=180, Y=58, Mirror ON. Geometry only.
  /// </summary>
  private static bool IsViewport17RightD3OuterCorridorSliver(
      Viewport17Inspection inspection)
  {
    if (inspection.Cells == null)
      return false;

    return IsViewport17Solid(FindViewport17Cell(inspection.Cells, 1, 0))
        && IsViewport17LaneOpenAt(inspection, 0, 1)
        && IsViewport17LaneOpenAt(inspection, 1, 1)
        && IsViewport17LaneOpenAt(inspection, 0, 2)
        && IsViewport17LaneOpenAt(inspection, 1, 2)
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, 2, 2))
        && IsViewport17LaneOpenAt(inspection, 0, 3)
        && IsViewport17LaneOpenAt(inspection, 1, 3)
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, 2, 3));
  }

  private static bool IsViewport17D3LeftEdgeFrontGutter(
      Viewport17Inspection inspection)
  {
    if (inspection.Cells == null)
      return false;

    if (!IsViewport17LaneOpenAt(inspection, -1, 0)
        || !IsViewport17LaneOpenAt(inspection, -1, 1)
        || !IsViewport17LaneOpenAt(inspection, -1, 2))
    {
      return false;
    }

    if (!IsViewport17Solid(FindViewport17Cell(inspection.Cells, -1, 3))
        || !IsViewport17Solid(FindViewport17Cell(inspection.Cells, 0, 3))
        || !IsViewport17Solid(FindViewport17Cell(inspection.Cells, 1, 3)))
    {
      return false;
    }

    return !IsViewport17LaneOpenAt(inspection, 0, 1)
        || !IsViewport17LaneOpenAt(inspection, 0, 2);
  }

  /// <summary>
  /// Open right corridor through D0/D1/D2 into a D3 right-lane wall while
  /// the D3 center stays open and the outer-right D3 context is solid.
  /// Original DM then exposes the tiny viewport-edge front face immediately
  /// after RightF3. The verified recipe is the full 141px FrontF3 at X=216,
  /// Y=58, Mirror OFF; viewport clipping leaves only the right-edge sliver.
  /// This is the right-edge counterpart to the verified 6,1-West gutter, but
  /// it intentionally uses the 9,4-East source/placement recipe.
  /// </summary>
  private static bool IsViewport17D3RightEdgeFrontGutter(
      Viewport17Inspection inspection)
  {
    if (inspection.Cells == null)
      return false;

    if (!IsViewport17LaneOpenAt(inspection, 1, 0)
        || !IsViewport17LaneOpenAt(inspection, 1, 1)
        || !IsViewport17LaneOpenAt(inspection, 1, 2))
    {
      return false;
    }

    // The verified 9,4-East shape is a right-side termination, not a full
    // D3 front plane: C remains open, R is solid, and RR is solid context.
    return IsViewport17LaneOpenAt(inspection, 0, 3)
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, 1, 3))
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, 2, 3));
  }


  /// <summary>
  /// Verified 10,5-West-class right-front shape. D1 is open, D2 terminates
  /// on L+C while the right lane remains open, and D3 is a full L+C+R front
  /// plane. The verified manual FrontF3 placement is the full 141px source
  /// at X=185, Y=58, Mirror OFF.
  /// </summary>
  private bool IsViewport17D3RightOpenSlitFront()
  {
    // Read the geometry directly from the minimap rather than relying on a
    // previously built V17 inspection. This keeps the verified 10,5-West
    // recipe authoritative in both Game View and ViewEdit after a script/domain
    // reload, while remaining a coordinate-free geometry rule.
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null)
      return false;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    bool IsWall(int localX, int depth)
    {
      int mapX = previewX + forwardX * depth + rightX * localX;
      int mapY = previewY + forwardY * depth + rightY * localX;
      if (!previewMiniMap.IsInside(mapX, mapY))
        return true;
      return IsViewport17WallType(previewMiniMap.GetTile(mapX, mapY).Type);
    }

    bool IsOpen(int localX, int depth)
    {
      int mapX = previewX + forwardX * depth + rightX * localX;
      int mapY = previewY + forwardY * depth + rightY * localX;
      return previewMiniMap.IsInside(mapX, mapY)
          && !IsViewport17WallType(previewMiniMap.GetTile(mapX, mapY).Type);
    }

    return IsOpen(-1, 1)
        && IsOpen(0, 1)
        && IsOpen(1, 1)
        && IsWall(-1, 2)
        && IsWall(0, 2)
        && IsOpen(1, 2)
        && IsWall(-1, 3)
        && IsWall(0, 3)
        && IsWall(1, 3);
  }

  /// <summary>
  /// A D2 corridor side can remain visible through the 32px side opening of a
  /// nearer D1 CENTER front wall. The side lane itself must still be open at
  /// D1; the existing LeftF2/RightF2 command proves there is a D2 side face.
  /// Verified original-DM example: (7,11) West keeps LeftF2 at X=0/Y=52
  /// beside the nearer FrontF1 center. Geometry only; no pose exception.
  /// </summary>
  private static bool IsViewport17F2SideVisiblePastD1CenterFront(
      Viewport17Inspection inspection,
      Viewport17RenderCommand command)
  {
    if (inspection.Cells == null || command.Depth != 2)
      return false;

    bool leftF2 = command.PieceFamily == "LeftF2";
    bool rightF2 = command.PieceFamily == "RightF2";
    if (!leftF2 && !rightF2)
      return false;

    int sideLocalX = leftF2 ? -1 : 1;

    return IsViewport17Solid(FindViewport17Cell(inspection.Cells, 0, 1))
        && IsViewport17LaneOpenAt(inspection, sideLocalX, 1);
  }

  /// <summary>
  /// Inner LeftF/RightF faces that nearer geometry already hides.
  ///
  /// A spanning D3 inner third beside an open D2 side and a surviving D3
  /// center FrontF3 is LeftF3/RightF3. The opposite D3 inner lane being
  /// open does not hide that third.
  /// </summary>
  private static bool IsViewport17OccludedInnerSide(
      Viewport17Inspection inspection,
      Viewport17RenderCommand command)
  {
    int localX = command.LocalX < 0 ? -1 : 1;
    int depth = command.Depth;
    if (depth != 3)
      return false;

    bool nearerOpen = IsViewport17LaneOpenAt(inspection, localX, depth - 1);
    if (!nearerOpen)
      return false;

    if (!IsViewport17LaneOpenAt(inspection, 0, 1)
        || !IsViewport17LaneOpenAt(inspection, 0, 2))
    {
      return false;
    }

    // Open D2 beside a surviving D3 center is why the spanning third is
    // visible as LeftF3/RightF3. Opposite-lane openness must not drop it.
    return false;
  }

  /// <summary>
  /// Outer LeftD3/RightD3 occupy the uncovered 32px side opening. A nearer
  /// same-side inner wall that actually survives FINAL DRAW (LeftF0/RightF0
  /// or LeftF/RightF) already covers that band, so the outer D3 face is
  /// hidden. A nearer CENTER front does not, because it leaves those 32px
  /// open.
  /// </summary>
  private static bool IsViewport17OuterSideHiddenByNearerInner(
      Viewport17Inspection inspection,
      List<Viewport17RenderCommand> candidates,
      Viewport17RenderCommand outerCommand,
      int nearestLeftFront,
      int nearestCenterFront,
      int nearestRightFront)
  {
    bool left = outerCommand.LocalX < 0
        || outerCommand.SurfaceType == Viewport17SurfaceType.LeftSide
        || outerCommand.SurfaceType == Viewport17SurfaceType.LeftInner;

    for (int i = 0; i < candidates.Count; i++)
    {
      Viewport17RenderCommand command = candidates[i];
      if (command.IsFrontComposite || command.Depth >= outerCommand.Depth)
        continue;
      if (IsViewport17OuterSideCommand(command))
        continue;

      bool sameSide = left
          ? command.SurfaceType == Viewport17SurfaceType.LeftSide
            || command.SurfaceType == Viewport17SurfaceType.LeftInner
          : command.SurfaceType == Viewport17SurfaceType.RightSide
            || command.SurfaceType == Viewport17SurfaceType.RightInner;
      if (!sameSide)
        continue;

      if (left)
      {
        if (nearestLeftFront < command.Depth)
          continue;
        if (command.SurfaceType != Viewport17SurfaceType.LeftInner
            && nearestCenterFront < command.Depth)
        {
          continue;
        }
        if (command.SurfaceType == Viewport17SurfaceType.LeftSide
            && IsViewport17OccludedInnerSide(inspection, command))
        {
          continue;
        }
      }
      else
      {
        if (nearestRightFront < command.Depth)
          continue;
        if (command.SurfaceType != Viewport17SurfaceType.RightInner
            && nearestCenterFront < command.Depth)
        {
          continue;
        }
        if (command.SurfaceType == Viewport17SurfaceType.RightSide
            && IsViewport17OccludedInnerSide(inspection, command))
        {
          continue;
        }
      }

      return true;
    }

    return false;
  }
  private static List<Viewport17Surface> BuildViewport17SurfaceCandidates(
      Viewport17Inspection inspection)
  {
    List<Viewport17Surface> surfaces = new List<Viewport17Surface>();
    if (inspection.Cells == null)
      return surfaces;

    // Painter order: far to near. D2/D3 LL/RR samples classify outer
    // context. Only the three main lanes L/C/R create front-face candidates.
    for (int depth = 3; depth >= 1; depth--)
    {
      for (int localX = -1; localX <= 1; localX++)
      {
        Viewport17Cell cell =
            FindViewport17Cell(inspection.Cells, localX, depth);

        // A Front is the face of a solid cell that belongs to a front wall
        // plane at this depth. Center-lane solids always own that plane
        // (in-map WALL or map-edge Outside).
        //
        // A side-lane solid beside an OPEN center is the corridor wall, not
        // that plane. The OPEN/SOLID join below already emits LeftF/RightF
        // for that cell; emitting a Front as well would mark the side lane
        // as having a nearer front and occlude deeper sides in that lane.
        // Side-lane Front is kept only when the same-depth center is solid
        // (one shared front wall spanning L/C/R).
        if (IsViewport17Solid(cell))
        {
          bool sideLaneBesideOpenCenter = false;
          if (localX != 0)
          {
            Viewport17Cell centerCell =
                FindViewport17Cell(inspection.Cells, 0, depth);
            sideLaneBesideOpenCenter = !IsViewport17Solid(centerCell);
          }

          if (!sideLaneBesideOpenCenter)
          {
            surfaces.Add(new Viewport17Surface
            {
              Type = Viewport17SurfaceType.Front,
              Depth = depth,
              LocalX = localX,
              PrimaryCell = cell,
              AdjacentCell = default
            });

            // A solid side-lane cell on the same front plane is the left/right
            // third of that wall (DOS D3: 83px LeftF3/RightF3 beside the 70px
            // center). OPEN/SOLID transitions do not fire when L/C/R are all
            // solid, so emit those side faces here. Corridor sides (solid
            // beside an OPEN center) are already handled below.
            if (localX < 0)
            {
              surfaces.Add(new Viewport17Surface
              {
                Type = Viewport17SurfaceType.LeftSide,
                Depth = depth,
                LocalX = localX,
                PrimaryCell = cell,
                AdjacentCell = FindViewport17Cell(inspection.Cells, 0, depth)
              });
            }
            else if (localX > 0)
            {
              surfaces.Add(new Viewport17Surface
              {
                Type = Viewport17SurfaceType.RightSide,
                Depth = depth,
                LocalX = localX,
                PrimaryCell = cell,
                AdjacentCell = FindViewport17Cell(inspection.Cells, 0, depth)
              });
            }
          }
        }
      }

      // A side face exists at an OPEN/SOLID transition within the inspected
      // row. D2/D3 LL/RR cells supply outer context; only D3 outer
      // transitions own LeftD3/RightD3 bitmaps.
      GetViewport17RowLocalXBounds(depth, out int minLocalX, out int maxLocalX);
      for (int localX = minLocalX; localX < maxLocalX; localX++)
      {
        if (!IsViewport17DrawableSidePair(depth, localX))
          continue;

        Viewport17Cell leftCell =
            FindViewport17Cell(inspection.Cells, localX, depth);
        Viewport17Cell rightCell =
            FindViewport17Cell(inspection.Cells, localX + 1, depth);

        bool leftSolid = IsViewport17Solid(leftCell);
        bool rightSolid = IsViewport17Solid(rightCell);
        if (leftSolid == rightSolid)
          continue;

        if (leftSolid)
        {
          // Solid geometry is on the LEFT side of an open passage.
          // A solid CENTER's right face is FrontF, not LeftF into the
          // adjacent open lane.
          if (localX == 0)
            continue;

          surfaces.Add(new Viewport17Surface
          {
            Type = Viewport17SurfaceType.LeftSide,
            Depth = depth,
            LocalX = localX,
            PrimaryCell = leftCell,
            AdjacentCell = rightCell
          });
        }
        else
        {
          // Solid geometry is on the RIGHT side of an open passage.
          // A solid CENTER's left face is FrontF, not RightF into the
          // adjacent open lane.
          if (localX + 1 == 0)
            continue;

          surfaces.Add(new Viewport17Surface
          {
            Type = Viewport17SurfaceType.RightSide,
            Depth = depth,
            LocalX = localX + 1,
            PrimaryCell = rightCell,
            AdjacentCell = leftCell
          });
        }
      }
    }

    // D0 BACK is one of the 19-slot evaluations, but it is context for
    // closure/lighting rather than a drawable viewport wall. LEFT/RIGHT INNER
    // remain drawable near-side face candidates.
    if (inspection.LeftInnerFace.IsSolid)
    {
      surfaces.Add(new Viewport17Surface
      {
        Type = Viewport17SurfaceType.LeftInner,
        Depth = 0,
        LocalX = -1,
        PrimaryCell = inspection.LeftInnerFace.ProbeCell,
        AdjacentCell = default
      });
    }

    if (inspection.RightInnerFace.IsSolid)
    {
      surfaces.Add(new Viewport17Surface
      {
        Type = Viewport17SurfaceType.RightInner,
        Depth = 0,
        LocalX = 1,
        PrimaryCell = inspection.RightInnerFace.ProbeCell,
        AdjacentCell = default
      });
    }

    return surfaces;
  }
// -------------------------------------------------------------------------
  // Stage 3: translate generic viewport surfaces into ordered render commands.
  //
  // This is still diagnostic-only. A render command names the Dungeon Master
  // wall-piece FAMILY that would be used for that surface, while preserving
  // the source lane/projection. It does not enable pieces or blit anything.
  //
  // Front surfaces:
  //   D1 -> FrontF1, D2 -> FrontF2, D3 -> FrontF3
  //   The lane (LEFT/CENTER/RIGHT) is retained because more than one front
  //   projection can exist at the same depth.
  //
  // Side surfaces:
  //   D1 -> Left/RightF1, D2 -> Left/RightF2
  //   D3 inner transition -> Left/RightF3
  //   D3 outer transition (LL/L or R/RR edge) -> Left/RightD3
  //
  // D0 inner faces:
  //   LEFT INNER -> LeftF0, RIGHT INNER -> RightF0
  // -------------------------------------------------------------------------
  private static string GetViewport17CommandLane(Viewport17Surface surface)
  {
    switch (surface.Type)
    {
      case Viewport17SurfaceType.Front:
        if (surface.LocalX < 0) return "LEFT";
        if (surface.LocalX > 0) return "RIGHT";
        return "CENTER";

      case Viewport17SurfaceType.LeftSide:
        return surface.Depth == 3 && surface.LocalX <= -2
            ? "OUTER_LEFT"
            : "LEFT";

      case Viewport17SurfaceType.RightSide:
        return surface.Depth == 3 && surface.LocalX >= 2
            ? "OUTER_RIGHT"
            : "RIGHT";

      case Viewport17SurfaceType.LeftInner:
        return "LEFT";

      case Viewport17SurfaceType.RightInner:
        return "RIGHT";
    }

    return "CONTEXT";
  }

  private static Viewport17RenderCommand CreateViewport17RenderCommand(
      string pieceFamily,
      string projection,
      string lane,
      Viewport17Surface surface)
  {
    return new Viewport17RenderCommand
    {
      Sequence = 0,
      PieceFamily = pieceFamily,
      Projection = projection ?? string.Empty,
      Lane = lane,
      SurfaceType = surface.Type,
      Depth = surface.Depth,
      LocalX = surface.LocalX,
      IsFrontComposite = false,
      FrontLeft = false,
      FrontCenter = false,
      FrontRight = false,
      FrontMask = string.Empty,
      HasBaseReference = false,
      BaseReferenceX = 0,
      BaseReferenceY = 0,
      HasPieceMetrics = false,
      PieceHeight = 0,
      HasPieceWidth = false,
      PieceWidth = 0,
      HasBaseBufferReference = false,
      BaseBufferX = 0,
      BaseBufferY = 0,
      HasDisplayPlacement = false,
      DisplayX = 0,
      DisplayY = 0,
      HasBufferPlacement = false,
      BufferX = 0,
      BufferY = 0,
      HasProjectedDisplayY = false,
      ProjectedDisplayY = 0,
      HasProjectedBufferY = false,
      ProjectedBufferY = 0,
      HasProjectedGraphicOriginX = false,
      ProjectedGraphicOriginX = 0,
      HasSourceWindow = false,
      SourceMinX = 0,
      SourceMaxX = 0,
      SourceWindowMode = "PENDING",
      HasMirror = false,
      Mirror = false,
      ClipMode = "PENDING",
      ResolutionNote = string.Empty,
      SourceSurface = surface
    };
  }

  private static string BuildViewport17FrontMask(
      bool left,
      bool center,
      bool right)
  {
    string mask = string.Empty;
    if (left) mask += "L";
    if (center) mask += "C";
    if (right) mask += "R";
    return mask;
  }

  private static Viewport17Surface FindViewport17FrontSurface(
      List<Viewport17Surface> surfaces,
      int depth,
      int localX)
  {
    for (int i = 0; i < surfaces.Count; i++)
    {
      Viewport17Surface surface = surfaces[i];
      if (surface.Type == Viewport17SurfaceType.Front
          && surface.Depth == depth
          && surface.LocalX == localX)
      {
        return surface;
      }
    }

    return default;
  }

  private static List<Viewport17RenderCommand> BuildViewport17RenderCommands(
      Viewport17Inspection inspection)
  {
    List<Viewport17Surface> surfaces =
        BuildViewport17SurfaceCandidates(inspection);
    List<Viewport17RenderCommand> commands =
        new List<Viewport17RenderCommand>(surfaces.Count);

    // Stage 6Q: group the three front-wall lanes at each depth into ONE
    // front-wall composition. The occupancy mask (L/C/R) is carried on the
    // command and will later drive the exact crop/composite geometry.
    //
    // Example:
    //   D1 L=W C=W R=W -> one FrontF1 command with mask=LCR
    // NOT three FrontF1 commands.
    //
    // Side surfaces remain independent commands. We still emit far -> near.
    for (int depth = 3; depth >= 1; depth--)
    {
      bool frontLeft = false;
      bool frontCenter = false;
      bool frontRight = false;

      for (int i = 0; i < surfaces.Count; i++)
      {
        Viewport17Surface surface = surfaces[i];
        if (surface.Type != Viewport17SurfaceType.Front
            || surface.Depth != depth)
        {
          continue;
        }

        if (surface.LocalX < 0)
          frontLeft = true;
        else if (surface.LocalX > 0)
          frontRight = true;
        else
          frontCenter = true;
      }

      if (frontLeft || frontCenter || frontRight)
      {
        // Use CENTER as the representative source when present because the
        // family canonical Ref belongs to the center projection. Otherwise
        // retain one of the real occupied lanes for source-map diagnostics.
        int representativeLocalX = frontCenter ? 0 : frontLeft ? -1 : 1;
        Viewport17Surface representative =
            FindViewport17FrontSurface(
                surfaces,
                depth,
                representativeLocalX);

        string mask =
            BuildViewport17FrontMask(frontLeft, frontCenter, frontRight);
        Viewport17RenderCommand frontCommand =
            CreateViewport17RenderCommand(
                "FrontF" + depth,
                "COMPOSITE " + mask,
                "COMPOSITE",
                representative);

        frontCommand.IsFrontComposite = true;
        frontCommand.FrontLeft = frontLeft;
        frontCommand.FrontCenter = frontCenter;
        frontCommand.FrontRight = frontRight;
        frontCommand.FrontMask = mask;
        // A front composite is depth-owned, not lane-owned. LocalX=0 keeps
        // the canonical family reference neutral; FrontMask carries geometry.
        frontCommand.LocalX = 0;
        frontCommand.Sequence = commands.Count;
        commands.Add(frontCommand);
      }

      // Add side surfaces for this depth after the front composition, keeping
      // the same far-to-near layer order used by the existing candidate list.
      for (int i = 0; i < surfaces.Count; i++)
      {
        Viewport17Surface surface = surfaces[i];
        if (surface.Depth != depth
            || surface.Type == Viewport17SurfaceType.Front)
        {
          continue;
        }

        string pieceFamily = null;
        string projection = null;

        if (surface.Type == Viewport17SurfaceType.LeftSide)
        {
          if (depth == 1)
            pieceFamily = "LeftF1";
          else if (depth == 2)
            pieceFamily = "LeftF2";
          else if (depth == 3)
          {
            // LeftF3 is the inner-left D3 third only. A right-lane join
            // can emit LeftSide with LocalX >= 0; that is not LeftF3.
            if (surface.LocalX <= -2)
            {
              pieceFamily = "LeftD3";
              projection = "OUTER D3";
            }
            else if (surface.LocalX == -1)
            {
              pieceFamily = "LeftF3";
              projection = "INNER D3";
            }
          }
        }
        else if (surface.Type == Viewport17SurfaceType.RightSide)
        {
          if (depth == 1)
            pieceFamily = "RightF1";
          else if (depth == 2)
            pieceFamily = "RightF2";
          else if (depth == 3)
          {
            // RightF3 is the inner-right D3 third only. A left-lane join
            // can emit RightSide with LocalX <= 0; that is not RightF3.
            if (surface.LocalX >= 2)
            {
              pieceFamily = "RightD3";
              projection = "OUTER D3";
            }
            else if (surface.LocalX == 1)
            {
              pieceFamily = "RightF3";
              projection = "INNER D3";
            }
          }
        }

        if (string.IsNullOrEmpty(pieceFamily))
          continue;

        Viewport17RenderCommand sideCommand =
            CreateViewport17RenderCommand(
                pieceFamily,
                projection,
                GetViewport17CommandLane(surface),
                surface);
        sideCommand.Sequence = commands.Count;
        commands.Add(sideCommand);
      }
    }

    // LeftS3 has three verified geometry roles:
    //   1) the narrow far-left D3 terminator strip (6,4 East class),
    //   2) the tiny exposed left edge of a D2 C+R front block behind a fully
    //      open D1 span (10,5 East class), and
    //   3) the tiny far-left edge beside a full D3 L+C+R front plane when the
    //      right side is closed at D0/D1 but the center stays open through D2
    //      (7,13 East class), and
    //   4) the same 8px strip when the left lane stays open through D3 and
    //      the center closes on a D3 front wall (17,8 West class).
    bool d3FullFrontPlane =
        IsViewport17Solid(FindViewport17Cell(inspection.Cells, -1, 3))
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, 0, 3))
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, 1, 3));
    bool leftS3D3Terminator =
        !d3FullFrontPlane
        && IsViewport17LaneOpenAt(inspection, -1, 0)
        && IsViewport17LaneOpenAt(inspection, -1, 1)
        && IsViewport17LaneOpenAt(inspection, -1, 2)
        && IsViewport17Solid(FindViewport17Cell(inspection.Cells, -1, 3));
    bool leftS3D2FrontEdge = IsViewport17LeftS3D2FrontEdge(inspection);
    bool leftS3D3FullFrontEdge =
        IsViewport17LeftS3D3FullFrontEdge(inspection);
    bool leftS3OpenLeftD3CenterFront =
        IsViewport17LeftS3OpenLeftD3CenterFront(inspection);
    if (leftS3D3Terminator
        || leftS3D2FrontEdge
        || leftS3D3FullFrontEdge
        || leftS3OpenLeftD3CenterFront)
    {
      Viewport17Cell primaryCell = leftS3D3Terminator || leftS3D3FullFrontEdge
          ? FindViewport17Cell(inspection.Cells, -1, 3)
          : leftS3OpenLeftD3CenterFront
              ? FindViewport17Cell(inspection.Cells, 0, 3)
              : FindViewport17Cell(inspection.Cells, 0, 2);
      Viewport17Cell adjacentCell = leftS3D3Terminator || leftS3D3FullFrontEdge
          ? FindViewport17Cell(inspection.Cells, 0, 3)
          : FindViewport17Cell(inspection.Cells, -1, 2);
      Viewport17Surface leftS3Surface = new Viewport17Surface
      {
        Type = Viewport17SurfaceType.LeftSide,
        Depth = 3,
        LocalX = -1,
        PrimaryCell = primaryCell,
        AdjacentCell = adjacentCell
      };
      Viewport17RenderCommand leftS3Command =
          CreateViewport17RenderCommand(
              "LeftS3",
              leftS3D2FrontEdge
                  ? "LEFT S3 D2 FRONT EDGE"
                  : leftS3D3FullFrontEdge
                      ? "LEFT S3 D3 FULL FRONT EDGE"
                      : leftS3OpenLeftD3CenterFront
                          ? "LEFT S3 OPEN LEFT D3 CENTER"
                          : "LEFT S3 STRIP",
              "LEFT",
              leftS3Surface);
      leftS3Command.Sequence = commands.Count;
      commands.Add(leftS3Command);
    }

    // RightS3 verified at 11,5 West: exposed far-right edge of a D3 L+C
    // front block with the right lane still open.  This is the handed
    // counterpart family and keeps its own X/Y/mirror controls in ViewEdit.
    bool rightS3D3FrontEdge = IsViewport17RightS3D3FrontEdge(inspection);
    if (rightS3D3FrontEdge)
    {
      Viewport17Cell primaryCell =
          FindViewport17Cell(inspection.Cells, 0, 3);
      Viewport17Cell adjacentCell =
          FindViewport17Cell(inspection.Cells, 1, 3);
      Viewport17Surface rightS3Surface = new Viewport17Surface
      {
        Type = Viewport17SurfaceType.RightSide,
        Depth = 3,
        LocalX = 1,
        PrimaryCell = primaryCell,
        AdjacentCell = adjacentCell
      };
      Viewport17RenderCommand rightS3Command =
          CreateViewport17RenderCommand(
              "RightS3",
              "RIGHT S3 D3 FRONT EDGE",
              "RIGHT",
              rightS3Surface);
      rightS3Command.Sequence = commands.Count;
      commands.Add(rightS3Command);
    }

    // D0 inner faces are nearest and therefore appended last.
    for (int i = 0; i < surfaces.Count; i++)
    {
      Viewport17Surface surface = surfaces[i];
      string pieceFamily = null;

      if (surface.Type == Viewport17SurfaceType.LeftInner)
        pieceFamily = "LeftF0";
      else if (surface.Type == Viewport17SurfaceType.RightInner)
        pieceFamily = "RightF0";

      if (string.IsNullOrEmpty(pieceFamily))
        continue;

      Viewport17RenderCommand innerCommand =
          CreateViewport17RenderCommand(
              pieceFamily,
              "D0 INNER",
              GetViewport17CommandLane(surface),
              surface);
      innerCommand.Sequence = commands.Count;
      commands.Add(innerCommand);
    }

    return commands;
  }

  private bool TryGetViewport17FrontProjectionSlot(
      int depth,
      int localX,
      out Viewport17FrontProjectionSlot slot)
  {
    slot = default;
    if (depth < 1 || depth > 3 || localX < -1 || localX > 1)
      return false;

    bool center = localX == 0;
    bool d3Left = depth == 3 && localX == -1;
    bool d3Right = depth == 3 && localX == 1;
    bool d3Side = d3Left || d3Right;
    string lane = localX < 0 ? "LEFT" : localX > 0 ? "RIGHT" : "CENTER";

    string d3SideSourceWindow = "PENDING";
    string d3SideOriginRule = "PENDING";
    bool d3SideMirror = false;
    string d3SideStatus = "PENDING_LANE_CALIBRATION";

    if (d3Side)
    {
      int sourceStart = Viewport17D3SideLockedSourceX;
      d3SideSourceWindow = "LOCKED_32_FROM_X_" + sourceStart;
      d3SideMirror = d3Left
          ? Viewport17D3LeftLockedMirror
          : Viewport17D3RightCandidateMirror;
      d3SideOriginRule = d3Left
          ? "CROP_LOCKED_32_TO_DEST_X_0_31"
          : "CROP_SYMMETRIC_32_TO_DEST_X_192_223";
      d3SideStatus = d3Left
          ? "LOCKED_D3_LEFT_SOURCE_X_64_MIRROR_OFF"
          : "SYMMETRIC_D3_RIGHT_CANDIDATE_SOURCE_X_64_MIRROR_ON";
    }

    slot = new Viewport17FrontProjectionSlot
    {
      Depth = depth,
      LocalX = localX,
      Lane = lane,
      PieceFamily = "FrontF" + depth,
      UseCanonicalBase = true,

      // CENTER is fully calibrated from the canonical family Ref.
      // D3 LEFT is fully locked from the original reference. D3 RIGHT uses
      // the symmetric candidate slot until an original-game right-side case
      // visually confirms it.
      HasDisplayXOffset = center,
      HasDisplayYOffset = center || d3Side,
      // Calibrated from the original Dungeon Master reference: D1 CENTER
      // FrontF1 sits exactly one pixel right of its canonical ViewEdit Ref.
      // This is a generic depth/lane projection rule, not a map-position fix.
      DisplayOffsetX = center && depth == 1 ? 1 : 0,
      DisplayOffsetY = 0,
      HasClipWindow = d3Side,
      ClipMinX = d3Left ? 0 : d3Right ? 192 : 0,
      ClipMaxX = d3Left ? 31 : d3Right ? 223 : 0,
      ClipMode = center
          ? "NONE"
          : d3Left
              ? "DEST_X_0_31"
              : d3Right
                  ? "DEST_X_192_223"
                  : (localX < 0 ? "LEFT_LANE_PENDING" : "RIGHT_LANE_PENDING"),
      SourceWindowMode = center
          ? "FULL_SOURCE"
          : d3Side
              ? d3SideSourceWindow
              : "PENDING",
      GraphicOriginRule = center
          ? "CANONICAL_REF_X"
          : d3Side
              ? d3SideOriginRule
              : "PENDING",
      HasMirror = d3Side,
      Mirror = d3SideMirror,
      CalibrationStatus = center
          ? (depth == 1
              ? "CALIBRATED_D1_CENTER_X_PLUS_1"
              : "CALIBRATED_CANONICAL_CENTER")
          : d3Side
              ? d3SideStatus
              : "PENDING_LANE_CALIBRATION"
    };

    return true;
  }
 // -------------------------------------------------------------------------
  // Stage 5B: normalize command coordinates.
  //
  // Canonical ViewEdit Ref X/Y are DISPLAY coordinates (top-origin). The
  // existing framebuffer blitters consume X plus a bottom-origin Y. Keep both
  // coordinate spaces explicitly on every command.
  //
  // This still does NOT invent LEFT/RIGHT front-lane projection coordinates.
  // Projected front instances retain their normalized base reference but their
  // actual display/buffer placement remains PENDING.
  // -------------------------------------------------------------------------
  private static bool TryGetViewport17CanonicalReferenceXY(
      string pieceFamily,
      out int x,
      out int displayY)
  {
    // Native DOS F1/F2/F3 coordinates are now the canonical ViewEdit
    // references as well, so ViewEdit cards and the renderer use the same
    // positions that the native blitters actually draw.
    return TryGetCanonicalReferenceXY(pieceFamily, out x, out displayY);
  }

  private bool TryGetViewport17PieceHeight(
      string pieceFamily,
      out int height)
  {
    height = 0;
    if (string.IsNullOrEmpty(pieceFamily))
      return false;

    // FrontF2 is drawn through a special 106x74/224-reference path in the
    // legacy renderer, so graphics.GetTexture(piece.Graphic) can report the
    // placeholder height rather than the actual wall height. Normalize it for
    // Viewport-17 command geometry.
    if (pieceFamily == "FrontF2")
    {
      height = 74;
      return true;
    }

    ViewportPiece piece = FindLayoutPieceByName(pieceFamily);
    if (piece == null)
    {
      switch (pieceFamily)
      {
        case "FrontF1": piece = FindLayoutPieceByName("Front Wall F1"); break;
        case "FrontF2": piece = FindLayoutPieceByName("Front Wall F2"); break;
        case "FrontF3": piece = FindLayoutPieceByName("Front Wall F3"); break;
        case "LeftF0": piece = FindLayoutPieceByName("Wall F0Left"); break;
        case "LeftF1": piece = FindLayoutPieceByName("Wall F1Left"); break;
        case "LeftF2": piece = FindLayoutPieceByName("Wall F2Left"); break;
        case "LeftF3": piece = FindLayoutPieceByName("Wall F3Left"); break;
        case "RightF0": piece = FindLayoutPieceByName("Wall F0Right"); break;
        case "RightF1": piece = FindLayoutPieceByName("Wall F1Right"); break;
        case "RightF2": piece = FindLayoutPieceByName("Wall F2Right"); break;
        case "RightF3": piece = FindLayoutPieceByName("Wall F3Right"); break;
        case "LeftD3": piece = FindLayoutPieceByName("Wall D3L2"); break;
        case "RightD3": piece = FindLayoutPieceByName("Wall D3R2"); break;
      }
    }

    if (piece == null)
      return false;

    height = GetPieceHeightForEditorY(piece);
    return height > 0;
  }

  private bool TryGetViewport17PieceWidth(
      string pieceFamily,
      out int width)
  {
    width = 0;
    if (string.IsNullOrEmpty(pieceFamily))
      return false;

    // FrontF2 has a special legacy reference path. Its native source is 106px
    // wide; Stage 6C only needs FrontF3, but keeping this explicit prevents
    // future command calibration from reading a placeholder texture width.
    if (pieceFamily == "FrontF2")
    {
      width = 106;
      return true;
    }

    ViewportPiece piece = FindLayoutPieceByName(pieceFamily);
    if (piece == null)
    {
      switch (pieceFamily)
      {
        case "FrontF1": piece = FindLayoutPieceByName("Front Wall F1"); break;
        case "FrontF2": piece = FindLayoutPieceByName("Front Wall F2"); break;
        case "FrontF3": piece = FindLayoutPieceByName("Front Wall F3"); break;
        case "LeftF0": piece = FindLayoutPieceByName("Wall F0Left"); break;
        case "LeftF1": piece = FindLayoutPieceByName("Wall F1Left"); break;
        case "LeftF2": piece = FindLayoutPieceByName("Wall F2Left"); break;
        case "LeftF3": piece = FindLayoutPieceByName("Wall F3Left"); break;
        case "RightF0": piece = FindLayoutPieceByName("Wall F0Right"); break;
        case "RightF1": piece = FindLayoutPieceByName("Wall F1Right"); break;
        case "RightF2": piece = FindLayoutPieceByName("Wall F2Right"); break;
        case "RightF3": piece = FindLayoutPieceByName("Wall F3Right"); break;
        case "LeftD3": piece = FindLayoutPieceByName("Wall D3L2"); break;
        case "RightD3": piece = FindLayoutPieceByName("Wall D3R2"); break;
      }
    }

    if (piece == null || graphics == null)
      return false;

    if (pieceFamily == "FrontF1")
    {
      width = 160;
      return true;
    }

    Texture2D texture = graphics.GetTexture(piece.Graphic);
    if (texture == null || texture.width <= 0)
      return false;

    width = texture.width;
    return true;
  }

  private void ResolveViewport17RenderCommandStage6(
      ref Viewport17RenderCommand command)
  {
    command.HasBaseReference = false;
    command.HasPieceMetrics = false;
    command.HasPieceWidth = false;
    command.HasBaseBufferReference = false;
    command.HasDisplayPlacement = false;
    command.HasBufferPlacement = false;
    command.HasProjectedDisplayY = false;
    command.HasProjectedBufferY = false;
    command.HasProjectedGraphicOriginX = false;
    command.HasSourceWindow = false;
    command.SourceMinX = 0;
    command.SourceMaxX = 0;
    command.SourceWindowMode = "PENDING";
    command.HasMirror = false;
    command.ClipMode = "PENDING";
    command.ResolutionNote = string.Empty;

    if (TryGetViewport17CanonicalReferenceXY(
            command.PieceFamily, out int refX, out int refDisplayY))
    {
      command.HasBaseReference = true;
      command.BaseReferenceX = refX;
      command.BaseReferenceY = refDisplayY;
    }

    if (TryGetViewport17PieceHeight(command.PieceFamily, out int pieceHeight))
    {
      command.HasPieceMetrics = true;
      command.PieceHeight = pieceHeight;
    }

    if (TryGetViewport17PieceWidth(command.PieceFamily, out int pieceWidth))
    {
      command.HasPieceWidth = true;
      command.PieceWidth = pieceWidth;
    }

    if (command.HasBaseReference && command.HasPieceMetrics)
    {
      command.HasBaseBufferReference = true;
      command.BaseBufferX = command.BaseReferenceX;
      command.BaseBufferY = DisplayYToUnityY(
          command.BaseReferenceY,
          command.PieceHeight);
    }

    bool isFront = command.SurfaceType == Viewport17SurfaceType.Front;

    if (isFront)
    {
      // Stage 6Q front-composite decisions group L/C/R occupancy at a depth
      // into one FrontF family command. FULL/CENTER compositions can already
      // use the canonical center projection. Partial multi-lane masks retain
      // their canonical Y but leave exact X/crop composition for the next
      // projection stage.
      if (command.IsFrontComposite)
      {
        string mask = string.IsNullOrEmpty(command.FrontMask)
            ? "NONE"
            : command.FrontMask;

        command.ClipMode = "FRONT_COMPOSITE_MASK_" + mask;
        command.SourceWindowMode = "COMPOSITE_BY_MASK_" + mask;

        if (command.HasBaseReference && command.HasPieceMetrics)
        {
          command.HasProjectedDisplayY = true;
          command.ProjectedDisplayY = command.BaseReferenceY;
          command.HasProjectedBufferY = true;
          command.ProjectedBufferY = DisplayYToUnityY(
              command.ProjectedDisplayY,
              command.PieceHeight);
        }

        bool canonicalFullOrCenter =
            mask == "LCR"
            || mask == "C";

        if (canonicalFullOrCenter
            && TryGetViewport17FrontProjectionSlot(
                command.Depth, 0, out var centerSlot)
            && centerSlot.UseCanonicalBase
            && centerSlot.HasDisplayXOffset
            && centerSlot.HasDisplayYOffset
            && command.HasBaseReference
            && command.HasPieceMetrics)
        {
          command.HasDisplayPlacement = true;
          command.DisplayX =
              command.BaseReferenceX + centerSlot.DisplayOffsetX;
          command.DisplayY =
              command.BaseReferenceY + centerSlot.DisplayOffsetY;
          command.HasBufferPlacement = true;
          command.BufferX = command.DisplayX;
          command.BufferY = DisplayYToUnityY(
              command.DisplayY,
              command.PieceHeight);
          command.SourceWindowMode =
              mask == "LCR" ? "FULL_COMPOSITE" : "CENTER_ONLY";
          command.ClipMode =
              mask == "LCR" ? "NONE" : "CENTER_COMPOSITE";
          command.ResolutionNote =
              "front occupancy grouped into one "
              + command.PieceFamily
              + " composition; mask=" + mask
              + "; canonical center projection";
        }
        else
        {
          command.ResolutionNote =
              "front occupancy grouped into one "
              + command.PieceFamily
              + " composition; mask=" + mask
              + "; exact partial composite X/crop still pending";
        }
      }
      else if (TryGetViewport17FrontProjectionSlot(
              command.Depth, command.LocalX, out var slot))
      {
        command.ClipMode = slot.HasClipWindow
            ? "DEST_X_[" + slot.ClipMinX + ".." + slot.ClipMaxX + "]"
            : slot.ClipMode;
        command.SourceWindowMode = slot.SourceWindowMode;

        if (slot.HasMirror)
        {
          command.HasMirror = true;
          command.Mirror = slot.Mirror;
        }

        if (slot.UseCanonicalBase
            && slot.HasDisplayYOffset
            && command.HasBaseReference
            && command.HasPieceMetrics)
        {
          command.HasProjectedDisplayY = true;
          command.ProjectedDisplayY = command.BaseReferenceY + slot.DisplayOffsetY;
          command.HasProjectedBufferY = true;
          command.ProjectedBufferY = DisplayYToUnityY(
              command.ProjectedDisplayY,
              command.PieceHeight);
        }

        // Stage 6P D3 side-strip projection. D3 LEFT is fully locked; D3 RIGHT
        // uses the symmetric candidate. Both use the same 32px FrontF3 source
        // window and independent destination bands.
        bool d3SideCandidate = command.Depth == 3
            && (command.LocalX == -1 || command.LocalX == 1)
            && slot.SourceWindowMode.StartsWith("LOCKED_32_FROM_X_");
        if (d3SideCandidate
            && slot.HasClipWindow
            && command.HasPieceWidth
            && command.HasProjectedDisplayY
            && command.HasProjectedBufferY)
        {
          int visibleWidth = slot.ClipMaxX - slot.ClipMinX + 1;
          visibleWidth = Mathf.Clamp(visibleWidth, 1, command.PieceWidth);
          int maxSourceStart = Mathf.Max(0, command.PieceWidth - visibleWidth);
          int sourceStart = Mathf.Clamp(Viewport17D3SideLockedSourceX, 0, maxSourceStart);

          command.HasSourceWindow = true;
          command.SourceMinX = sourceStart;
          command.SourceMaxX = sourceStart + visibleWidth - 1;

          // This is now a true cropped-strip command, not a shifted full graphic.
          // Its destination origin is the calibrated lane band itself.
          command.HasProjectedGraphicOriginX = true;
          command.ProjectedGraphicOriginX = slot.ClipMinX;

          command.HasDisplayPlacement = true;
          command.DisplayX = slot.ClipMinX;
          command.DisplayY = command.ProjectedDisplayY;
          command.HasBufferPlacement = true;
          command.BufferX = slot.ClipMinX;
          command.BufferY = command.ProjectedBufferY;
          command.SourceWindowMode =
              "SRC_X_[" + command.SourceMinX + ".." + command.SourceMaxX + "]"
              + (slot.Mirror ? "_MIRROR_ON" : "_MIRROR_OFF");
        }

        if (slot.UseCanonicalBase
            && slot.HasDisplayXOffset
            && slot.HasDisplayYOffset
            && command.HasBaseReference
            && command.HasPieceMetrics)
        {
          command.HasDisplayPlacement = true;
          command.DisplayX = command.BaseReferenceX + slot.DisplayOffsetX;
          command.DisplayY = command.BaseReferenceY + slot.DisplayOffsetY;

          command.HasBufferPlacement = true;
          command.BufferX = command.DisplayX;
          command.BufferY = DisplayYToUnityY(
              command.DisplayY,
              command.PieceHeight);
        }

        command.ResolutionNote =
            "projectionSlot=D" + slot.Depth + "/" + slot.Lane
            + " status=" + slot.CalibrationStatus
            + (d3SideCandidate && command.HasSourceWindow
                ? (command.LocalX < 0
                    ? "; D3 LEFT locked: source X 64..95 -> destination X 0..31, mirror OFF"
                    : "; D3 RIGHT symmetric candidate: source X 64..95 -> destination X 192..223, mirror ON")
                : command.HasDisplayPlacement
                    ? "; canonical base + calibrated lane offset"
                    : command.HasProjectedDisplayY
                        ? "; destination Y/clip calibrated; graphic-origin X/source window still pending"
                        : "; normalized base Ref known; lane placement/clip still pending");
      }
      else
      {
        command.ResolutionNote = "front projection slot unavailable";
      }
    }
    else if (command.HasBaseBufferReference)
    {
      command.HasDisplayPlacement = true;
      command.DisplayX = command.BaseReferenceX;
      command.DisplayY = command.BaseReferenceY;
      command.HasBufferPlacement = true;
      command.BufferX = command.BaseBufferX;
      command.BufferY = command.BaseBufferY;
      command.ClipMode = "NONE";
      command.SourceWindowMode = "FULL_SOURCE";
      command.ResolutionNote =
          "canonical piece reference; display/buffer normalized";
    }

    // Outer LeftD3 has two geometry-driven horizontal placements. When the
    // leading D3 strip is visible it keeps the canonical X=0 placement. When
    // that outer-left map tile is solid/non-active, the oblique bitmap is
    // shifted 9 pixels left. This is the same distinction exposed in ViewEdit
    // and keeps opening-at-D3 cases such as the verified 2,7 North geometry
    // on their existing X=0 path.
    if (command.PieceFamily == "LeftD3" && command.HasPieceMetrics)
    {
      int leftD3DisplayX = HasLeftD3LeadingStripActiveTile() ? 0 : -9;
      int leftD3DisplayY = 58;
      command.HasDisplayPlacement = true;
      command.DisplayX = leftD3DisplayX;
      command.DisplayY = leftD3DisplayY;
      command.HasBufferPlacement = true;
      command.BufferX = leftD3DisplayX;
      command.BufferY = DisplayYToUnityY(
          leftD3DisplayY,
          command.PieceHeight);
      command.ClipMode = "NONE";
      command.SourceWindowMode = "FULL_SOURCE";
    }

    bool ordinarySideFamily =
        command.PieceFamily == "LeftF0"
        || command.PieceFamily == "RightF0"
        || command.PieceFamily == "LeftF1"
        || command.PieceFamily == "RightF1"
        || command.PieceFamily == "LeftF2"
        || command.PieceFamily == "RightF2"
        || command.PieceFamily == "RightF3";

    if (command.PieceFamily == "LeftF3")
    {
      command.HasMirror = true;
      command.Mirror = GetViewport17LeftF3Mirror();
    }
    else if (ordinarySideFamily)
    {
      command.HasMirror = true;
      command.Mirror = GetSideWallMirrorFromPose();
    }
    else if (command.PieceFamily == "LeftD3"
        || command.PieceFamily == "RightD3")
    {
      command.HasMirror = true;
      command.Mirror = GetViewport17D3OuterMirror(
          command.PieceFamily == "RightD3");
    }
  }
  // -------------------------------------------------------------------------
  // Stage 6S: final draw decision from the generic Viewport-17 geometry.
  //
  // BuildViewport17RenderCommands() deliberately emits far->near candidates.
  // This pass performs geometry-only visibility reduction:
  //   * for each front lane (L/C/R), only the nearest real front wall survives;
  //   * a nearer center front hides farther INNER corridor sides (LeftF/RightF).
  //     Those faces sit on the corridor the center wall just closed;
  //   * OUTER D3 sides (LeftD3/RightD3) are the wall faces seen through the
  //     32px left/right openings that a center FrontF1/F2 does not cover.
  //     A center front must not hide them; a nearer same-lane front does;
  //     a surviving nearer same-side inner wall (F0/F1/F2) also hides them
  //     because that graphic already covers the 32px band;
  //   * a nearer front in a side lane hides farther same-side surfaces;
  //   * D0 inner faces (LeftF0/RightF0) do NOT hide F1/F2/F3 corridor sides;
  //   * a spanning D3 inner third beside an open D2 side and a surviving D3
  //     center remains LeftF3/RightF3; opposite-lane openness does not hide it.
  //
  // A front composite may therefore survive with a smaller mask.
  // Partial D3 L/R occupancy beside a hidden D3 center is LeftF3/RightF3,
  // not leftover FrontF3 edge strips. A FULL D3 L+C+R front plane still
  // owns its visible 32px L/R FrontF3 strips when that lane is open
  // through nearer depths (nearest same-lane front is still D3).
  // No map coordinate or pose exception is used here.
  // -------------------------------------------------------------------------
  private static bool IsViewport17OuterSideCommand(
      Viewport17RenderCommand command)
  {
    if (command.PieceFamily == "LeftD3" || command.PieceFamily == "RightD3")
      return true;

    if (command.SurfaceType == Viewport17SurfaceType.LeftSide
        && command.LocalX <= -2)
    {
      return true;
    }

    if (command.SurfaceType == Viewport17SurfaceType.RightSide
        && command.LocalX >= 2)
    {
      return true;
    }

    return false;
  }

  private static List<Viewport17RenderCommand> BuildViewport17FinalDrawCommands(
      Viewport17Inspection inspection)
  {
    List<Viewport17RenderCommand> candidates =
        BuildViewport17RenderCommands(inspection);
    List<Viewport17RenderCommand> finalCommands =
        new List<Viewport17RenderCommand>(candidates.Count);

    int nearestLeftFront = int.MaxValue;
    int nearestCenterFront = int.MaxValue;
    int nearestRightFront = int.MaxValue;

    for (int i = 0; i < candidates.Count; i++)
    {
      Viewport17RenderCommand command = candidates[i];

      if (!command.IsFrontComposite)
        continue;

      if (command.FrontLeft)
        nearestLeftFront = Mathf.Min(nearestLeftFront, command.Depth);
      if (command.FrontCenter)
        nearestCenterFront = Mathf.Min(nearestCenterFront, command.Depth);
      if (command.FrontRight)
        nearestRightFront = Mathf.Min(nearestRightFront, command.Depth);
    }

    for (int i = 0; i < candidates.Count; i++)
    {
      Viewport17RenderCommand command = candidates[i];

      if (command.IsFrontComposite)
      {
        bool keepLeft = command.FrontLeft
            && command.Depth == nearestLeftFront;
        bool keepCenter = command.FrontCenter
            && command.Depth == nearestCenterFront;
        bool keepRight = command.FrontRight
            && command.Depth == nearestRightFront;

        // Partial D3 L/R beside a hidden D3 center is LeftF3/RightF3.
        // A full D3 L+C+R front keeps its 32px L/R FrontF3 strips when
        // that lane is still the nearest front (open through D1/D2).
        bool fullD3Front = command.Depth == 3
            && command.FrontLeft
            && command.FrontCenter
            && command.FrontRight;
        if (command.Depth == 3 && !keepCenter && !fullD3Front)
        {
          keepLeft = false;
          keepRight = false;
        }

        if (!keepLeft && !keepCenter && !keepRight)
          continue;

        command.FrontLeft = keepLeft;
        command.FrontCenter = keepCenter;
        command.FrontRight = keepRight;
        command.FrontMask = BuildViewport17FrontMask(
            keepLeft, keepCenter, keepRight);
        command.Projection = "COMPOSITE " + command.FrontMask;
        command.Sequence = finalCommands.Count;
        finalCommands.Add(command);
        continue;
      }

      bool leftSide = command.SurfaceType == Viewport17SurfaceType.LeftSide;
      bool rightSide = command.SurfaceType == Viewport17SurfaceType.RightSide;
      bool outerSide = IsViewport17OuterSideCommand(command);

      // The verified 10,5-East LeftS3 strip is the exposed edge of the D2
      // C+R front block. A nearer center front at D2 is exactly what creates
      // this sliver, so the normal inner-side occlusion rule must not remove it.
      if (command.PieceFamily == "LeftS3"
          && (IsViewport17LeftS3D2FrontEdge(inspection)
              || IsViewport17LeftS3D3FullFrontEdge(inspection)
              || IsViewport17LeftS3OpenLeftD3CenterFront(inspection)))
      {
        command.Sequence = finalCommands.Count;
        finalCommands.Add(command);
        continue;
      }

      // The verified 11,5-West RightS3 strip is the exposed edge of the D3
      // L+C front block.  Preserve it before generic side occlusion removes
      // the distant side command.
      if (command.PieceFamily == "RightS3"
          && IsViewport17RightS3D3FrontEdge(inspection))
      {
        command.Sequence = finalCommands.Count;
        finalCommands.Add(command);
        continue;
      }

      bool rightD3F0Sliver =
          command.PieceFamily == "RightD3"
          && IsViewport17RightD3F0Sliver(inspection);
      bool rightD3OuterCorridorSliver =
          command.PieceFamily == "RightD3"
          && IsViewport17RightD3OuterCorridorSliver(inspection);

      if (leftSide)
      {
        if (nearestLeftFront < command.Depth)
          continue;
        // Inner corridor sides sit behind a nearer center wall. Outer D3
        // faces are drawn in the uncovered 32px side opening instead.
        if (!outerSide && nearestCenterFront < command.Depth)
        {
          bool f2VisiblePastD1Center =
              IsViewport17F2SideVisiblePastD1CenterFront(inspection, command);
          if (command.Depth != 3 && !f2VisiblePastD1Center)
            continue;
        }
        if (!outerSide && IsViewport17OccludedInnerSide(inspection, command))
          continue;
        if (outerSide
            && IsViewport17OuterSideHiddenByNearerInner(
                inspection,
                candidates,
                command,
                nearestLeftFront,
                nearestCenterFront,
                nearestRightFront))
        {
          continue;
        }
      }
      else if (rightSide)
      {
        if (nearestRightFront < command.Depth)
          continue;
        if (!outerSide && nearestCenterFront < command.Depth)
        {
          bool f2VisiblePastD1Center =
              IsViewport17F2SideVisiblePastD1CenterFront(inspection, command);
          if (command.Depth != 3 && !f2VisiblePastD1Center)
            continue;
        }
        if (!outerSide && IsViewport17OccludedInnerSide(inspection, command))
          continue;
        if (outerSide
            && !rightD3F0Sliver
            && !rightD3OuterCorridorSliver
            && IsViewport17OuterSideHiddenByNearerInner(
                inspection,
                candidates,
                command,
                nearestLeftFront,
                nearestCenterFront,
                nearestRightFront))
        {
          continue;
        }
      }

      // D0 inner commands always survive. They are the nearest side boundary
      // and do not occlude the receding F1/F2/F3 corridor sides.
      command.Sequence = finalCommands.Count;
      finalCommands.Add(command);
    }

    return finalCommands;
  }

  private bool IsViewport17WallAuthorityActive()
  {
    // Viewport 17 owns the automatic wall decision in edit mode. All Walls
    // only changes which cards are listed; it must not change the dungeon view.
    return !Application.isPlaying;
  }

  private HashSet<string> BuildViewport17FinalPieceFamilySet()
  {
    Viewport17Inspection inspection = BuildViewport17Inspection();
    List<Viewport17RenderCommand> finalCommands =
        BuildViewport17FinalDrawCommands(inspection);
    HashSet<string> families = new HashSet<string>(System.StringComparer.Ordinal);

    for (int i = 0; i < finalCommands.Count; i++)
    {
      string family = finalCommands[i].PieceFamily;
      if (!string.IsNullOrEmpty(family))
        families.Add(family);
    }

    return families;
  }

  private static string GetViewport17NormalWallFamily(ViewportPiece piece)
  {
    if (piece == null)
      return string.Empty;

    if (IsFrontWallF1Card(piece)) return "FrontF1";
    if (IsFrontWallF2Card(piece)) return "FrontF2";
    if (IsFrontWallF3Card(piece)) return "FrontF3";
    if (IsWallF0LeftPiece(piece)) return "LeftF0";
    if (IsWallF0RightPiece(piece)) return "RightF0";
    if (IsWallF1LeftPiece(piece)) return "LeftF1";
    if (IsWallF1RightPiece(piece)) return "RightF1";
    if (IsWallF2LeftPiece(piece)) return "LeftF2";
    if (IsWallF2RightPiece(piece)) return "RightF2";
    if (IsWallF3LeftPiece(piece)) return "LeftF3";
    if (IsWallF3RightPiece(piece)) return "RightF3";

    if (piece.Name == "LeftD3"
        || piece.Name == "Wall D3L2"
        || piece.Graphic == DungeonGraphicType.WallD3L2)
      return "LeftD3";

    if (piece.Name == "RightD3"
        || piece.Name == "Wall D3R2"
        || piece.Graphic == DungeonGraphicType.WallD3R2)
      return "RightD3";

    if (piece.Name == "LeftS3")
      return "LeftS3";

    if (piece.Name == "RightS3")
      return "RightS3";

    return string.Empty;
  }

  private static bool IsViewport17NormalWallSelected(
      ViewportPiece piece,
      List<Viewport17RenderCommand> finalCommands)
  {
    if (piece == null || finalCommands == null)
      return false;

    string family = GetViewport17NormalWallFamily(piece);
    if (string.IsNullOrEmpty(family))
      return false;

    bool isFrontFamily =
        family == "FrontF1"
        || family == "FrontF2"
        || family == "FrontF3";

    for (int i = 0; i < finalCommands.Count; i++)
    {
      Viewport17RenderCommand command = finalCommands[i];
      if (!string.Equals(
              command.PieceFamily,
              family,
              System.StringComparison.Ordinal))
      {
        continue;
      }

      // FrontF1/F2 ViewEdit cards are CENTER projections. Their L/R occupancy
      // is drawn as the side-wall graphic, so only C selects the front card.
      // FrontF3 is one native source image: a surviving L or R strip is still
      // that FrontF3 image, so the FrontF3 card must stay selected/enabled.
      if (family == "FrontF3")
      {
        return command.IsFrontComposite
            && (command.FrontLeft || command.FrontCenter || command.FrontRight);
      }

      if (isFrontFamily)
        return command.IsFrontComposite && command.FrontCenter;

      // Side-wall and D3 families remain a direct family match.
      return true;
    }

    return false;
  }


  private static bool HasViewport17FinalFamily(
      List<Viewport17RenderCommand> finalCommands,
      string pieceFamily)
  {
    if (finalCommands == null || string.IsNullOrEmpty(pieceFamily))
      return false;

    for (int i = 0; i < finalCommands.Count; i++)
    {
      if (string.Equals(
              finalCommands[i].PieceFamily,
              pieceFamily,
              System.StringComparison.Ordinal))
      {
        return true;
      }
    }

    return false;
  }

  private static void GetViewport17FinalFrontLanes(
      List<Viewport17RenderCommand> finalCommands,
      int depth,
      out bool left,
      out bool center,
      out bool right)
  {
    left = false;
    center = false;
    right = false;

    if (finalCommands == null)
      return;

    for (int i = 0; i < finalCommands.Count; i++)
    {
      Viewport17RenderCommand command = finalCommands[i];
      if (!command.IsFrontComposite || command.Depth != depth)
        continue;

      left |= command.FrontLeft;
      center |= command.FrontCenter;
      right |= command.FrontRight;
    }
  }
  private static string FormatRelativeViewportCell(RelativeViewportCell cell)
  {
    return cell.IsInside
        ? cell.Type + " (" + cell.X + "," + cell.Y + ")"
        : "OUT (" + cell.X + "," + cell.Y + ")";
  }

  private static string FormatRelativeViewportCellShort(RelativeViewportCell cell)
  {
    if (!cell.IsInside)
      return "X";

    if (IsViewEditGeometryWall(cell))
      return "W";

    string type = cell.Type.ToString();
    if (type.IndexOf("STONE", System.StringComparison.OrdinalIgnoreCase) >= 0
        || type.IndexOf("WALL", System.StringComparison.OrdinalIgnoreCase) >= 0)
      return "W";

    if (type.IndexOf("DOOR", System.StringComparison.OrdinalIgnoreCase) >= 0)
      return "D";

    if (type.IndexOf("PIT", System.StringComparison.OrdinalIgnoreCase) >= 0)
      return "P";

    if (type.IndexOf("STAIR", System.StringComparison.OrdinalIgnoreCase) >= 0)
      return "S";

    if (type.IndexOf("TELE", System.StringComparison.OrdinalIgnoreCase) >= 0)
      return "T";

    if (type.IndexOf("FALSE", System.StringComparison.OrdinalIgnoreCase) >= 0)
      return "F";

    return "O";
  }

  private string BuildViewportGeometryOverlayText()
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null)
      return "GEOM: NO MAP";

    RelativeViewportGeometry g =
        RelativeViewportGeometry.Calculate(
            previewMiniMap,
            previewX,
            previewY,
            previewFacing);

    return "F0 L" + FormatRelativeViewportCellShort(g.F0Left)
        + " R" + FormatRelativeViewportCellShort(g.F0Right)
        + "\nF1 L" + FormatRelativeViewportCellShort(g.F1Left)
        + " C" + FormatRelativeViewportCellShort(g.F1Center)
        + " R" + FormatRelativeViewportCellShort(g.F1Right)
        + "\nF2 L" + FormatRelativeViewportCellShort(g.F2Left)
        + " C" + FormatRelativeViewportCellShort(g.F2Center)
        + " R" + FormatRelativeViewportCellShort(g.F2Right)
        + "\nF3 L" + FormatRelativeViewportCellShort(g.F3Left)
        + " C" + FormatRelativeViewportCellShort(g.F3Center)
        + " R" + FormatRelativeViewportCellShort(g.F3Right);
  }
  private void DrawPreviewMiniMap()
  {
    // When hidden, reserve no minimap layout space at all. The Show/Hide Map
    // button lives in DrawSnapToolbar(), which remains visible.
    if (previewMiniMapMuted)
      return;

    EditorGUILayout.Space();
    EnsurePreviewMiniMapLoaded();

    if (previewMiniMap == null)
    {
      EditorGUILayout.HelpBox(
          string.IsNullOrEmpty(previewMiniMapLoadError)
              ? "Could not load Hall of Champions map."
              : previewMiniMapLoadError,
          MessageType.Warning);
      return;
    }

    // Keep minimap arrow on the same previewFacing as viewport + Console.
    previewMiniMap.SetPlayerPose(previewX, previewY, previewFacing);

    // The minimap owns the full ViewEdit width. Do not reserve space for the
    // old 3x2 movement pad; keyboard and Game View navigation remain active.
    // Giving DungeonMiniMapGui all available width also prevents the map from
    // being artificially clipped by the old fixed 300 px column.
    EditorGUILayout.BeginVertical(GUILayout.ExpandWidth(true));

    DrawPreviewMiniMapWithoutScrollbars();

    EditorGUILayout.EndVertical();
  }

  private void DrawPreviewMiniMapWithoutScrollbars()
  {
    if (previewMiniMap == null)
      return;

    // ViewEdit map overview is deliberately non-scrollable. Keep every map
    // cell visible at once; scrolling is reserved for the wall/feature editor
    // controls below the overview.
    const float CellSize = 14f;
    const float AxisSize = 18f;

    float gridWidth = previewMiniMap.Width * CellSize;
    float gridHeight = previewMiniMap.Height * CellSize;
    float totalWidth = AxisSize + gridWidth;
    float totalHeight = AxisSize + gridHeight;

    Rect outer = GUILayoutUtility.GetRect(
        totalWidth,
        totalHeight,
        GUILayout.Width(totalWidth),
        GUILayout.Height(totalHeight),
        GUILayout.ExpandWidth(false),
        GUILayout.ExpandHeight(false));
    NoteContentRight(outer);

    Rect grid = new Rect(
        outer.x + AxisSize,
        outer.y + AxisSize,
        gridWidth,
        gridHeight);

    GUIStyle axisStyle = new GUIStyle(EditorStyles.miniLabel)
    {
      alignment = TextAnchor.MiddleCenter,
      fontSize = 9,
      clipping = TextClipping.Overflow
    };

    GUIStyle cellTextStyle = new GUIStyle(EditorStyles.miniBoldLabel)
    {
      alignment = TextAnchor.MiddleCenter,
      fontSize = 9,
      clipping = TextClipping.Clip
    };

    for (int x = 0; x < previewMiniMap.Width; x++)
    {
      GUI.Label(
          new Rect(
              grid.x + x * CellSize,
              outer.y,
              CellSize,
              AxisSize),
          x.ToString(),
          axisStyle);
    }

    for (int y = 0; y < previewMiniMap.Height; y++)
    {
      GUI.Label(
          new Rect(
              outer.x,
              grid.y + y * CellSize,
              AxisSize,
              CellSize),
          y.ToString(),
          axisStyle);
    }

    Event current = Event.current;

    for (int y = 0; y < previewMiniMap.Height; y++)
    {
      for (int x = 0; x < previewMiniMap.Width; x++)
      {
        Rect cellRect = new Rect(
            grid.x + x * CellSize,
            grid.y + y * CellSize,
            CellSize,
            CellSize);

        DungeonTile tile = previewMiniMap.GetTile(x, y);
        bool wall = tile == null || tile.Type == DungeonTileType.Wall;

        EditorGUI.DrawRect(cellRect, new Color(0.07f, 0.07f, 0.07f, 1f));
        Rect fillRect = new Rect(
            cellRect.x + 1f,
            cellRect.y + 1f,
            cellRect.width - 1f,
            cellRect.height - 1f);
        EditorGUI.DrawRect(
            fillRect,
            wall
                ? new Color(0.22f, 0.22f, 0.22f, 1f)
                : new Color(0.78f, 0.78f, 0.78f, 1f));

        string marker = null;
        Color markerColor = Color.black;
        bool drawFacingTriangle = false;

        if (x == previewX && y == previewY)
        {
          drawFacingTriangle = true;
          markerColor = new Color(0f, 1f, 0f, 1f);
        }
        else if (tile != null && tile.TryGetStairsDirection(out bool stairsUp))
        {
          marker = stairsUp ? "U" : "D";
          markerColor = stairsUp ? Color.blue : new Color(0.65f, 0f, 0f, 1f);
        }
        else if (x == previewMiniMap.EntranceX && y == previewMiniMap.EntranceY)
        {
          marker = "E";
          markerColor = Color.red;
        }

        if (drawFacingTriangle)
        {
          DrawPreviewFacingTriangle(fillRect, previewFacing, markerColor);
        }
        else if (!string.IsNullOrEmpty(marker))
        {
          Color saved = GUI.contentColor;
          GUI.contentColor = markerColor;
          GUI.Label(cellRect, marker, cellTextStyle);
          GUI.contentColor = saved;
        }

        if (current.type == EventType.MouseDown
            && current.button == 0
            && cellRect.Contains(current.mousePosition)
            && previewMiniMap.CanEnter(x, y))
        {
          ApplyPreviewPoseFromMiniMapClick(x, y);
          current.Use();
          GUI.changed = true;
          Repaint();
        }
      }
    }
  }

  private static void DrawPreviewFacingTriangle(
      Rect fillRect,
      DungeonFacing facing,
      Color color)
  {
    float pad = Mathf.Max(1.5f, Mathf.Min(fillRect.width, fillRect.height) * 0.16f);
    float left = fillRect.x + pad;
    float right = fillRect.xMax - pad;
    float top = fillRect.y + pad;
    float bottom = fillRect.yMax - pad;
    float centerX = fillRect.center.x;
    float centerY = fillRect.center.y;

    Vector3[] points;
    switch (facing)
    {
      case DungeonFacing.North:
        points = new[]
        {
          new Vector3(centerX, top, 0f),
          new Vector3(right, bottom, 0f),
          new Vector3(left, bottom, 0f)
        };
        break;
      case DungeonFacing.East:
        points = new[]
        {
          new Vector3(right, centerY, 0f),
          new Vector3(left, top, 0f),
          new Vector3(left, bottom, 0f)
        };
        break;
      case DungeonFacing.South:
        points = new[]
        {
          new Vector3(centerX, bottom, 0f),
          new Vector3(left, top, 0f),
          new Vector3(right, top, 0f)
        };
        break;
      default: // West
        points = new[]
        {
          new Vector3(left, centerY, 0f),
          new Vector3(right, bottom, 0f),
          new Vector3(right, top, 0f)
        };
        break;
    }

    Handles.BeginGUI();
    Color previousColor = Handles.color;
    Handles.color = color;
    Handles.DrawAAConvexPolygon(points);

    Vector3[] outlinePoints = new[]
    {
      points[0],
      points[1],
      points[2],
      points[0]
    };

    Handles.color = new Color(1f, 0f, 0f, 1f);
    Handles.DrawAAPolyLine(1.0f, outlinePoints);

    Handles.color = previousColor;
    Handles.EndGUI();
  }

  private void DrawPreviewNavigationPad()
  {
    using (new EditorGUI.DisabledScope(Application.isPlaying || layout == null))
    {
      Texture2D arrowsTexture = graphics != null
          ? graphics.GetTexture(DungeonGraphicType.MovementArrows)
          : null;

      // Edit Mode only: draw the real Dungeon Master movement-arrow graphic
      // and place six invisible hit regions directly over its 3x2 cells.
      // Every mouse region calls the exact same navigation methods used by
      // the existing keyboard/editor controls, so there is only one movement
      // path to maintain.
      if (arrowsTexture != null)
      {
        float drawWidth = Mathf.Min(96f, arrowsTexture.width);
        float drawHeight = arrowsTexture.height * (drawWidth / arrowsTexture.width);
        Rect padRect = GUILayoutUtility.GetRect(
            drawWidth,
            drawHeight,
            GUILayout.Width(drawWidth),
            GUILayout.Height(drawHeight));

        GUI.DrawTexture(
            padRect,
            arrowsTexture,
            ScaleMode.StretchToFill,
            true);

        float cellWidth = padRect.width / 3f;
        float cellHeight = padRect.height / 2f;

        Rect turnLeftRect = new Rect(
            padRect.x, padRect.y, cellWidth, cellHeight);
        Rect forwardRect = new Rect(
            padRect.x + cellWidth, padRect.y, cellWidth, cellHeight);
        Rect turnRightRect = new Rect(
            padRect.x + cellWidth * 2f, padRect.y, cellWidth, cellHeight);
        Rect strafeLeftRect = new Rect(
            padRect.x, padRect.y + cellHeight, cellWidth, cellHeight);
        Rect backwardRect = new Rect(
            padRect.x + cellWidth, padRect.y + cellHeight, cellWidth, cellHeight);
        Rect strafeRightRect = new Rect(
            padRect.x + cellWidth * 2f,
            padRect.y + cellHeight,
            cellWidth,
            cellHeight);

        Event current = Event.current;
        if (current.type == EventType.MouseDown
            && current.button == 0
            && padRect.Contains(current.mousePosition))
        {
          if (turnLeftRect.Contains(current.mousePosition))
            PreviewNavigateTurnLeft();
          else if (forwardRect.Contains(current.mousePosition))
            PreviewNavigateMoveForward();
          else if (turnRightRect.Contains(current.mousePosition))
            PreviewNavigateTurnRight();
          else if (strafeLeftRect.Contains(current.mousePosition))
            PreviewNavigateStrafeLeft();
          else if (backwardRect.Contains(current.mousePosition))
            PreviewNavigateMoveBackward();
          else if (strafeRightRect.Contains(current.mousePosition))
            PreviewNavigateStrafeRight();

          current.Use();
          TryRefocusPreviewWindow();
          Repaint();
        }

        return;
      }

      // Fallback only if the movement-arrow texture is unavailable.
      const float buttonWidth = 28f;
      const float buttonHeight = 22f;

      EditorGUILayout.BeginHorizontal();
      if (GUILayout.Button(
              "↶",
              GUILayout.Width(buttonWidth),
              GUILayout.Height(buttonHeight)))
      {
        PreviewNavigateTurnLeft();
        TryRefocusPreviewWindow();
      }

      if (GUILayout.Button(
              "↑",
              GUILayout.Width(buttonWidth),
              GUILayout.Height(buttonHeight)))
      {
        PreviewNavigateMoveForward();
        TryRefocusPreviewWindow();
      }

      if (GUILayout.Button(
              "↷",
              GUILayout.Width(buttonWidth),
              GUILayout.Height(buttonHeight)))
      {
        PreviewNavigateTurnRight();
        TryRefocusPreviewWindow();
      }

      EditorGUILayout.EndHorizontal();

      EditorGUILayout.BeginHorizontal();
      if (GUILayout.Button(
              "←",
              GUILayout.Width(buttonWidth),
              GUILayout.Height(buttonHeight)))
      {
        PreviewNavigateStrafeLeft();
        TryRefocusPreviewWindow();
      }

      if (GUILayout.Button(
              "↓",
              GUILayout.Width(buttonWidth),
              GUILayout.Height(buttonHeight)))
      {
        PreviewNavigateMoveBackward();
        TryRefocusPreviewWindow();
      }

      if (GUILayout.Button(
              "→",
              GUILayout.Width(buttonWidth),
              GUILayout.Height(buttonHeight)))
      {
        PreviewNavigateStrafeRight();
        TryRefocusPreviewWindow();
      }

      EditorGUILayout.EndHorizontal();
    }
  }

  private void ApplyPreviewPoseFromMiniMapClick(int x, int y)
  {
    // Preview Facing is unchanged.
    SwitchPreviewPose(x, y, previewFacing);
    TryRefocusPreviewWindow();
  }

  private void SwitchPreviewPose(int newX, int newY, DungeonFacing newFacing)
  {
    // During Play the Game View is owned by DungeonRenderer — do not let the
    // editor previewFacing / minimap drift away from a skipped Refresh/log.
    if (Application.isPlaying)
      return;

    if (newX == previewX && newY == previewY && newFacing == previewFacing)
      return;

    bool positionChanged = newX != previewX || newY != previewY;

    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap != null && !previewMiniMap.CanEnter(newX, newY))
      return;


    // Any manual Mirror test belongs only to the pose we are leaving.
    // Restore the checkbox itself to the geometry result before changing pose,
    // then discard the temporary preview override.
    foreach (ViewportPiece overriddenPiece in previewMirrorOverrideByPiece.Keys)
    {
      if (overriddenPiece != null
          && resolvedNormalWallByPiece.TryGetValue(
              overriddenPiece, out ResolvedNormalWallState resolvedState))
        overriddenPiece.MirrorHorizontally = resolvedState.Mirror;
    }
    previewMirrorOverrideByPiece.Clear();
    previewFrontF1WidthOverrideByPiece.Clear();
    previewFrontF3WidthOverrideByPiece.Clear();
    previewPositionOverrideByPiece.Clear();
    previewPositionReferenceByPiece.Clear();
    previewEnabledOverrideByPiece.Clear();
    previewGraphicOverrideByPiece.Clear();
    previewDisableAllWalls = false;
    ResetStairsDownF1PreviewControls();

    previewX = newX;
    previewY = newY;
    previewFacing = newFacing;

    // A pose change always returns ViewEdit to the geometry-filtered list.
    // "Show all walls" is a temporary inspection mode for the pose where the
    // user enabled it; it must never carry into a different X/Y/Facing.
    showOnlyWallsNeededForCurrentPose = true;
    showWallsActivFilter = false;
    pieceSearchFamilyIndex = 0;
    pieceSearchText = string.Empty;
    editorScroll = Vector2.zero;

    SaveSessionPrefs();

    if (previewMiniMap != null)
      previewMiniMap.SetPlayerPose(previewX, previewY, previewFacing);

    if (positionChanged)
      TryPreviewStairsTransition();

    ApplyCurrentPoseVisibilityToLayout();

    // Full cache reset so Console must emit the new previewFacing.
    ResetEditModeViewportLogCache();
    RefreshEditModePreview();
    GUI.changed = true;
    Repaint();
  }

  /// <summary>
  /// Preview navigation only (editor 3×2 pad). Updates X/Y/Facing, applies the
  /// destination pose for display, refreshes preview/minimap. Does not capture
  /// or save pose visibility / layout assets.
  /// </summary>
  private void NavigatePreviewPoseOnly(int newX, int newY, DungeonFacing newFacing)
  {
    if (Application.isPlaying)
      return;

    if (newX == previewX && newY == previewY && newFacing == previewFacing)
      return;

    bool positionChanged = newX != previewX || newY != previewY;

    // Any manual Mirror test belongs only to the pose we are leaving.
    // Restore the checkbox itself to the geometry result before changing pose,
    // then discard the temporary preview override.
    foreach (ViewportPiece overriddenPiece in previewMirrorOverrideByPiece.Keys)
    {
      if (overriddenPiece != null
          && resolvedNormalWallByPiece.TryGetValue(
              overriddenPiece, out ResolvedNormalWallState resolvedState))
        overriddenPiece.MirrorHorizontally = resolvedState.Mirror;
    }
    previewMirrorOverrideByPiece.Clear();
    previewFrontF1WidthOverrideByPiece.Clear();
    previewFrontF3WidthOverrideByPiece.Clear();
    previewPositionOverrideByPiece.Clear();
    previewPositionReferenceByPiece.Clear();
    previewEnabledOverrideByPiece.Clear();
    previewGraphicOverrideByPiece.Clear();
    previewDisableAllWalls = false;
    ResetStairsDownF1PreviewControls();

    previewX = newX;
    previewY = newY;
    previewFacing = newFacing;

    // A pose change always returns ViewEdit to the geometry-filtered list.
    // "Show all walls" is a temporary inspection mode for the pose where the
    // user enabled it; it must never carry into a different X/Y/Facing.
    showOnlyWallsNeededForCurrentPose = true;
    showWallsActivFilter = false;
    pieceSearchFamilyIndex = 0;
    pieceSearchText = string.Empty;
    editorScroll = Vector2.zero;

    SaveSessionPrefs();

    if (previewMiniMap != null)
      previewMiniMap.SetPlayerPose(previewX, previewY, previewFacing);

    if (positionChanged)
      TryPreviewStairsTransition();

    // Initialize every entered pose through the normal authoritative wall/door renderer.
    ApplyCurrentPoseVisibilityToLayout();

    ResetEditModeViewportLogCache();
    RefreshEditModePreview();
    GUI.changed = true;
    Repaint();
  }

  private void PreviewNavigateTurnLeft()
  {
    NavigatePreviewPoseOnly(
        previewX,
        previewY,
        TurnPreviewFacingLeft(previewFacing));
  }

  private void PreviewNavigateTurnRight()
  {
    NavigatePreviewPoseOnly(
        previewX,
        previewY,
        TurnPreviewFacingRight(previewFacing));
  }

  private void PreviewNavigateMoveForward()
  {
    TryPreviewNavigateRelative(0, 1);
  }

  private void PreviewNavigateMoveBackward()
  {
    TryPreviewNavigateRelative(0, -1);
  }

  private void PreviewNavigateStrafeLeft()
  {
    TryPreviewNavigateRelative(-1, 0);
  }

  private void PreviewNavigateStrafeRight()
  {
    TryPreviewNavigateRelative(1, 0);
  }

  /// <summary>
  /// Facing-local move: +Y forward, -Y back, -X strafe left, +X strafe right.
  /// </summary>
  private void TryPreviewNavigateRelative(int localX, int localY)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    int nextX = previewX + forwardX * localY + rightX * localX;
    int nextY = previewY + forwardY * localY + rightY * localX;

    // Stairs are traversable transition tiles in ViewEdit. DungeonMap.CanEnter
    // may reject the raw stairs tile because it is not an ordinary Floor tile,
    // so explicitly allow a tile that carries stairs geometry. The destination
    // pose is entered first; NavigatePreviewPoseOnly then calls
    // TryPreviewStairsTransition(), which loads the adjacent dungeon level.
    bool canEnterDestination = previewMiniMap.CanEnter(nextX, nextY);
    if (!canEnterDestination)
    {
      DungeonTile destinationTile = previewMiniMap.IsInside(nextX, nextY)
          ? previewMiniMap.GetTile(nextX, nextY)
          : null;
      canEnterDestination = destinationTile != null
          && destinationTile.TryGetStairsDirection(out _);
    }

    if (!canEnterDestination)
      return;

    NavigatePreviewPoseOnly(nextX, nextY, previewFacing);
  }

  private static WallOrnamentPlacement[] BuildHallOfChampionsWallOrnaments(
      string json,
      WallOrnamentPlacement[] explicitOrnaments)
  {
    List<WallOrnamentPlacement> resolved =
        new List<WallOrnamentPlacement>();

    // Preserve any explicit map records. The current JSON has none, so the
    // fallback keeps the verified Sensor at (6,9) North plus the three older
    // random-decoration samples as safety references. Generated random faces
    // are de-duplicated against those samples below.
    WallOrnamentPlacement[] baseOrnaments =
        explicitOrnaments != null && explicitOrnaments.Length > 0
            ? explicitOrnaments
            : FallbackHallOfChampionsWallOrnaments;
    for (int i = 0; i < baseOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = baseOrnaments[i];
      if (ornament != null)
        resolved.Add(ornament);
    }

    if (string.IsNullOrEmpty(json))
      return resolved.ToArray();

    MatchCollection matches = HallOfChampionsRawWallTileRegex.Matches(json);
    for (int i = 0; i < matches.Count; i++)
    {
      Match match = matches[i];
      if (!int.TryParse(match.Groups["x"].Value, out int x)
          || !int.TryParse(match.Groups["y"].Value, out int y)
          || !int.TryParse(match.Groups["raw"].Value, out int raw))
      {
        continue;
      }

      // DUNGEON.DAT wall flag order:
      // bit 0 = West, bit 1 = South, bit 2 = East, bit 3 = North.
      TryAddHallOfChampionsRandomWallOrnament(
          resolved, x, y, raw, 0x01, "West", 4);
      TryAddHallOfChampionsRandomWallOrnament(
          resolved, x, y, raw, 0x02, "South", 3);
      TryAddHallOfChampionsRandomWallOrnament(
          resolved, x, y, raw, 0x04, "East", 2);
      TryAddHallOfChampionsRandomWallOrnament(
          resolved, x, y, raw, 0x08, "North", 1);
    }

    return resolved.ToArray();
  }

  private static void TryAddHallOfChampionsRandomWallOrnament(
      List<WallOrnamentPlacement> resolved,
      int x,
      int y,
      int raw,
      int faceMask,
      string physicalWallFace,
      int faceFactor)
  {
    if ((raw & faceMask) == 0)
      return;

    int ordinal = ResolveHallOfChampionsRandomWallOrnamentOrdinal(
        x,
        y,
        faceFactor);
    if (ordinal <= 0)
      return;

    string type = HallOfChampionsRandomWallOrnamentType(ordinal);
    if (string.IsNullOrEmpty(type))
      return;

    for (int i = 0; i < resolved.Count; i++)
    {
      WallOrnamentPlacement existing = resolved[i];
      if (existing == null || !existing.wallTilePlacement)
        continue;

      if (existing.x == x
          && existing.y == y
          && string.Equals(
              existing.wall,
              physicalWallFace,
              System.StringComparison.OrdinalIgnoreCase)
          && string.Equals(
              existing.type,
              type,
              System.StringComparison.OrdinalIgnoreCase))
      {
        return;
      }
    }

    resolved.Add(
        new WallOrnamentPlacement
        {
          type = type,
          ornamentOrdinal = ordinal,
          x = x,
          y = y,
          wall = physicalWallFace,
          wallTilePlacement = true
        });
  }

  private static int ResolveHallOfChampionsRandomWallOrnamentOrdinal(
      int mapX,
      int mapY,
      int physicalFaceFactor)
  {
    // ReDMCSB/CSBwin random wall-decoration input for one physical wall face:
    // P1 = 2000 + (x << 5) + ((y + 1) * faceFactor)
    // P2 = 3000 + (level << 6) + width + height
    // Hall of Champions: level=0, width=18, height=19.
    int value1 = 2000 + (mapX << 5) + ((mapY + 1) * physicalFaceFactor);
    int value2 = 3000 + 18 + 19;
    int index = HallOfChampionsRandomOrnamentHash(
        value1,
        value2,
        HallOfChampionsRandomOrnamentModulo);

    return index < HallOfChampionsRandomWallOrnamentCount
        ? index + 1
        : 0;
  }

  private static int HallOfChampionsRandomOrnamentHash(
      int value1,
      int value2,
      int modulo)
  {
    if (modulo <= 0)
      return 0;

    unchecked
    {
      // Preserve the original 68000-era 16-bit truncation at every word step.
      uint d0Long = (uint)(ushort)value1 * 31417u;
      ushort d0Word = (ushort)d0Long;
      d0Word = (ushort)((d0Word >> 1) & 0x7FFF);

      uint d1Long = (uint)(ushort)value2 * 11u;
      d0Word = (ushort)(d0Word + (ushort)d1Long);
      d0Word = (ushort)(d0Word + HallOfChampionsDungeonSeed);
      d0Word = (ushort)((d0Word >> 2) & 0x3FFF);

      return d0Word % modulo;
    }
  }

  private static string HallOfChampionsRandomWallOrnamentType(int ordinal)
  {
    switch (ordinal)
    {
      case 1:
        return "Hook";
      case 2:
        return "Slime";
      case 3:
        return "Grate";
      case 4:
        return "WoodRing";
      default:
        return null;
    }
  }

  private void TryJumpToPreviewLevelFromField()
  {
    if (!int.TryParse(previewLevelJumpText, out int requestedLevel))
    {
      previewLevelJumpText = previewDungeonLevel.ToString();
      return;
    }

    requestedLevel = Mathf.Clamp(
        requestedLevel,
        0,
        PreviewLevelMapPaths.Length - 1);

    if (!TryLoadPreviewLevel(requestedLevel))
    {
      previewLevelJumpText = previewDungeonLevel.ToString();
      return;
    }

    // Direct map jumps enter the level at that map's authored/default start.
    // Stair-to-stair travel keeps using TryPreviewStairsTransition instead.
    previewX = previewMiniMap.PlayerX;
    previewY = previewMiniMap.PlayerY;
    previewFacing = previewMiniMap.PlayerFacing;
    previewMiniMap.SetPlayerPose(previewX, previewY, previewFacing);

    foreach (ViewportPiece overriddenPiece in previewMirrorOverrideByPiece.Keys)
    {
      if (overriddenPiece != null
          && resolvedNormalWallByPiece.TryGetValue(
              overriddenPiece, out ResolvedNormalWallState resolvedState))
      {
        overriddenPiece.MirrorHorizontally = resolvedState.Mirror;
      }
    }

    previewMirrorOverrideByPiece.Clear();
    previewFrontF1WidthOverrideByPiece.Clear();
    previewFrontF3WidthOverrideByPiece.Clear();
    previewPositionOverrideByPiece.Clear();
    previewPositionReferenceByPiece.Clear();
    previewEnabledOverrideByPiece.Clear();
    previewGraphicOverrideByPiece.Clear();
    previewDisableAllWalls = false;
    ResetStairsDownF1PreviewControls();

    showOnlyWallsNeededForCurrentPose = true;
    showWallsActivFilter = false;
    pieceSearchFamilyIndex = 0;
    pieceSearchText = string.Empty;
    editorScroll = Vector2.zero;
    previewLevelJumpText = previewDungeonLevel.ToString();

    SaveSessionPrefs();
    // Initialize every entered pose through the normal authoritative wall/door renderer.
    ApplyCurrentPoseVisibilityToLayout();
    ResetEditModeViewportLogCache();
    RefreshEditModePreview();
    RepaintGameViews();
    GUI.changed = true;
    Repaint();
  }

  private void EnsurePreviewMiniMapLoaded()
  {
    if (previewMiniMap != null)
      return;

    TryLoadPreviewLevel(previewDungeonLevel);
  }

  /// <summary>
  /// Edit-mode movement uses the same stair rule as GameBootstrap:
  /// a down stair loads the next level, an up stair loads the previous
  /// level, and arrival is the nearest opposite stair. No map coordinate
  /// is special-cased.
  /// </summary>
  private void TryPreviewStairsTransition()
  {
    // Read the stair state directly from the tile at ViewEdit's current
    // preview coordinates. Do not depend on DungeonMap's internal player
    // state being synchronized before the transition check.
    if (previewMiniMap == null
        || !previewMiniMap.IsInside(previewX, previewY))
    {
      return;
    }

    DungeonTile currentTile = previewMiniMap.GetTile(previewX, previewY);
    if (currentTile == null
        || !currentTile.TryGetStairsDirection(out bool stairsUp))
    {
      return;
    }

    int targetLevel = stairsUp
        ? previewDungeonLevel - 1
        : previewDungeonLevel + 1;
    if (targetLevel < 0 || targetLevel >= PreviewLevelMapPaths.Length)
    {
      Debug.LogWarning(
          "ViewEdit: Player stepped on "
          + (stairsUp ? "stairs up" : "stairs down")
          + " at level " + previewDungeonLevel
          + " (" + previewX + "," + previewY + "), "
          + "but level " + targetLevel + " has no preview map.");
      return;
    }

    int sourceX = previewX;
    int sourceY = previewY;
    DungeonFacing sourceFacing = previewFacing;
    DungeonMap sourceMap = previewMiniMap;
    int sourceLevel = previewDungeonLevel;

    if (!TryLoadPreviewLevel(targetLevel))
    {
      previewMiniMap = sourceMap;
      previewDungeonLevel = sourceLevel;
      return;
    }

    bool targetStairsUp = !stairsUp;
    if (previewMiniMap.TryFindStairs(
            targetStairsUp,
            sourceX,
            sourceY,
            out int targetX,
            out int targetY))
    {
      previewX = targetX;
      previewY = targetY;
      previewFacing = sourceFacing;
    }
    else
    {
      Debug.LogWarning(
          "ViewEdit: Level " + targetLevel + " has no "
          + (targetStairsUp ? "stairs up" : "stairs down")
          + " tile. Using that map's playerStart instead.");
      previewX = previewMiniMap.PlayerX;
      previewY = previewMiniMap.PlayerY;
      previewFacing = previewMiniMap.PlayerFacing;
    }

    previewMiniMap.SetPlayerPose(previewX, previewY, previewFacing);
    previewLevelJumpText = previewDungeonLevel.ToString();

    // NavigatePreviewPoseOnly saves the source-level stair tile before this
    // transition. Persist the loaded level and arrival tile now, or the next
    // EditorPrefs sync sends the preview back to Level 0.
    SaveSessionPrefs();
  }

  private void LoadPreviewDoorTilesFromJson(string json)
  {
    previewDoorTiles.Clear();

    if (string.IsNullOrEmpty(json))
      return;

    MatchCollection matches = DoorTileRegex.Matches(json);
    for (int i = 0; i < matches.Count; i++)
    {
      Match match = matches[i];
      if (!int.TryParse(match.Groups["x"].Value, out int x)
          || !int.TryParse(match.Groups["y"].Value, out int y))
      {
        continue;
      }

      previewDoorTiles.Add(new Vector2Int(x, y));
    }
  }

  private bool TryLoadPreviewLevel(int level)
  {
    if (level < 0 || level >= PreviewLevelMapPaths.Length)
      return false;

    string path = PreviewLevelMapPaths[level];
    if (!File.Exists(path))
    {
      previewMiniMapLoadError = "Map not found at " + path;
      return false;
    }

    DungeonMap previousMap = previewMiniMap;
    int previousLevel = previewDungeonLevel;
    HashSet<Vector2Int> previousDoorTiles =
        new HashSet<Vector2Int>(previewDoorTiles);

    try
    {
      string json = File.ReadAllText(path);
      previewMiniMap = DungeonMap.LoadFromJsonText(json);
      LoadPreviewDoorTilesFromJson(json);
      previewDungeonLevel = level;

      ChampionMirrorMapRoot mirrorRoot =
          JsonUtility.FromJson<ChampionMirrorMapRoot>(json);
      previewChampionMirrors =
          mirrorRoot != null && mirrorRoot.championMirrors != null
              ? mirrorRoot.championMirrors
              : new ChampionMirrorPlacement[0];
      // Prefer the all-level feature database for the loaded level.
      // Hall-of-Champions builders remain the Level 0 fallback.
      bool loadedFeatureDatabase = LoadPreviewFeaturesFromDatabase();
      if (!loadedFeatureDatabase)
      {
        if (level == PreviewDungeonLevel)
        {
          previewWallOrnaments = BuildHallOfChampionsWallOrnaments(
              json,
              mirrorRoot != null ? mirrorRoot.wallOrnaments : null);
          LoadPreviewPuddleFloors();
        }
        else
        {
          previewWallOrnaments = new WallOrnamentPlacement[0];
          previewPuddleFloors.Clear();
        }
      }

      previewMiniMapLoadError = null;
      return true;
    }
    catch (System.Exception ex)
    {
      previewMiniMap = previousMap;
      previewDungeonLevel = previousLevel;
      previewDoorTiles.Clear();
      foreach (Vector2Int doorTile in previousDoorTiles)
        previewDoorTiles.Add(doorTile);

      if (previewMiniMap == null)
      {
        previewChampionMirrors = new ChampionMirrorPlacement[0];
        previewWallOrnaments = FallbackHallOfChampionsWallOrnaments;
        previewPuddleFloors.Clear();
      }

      previewMiniMapLoadError = ex.Message;
      Debug.LogWarning(
          "ViewEdit: Could not load preview level " + level
          + " from " + path + ": " + ex.Message);
      return false;
    }
  }

  /// <summary>
  /// Disables every piece except Floor, Ceiling, Movement Arrows, and
  /// Champion Status Slot 1–4 (matched by ViewportPiece.Name).
  /// </summary>
  /// <summary>
  /// ViewEdit preview only. Floor, ceiling, arrows, and champion slots stay.
  /// Stored piece Enabled / X / Y / Graphic / Mirror are not changed.
  /// </summary>
  private void DisableWallsKeepChrome()
  {
    if (Application.isPlaying)
      return;

    // Start a fresh manual wall-selection session. Geometry/pose rules remain
    // blocked, but the user can explicitly re-enable individual walls.
    previewEnabledOverrideByPiece.Clear();
    previewDisableAllWalls = true;
  }

  private static bool IsDisableWallsKeeper(ViewportPiece piece)
  {
    if (piece == null || piece.Name == null)
      return false;

    return piece.Name == "Floor"
        || piece.Name == "Ceiling"
        || piece.Name == "Movement Arrows"
        || piece.Name == "Champion Status Slot 1"
        || piece.Name == "Champion Status Slot 2"
        || piece.Name == "Champion Status Slot 3"
        || piece.Name == "Champion Status Slot 4";
  }

  private static bool IsFloorOrCeiling(ViewportPiece piece)
  {
    return piece.Graphic == DungeonGraphicType.Floor
        || piece.Graphic == DungeonGraphicType.Ceiling
        || piece.Name == "Floor"
        || piece.Name == "Ceiling";
  }

  private static bool IsChampionStatusSlotPiece(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    if (piece.Graphic == DungeonGraphicType.ChampionStatusBackground)
      return true;

    return piece.Name == "Champion Status Slot 1"
        || piece.Name == "Champion Status Slot 2"
        || piece.Name == "Champion Status Slot 3"
        || piece.Name == "Champion Status Slot 4";
  }

  private void PersistChanges()
  {
    if (Application.isPlaying || layout == null)
      return;

    StripObsoleteFrontWallF1ABPieces();
    EditorUtility.SetDirty(layout);
    AssetDatabase.SaveAssets();

    RefreshDungeonRenderer();
    RefreshEditModePreview();
  }


  /// <summary>
  /// Mirror Horizontally toggled: capture per-pose flag, then force an immediate
  /// Edit Mode viewport + Console refresh (including (M) markers).
  /// </summary>
  private void ApplyMirrorHorizontallyChangeForCurrentPose()
  {
    if (Application.isPlaying || layout == null)
      return;

    EditorUtility.SetDirty(layout);

    // Same pose X/Y/Facing — clear dedupe so Console re-emits with new (M).
    ResetEditModeViewportLogCache();
    DestroyEditModePreviewTextureOnly();
    RefreshEditModePreview();
    RepaintGameViews();
    Repaint();
  }

  private static bool IsFrontWallF1Card(ViewportPiece piece)
  {
    if (piece == null || piece.Name == null)
      return false;

    return piece.Name == "FrontF1"
        || piece.Name == "Front Wall F1";
  }

  private bool TryGetFrontF1PreviewEnabledOverride(out bool value)
  {
    value = false;
    foreach (KeyValuePair<ViewportPiece, bool> entry in previewEnabledOverrideByPiece)
    {
      if (entry.Key == null || !IsFrontWallF1Card(entry.Key))
        continue;

      value = entry.Value;
      return true;
    }

    return false;
  }

  private bool TryGetFrontF1PreviewPositionOverride(
      ViewportPiece piece,
      out Vector2Int position)
  {
    if (piece != null
        && previewPositionOverrideByPiece.TryGetValue(piece, out position))
    {
      return true;
    }

    foreach (KeyValuePair<ViewportPiece, Vector2Int> entry in previewPositionOverrideByPiece)
    {
      if (entry.Key == null || !IsFrontWallF1Card(entry.Key))
        continue;
      if (piece != null && ReferenceEquals(entry.Key, piece))
        continue;

      position = entry.Value;
      return true;
    }

    position = default;
    return false;
  }

  private bool TryGetFrontF1PreviewMirrorOverride(
      ViewportPiece piece,
      out bool mirror)
  {
    if (piece != null
        && previewMirrorOverrideByPiece.TryGetValue(piece, out mirror))
    {
      return true;
    }

    foreach (KeyValuePair<ViewportPiece, bool> entry in previewMirrorOverrideByPiece)
    {
      if (entry.Key == null || !IsFrontWallF1Card(entry.Key))
        continue;
      if (piece != null && ReferenceEquals(entry.Key, piece))
        continue;

      mirror = entry.Value;
      return true;
    }

    mirror = false;
    return false;
  }

  private bool TryGetFrontF1PreviewWidthOverride(
      ViewportPiece piece,
      out int width)
  {
    if (piece != null
        && previewFrontF1WidthOverrideByPiece.TryGetValue(piece, out width))
    {
      width = StraightF1WallLogic.NormalizeFrontWallF1Width(width);
      return true;
    }

    foreach (KeyValuePair<ViewportPiece, int> entry in previewFrontF1WidthOverrideByPiece)
    {
      if (entry.Key == null || !IsFrontWallF1Card(entry.Key))
        continue;
      if (piece != null && ReferenceEquals(entry.Key, piece))
        continue;

      width = StraightF1WallLogic.NormalizeFrontWallF1Width(entry.Value);
      return true;
    }

    width = 0;
    return false;
  }

  private int GetFrontF3FullSourceWidthForViewEdit()
  {
    // The authored/original FrontF3 artwork is 141x49. ViewEdit Width is
    // intentionally expressed against that full source width, independent of
    // the 70x49 native center texture used by the normal V17 compositor.
    return 141;
  }

  private bool TryGetFrontF3PreviewEnabledOverride(out bool value)
  {
    foreach (KeyValuePair<ViewportPiece, bool> entry in previewEnabledOverrideByPiece)
    {
      if (entry.Key == null || !IsFrontWallF3Card(entry.Key))
        continue;

      value = entry.Value;
      return true;
    }

    value = false;
    return false;
  }

  private bool TryGetFrontF3PreviewMirrorOverride(out bool value)
  {
    foreach (KeyValuePair<ViewportPiece, bool> entry in previewMirrorOverrideByPiece)
    {
      if (entry.Key == null || !IsFrontWallF3Card(entry.Key))
        continue;

      value = entry.Value;
      return true;
    }

    value = false;
    return false;
  }

  private bool TryGetFrontF3PreviewWidthOverride(out int width)
  {
    foreach (KeyValuePair<ViewportPiece, int> entry in previewFrontF3WidthOverrideByPiece)
    {
      if (entry.Key == null || !IsFrontWallF3Card(entry.Key))
        continue;

      width = Mathf.Max(1, entry.Value);
      return true;
    }

    width = 0;
    return false;
  }

  private static bool IsFrontWallF2Card(ViewportPiece piece)
  {
    if (piece == null || piece.Name == null)
      return false;

    return piece.Name == "FrontF2"
        || piece.Name == "Front Wall F2";
  }

  private static bool IsFrontWallF3Card(ViewportPiece piece)
  {
    if (piece == null || piece.Name == null)
      return false;

    return piece.Name == "FrontF3"
        || piece.Name == "Front Wall F3";
  }

  private static bool IsPoseOffsetCard(ViewportPiece piece)
  {
    if (piece == null || piece.Name == null)
      return false;

    switch (piece.Name)
    {
      case "FrontF3":
      case "LeftF3":
      case "RightF3":
      case "LeftD3":
      case "RightD3":
      case "FrontF2":
      case "LeftF2":
      case "RightF2":
      case "FrontF1":
      case "LeftF1":
      case "RightF1":
      case "LeftF0":
      case "RightF0":
        return true;
      default:
        return false;
    }
  }

  /// <summary>
  /// Pose Offset X/Y toggled: capture per-pose offsets without mutating
  /// layout piece.X / piece.Y, then refresh Edit Mode preview.
  /// </summary>
  private void ApplyPoseOffsetChangeForCurrentPose()
  {
    if (Application.isPlaying || layout == null)
      return;


    ResetEditModeViewportLogCache();
    DestroyEditModePreviewTextureOnly();
    RefreshEditModePreview();
    RepaintGameViews();
    Repaint();
  }

  private void EnsureChampionStatusSlotsEnabled()
  {
    if (layout == null || layout.Pieces == null)
      return;

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null)
        continue;

      if (piece.Name == "Champion Status Slot 1"
          || piece.Name == "Champion Status Slot 2"
          || piece.Name == "Champion Status Slot 3"
          || piece.Name == "Champion Status Slot 4")
      {
        piece.Enabled = true;
      }
    }
  }

  private void ApplyCurrentPoseVisibilityToLayout()
  {
    if (layout == null)
      return;

    // No stored view is loaded or created here.
    ApplyUnknownPoseDefaultsToLayout();
    EnsureChampionStatusSlotsEnabled();
    ApplyCeilingMirrorFromPose();
    ApplyFloorMirrorReferenceOverride();

    // CHATGPT_BUILD_F1_MINIMAP_ALGORITHM_STAGE1_20260830_AB
    // Stage 1: automatic F0/F1 wall assembly from minimap only.
    // F2/F3/D3/Black Door remain disabled until F1 is verified.
    ApplyF1MinimapWallRecipe();

    // Apply Black Door F1/F2/F3 pose-specific Enabled states after the normal
    // wall recipe. This routine previously existed but was never called.
    ApplyBlackDoorEnabledFromPoseException();

  }


  /// <summary>
  /// Stage-1 automatic wall resolver.
  /// Reads only the player-relative minimap cells and resolves F0/F1.
  /// No pose storage and no absolute map-coordinate exceptions.
  ///
  /// FrontF1:
  ///   F0L wall + F0R wall -> 160px centered at X=32
  ///   F0L wall + F0R open -> 192px mirrored, covering X=32..223
  ///   F0L open + F0R wall -> 192px normal, covering X=0..191
  ///   F0L open + F0R open -> 224px at X=0
  ///
  /// F1 side walls are visible only when F1 center is open.
  /// </summary>
  private static bool GetFrontF2LateralMirrorPhase(
      int playerX,
      int playerY,
      DungeonFacing facing)
  {
    return StraightF1WallLogic.GetFrontF2LateralMirrorPhase(
        playerX,
        playerY,
        facing);
  }

  /// <summary>
  /// Deterministic F0 side-wall mirror phase.
  /// Reference pose (1,3) South is Mirror OFF.
  /// Moving one map tile OR turning 90 degrees flips the phase.
  /// </summary>
  private bool GetSideWallMirrorFromPose()
  {
    int referenceParity =
        (1 + 3 + (int)DungeonFacing.South) & 1;
    int currentParity =
        (previewX + previewY + (int)previewFacing) & 1;

    return currentParity != referenceParity;
  }

  private bool GetF0MirrorFromPose()
  {
    return GetSideWallMirrorFromPose();
  }

  /// <summary>
  /// LeftD3 / RightD3 orientation from viewing direction. Outer D3 normally
  /// uses the FrontF1 brick phase. For LeftD3, when the outer-left leading
  /// strip is clipped away, the remaining visible face follows the side-wall
  /// phase instead. This preserves the verified full-strip LeftD3 cases while
  /// matching the clipped oblique-left geometry. RightD3 keeps its established
  /// near-left-side rule. No map coordinate is stored.
  /// </summary>
  private bool GetViewport17D3OuterMirror(bool rightOuter)
  {
    bool frontPhase = GetFrontF1MirrorFromPose();

    if (!rightOuter)
    {
      // When the tiny leading LeftD3 strip is hidden outside the viewport,
      // use the side-wall phase for the remaining visible oblique face.
      if (!HasLeftD3LeadingStripActiveTile())
        return GetSideWallMirrorFromPose();

      return frontPhase;
    }

    // D1-left solid means LeftF1 is the near-left side graphic. RightD3 must
    // share that side-wall phase (the complement of FrontF1). An open D1-left
    // keeps the FrontF1 phase, which is the verified (5,2) South case.
    if (IsViewport17Solid(SampleViewport17Cell(-1, 1)))
      return GetSideWallMirrorFromPose();

    return frontPhase;
  }

  private static bool IsLeftD3Piece(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    return piece.Name == "LeftD3"
        || piece.Name == "Wall D3L2"
        || piece.Graphic == DungeonGraphicType.WallD3L2;
  }

  private static bool IsRightD3Piece(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    return piece.Name == "RightD3"
        || piece.Name == "Wall D3R2"
        || piece.Graphic == DungeonGraphicType.WallD3R2;
  }


  private static bool IsViewEditGeometryWall(RelativeViewportCell cell)
  {
    return cell.IsWall;
  }

  private static bool IsLeftD3ObliqueOpening(RelativeViewportGeometry g)
  {
    return !IsViewEditGeometryWall(g.F0Left)
        && !IsViewEditGeometryWall(g.F0Right)
        && IsViewEditGeometryWall(g.F1Center)
        && !IsViewEditGeometryWall(g.F1Left);
  }

  private bool HasLeftD3LeadingStripActiveTile()
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null)
      return false;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    int sampleX = previewX + forwardX * 2 - rightX * 2;
    int sampleY = previewY + forwardY * 2 - rightY * 2;

    if (!previewMiniMap.IsInside(sampleX, sampleY))
      return false;

    return previewMiniMap.GetTile(sampleX, sampleY).Type != DungeonTileType.Wall;
  }

  /// <summary>
  /// Deterministic FrontF1 brick phase. Moving one map tile or turning 90
  /// degrees flips the phase. Even (X + Y + facing) parity is mirrored.
  /// FrontF2 keeps its separate lateral-coordinate phase.
  /// </summary>
  private bool GetFrontF1MirrorFromPose()
  {
    int parity =
        (previewX + previewY + (int)previewFacing) & 1;
    return parity == 0;
  }

  /// <summary>
  /// LeftF3 on a full D3 L+C+R front plane is the left third of that front
  /// wall, so it uses the FrontF1 brick phase. A partial D3 front keeps
  /// LeftF3 on the F0/F1 side-wall phase.
  /// </summary>
  private bool GetViewport17LeftF3Mirror()
  {
    bool d3FullFrontPlane =
        IsViewport17Solid(SampleViewport17Cell(-1, 3))
        && IsViewport17Solid(SampleViewport17Cell(0, 3))
        && IsViewport17Solid(SampleViewport17Cell(1, 3));

    if (d3FullFrontPlane)
      return GetFrontF1MirrorFromPose();

    return GetSideWallMirrorFromPose();
  }

  private bool TryGetCurrentRelativeViewportGeometry(out RelativeViewportGeometry geometry)
  {
    geometry = default;
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null)
      return false;

    geometry = RelativeViewportGeometry.Calculate(
        previewMiniMap,
        previewX,
        previewY,
        previewFacing);
    return true;
  }

  private bool TryGetPieceCardReferenceXY(
      ViewportPiece piece,
      bool mirror,
      out int x,
      out int y)
  {
    if (piece != null
        && previewPositionReferenceByPiece.TryGetValue(
            piece, out Vector2Int frozenReference))
    {
      x = frozenReference.x;
      y = frozenReference.y;
      return true;
    }

    // V17 Game View dest is the card Ref. Live X/Y must not show red against
    // an older family default (for example old FrontF3 Ref 7).
    if (IsViewport17WallAuthorityActive()
        && TryGetResolvedNormalWallState(
            piece, out ResolvedNormalWallState liveDraw)
        && liveDraw.Enabled)
    {
      x = liveDraw.X;
      y = UnityYToDisplayY(
          liveDraw.Y,
          GetPieceHeightForEditorY(piece));
      return true;
    }

    bool hasCurrentGeometry =
        TryGetCurrentRelativeViewportGeometry(
            out RelativeViewportGeometry currentGeometry);

    bool leftD3FrontF1Reference =
        IsFrontWallF1Card(piece)
        && hasCurrentGeometry
        && IsLeftD3ObliqueOpening(currentGeometry);

    if (TryGetSideWallCanonicalName(piece, out _)
        && TryGetActiveCanonicalReferenceXY(piece, mirror, out x, out y))
    {
      return true;
    }

    if (!TryGetActiveCanonicalReferenceXY(piece, mirror, out x, out y))
      return false;

    if (leftD3FrontF1Reference)
      x = 32;

    return true;
  }

  private void ApplyF1MinimapWallRecipe()
  {
    DisableAllWallRenderingPieces();

    if (layout == null || layout.Pieces == null)
      return;

    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null)
      return;

    RelativeViewportGeometry g =
        RelativeViewportGeometry.Calculate(
            previewMiniMap,
            previewX,
            previewY,
            previewFacing);

    bool frontF1 =
        IsViewEditGeometryWall(g.F1Center);
    // Exposed left depth lane: F1/F2 centers open, F1-left open, F2-left open,
    // F3-left wall. This requires the side LeftF3 piece only. FrontF3 remains
    // the normal straight-ahead center-wall case. Keep it player-relative so
    // it works after moving or turning.
    bool leftLaneF3 =
        !IsViewEditGeometryWall(g.F1Center)
        && !IsViewEditGeometryWall(g.F2Center)
        && !IsViewEditGeometryWall(g.F1Left)
        && !IsViewEditGeometryWall(g.F2Left)
        && IsViewEditGeometryWall(g.F3Left);

    bool leftS2 =
        IsViewEditGeometryWall(g.F1Center)
        && IsViewEditGeometryWall(g.F2Center)
        && IsViewEditGeometryWall(g.F3Center)
        && !IsViewEditGeometryWall(g.F1Left)
        && !IsViewEditGeometryWall(g.F2Left)
        && IsViewEditGeometryWall(g.F3Left);

    bool frontF3 =
        (!IsViewEditGeometryWall(g.F1Center) &&
         !IsViewEditGeometryWall(g.F2Center) &&
         IsViewEditGeometryWall(g.F3Center))
        || leftS2;

    bool leftF0 = IsViewEditGeometryWall(g.F0Left);
    bool rightF0 = IsViewEditGeometryWall(g.F0Right);
    bool f0Mirror = GetF0MirrorFromPose();
    bool frontF1Mirror = leftS2 || GetFrontF1MirrorFromPose();

    bool leftF1 =
        !IsViewEditGeometryWall(g.F1Center) &&
        IsViewEditGeometryWall(g.F1Left);
    bool rightF1 =
        !IsViewEditGeometryWall(g.F1Center) &&
        IsViewEditGeometryWall(g.F1Right);

    bool leftF2 =
        !IsViewEditGeometryWall(g.F1Center) &&
        !IsViewEditGeometryWall(g.F2Center) &&
        IsViewEditGeometryWall(g.F2Left);
    bool rightF2 =
        !IsViewEditGeometryWall(g.F1Center) &&
        !IsViewEditGeometryWall(g.F2Center) &&
        IsViewEditGeometryWall(g.F2Right);

    bool leftF3 = leftLaneF3;
    bool rightF3 =
        !IsViewEditGeometryWall(g.F1Center) &&
        !IsViewEditGeometryWall(g.F2Center) &&
        !IsViewEditGeometryWall(g.F3Center) &&
        IsViewEditGeometryWall(g.F3Right);

    // RightD3 oblique-right opening derived only from player-relative near geometry,
    // never from absolute map coordinates. Verified examples include 1,6 East,
    // 1,16 East, 6,2 East, 6,14 East, and 15,7 East. Deeper F2/F3 cells
    // vary across those views, so they are deliberately not part of the rule.
    bool rightD3ObliqueOpening =
        !IsViewEditGeometryWall(g.F0Left)
        && !IsViewEditGeometryWall(g.F0Right)
        && IsViewEditGeometryWall(g.F1Center)
        && !IsViewEditGeometryWall(g.F1Right);

    // LeftD3 oblique-left opening is the independent mirror-side decision.
    // Verified at 2,17 North and 7,15 North; 16,17 North confirms that
    // LeftD3 and RightD3 can both be active at the same time.
    bool leftD3ObliqueOpening =
        IsLeftD3ObliqueOpening(g)
        && !leftS2;

    // Minimap occupancy signature, not a map pose.
    bool frontMirror =
        GetFrontF2LateralMirrorPhase(
            previewX,
            previewY,
            previewFacing);

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null)
        continue;

      bool enabled;
      int x;
      int y;
      bool mirror = false;
      int frontF1Width = 0;

      if (IsFrontWallF1Card(piece))
      {
        enabled = frontF1;
        // Display Y 42 -> Unity Y 47 (FrontF1 height 111).
        y = 47;
        mirror = frontF1Mirror;
        if (leftD3ObliqueOpening && rightD3ObliqueOpening)
            frontF1Width = StraightF1WallLogic.CompositeWidth160;
        else if (leftD3ObliqueOpening || rightD3ObliqueOpening)
            frontF1Width = StraightF1WallLogic.CompositeWidth191;
        else if (leftF0 && rightF0)
            frontF1Width = StraightF1WallLogic.CompositeWidth191;
        else if (leftF0 || rightF0)
            frontF1Width = StraightF1WallLogic.CompositeWidth191;
        else
            frontF1Width = StraightF1WallLogic.CompositeWidth;
        x = (leftF0 && rightF0)
            ? 0
            : frontF1Width == StraightF1WallLogic.CompositeWidth ? 0 : 32;

        // D3 oblique views keep their occupancy-specific FrontF1 anchor.
        // LeftD3 needs the first 32 screen pixels free, so FrontF1 starts at X=32.
        // RightD3-only views anchor FrontF1 at X=0. If both are active, LeftD3
        // wins because X=0 would cover the left oblique strip.
        if (leftD3ObliqueOpening)
          x = 32;
        else if (rightD3ObliqueOpening)
          x = 0;
      }
      else if (IsFrontWallF2Card(piece))
      {
        enabled = !IsViewEditGeometryWall(g.F1Center)
            && IsViewEditGeometryWall(g.F2Center);
        x = 0;
        y = DisplayYToUnityY(42, 74);
        mirror = frontMirror;
      }
      else if (IsFrontWallF3Card(piece))
      {
        enabled = frontF3;
        x = 77;
        y = DisplayYToUnityY(58, GetPieceHeightForEditorY(piece));
        mirror = GetSideWallMirrorFromPose();
      }
      else if (IsWallF0LeftPiece(piece))
      {
        enabled = leftF0;
        mirror = GetSideWallMirrorFromPose();
        if (TryGetActiveCanonicalReferenceXY(
                piece, mirror, out int leftF0RefX, out int leftF0RefY))
        {
          x = leftF0RefX;
          y = DisplayYToUnityY(leftF0RefY, GetPieceHeightForEditorY(piece));
        }
        else
        {
          x = 0;
          y = DisplayYToUnityY(33, GetPieceHeightForEditorY(piece));
        }
      }
      else if (IsWallF0RightPiece(piece))
      {
        enabled = rightF0;
        mirror = GetSideWallMirrorFromPose();
        if (TryGetActiveCanonicalReferenceXY(
                piece, mirror, out int rightF0RefX, out int rightF0RefY))
        {
          x = rightF0RefX;
          y = DisplayYToUnityY(rightF0RefY, GetPieceHeightForEditorY(piece));
        }
        else
        {
          x = 191;
          y = DisplayYToUnityY(33, GetPieceHeightForEditorY(piece));
        }
      }
      else if (IsWallF1LeftPiece(piece))
      {
        enabled = leftF1;
        mirror = GetSideWallMirrorFromPose();

        if (TryGetActiveCanonicalReferenceXY(piece, mirror, out int leftF1RefX, out int leftF1RefY))
        {
          x = leftF1RefX;
          y = DisplayYToUnityY(leftF1RefY, GetPieceHeightForEditorY(piece));
        }
        else
        {
          x = 0;
          y = DisplayYToUnityY(42, GetPieceHeightForEditorY(piece));
        }
      }
      else if (IsWallF1RightPiece(piece))
      {
        enabled = rightF1;
        mirror = GetSideWallMirrorFromPose();

        if (TryGetActiveCanonicalReferenceXY(piece, mirror, out int rightF1RefX, out int rightF1RefY))
        {
          x = rightF1RefX;
          y = DisplayYToUnityY(rightF1RefY, GetPieceHeightForEditorY(piece));
        }
        else
        {
          x = 165;
          y = DisplayYToUnityY(41, GetPieceHeightForEditorY(piece));
        }
      }
      else if (IsWallF2LeftPiece(piece))
      {
        enabled = leftF2;
        mirror = GetSideWallMirrorFromPose();
        if (TryGetActiveCanonicalReferenceXY(
                piece, mirror, out int leftF2RefX, out int leftF2RefY))
        {
          x = leftF2RefX;
          y = DisplayYToUnityY(leftF2RefY, GetPieceHeightForEditorY(piece));
        }
        else
        {
          x = 0;
          y = DisplayYToUnityY(52, GetPieceHeightForEditorY(piece));
        }
      }
      else if (IsWallF2RightPiece(piece))
      {
        enabled = rightF2;
        mirror = GetSideWallMirrorFromPose();
        if (TryGetActiveCanonicalReferenceXY(
                piece, mirror, out int rightF2RefX, out int rightF2RefY))
        {
          x = rightF2RefX;
          y = DisplayYToUnityY(rightF2RefY, GetPieceHeightForEditorY(piece));
        }
        else
        {
          x = 147;
          y = DisplayYToUnityY(52, GetPieceHeightForEditorY(piece));
        }
      }
      else if (IsWallF3LeftPiece(piece))
      {
        enabled = leftF3;
        mirror = GetSideWallMirrorFromPose();
        if (TryGetActiveCanonicalReferenceXY(
                piece, mirror, out int leftF3RefX, out int leftF3RefY))
        {
          x = leftF3RefX;
          y = DisplayYToUnityY(leftF3RefY, GetPieceHeightForEditorY(piece));
        }
        else
        {
          x = 0;
          y = DisplayYToUnityY(58, GetPieceHeightForEditorY(piece));
        }
      }
      else if (IsWallF3RightPiece(piece))
      {
        enabled = rightF3;
        mirror = GetSideWallMirrorFromPose();
        if (TryGetActiveCanonicalReferenceXY(
                piece, mirror, out int rightF3RefX, out int rightF3RefY))
        {
          x = rightF3RefX;
          y = DisplayYToUnityY(rightF3RefY, GetPieceHeightForEditorY(piece));
        }
        else
        {
          x = 141;
          y = DisplayYToUnityY(58, GetPieceHeightForEditorY(piece));
        }
      }
      else if (piece.Name == "LeftS3")
      {
        enabled = leftS2;
        x = 0;
        y = DisplayYToUnityY(
            57,
            GetPieceHeightForEditorY(piece));
        mirror = piece.MirrorHorizontally;
        if (previewMirrorOverrideByPiece.TryGetValue(piece, out bool leftS3Mirror))
          mirror = leftS3Mirror;
      }
      else if (piece.Name == "RightS3")
      {
        // RightS3 is still manual-calibration only until its generic geometry
        // rule is verified.  Give the card real S3-space defaults so X/Y can
        // be tuned live in ViewEdit instead of showing the old placeholder
        // X=0 / Y=199 values.
        enabled = false;
        x = 216;
        y = DisplayYToUnityY(
            57,
            GetPieceHeightForEditorY(piece));
        mirror = piece.MirrorHorizontally;
        if (previewMirrorOverrideByPiece.TryGetValue(piece, out bool rightS3Mirror))
          mirror = rightS3Mirror;
      }
      else if (piece.Name == "LeftD3"
          || piece.Name == "Wall D3L2"
          || piece.Graphic == DungeonGraphicType.WallD3L2)
      {
        // Geometry-driven oblique left-side depth piece.
        // The first tiny leading strip is visible when the outer-left map tile
        // at 2-forward / 2-left is active/white. A black wall/non-existing
        // tile shifts the piece 9 px left so the strip disappears.
        enabled = leftD3ObliqueOpening;
        x = HasLeftD3LeadingStripActiveTile() ? 0 : -9;
        y = DisplayYToUnityY(
            58,
            GetPieceHeightForEditorY(piece));
        mirror = GetViewport17D3OuterMirror(false);
      }
      else if (piece.Name == "RightD3"
          || piece.Name == "Wall D3R2"
          || piece.Graphic == DungeonGraphicType.WallD3R2)
      {
        // Geometry-driven oblique right-side depth piece. Position/blit stay on
        // the existing RightD3 path; this rule decides only whether it is needed.
        enabled = rightD3ObliqueOpening;
        x = piece.EffectiveX;
        y = DisplayYToUnityY(
            58,
            GetPieceHeightForEditorY(piece));
        mirror = GetViewport17D3OuterMirror(true);
      }
      else
      {
        continue;
      }

      // Exposed-left LeftF3 visibility is geometry authority.
      if (leftLaneF3 && IsWallF3LeftPiece(piece))
      {
        enabled = true;
      }

      // Native DOS D3 center placement is authoritative.
      // FrontF3 is the raw 70px center at X=77.
      if (IsFrontWallF3Card(piece))
      {
        x = 77;
        y = DisplayYToUnityY(58, GetPieceHeightForEditorY(piece));
      }

      // RightD3 canonical position is authoritative. Ref Y is top-down display space.
      if ((piece.Name == "RightD3"
              || piece.Name == "Wall D3R2"
              || piece.Graphic == DungeonGraphicType.WallD3R2)
          && TryGetActiveCanonicalReferenceXY(
              piece, mirror, out int rightD3RefX, out int rightD3RefY))
      {
        x = rightD3RefX;
        y = DisplayYToUnityY(
            rightD3RefY, GetPieceHeightForEditorY(piece));
      }

      // LeftD3 X is geometry-driven from the outer-left active/black map tile.
      // D3 Y is canonical and always 58 in top-down display space.
      if ((piece.Name == "LeftD3"
              || piece.Name == "Wall D3L2"
              || piece.Graphic == DungeonGraphicType.WallD3L2)
          && enabled)
      {
        x = HasLeftD3LeadingStripActiveTile() ? 0 : -9;
        y = DisplayYToUnityY(
            58,
            GetPieceHeightForEditorY(piece));
      }

      if (IsFrontWallF3Card(piece))
      {
        if (previewMirrorOverrideByPiece.TryGetValue(
                piece, out bool frontF3MirrorOverride))
          mirror = frontF3MirrorOverride;
        else
          mirror = GetSideWallMirrorFromPose();
        if (previewEnabledOverrideByPiece.TryGetValue(
                piece, out bool frontF3EnabledOverride))
          enabled = frontF3EnabledOverride;
      }

      // FrontF1 mirror is pose-parity driven and must flip when moving one
      // tile or turning 90 degrees. Keep it authoritative over any older
      // geometry-level mirror override.
      if (IsFrontWallF1Card(piece))
      {
        mirror = frontF1Mirror;
      }

      if (piece.Name == "LeftS3")
      {
        enabled = leftS2;
        x = 0;
        y = DisplayYToUnityY(
            57,
            GetPieceHeightForEditorY(piece));
        mirror = piece.MirrorHorizontally;
        if (previewMirrorOverrideByPiece.TryGetValue(
                piece, out bool leftS3MirrorAfter))
          mirror = leftS3MirrorAfter;
      }

      ResolvedNormalWallState state = new ResolvedNormalWallState
      {
        Enabled = enabled,
        Graphic = piece.Graphic,
        X = x,
        Y = y,
        Mirror = mirror,
        FrontF1Width = frontF1Width,
        FrontF2Width = 0
      };

      resolvedNormalWallByPiece[piece] = state;
      piece.Enabled = state.Enabled;
      piece.MirrorHorizontally = state.Mirror;
      piece.PoseOffsetX = 0;
      piece.PoseOffsetY = 0;
    }

    bool sideWallMirror = GetSideWallMirrorFromPose();
    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null
          || (!IsWallF0LeftPiece(piece) && !IsWallF0RightPiece(piece)
              && !IsWallF1LeftPiece(piece) && !IsWallF1RightPiece(piece)
              && !IsWallF2LeftPiece(piece) && !IsWallF2RightPiece(piece)
              && !IsWallF3LeftPiece(piece) && !IsWallF3RightPiece(piece)))
        continue;

      bool resolvedSideMirror = sideWallMirror;

      if (resolvedNormalWallByPiece.TryGetValue(
              piece, out ResolvedNormalWallState sideWallState))
      {
        sideWallState.Mirror = resolvedSideMirror;
        resolvedNormalWallByPiece[piece] = sideWallState;
      }

      piece.MirrorHorizontally = resolvedSideMirror;
    }

    // FrontF1 mirror is deterministic from the current map pose.
    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null || !IsFrontWallF1Card(piece))
        continue;

      if (resolvedNormalWallByPiece.TryGetValue(
              piece, out ResolvedNormalWallState frontF1State))
      {
        frontF1State.Mirror = frontF1Mirror;
        resolvedNormalWallByPiece[piece] = frontF1State;
      }

      piece.MirrorHorizontally = frontF1Mirror;
    }

    // LeftF0 mirror is deterministic from the current pose. A temporary manual
    // ViewEdit mirror override is applied later and can still win for testing.
    bool leftF0PoseMirror = GetSideWallMirrorFromPose();
    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null || !IsWallF0LeftPiece(piece))
        continue;

      if (resolvedNormalWallByPiece.TryGetValue(
              piece, out ResolvedNormalWallState leftF0StateAfterResolve))
      {
        leftF0StateAfterResolve.Mirror = leftF0PoseMirror;
        resolvedNormalWallByPiece[piece] = leftF0StateAfterResolve;
      }

      piece.MirrorHorizontally = leftF0PoseMirror;
    }

    // FrontF1 live X follows the canonical card reference for this geometry, so
    // the resolved value can never disagree with the Ref shown on the card.
    // Temporary ViewEdit X/Y overrides are applied afterward and still win.
    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null || !IsFrontWallF1Card(piece))
        continue;

      if (!TryGetPieceCardReferenceXY(
              piece,
              GetFrontF1MirrorFromPose(),
              out int frontF1RefX,
              out _))
      {
        continue;
      }

      if (resolvedNormalWallByPiece.TryGetValue(
              piece, out ResolvedNormalWallState frontF1StateAfterResolve))
      {
        frontF1StateAfterResolve.X = frontF1RefX;
        resolvedNormalWallByPiece[piece] = frontF1StateAfterResolve;
      }

      // Remove any older temporary ViewEdit X/Y edit for FrontF1 in the
      // solid-front geometries that previously owned this rule. Otherwise
      // ApplyTemporaryNormalWallPreviewOverrides() would put a stale X back.
      if (leftF0 && rightF0)
        previewPositionOverrideByPiece.Remove(piece);
    }

    // FrontF1 mirror is pose-parity driven. Temporary ViewEdit mirror
    // overrides are applied afterward and still win.
    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null || !IsFrontWallF1Card(piece))
        continue;

      bool poseMirror = frontF1Mirror;

      if (resolvedNormalWallByPiece.TryGetValue(
              piece, out ResolvedNormalWallState frontF1StateAfterResolve))
      {
        frontF1StateAfterResolve.Mirror = poseMirror;
        resolvedNormalWallByPiece[piece] = frontF1StateAfterResolve;
      }

      piece.MirrorHorizontally = poseMirror;
    }

    ApplyViewport17LiveDrawToResolvedWalls();
    ApplyTemporaryNormalWallPreviewOverrides();
  }

  /// <summary>
  /// When V17 Walls owns Game View, ViewEdit shows the same Enabled / X /
  /// Y / Width / Mirror that Compose actually blits. Stationary-pose ViewEdit
  /// Enabled / Mirror / X/Y tests are applied afterward and still win.
  /// </summary>
  private void ApplyViewport17LiveDrawToResolvedWalls()
  {
    if (!IsViewport17WallAuthorityActive()
        || layout == null
        || layout.Pieces == null)
    {
      return;
    }

    Viewport17Inspection inspection = BuildViewport17Inspection();
    List<Viewport17RenderCommand> finalCommands =
        BuildViewport17FinalDrawCommands(inspection);

    // Use the same FINAL DRAW decisions as the native V17 blitters. ViewEdit
    // must be a truthful report of what Compose actually draws, not a second
    // approximation from the raw D1/D2/D3 cells.
    GetViewport17FinalFrontLanes(
        finalCommands, 1,
        out bool d1FrontLeft, out bool d1FrontCenter, out bool d1FrontRight);
    GetViewport17FinalFrontLanes(
        finalCommands, 2,
        out bool d2FrontLeft, out bool d2FrontCenter, out bool d2FrontRight);
    GetViewport17FinalFrontLanes(
        finalCommands, 3,
        out bool d3FrontLeft, out bool d3FrontCenter, out bool d3FrontRight);

    bool d1LeftEnabled =
        HasViewport17FinalFamily(finalCommands, "LeftF1") || d1FrontLeft;
    bool d1CenterEnabled = d1FrontCenter;
    bool d1RightEnabled =
        HasViewport17FinalFamily(finalCommands, "RightF1") || d1FrontRight;

    bool d2LeftEnabled =
        HasViewport17FinalFamily(finalCommands, "LeftF2") || d2FrontLeft;
    bool d2CenterEnabled = d2FrontCenter;
    bool d2RightEnabled =
        HasViewport17FinalFamily(finalCommands, "RightF2") || d2FrontRight;

    bool d3LeftEnabled = HasViewport17FinalFamily(finalCommands, "LeftF3");
    bool d3RightEnabled = HasViewport17FinalFamily(finalCommands, "RightF3");

    // Mirror the Black Door suppression/side-wall rules used by Compose so
    // the Enabled checkboxes and ACTIVE diagnostic remain truthful there too.
    bool blackDoorF1Pose = IsDoorF1FrontView();
    bool blockD2ForBlackDoor = blackDoorF1Pose;
    bool suppressD2CenterForBlackDoor =
        IsDoorF2FrontView();
    bool suppressD3CenterForBlackDoor =
        IsDoorF2FrontView()
        || IsDoorF3FrontView();

    if (blackDoorF1Pose)
    {
      d1LeftEnabled = true;
      d1CenterEnabled = false;
      d1RightEnabled = true;
    }

    if (blockD2ForBlackDoor)
    {
      d2LeftEnabled = false;
      d2CenterEnabled = false;
      d2RightEnabled = false;
    }
    else if (suppressD2CenterForBlackDoor)
    {
      d2CenterEnabled = false;
    }

    if (suppressD3CenterForBlackDoor)
      d3FrontCenter = false;

    // Apply the exact same live ViewEdit overrides used by the native blitters.
    // This keeps checkbox/mirror state synchronized even during manual tests.
    bool d1LeftMirror = GetSideWallMirrorFromPose();
    bool d1CenterMirror = GetFrontF1MirrorFromPose();
    bool d1RightMirror = d1LeftMirror;
    ApplyViewport17NativeManualControls(
        "LeftF1", ref d1LeftEnabled, ref d1LeftMirror);
    ApplyViewport17NativeManualControls(
        "FrontF1", ref d1CenterEnabled, ref d1CenterMirror);
    ApplyViewport17NativeManualControls(
        "RightF1", ref d1RightEnabled, ref d1RightMirror);

    bool d2LeftMirror = GetSideWallMirrorFromPose();
    bool d2CenterMirror = d2LeftMirror;
    bool d2RightMirror = d2LeftMirror;
    ApplyViewport17NativeManualControls(
        "LeftF2", ref d2LeftEnabled, ref d2LeftMirror);
    ApplyViewport17NativeManualControls(
        "FrontF2", ref d2CenterEnabled, ref d2CenterMirror);
    ApplyViewport17NativeManualControls(
        "RightF2", ref d2RightEnabled, ref d2RightMirror);

    bool d3LeftMirror = GetViewport17LeftF3Mirror();
    bool d3RightMirror = GetSideWallMirrorFromPose();
    // The 6,1-West class gutter is an extra FrontF3 sliver required by the
    // D3 geometry even when the normal final-command occlusion pass has no
    // surviving FrontF3 lane. Promote that gutter to a real FrontF3 lane
    // before ViewEdit/manual controls are applied so it is both visible and
    // user-disableable like every other V17 wall draw.
    bool d3LeftEdgeFrontGutter =
        IsViewport17D3LeftEdgeFrontGutter(inspection);
    bool d3RightEdgeFrontGutter =
        IsViewport17D3RightEdgeFrontGutter(inspection);
    bool d3RightOpenSlitFront =
        IsViewport17D3RightOpenSlitFront();
    if (d3LeftEdgeFrontGutter)
        d3FrontLeft = true;
    if (d3RightEdgeFrontGutter || d3RightOpenSlitFront)
        d3FrontRight = true;
    bool d3FrontMirror = (d3LeftEdgeFrontGutter
        || d3RightEdgeFrontGutter
        || d3RightOpenSlitFront)
        ? false
        : GetViewport17FrontF3DefaultMirror(
            d3FrontLeft, d3FrontCenter, d3FrontRight);
    ApplyViewport17NativeManualControls(
        "LeftF3", ref d3LeftEnabled, ref d3LeftMirror);
    ApplyViewport17NativeManualControls(
        "RightF3", ref d3RightEnabled, ref d3RightMirror);
    ApplyViewport17NativeFrontF3ManualControls(
        ref d3FrontLeft,
        ref d3FrontCenter,
        ref d3FrontRight,
        ref d3FrontMirror);

    bool d3FrontSourceEnabled =
        d3FrontLeft || d3FrontCenter || d3FrontRight;

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null || !IsNormalWallPiece(piece))
        continue;

      if (!resolvedNormalWallByPiece.TryGetValue(
              piece, out ResolvedNormalWallState state))
      {
        continue;
      }

      if (piece.Name == "RightS3")
      {
        bool rightS3Enabled =
            HasViewport17FinalFamily(finalCommands, "RightS3");
        bool rightS3Mirror = IsViewport17RightS3D3FrontEdge(inspection)
            ? true
            : GetSideWallMirrorFromPose();
        ApplyViewport17NativeManualControls(
            "RightS3", ref rightS3Enabled, ref rightS3Mirror);
        state.Enabled = rightS3Enabled;
        state.X = 216;
        state.Y = DisplayYToUnityY(
            57, GetPieceHeightForEditorY(piece));
        state.Mirror = rightS3Mirror;
        resolvedNormalWallByPiece[piece] = state;
        continue;
      }

      if (piece.Name == "LeftS3")
      {
        bool leftS3D2FrontEdge =
            IsViewport17LeftS3D2FrontEdge(inspection);
        bool leftS3D3FullFrontEdge =
            IsViewport17LeftS3D3FullFrontEdge(inspection);
        bool leftS3OpenLeftD3CenterFront =
            IsViewport17LeftS3OpenLeftD3CenterFront(inspection);
        bool leftS3Enabled =
            HasViewport17FinalFamily(finalCommands, "LeftS3");
        bool leftS3Mirror = leftS3D2FrontEdge || leftS3OpenLeftD3CenterFront
            ? false
            : leftS3D3FullFrontEdge
                ? true
                : GetSideWallMirrorFromPose();
        ApplyViewport17NativeManualControls(
            "LeftS3", ref leftS3Enabled, ref leftS3Mirror);
        state.Enabled = leftS3Enabled;
        state.X = 0;
        state.Y = DisplayYToUnityY(
            57, GetPieceHeightForEditorY(piece));
        state.Mirror = leftS3Mirror;
        resolvedNormalWallByPiece[piece] = state;
        continue;
      }

      // D1: 60 / 160 / 60 at X 0 / 32 / 164, display Y 42.
      if (IsWallF1LeftPiece(piece))
      {
        state.Enabled = d1LeftEnabled;
        state.X = 0;
        state.Y = DisplayYToUnityY(42, 111);
        state.Mirror = d1LeftMirror;
        resolvedNormalWallByPiece[piece] = state;
        continue;
      }

      if (IsFrontWallF1Card(piece))
      {
        state.Enabled = d1CenterEnabled;
        state.X = 32;
        state.Y = DisplayYToUnityY(42, 111);
        state.Mirror = d1CenterMirror;
        state.FrontF1Width = StraightF1WallLogic.CompositeWidth160;
        resolvedNormalWallByPiece[piece] = state;
        continue;
      }

      if (IsWallF1RightPiece(piece))
      {
        state.Enabled = d1RightEnabled;
        state.X = 164;
        state.Y = DisplayYToUnityY(42, 111);
        state.Mirror = d1RightMirror;
        resolvedNormalWallByPiece[piece] = state;
        continue;
      }

      // D2: 78 / 106 / 78 at X 0 / 59 / 146, display Y 52.
      if (IsWallF2LeftPiece(piece))
      {
        state.Enabled = d2LeftEnabled;
        state.X = 0;
        state.Y = DisplayYToUnityY(52, 74);
        state.Mirror = d2LeftMirror;
        resolvedNormalWallByPiece[piece] = state;
        continue;
      }

      if (IsFrontWallF2Card(piece))
      {
        state.Enabled = d2CenterEnabled;
        state.X = 59;
        state.Y = DisplayYToUnityY(52, 74);
        state.Mirror = d2CenterMirror;
        state.FrontF2Width = 106;
        resolvedNormalWallByPiece[piece] = state;
        continue;
      }

      if (IsWallF2RightPiece(piece))
      {
        state.Enabled = d2RightEnabled;
        state.X = 146;
        state.Y = DisplayYToUnityY(52, 74);
        state.Mirror = d2RightMirror;
        resolvedNormalWallByPiece[piece] = state;
        continue;
      }

      // D3 side walls are 83px at X 7 / 134. The FrontF3 card represents
      // every draw from the native FrontF3 source: left 32px strip, center
      // 70px image, or right 32px strip. This closes the old ViewEdit blind
      // spot where a FrontF3 edge strip was visible in Game View but ACTIVE
      // and the FrontF3 checkbox both said it was off.
      if (IsWallF3LeftPiece(piece))
      {
        state.Enabled = d3LeftEnabled;
        state.X = NativeD3LeftF3DestX;
        state.Y = DisplayYToUnityY(58, 49);
        state.Mirror = d3LeftMirror;
        resolvedNormalWallByPiece[piece] = state;
        continue;
      }

      if (IsFrontWallF3Card(piece))
      {
        state.Graphic = DungeonGraphicType.FrontWallF3;
        state.X = d3RightOpenSlitFront
            ? NativeD3RightOpenSlitFrontX
            : (d3LeftEdgeFrontGutter
                ? NativeD3LeftFrontGutterX
                : (d3RightEdgeFrontGutter
                    ? NativeD3RightFrontGutterX
                    : (d3FrontCenter
                        ? 77
                        : (d3FrontLeft ? 0 : (d3FrontRight ? 192 : 77)))));
        state.Y = DisplayYToUnityY(58, 49);
        if (d3RightOpenSlitFront)
          state.FrontF3Width = NativeD3RightOpenSlitFrontWidth;
        else if (d3LeftEdgeFrontGutter)
          state.FrontF3Width = NativeD3LeftFrontGutterWidth;
        else if (d3RightEdgeFrontGutter)
          state.FrontF3Width = NativeD3RightFrontGutterWidth;
        // Stationary ViewEdit Enabled/Mirror tests own these two fields.
        // Geometry still supplies the default when no override exists.
        if (previewEnabledOverrideByPiece.TryGetValue(
                piece, out bool manualFrontF3Enabled))
          state.Enabled = manualFrontF3Enabled;
        else
          state.Enabled = d3FrontSourceEnabled;
        if (previewMirrorOverrideByPiece.TryGetValue(
                piece, out bool manualFrontF3Mirror))
          state.Mirror = manualFrontF3Mirror;
        else
          state.Mirror = d3FrontMirror;
        resolvedNormalWallByPiece[piece] = state;
        piece.Graphic = DungeonGraphicType.FrontWallF3;
        continue;
      }

      if (IsWallF3RightPiece(piece))
      {
        state.Enabled = d3RightEnabled;
        state.X = 134;
        state.Y = DisplayYToUnityY(58, 49);
        state.Mirror = d3RightMirror;
        resolvedNormalWallByPiece[piece] = state;
        continue;
      }

      // F0, LeftD3, and RightD3 still use the V17 command selection. Live
      // Enabled/X/Y/Mirror must match the same FINAL DRAW the blitters use.
      bool remainingEnabled =
          IsViewport17NormalWallSelected(piece, finalCommands);
      bool remainingMirror = state.Mirror;
      string remainingFamily = GetViewport17NormalWallFamily(piece);
      if (remainingFamily == "LeftD3")
        remainingMirror = GetViewport17D3OuterMirror(false);
      else if (remainingFamily == "RightD3")
        remainingMirror = GetViewport17D3OuterMirror(true);
      if (!string.IsNullOrEmpty(remainingFamily))
      {
        ApplyViewport17NativeManualControls(
            remainingFamily, ref remainingEnabled, ref remainingMirror);
      }

      state.Enabled = remainingEnabled;
      state.Mirror = remainingMirror;
      if (state.Enabled && IsWallF0RightPiece(piece))
      {
        state.X = 191;
        state.Y = DisplayYToUnityY(33, GetPieceHeightForEditorY(piece));
        if (!previewMirrorOverrideByPiece.ContainsKey(piece))
          state.Mirror = GetSideWallMirrorFromPose();
      }
      if (state.Enabled && IsWallF0LeftPiece(piece))
      {
        state.X = 0;
        state.Y = DisplayYToUnityY(33, GetPieceHeightForEditorY(piece));
        if (!previewMirrorOverrideByPiece.ContainsKey(piece))
          state.Mirror = GetSideWallMirrorFromPose();
      }
      if (state.Enabled
          && remainingFamily == "LeftD3")
      {
        // Match the actual V17 draw command: opening-at-D3 geometry keeps
        // X=0, while the clipped oblique LeftD3 geometry uses X=-9.
        state.X = HasLeftD3LeadingStripActiveTile() ? 0 : -9;
        state.Y = DisplayYToUnityY(
            58, GetPieceHeightForEditorY(piece));
        if (!previewMirrorOverrideByPiece.ContainsKey(piece))
          state.Mirror = GetViewport17D3OuterMirror(false);
      }
      if (state.Enabled
          && remainingFamily == "RightD3"
          && TryGetCanonicalReferenceXY("RightD3", out int rightD3X, out int rightD3Y))
      {
        // Two verified RightD3-behind-RightF0 sliver classes use their own
        // horizontal calibration while remaining geometry-driven:
        //   center terminates at D3 -> X=178 (7,11 South class)
        //   center/right stay open to D3 outer wall -> X=180 (9,9 East class)
        // Both use Y=58 and Mirror ON in the original.
        bool rightD3F0Sliver = IsViewport17RightD3F0Sliver(inspection);
        bool rightD3OuterCorridorSliver =
            IsViewport17RightD3OuterCorridorSliver(inspection);
        state.X = rightD3F0Sliver
            ? NativeD3RightF0SliverX
            : rightD3OuterCorridorSliver
                ? NativeD3RightOuterCorridorSliverX
                : rightD3X;
        state.Y = DisplayYToUnityY(
            rightD3Y, GetPieceHeightForEditorY(piece));
        if (!previewMirrorOverrideByPiece.ContainsKey(piece))
          state.Mirror = rightD3F0Sliver || rightD3OuterCorridorSliver
              ? true
              : GetViewport17D3OuterMirror(true);
      }

      resolvedNormalWallByPiece[piece] = state;
    }
  }

  /// <summary>
  /// Stationary-pose ViewEdit tests overlay geometry in resolved state
  /// only. They are never written to ViewportLayout.asset.
  /// </summary>
  private void ApplyTemporaryNormalWallPreviewOverrides()
  {
    if (layout == null || layout.Pieces == null)
      return;

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null || !IsWallRenderingPiece(piece))
        continue;

      bool hasEnabledOverride = previewEnabledOverrideByPiece.TryGetValue(
          piece, out bool previewEnabled);
      bool hasPositionOverride = previewPositionOverrideByPiece.TryGetValue(
          piece, out Vector2Int previewPosition);
      bool hasMirrorOverride = previewMirrorOverrideByPiece.TryGetValue(
          piece, out bool previewMirror);
      bool hasGraphicOverride = previewGraphicOverrideByPiece.TryGetValue(
          piece, out DungeonGraphicType previewGraphic);
      bool hasWidthOverride = false;
      bool hasFrontF3WidthOverride = false;
      int previewWidth = 0;
      int previewFrontF3Width = 0;
      if (IsFrontWallF1Card(piece)
          && previewFrontF1WidthOverrideByPiece.TryGetValue(
              piece, out previewWidth))
      {
        hasWidthOverride = true;
      }
      if (IsFrontWallF3Card(piece)
          && previewFrontF3WidthOverrideByPiece.TryGetValue(
              piece, out previewFrontF3Width))
      {
        hasFrontF3WidthOverride = true;
      }

      if (!hasEnabledOverride
          && !hasPositionOverride
          && !hasMirrorOverride
          && !hasWidthOverride
          && !hasFrontF3WidthOverride
          && !hasGraphicOverride)
      {
        continue;
      }

      if (!resolvedNormalWallByPiece.TryGetValue(
              piece, out ResolvedNormalWallState state))
      {
        state = new ResolvedNormalWallState
        {
          Enabled = piece.Enabled,
          Graphic = piece.Graphic,
          X = piece.EffectiveX,
          Y = piece.EffectiveY,
          Mirror = piece.MirrorHorizontally,
          FrontF1Width = piece.FrontWallF1Width,
          FrontF2Width = piece.FrontWallF2Width
        };
      }

      if (hasEnabledOverride)
        state.Enabled = previewEnabled;
      if (hasGraphicOverride)
        state.Graphic = previewGraphic;
      if (hasPositionOverride)
      {
        state.X = previewPosition.x;
        state.Y = previewPosition.y;
      }
      if (hasMirrorOverride)
        state.Mirror = previewMirror;
      if (hasWidthOverride)
      {
        state.FrontF1Width =
            StraightF1WallLogic.NormalizeFrontWallF1Width(previewWidth);
      }
      if (hasFrontF3WidthOverride)
      {
        state.FrontF3Width = Mathf.Clamp(
            previewFrontF3Width, 1, GetFrontF3FullSourceWidthForViewEdit());
      }

      // Keep the resolved card in lockstep with the verified automatic
      // 10,5-West FrontF3 recipe (full authored width at X=185).
      if (IsFrontWallF3Card(piece)
          && IsViewport17D3RightOpenSlitFront())
      {
        state.FrontF3Width = NativeD3RightOpenSlitFrontWidth;
        previewFrontF3WidthOverrideByPiece[piece] =
            NativeD3RightOpenSlitFrontWidth;
      }

      resolvedNormalWallByPiece[piece] = state;
    }
  }

  /// <summary>
  /// Original-Dungeon-Master-style normal-wall authority:
  /// map + facing -> fixed relative cells -> fixed wall pieces.
  ///
  /// No saved views, no absolute map-coordinate cases, no perspective math.
  /// This stage changes only Enabled. Existing authored X/Y/width/source/mirror
  /// remain the fixed drawing recipe for each wall piece.
  /// </summary>
  private void ApplyFixedDungeonWallRecipe()
  {
    resolvedNormalWallByPiece.Clear();

    if (layout == null || layout.Pieces == null)
      return;

    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null)
      return;

    // Always return geometry/source properties to the one shared authored
    // baseline before deciding which relative slots are occupied.
    RestoreNormalWallBaselineProperties();

    RelativeViewportGeometry g =
        RelativeViewportGeometry.Calculate(
            previewMiniMap,
            previewX,
            previewY,
            previewFacing);

    // CHATGPT_BUILD_SCUMMVM_RELATIVE_CELLS_STAGE1_20260829_AG
    // Source-backed Dungeon Master occupancy: each relative wall cell is
    // enabled directly from its own map cell. Do not manually suppress farther
    // cells; the original renderer gets occlusion from fixed draw order/shapes.
    bool leftF0   = IsViewEditGeometryWall(g.F0Left);
    bool rightF0  = IsViewEditGeometryWall(g.F0Right);

    bool leftF1   = IsViewEditGeometryWall(g.F1Left);
    bool frontF1  = IsViewEditGeometryWall(g.F1Center);
    bool rightF1  = IsViewEditGeometryWall(g.F1Right);

    bool leftF2   = IsViewEditGeometryWall(g.F2Left);
    bool rightF2  = IsViewEditGeometryWall(g.F2Right);

    bool leftF3   = IsViewEditGeometryWall(g.F3Left);
    bool frontF3  = IsViewEditGeometryWall(g.F3Center);
    bool rightF3  = IsViewEditGeometryWall(g.F3Right);

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (!IsNormalWallPiece(piece))
        continue;

      bool enabled = false;

      if (IsWallF0LeftPiece(piece))
        enabled = leftF0;
      else if (IsWallF0RightPiece(piece))
        enabled = rightF0;
      else if (IsWallF1LeftPiece(piece))
        enabled = leftF1;
      else if (IsFrontWallF1Card(piece))
        enabled = frontF1;
      else if (IsWallF1RightPiece(piece))
        enabled = rightF1;
      else if (IsWallF2LeftPiece(piece))
        enabled = leftF2;
      else if (IsFrontWallF2Card(piece))
        enabled = piece.Enabled;
      else if (IsWallF2RightPiece(piece))
        enabled = rightF2;
      else if (IsWallF3LeftPiece(piece))
        enabled = leftF3;
      else if (IsFrontWallF3Card(piece))
        enabled = frontF3;
      else if (IsWallF3RightPiece(piece))
        enabled = rightF3;
      else
      {
        // Legacy D3 helper pieces are not part of the first fixed-slot table.
        enabled = false;
      }

      if (!IsFrontWallF2Card(piece))
        piece.Enabled = enabled;
      piece.PoseOffsetX = 0;
      piece.PoseOffsetY = 0;

      // CHATGPT_BUILD_SCUMMVM_D1_Y_FIX_STAGE3_20260829_AI
      // ScummVM/DM destination frames for depth D1 only.
      // D1L: 0..63, D1C: 32..191, D1R: 160..223; ScummVM top-down y 9..119 converts to Unity bottom-up Y=16.
      // FrontF1 width 160 is centered by StraightF1WallLogic, so X=0
      // produces the source-backed D1C destination x=32.
      if (IsWallF1LeftPiece(piece))
      {
        piece.X = 0;
        piece.Y = 16;
      }
      else if (IsFrontWallF1Card(piece))
      {
        piece.X = 0;
        piece.Y = 16;
        piece.FrontWallF1Width = StraightF1WallLogic.CompositeWidth160;
      }
      else if (IsWallF1RightPiece(piece))
      {
        piece.X = 160;
        piece.Y = 16;
      }
    }
  }

  private static bool IsWallF0LeftPiece(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    if (piece.Name == "Wall F0Left" || piece.Name == "LeftF0")
      return true;

    return piece.Graphic == DungeonGraphicType.WallF0L;
  }

  private static bool IsWallF0RightPiece(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    if (piece.Name == "Wall F0Right" || piece.Name == "RightF0")
      return true;

    return piece.Graphic == DungeonGraphicType.WallF0R;
  }

  private static bool IsWallF1LeftPiece(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    if (piece.Name == "Wall F1Left" || piece.Name == "LeftF1")
      return true;

    return piece.Graphic == DungeonGraphicType.WallF1L;
  }

  private static bool IsWallF1RightPiece(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    if (piece.Name == "Wall F1Right" || piece.Name == "RightF1")
      return true;

    return piece.Graphic == DungeonGraphicType.WallF1R;
  }

  private static bool IsWallF2LeftPiece(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    if (piece.Name == "Wall F2Left" || piece.Name == "LeftF2")
      return true;

    return piece.Graphic == DungeonGraphicType.WallF2L;
  }

  private static bool IsWallF2RightPiece(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    if (piece.Name == "Wall F2Right" || piece.Name == "RightF2")
      return true;

    return piece.Graphic == DungeonGraphicType.WallF2R;
  }

  private static bool IsWallF3LeftPiece(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    if (piece.Name == "Wall F3Left" || piece.Name == "LeftF3")
      return true;

    return piece.Graphic == DungeonGraphicType.WallF3L;
  }

  private static bool IsWallF3RightPiece(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    if (piece.Name == "Wall F3Right" || piece.Name == "RightF3")
      return true;

    return piece.Graphic == DungeonGraphicType.WallF3R;
  }

  private static bool IsNormalWallPiece(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    if (IsWallF0LeftPiece(piece)
        || IsWallF0RightPiece(piece)
        || IsWallF1LeftPiece(piece)
        || IsWallF1RightPiece(piece)
        || IsWallF2LeftPiece(piece)
        || IsWallF2RightPiece(piece)
        || IsWallF3LeftPiece(piece)
        || IsWallF3RightPiece(piece)
        || IsFrontWallF1Card(piece)
        || IsFrontWallF2Card(piece)
        || IsFrontWallF3Card(piece))
    {
      return true;
    }

    return piece.Graphic == DungeonGraphicType.WallD3L2
        || piece.Graphic == DungeonGraphicType.WallD3R2
        || piece.Name == "LeftS3"
        || piece.Name == "RightS3"
        || piece.Name == "LeftD3"
        || piece.Name == "RightD3"
        || piece.Name == "Wall D3L2"
        || piece.Name == "Wall D3R2";
  }

  private void CaptureNormalWallBaselinesFromLayout()
  {
    normalWallBaselineByName.Clear();

    if (layout == null || layout.Pieces == null)
      return;

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (!IsNormalWallPiece(piece))
        continue;

      string key = piece.Name ?? string.Empty;
      if (key.Length == 0)
        continue;

      normalWallBaselineByName[key] = new NormalWallBaseline
      {
        Graphic = piece.Graphic,
        X = piece.X,
        Y = piece.Y,
        Mirror = piece.MirrorHorizontally,
        FrontF1Width = piece.FrontWallF1Width,
        FrontF2Width = piece.FrontWallF2Width
      };
    }
  }

  private void RestoreNormalWallBaselineProperties()
  {
    if (layout == null || layout.Pieces == null)
      return;

    if (normalWallBaselineByName.Count == 0)
      CaptureNormalWallBaselinesFromLayout();

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (!IsNormalWallPiece(piece))
        continue;

      string key = piece.Name ?? string.Empty;
      if (!normalWallBaselineByName.TryGetValue(key, out NormalWallBaseline baseline))
        continue;

      piece.Graphic = baseline.Graphic;
      piece.X = baseline.X;
      piece.Y = baseline.Y;
      piece.MirrorHorizontally = baseline.Mirror;
      piece.PoseOffsetX = 0;
      piece.PoseOffsetY = 0;
      piece.FrontWallF1Width = baseline.FrontF1Width;
      piece.FrontWallF2Width = baseline.FrontF2Width;
    }
  }


  private bool TryGetResolvedNormalWallState(
      ViewportPiece piece,
      out ResolvedNormalWallState state)
  {
    state = default;
    return piece != null
        && resolvedNormalWallByPiece.TryGetValue(piece, out state);
  }


  /// <summary>
  /// Ceiling mirror from (1,3) North = ON. Toggles once per tile step
  /// (forward/back/strafe) and once per 90° turn. Floor and walls unchanged.
  /// </summary>
  private void ApplyCeilingMirrorFromPose()
  {
    if (layout == null || layout.Pieces == null)
      return;

    bool mirrorOn =
        ((previewX + previewY + (int)previewFacing) & 1) == 0;

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null || piece.Name != "Ceiling")
        continue;

      piece.MirrorHorizontally = mirrorOn;
      return;
    }
  }

  /// <summary>
  /// Floor mirror from (1,3) North = OFF. Toggles once per tile step
  /// (forward/back/strafe) and once per 90° turn, opposite to the ceiling phase.
  /// No other piece is changed.
  /// </summary>
  private void ApplyFloorMirrorReferenceOverride()
  {
    if (layout == null || layout.Pieces == null)
      return;

    bool mirrorOn =
        ((previewX + previewY + (int)previewFacing) & 1) != 0;

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null || piece.Name != "Floor")
        continue;

      piece.MirrorHorizontally = mirrorOn;
      return;
    }
  }

  /// <summary>
  /// Black Door ViewEdit Enabled exceptions. Does not change blit or other poses.
  /// (1,4) North: F2 view — F1 off, F2 on.
  /// (1,3) North: F1 view — F1 on, F2 off, F3 off.
  /// (1,5) North: F3 view — F1 off, F2 off, F3 on.
  /// </summary>
  private void ApplyBlackDoorEnabledFromPoseException()
  {
    if (layout == null || layout.Pieces == null)
      return;

    bool doorAtF1 = IsDoorF1FrontView();
    bool doorAtF2 = IsDoorF2FrontView();
    bool doorAtF3 = IsDoorF3FrontView();

    // Black Door state is pose-local. A door piece enabled in one valid view
    // must never leak into an unrelated map pose (for example 4,9 East).
    // Clear every distance family that is not required by the current pose
    // before applying the matching F1/F2/F3 composition below.
    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null)
        continue;

      if (!doorAtF1
          && (piece.Name == "BlackDoorF1"
              || piece.Name == "Black Door Frame Left F1"
              || piece.Name == "Black Door Frame Right F1"))
      {
        piece.Enabled = false;
      }

      if (!doorAtF2
          && (piece.Name == "BlackDoorF2"
              || piece.Name == "Black Door Frame Left F2"
              || piece.Name == "Black Door Frame Right F2"))
      {
        piece.Enabled = false;
      }

      if (!doorAtF3
          && (piece.Name == "BlackDoorF3"
              || piece.Name == "Black Door Frame Left F3"
              || piece.Name == "Black Door Frame Right F3"))
      {
        piece.Enabled = false;
      }
    }

    if (!doorAtF2)
    {
      blackDoorF2CardEnabled = false;
      blackDoorF2CardInitialized = false;
    }

    if (!doorAtF3)
    {
      blackDoorF3CardEnabled = false;
      blackDoorF3CardInitialized = false;
      blackDoorFrameLeftF3CardEnabled = false;
      blackDoorFrameRightF3CardEnabled = false;
    }

    // Only the Hall of Champions special entrance Black Door may activate this
    // renderer. Ordinary Door tiles elsewhere are deliberately excluded.
    if (IsDoorF1FrontView())
    {
      blackDoorF2CardEnabled = false;
      blackDoorF2CardInitialized = true;
      blackDoorF3CardEnabled = false;
      blackDoorF3CardInitialized = true;
      blackDoorFrameLeftF3CardEnabled = false;
      blackDoorFrameRightF3CardEnabled = false;

      // Verified F1 door layout, now selected by a relative door-at-F1 test.
      // Display coordinates:
      //   Left frame  X=44  Y=46
      //   Right frame X=154 Y=46
      //   Door        X=63  Y=47
      for (int i = 0; i < layout.Pieces.Count; i++)
      {
        ViewportPiece piece = layout.Pieces[i];
        if (piece == null)
          continue;

        if (piece.Name == "Black Door Frame Left F1")
        {
          if (!blackDoorFrameLeftF1EnabledInitialized)
          {
            piece.Enabled = true;
            blackDoorFrameLeftF1EnabledInitialized = true;
          }

          piece.X = 44;
          piece.Y = DisplayYToUnityY(46, 94);
        }
        else if (piece.Name == "Black Door Frame Right F1")
        {
          if (!blackDoorFrameRightF1EnabledInitialized)
          {
            piece.Enabled = true;
            blackDoorFrameRightF1EnabledInitialized = true;
          }

          piece.X = 154;
          piece.Y = DisplayYToUnityY(46, 94);
        }
        else if (piece.Name == "BlackDoorF1")
        {
          if (!blackDoorF1EnabledInitialized)
          {
            piece.Enabled = true;
            blackDoorF1EnabledInitialized = true;
          }

          piece.X = 63;
          piece.Y = DisplayYToUnityY(47, 88);
        }
        else if (piece.Name == "LeftF1" || piece.Name == "Wall F1Left")
        {
          piece.Enabled = true;
          if (resolvedNormalWallByPiece.TryGetValue(
                  piece, out ResolvedNormalWallState leftF1State))
          {
            leftF1State.Enabled = true;
            resolvedNormalWallByPiece[piece] = leftF1State;
          }
        }
        else if (piece.Name == "RightF1" || piece.Name == "Wall F1Right")
        {
          piece.Enabled = true;
          if (resolvedNormalWallByPiece.TryGetValue(
                  piece, out ResolvedNormalWallState rightF1State))
          {
            rightF1State.Enabled = true;
            resolvedNormalWallByPiece[piece] = rightF1State;
          }
        }

        // An F1 door occupies the center opening.
        // Keep the normal FrontF2 wall disabled for this dedicated door view.
        if (IsFrontWallF2Card(piece)
            || FrontWallF2Logic.IsFrontWallF2Graphic(piece.Graphic))
        {
          piece.Enabled = false;
        }
      }

      return;
    }

    if (IsDoorF2FrontView())
    {
      // Initialize the ViewEdit F2 card once for this editor session.
      // Do not force it back on every preview compose, otherwise the
      // user's Enabled toggle is immediately overwritten.
      if (!blackDoorF2CardInitialized)
      {
        blackDoorF2CardEnabled = true;
        blackDoorF2CardInitialized = true;
      }
      blackDoorFrameLeftF3CardEnabled = false;
      blackDoorFrameRightF3CardEnabled = false;

      for (int i = 0; i < layout.Pieces.Count; i++)
      {
        ViewportPiece piece = layout.Pieces[i];
        if (piece == null)
          continue;

        if (piece.Name == "Black Door Frame Left F2"
            || piece.Name == "Black Door Frame Right F2")
        {
          piece.Enabled = true;
        }

        // Black Door F2 occupies the front view at an F2 door view. Any normal
        // FrontF3 card/graphic must stay disabled so it cannot appear behind
        // the dedicated door view.
        if (IsFrontWallF3Card(piece)
            || piece.Graphic == DungeonGraphicType.FrontWallF3)
        {
          piece.Enabled = false;
        }
      }

      return;
    }

    if (!doorAtF3)
      return;

    blackDoorF2CardEnabled = false;
    blackDoorF2CardInitialized = true;
    blackDoorF3CardEnabled = true;
    blackDoorF3CardInitialized = true;
    blackDoorFrameLeftF3CardEnabled = true;
    blackDoorFrameRightF3CardEnabled = true;

    // Initialize the visible Left F3 frame layout card once. After this,
    // its Enabled checkbox is authoritative and pose refreshes preserve it.
    if (!blackDoorFrameLeftF3EnabledInitialized)
    {
      ViewportPiece leftF3Frame = FindLayoutPieceByName("Black Door Frame Left F3");
      if (leftF3Frame != null)
        leftF3Frame.Enabled = true;

      blackDoorFrameLeftF3EnabledInitialized = true;
    }

    // Initialize the visible Right F3 frame layout card once. After this,
    // its Enabled checkbox is authoritative and pose refreshes preserve it.
    if (!blackDoorFrameRightF3EnabledInitialized)
    {
      ViewportPiece rightF3Frame = FindLayoutPieceByName("Black Door Frame Right F3");
      if (rightF3Frame != null)
        rightF3Frame.Enabled = true;

      blackDoorFrameRightF3EnabledInitialized = true;
    }

    // A Door at F3 occupies the center front view. Keep any
    // normal FrontF3 card/graphic disabled so it cannot render behind it.
    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null)
        continue;

      if (IsFrontWallF3Card(piece)
          || piece.Graphic == DungeonGraphicType.FrontWallF3)
      {
        piece.Enabled = false;
      }
    }

  }


  private bool[] CaptureWorkingEnabledFlags()
  {
    if (layout == null || layout.Pieces == null)
      return System.Array.Empty<bool>();

    bool[] flags = new bool[layout.Pieces.Count];
    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      flags[i] = piece != null && piece.Enabled;
    }

    return flags;
  }

  private void ApplyWorkingEnabledFlags(bool[] flags)
  {
    if (layout == null || layout.Pieces == null || flags == null)
      return;

    int count = Mathf.Min(flags.Length, layout.Pieces.Count);
    for (int i = 0; i < count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece != null)
        piece.Enabled = flags[i];
    }
  }

  private void ApplyKitBaselineEnabledToLayout()
  {
    if (layout == null || layout.Pieces == null)
      return;

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null)
        continue;

      if (piece.Name == "BlackDoorF1"
          || piece.Name == "BlackDoorF2"
          || piece.Name == "BlackDoorF3"
          || piece.Name == "Black Door Frame Left F1"
          || piece.Name == "Black Door Frame Right F1"
          || piece.Name == "Black Door Frame Left F2"
          || piece.Name == "Black Door Frame Right F2"
          || piece.Name == "Black Door Frame Left F3"
          || piece.Name == "Black Door Frame Right F3")
        continue;

      bool found = false;
      for (int b = 0; b < KitBaselineEnabled.Length; b++)
      {
        if (KitBaselineEnabled[b].Name == piece.Name)
        {
          piece.Enabled = KitBaselineEnabled[b].Enabled;
          found = true;
          break;
        }
      }

      // Unknown kit pieces must not keep a prior pose's Enabled.
      if (!found)
        piece.Enabled = false;
    }
  }

  /// <summary>
  /// Safe live defaults when a pose has no store entry: kit Enabled (or false)
  /// and MirrorHorizontally=false so the previous pose cannot leak.
  /// Does not write the store.
  /// </summary>
  private void ApplyUnknownPoseDefaultsToLayout()
  {
    ApplyKitBaselineEnabledToLayout();
    if (layout == null || layout.Pieces == null)
      return;

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece == null)
        continue;

      piece.MirrorHorizontally = false;
      piece.PoseOffsetX = 0;
      piece.PoseOffsetY = 0;
      if (StraightF1WallLogic.IsStraightF1FrontGraphic(piece.Graphic))
      {
        piece.FrontWallF1Width =
            StraightF1WallLogic.DefaultFrontWallF1Width;
      }

      if (FrontWallF2Logic.IsFrontWallF2Graphic(piece.Graphic))
      {
        piece.FrontWallF2Width = FrontWallF2Logic.DefaultWidth;
      }
    }
  }

  private void SwapPieces(int indexA, int indexB)
  {
    Undo.RecordObject(layout, "Viewport Layout Reorder");

    ViewportPiece temp = layout.Pieces[indexA];
    layout.Pieces[indexA] = layout.Pieces[indexB];
    layout.Pieces[indexB] = temp;
  }

  private void RefreshEditModePreview()
  {
    if (Application.isPlaying)
      return;

    if (layout == null)
    {
      RestoreViewportTextureAndDestroyPreview();
      RepaintGameViews();
      return;
    }

    if (graphics == null)
    {
      RestoreViewportTextureAndDestroyPreview();
      RepaintGameViews();
      // Still emit Console from previewFacing so it cannot lag the minimap.
      LogCurrentViewportStateToConsole();
      return;
    }

    // Drop any stale RawImage cache — hierarchy/presentation may have changed.
    cachedViewportImage = null;

    RawImage dungeonImage = FindLiveDungeonViewportRawImage();
    if (dungeonImage == null)
    {
      LogCurrentViewportStateToConsole();
      return;
    }

    cachedViewportImage = dungeonImage;

    // Recreate the preview Texture2D every refresh so RawImage/Canvas cannot
    // keep showing a stale GPU copy of an in-place updated texture.
    DestroyEditModePreviewTextureOnly();
    EnsureEditModePreviewTexture();
    ComposeEditModePreview();
    if (editModePreviewTexture == null)
    {
      LogCurrentViewportStateToConsole();
      return;
    }

    editModePreviewTexture.Apply(false);

    StealViewportTextureIfNeeded(dungeonImage);
    ApplyExact320x200EditModePresentation(dungeonImage);

    // Presentation may rebuild hierarchy — resolve the live RawImage again.
    dungeonImage = FindLiveDungeonViewportRawImage();
    if (dungeonImage == null)
    {
      LogCurrentViewportStateToConsole();
      return;
    }

    cachedViewportImage = dungeonImage;

    // Force a reference change so RawImage/Canvas pick up the new Texture2D.
    dungeonImage.texture = Texture2D.whiteTexture;
    dungeonImage.texture = editModePreviewTexture;
    if (dungeonImage.canvas != null)
      Canvas.ForceUpdateCanvases();

    MaintainMovementArrowsPreview();
    RepaintGameViews();

    // After pose visibility/mirror apply (+ compose when Game View is available).
    LogCurrentViewportStateToConsole();
  }

  private void ApplyExact320x200EditModePresentation(RawImage dungeonImage)
  {
    if (dungeonImage == null)
      return;

    ApplyConstantPixelCanvasScaler(dungeonImage);

    RectTransform gameplayRoot = FindGameplayRoot(dungeonImage);
    if (gameplayRoot != null)
    {
      if (!gameplayRootRectSaved)
      {
        savedGameplayRootRect =
            RectTransformSnapshot.Capture(gameplayRoot);
        gameplayRootRectSaved = true;
        cachedGameplayRoot = gameplayRoot;
      }

      ApplyCentered320x200Rect(gameplayRoot);
    }

    RectTransform viewportRect = dungeonImage.rectTransform;
    if (!viewportRectSaved)
    {
      savedViewportRect = RectTransformSnapshot.Capture(viewportRect);
      viewportRectSaved = true;
    }

    ApplyCentered320x200Rect(viewportRect);
    presentationOverrideActive = true;
  }

  private void MaintainMovementArrowsPreview()
  {
    if (Application.isPlaying)
    {
      RestoreMovementArrowsOverride();
      return;
    }

    if (layout == null
        || graphics == null
        || !presentationOverrideActive)
    {
      RestoreMovementArrowsOverride();
      return;
    }

    if (!TryGetViewportRawImage(out RawImage dungeonImage))
    {
      RestoreMovementArrowsOverride();
      return;
    }

    ViewportPiece arrowsPiece = FindMovementArrowsPiece();
    if (arrowsPiece == null)
    {
      RestoreMovementArrowsOverride();
      return;
    }

    Image arrows = FindMovementArrowsImage();
    if (arrows == null)
      return;

    CaptureMovementArrowsStateIfNeeded(arrows);

    RectTransform arrowsRect = arrows.rectTransform;
    if (arrowsRect.parent != dungeonImage.rectTransform)
      arrowsRect.SetParent(dungeonImage.rectTransform, false);

    MovementArrowsLayout.Apply(
        arrows,
        arrowsPiece.X,
        arrowsPiece.Y,
        arrowsPiece.Enabled);

    arrowsRect.SetAsLastSibling();
  }

  private ViewportPiece FindMovementArrowsPiece()
  {
    if (layout == null || layout.Pieces == null)
      return null;

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (piece != null
          && piece.Graphic == DungeonGraphicType.MovementArrows)
      {
        return piece;
      }
    }

    return null;
  }

  private static Image FindMovementArrowsImage()
  {
    Image[] images = Object.FindObjectsByType<Image>(
        FindObjectsInactive.Include);

    for (int i = 0; i < images.Length; i++)
    {
      Image image = images[i];
      if (image != null && image.gameObject.name == "MovementArrows")
        return image;
    }

    return null;
  }

  private void CaptureMovementArrowsStateIfNeeded(Image arrows)
  {
    if (movementArrowsStateSaved || arrows == null)
      return;

    RectTransform rect = arrows.rectTransform;
    savedMovementArrowsActive = arrows.gameObject.activeSelf;
    savedMovementArrowsParent = rect.parent;
    savedMovementArrowsSiblingIndex = rect.GetSiblingIndex();
    savedMovementArrowsRect = RectTransformSnapshot.Capture(rect);
    savedMovementArrowsPreserveAspect = arrows.preserveAspect;

    Texture texture = arrows.mainTexture;
    if (texture != null)
    {
      savedMovementArrowsFilterTexture = texture;
      savedMovementArrowsFilterMode = texture.filterMode;
      movementArrowsFilterSaved = true;
    }

    cachedMovementArrows = arrows;
    movementArrowsStateSaved = true;
  }

  private void RestoreMovementArrowsOverride()
  {
    if (!movementArrowsStateSaved)
      return;

    Image arrows = cachedMovementArrows;
    if (arrows == null)
      arrows = FindMovementArrowsImage();

    if (arrows != null)
    {
      RectTransform arrowsRect = arrows.rectTransform;

      if (savedMovementArrowsParent != null)
        arrowsRect.SetParent(savedMovementArrowsParent, false);
      else if (arrowsRect.parent != null)
        arrowsRect.SetParent(null, false);

      savedMovementArrowsRect.Apply(arrowsRect);

      int siblingCount = arrowsRect.parent != null
          ? arrowsRect.parent.childCount
          : 0;
      if (siblingCount > 0)
      {
        arrowsRect.SetSiblingIndex(
            Mathf.Clamp(
                savedMovementArrowsSiblingIndex,
                0,
                siblingCount - 1));
      }

      arrows.preserveAspect = savedMovementArrowsPreserveAspect;
      arrows.gameObject.SetActive(savedMovementArrowsActive);
    }

    if (movementArrowsFilterSaved
        && savedMovementArrowsFilterTexture != null)
    {
      savedMovementArrowsFilterTexture.filterMode =
          savedMovementArrowsFilterMode;
    }

    movementArrowsStateSaved = false;
    movementArrowsFilterSaved = false;
    savedMovementArrowsFilterTexture = null;
    savedMovementArrowsParent = null;
    cachedMovementArrows = null;
  }

  private void ApplyConstantPixelCanvasScaler(RawImage dungeonImage)
  {
    if (dungeonImage.canvas == null)
      return;

    CanvasScaler scaler =
        dungeonImage.canvas.GetComponent<CanvasScaler>();
    if (scaler == null)
      return;

    if (!canvasScalerStateSaved)
    {
      savedScalerMode = scaler.uiScaleMode;
      savedScalerScaleFactor = scaler.scaleFactor;
      savedScalerReferenceResolution = scaler.referenceResolution;
      savedScalerMatchWidthOrHeight = scaler.matchWidthOrHeight;
      canvasScalerStateSaved = true;
    }

    scaler.uiScaleMode = CanvasScaler.ScaleMode.ConstantPixelSize;
    scaler.scaleFactor = 1f;
  }

  private static void ApplyCentered320x200Rect(RectTransform rect)
  {
    rect.anchorMin = new Vector2(0.5f, 0.5f);
    rect.anchorMax = new Vector2(0.5f, 0.5f);
    rect.pivot = new Vector2(0.5f, 0.5f);
    rect.anchoredPosition = Vector2.zero;
    rect.sizeDelta = new Vector2(PreviewWidth, PreviewHeight);
    rect.localScale = Vector3.one;
    rect.localRotation = Quaternion.identity;
  }

  private static RectTransform FindGameplayRoot(RawImage dungeonImage)
  {
    if (dungeonImage == null)
      return null;

    Transform t = dungeonImage.transform;
    while (t != null)
    {
      if (t.name == "GameplayRoot")
        return t as RectTransform;
      t = t.parent;
    }

    if (dungeonImage.canvas == null)
      return null;

    Transform found =
        dungeonImage.canvas.transform.Find("GameplayRoot");
    return found as RectTransform;
  }

  private void RestoreEditModePresentationOverrides()
  {
    RestoreMovementArrowsOverride();

    if (!presentationOverrideActive
        && !canvasScalerStateSaved
        && !viewportRectSaved
        && !gameplayRootRectSaved)
    {
      return;
    }

    RawImage dungeonImage = null;
    TryGetViewportRawImage(out dungeonImage);

    if (viewportRectSaved && dungeonImage != null)
      savedViewportRect.Apply(dungeonImage.rectTransform);

    if (canvasScalerStateSaved
        && dungeonImage != null
        && dungeonImage.canvas != null)
    {
      CanvasScaler scaler =
          dungeonImage.canvas.GetComponent<CanvasScaler>();
      if (scaler != null)
      {
        scaler.uiScaleMode = savedScalerMode;
        scaler.scaleFactor = savedScalerScaleFactor;
        scaler.referenceResolution =
            savedScalerReferenceResolution;
        scaler.matchWidthOrHeight =
            savedScalerMatchWidthOrHeight;
      }
    }

    if (gameplayRootRectSaved)
    {
      RectTransform gameplayRoot = cachedGameplayRoot;
      if (gameplayRoot == null && dungeonImage != null)
        gameplayRoot = FindGameplayRoot(dungeonImage);

      if (gameplayRoot != null)
        savedGameplayRootRect.Apply(gameplayRoot);
    }

    canvasScalerStateSaved = false;
    viewportRectSaved = false;
    gameplayRootRectSaved = false;
    cachedGameplayRoot = null;
    presentationOverrideActive = false;
  }

  private void EnsureEditModePreviewTexture()
  {
    if (editModePreviewTexture != null
        && editModePreviewTexture.width == PreviewWidth
        && editModePreviewTexture.height == PreviewHeight)
    {
      return;
    }

    if (editModePreviewTexture != null)
      Object.DestroyImmediate(editModePreviewTexture);

    editModePreviewTexture = new Texture2D(
        PreviewWidth,
        PreviewHeight,
        TextureFormat.RGBA32,
        false)
    {
      name = "ViewportLayoutEditModePreview",
      filterMode = FilterMode.Point,
      wrapMode = TextureWrapMode.Clamp,
      hideFlags = HideFlags.HideAndDontSave
    };
  }

  private static int GetNormalWallRenderDepth(ViewportPiece piece)
  {
    if (piece == null)
      return -1;

    // Higher number = farther from the player. Compose draws far -> near.
    if (IsWallF3LeftPiece(piece)
        || IsWallF3RightPiece(piece)
        || IsFrontWallF3Card(piece)
        || piece.Graphic == DungeonGraphicType.WallD3L2
        || piece.Graphic == DungeonGraphicType.WallD3R2
        || piece.Name == "LeftD3"
        || piece.Name == "RightD3"
        || piece.Name == "Wall D3L2"
        || piece.Name == "Wall D3R2")
    {
      return 3;
    }

    if (IsWallF2LeftPiece(piece)
        || IsWallF2RightPiece(piece)
        || IsFrontWallF2Card(piece))
    {
      return 2;
    }

    if (IsWallF1LeftPiece(piece)
        || IsWallF1RightPiece(piece)
        || IsFrontWallF1Card(piece))
    {
      return 1;
    }

    if (IsWallF0LeftPiece(piece) || IsWallF0RightPiece(piece))
      return 0;

    return -1;
  }

  private void ComposeEditModePreview()
  {
    EnsureEditModePreviewTexture();
    if (editModePreviewTexture == null)
      return;

    Color32 magenta = new Color32(255, 0, 255, 255);
    Color32[] pixels = new Color32[PreviewWidth * PreviewHeight];
    for (int i = 0; i < pixels.Length; i++)
      pixels[i] = magenta;

    // Temporary pose for visibility/mirror only — never write the layout asset.
    DungeonMap poseMap = TryGetPreviewPoseMap();
    bool viewport17WallAuthorityActive = IsViewport17WallAuthorityActive();
    Viewport17Inspection viewport17Inspection = default;
    List<Viewport17RenderCommand> viewport17FinalWallCommands = null;
    if (viewport17WallAuthorityActive)
    {
      viewport17Inspection = BuildViewport17Inspection();
      viewport17FinalWallCommands =
          BuildViewport17FinalDrawCommands(viewport17Inspection);
      // Keep ViewEdit Enabled/X/Y/Mirror on the same values this compose
      // is about to blit, including FrontF3 L/R strips.
      ApplyViewport17LiveDrawToResolvedWalls();
      ApplyTemporaryNormalWallPreviewOverrides();
    }

    if (layout != null && layout.Pieces != null)
    {
      // Draw normal walls by physical depth (far -> near) without changing
      // layout.Pieces itself. Non-wall pieces keep their original slots/order.
      List<ViewportPiece> orderedNormalWalls = new List<ViewportPiece>();
      bool hasLiveFrontF3Card = false;
      for (int i = 0; i < layout.Pieces.Count; i++)
      {
        ViewportPiece candidate = layout.Pieces[i];
        if (candidate != null && candidate.Name == "FrontF3")
          hasLiveFrontF3Card = true;
        if (IsNormalWallPiece(candidate))
          orderedNormalWalls.Add(candidate);
      }

      orderedNormalWalls.Sort(
          (a, b) => GetNormalWallRenderDepth(b).CompareTo(
              GetNormalWallRenderDepth(a)));

      int nextNormalWall = 0;
      bool viewport17NativeD3Drawn = false;
      bool viewport17NativeD2Drawn = false;
      bool viewport17NativeD1Drawn = false;
      // Black Door F2/F3 replaces only the D3 center wall. The original
      // view still keeps the native D3 left/right side walls around the door.
      bool suppressViewport17NativeD3CenterForBlackDoor =
          IsDoorF2FrontView()
          || IsDoorF3FrontView();
      bool blockViewport17NativeD2ForBlackDoor =
          IsDoorF1FrontView();
      bool suppressViewport17NativeD2CenterForBlackDoorF2 =
          IsDoorF2FrontView();
      bool blockViewport17NativeD1ForBlackDoor =
          IsDoorF1FrontView();
      for (int i = 0; i < layout.Pieces.Count; i++)
      {
        ViewportPiece piece = layout.Pieces[i];
        if (IsNormalWallPiece(piece))
          piece = orderedNormalWalls[nextNormalWall++];

        if (previewDisableAllWalls
            && piece != null
            && !IsDisableWallsKeeper(piece)
            && (!previewEnabledOverrideByPiece.TryGetValue(
                    piece, out bool manuallyEnabledAfterDisable)
                || !manuallyEnabledAfterDisable))
        {
          continue;
        }

        // V17 F3 cutover: draw the original DOS D3 L/C/R artwork once, at
        // the far-wall point in painter order, before any nearer wall can
        // cover it.  The legacy 141x49 FrontF3 composite and the old F3
        // side placements are suppressed below.
        if (viewport17WallAuthorityActive
            && !viewport17NativeD3Drawn
            && piece != null
            && IsNormalWallPiece(piece))
        {
          viewport17NativeD3Drawn = true;
          // Black Door F2/F3 replaces only the D3 center wall. Keep the
          // native D3 left/right side walls visible around the dedicated door.
          BlitViewport17NativeD3Walls(
              pixels,
              viewport17Inspection,
              viewport17FinalWallCommands,
              suppressCenter: suppressViewport17NativeD3CenterForBlackDoor);

          // A door at relative (+1, 3) belongs to this same far D3 painter
          // stage. Draw the complete far-slot door/frame now and let the
          // ordinary D2/D1 geometry drawn later occlude it naturally.
          BlitDoorF3RightObliqueAtD3Stage(pixels);
        }

        if (viewport17WallAuthorityActive
            && piece != null
            && (IsWallF3LeftPiece(piece)
                || IsFrontWallF3Card(piece)
                || IsWallF3RightPiece(piece)))
        {
          continue;
        }

        // V17 F2 cutover: wait until painter order reaches depth 2, then draw
        // the original DOS D2 L/C/R artwork once. This preserves all depth-3
        // drawing behind it and all F1/F0 drawing in front of it.
        if (viewport17WallAuthorityActive
            && !viewport17NativeD2Drawn
            && piece != null
            && IsNormalWallPiece(piece)
            && GetNormalWallRenderDepth(piece) == 2)
        {
          viewport17NativeD2Drawn = true;
          if (!blockViewport17NativeD2ForBlackDoor)
          {
            // Black Door F2 replaces only the D2 center wall. Keep the
            // normal D2 left/right side walls visible around it.
            BlitViewport17NativeD2Walls(
                pixels,
                viewport17Inspection,
                viewport17FinalWallCommands,
                suppressCenter:
                    suppressViewport17NativeD2CenterForBlackDoorF2);
          }
        }

        if (viewport17WallAuthorityActive
            && piece != null
            && (IsWallF2LeftPiece(piece)
                || IsFrontWallF2Card(piece)
                || IsWallF2RightPiece(piece)))
        {
          continue;
        }

        // V17 F1 cutover: draw the original DOS D1 L/C/R artwork once when
        // painter order reaches depth 1.  This replaces the old 224x111
        // screenshot composite and the pose-specific (5,2) RAW160 test.
        if (viewport17WallAuthorityActive
            && !viewport17NativeD1Drawn
            && piece != null
            && IsNormalWallPiece(piece)
            && GetNormalWallRenderDepth(piece) == 1)
        {
          viewport17NativeD1Drawn = true;
          if (!blockViewport17NativeD1ForBlackDoor)
          {
            BlitViewport17NativeD1Walls(
                pixels, viewport17Inspection, viewport17FinalWallCommands);
          }
          else
          {
            // Black Door F1 owns the D1 center opening, but the original view
            // still uses the normal LeftF1/RightF1 side walls around it.
            // Draw those two side walls automatically; keep FrontF1 off so the
            // dedicated door remains the center surface. ViewEdit overrides
            // still apply last, so either side can be disabled/mirrored live.
            BlitViewport17NativeD1Walls(
                pixels, viewport17Inspection, viewport17FinalWallCommands,
                blackDoorSidesOnly: true);
          }
        }

        if (viewport17WallAuthorityActive
            && piece != null
            && (IsWallF1LeftPiece(piece)
                || IsFrontWallF1Card(piece)
                || IsWallF1RightPiece(piece)))
        {
          continue;
        }

        if (hasLiveFrontF3Card
            && piece != null
            && piece.Name == "Front Wall F3")
        {
          continue;
        }

        // A Door at F2 or F3 replaces the normal FrontF3 center wall.
        if ((IsDoorF2FrontView() || IsDoorF3FrontView())
            && piece != null
            && (IsFrontWallF3Card(piece)
                || piece.Graphic == DungeonGraphicType.FrontWallF3))
        {
          continue;
        }

        bool viewport17NormalWall =
            viewport17WallAuthorityActive && IsNormalWallPiece(piece);
        bool viewport17Selected =
            viewport17NormalWall
            && IsViewport17NormalWallSelected(
                piece, viewport17FinalWallCommands);
        bool viewport17EffectiveSelected = viewport17Selected;
        if (viewport17NormalWall
            && previewEnabledOverrideByPiece.TryGetValue(
                piece, out bool manualViewport17Enabled))
        {
          // V17 remains the automatic default, but ViewEdit may temporarily
          // force any individual wall image ON or OFF for this stationary pose.
          viewport17EffectiveSelected = manualViewport17Enabled;
        }
        bool shouldDraw = viewport17NormalWall
            ? viewport17EffectiveSelected
            : ShouldDrawPieceAtPreviewPose(piece);
        bool blackDoorF1Exception = IsBlackDoorF1PoseException(piece);
        bool blackDoorF2Exception = IsBlackDoorF2PoseException(piece);
        bool blackDoorF3Exception = IsBlackDoorF3PoseException(piece);
        bool manualNormalWallEnabledForDraw =
            !viewport17NormalWall
            && IsNormalWallPiece(piece)
            && previewEnabledOverrideByPiece.TryGetValue(
                piece, out bool manualWallEnabledForDraw)
            && manualWallEnabledForDraw;

        if (viewport17NormalWall)
        {
          // FINAL DRAW FROM VIEWPORT-17 is the automatic visibility default.
          // A ViewEdit Enabled click may temporarily override that one image
          // so the user can inspect exactly what each wall contributes.
          if (!viewport17EffectiveSelected)
            continue;
        }
        else if (!shouldDraw
            && !manualNormalWallEnabledForDraw
            && !blackDoorF1Exception
            && !blackDoorF2Exception
            && !blackDoorF3Exception)
        {
          continue;
        }

        if ((piece.Name == "Black Door Frame Left F2"
                || piece.Name == "Black Door Frame Right F2")
            && !IsDoorF2FrontView())
          continue;

        if (piece.Graphic == DungeonGraphicType.MovementArrows)
          continue;

        // Structural stairs replacement: a down-stairs tile in the D1-right
        // relative cell owns the screen slot normally occupied by RightF0.
        // Draw the stairs wall here, at the exact point where RightF0 would
        // have been rendered, and skip the ordinary wall. This makes stairs
        // part of wall geometry instead of a late overlay exception.
        if (IsWallF0RightPiece(piece)
            && IsStairsDownRightD1ForCurrentPose())
        {
          BlitStairsDownRightD1IntoPreview(pixels);
          continue;
        }

        // F1 door frames are drawn by the dedicated F1 door composition,
        // not in normal list order.
        if (IsDoorF1FrontView()
            && (piece.Name == "Black Door Frame Left F1"
                || piece.Name == "Black Door Frame Right F1"))
        {
          continue;
        }

        // A door directly ahead occupies the F1 center opening.
        // Do not draw the normal FrontF2 wall through it.
        if (IsDoorF1FrontView()
            && (IsFrontWallF2Card(piece)
                || FrontWallF2Logic.IsFrontWallF2Graphic(piece.Graphic)))
        {
          continue;
        }

        // Generic stairs-down rule: a down-stair in the near-center relative
        // cell occupies the FrontF2 band, so do not draw FrontF2 here.
        if (IsViewport17NearCenterStairsDown()
            && (IsFrontWallF2Card(piece)
                || FrontWallF2Logic.IsFrontWallF2Graphic(piece.Graphic)))
        {
          continue;
        }

        // CUTOVER: render transient geometry assembly for normal walls.
        bool mirror = GetPreviewMirror(piece, poseMap);
        // ViewEdit Mirror remains a temporary manual test for every normal wall,
        // including F2/F3 pieces that are not in the current cutover resolver.
        if (previewMirrorOverrideByPiece.TryGetValue(piece, out bool manualPreviewMirror))
          mirror = manualPreviewMirror;
        DungeonGraphicType drawGraphic = piece.Graphic;
        int resolvedX = piece.EffectiveX;
        int resolvedY = piece.EffectiveY;
        int resolvedF1Width =
            StraightF1WallLogic.NormalizeFrontWallF1Width(
                piece.FrontWallF1Width);

        if (TryGetResolvedNormalWallState(
                piece,
                out ResolvedNormalWallState resolvedWall))
        {

          bool resolvedEnabled = viewport17NormalWall
              ? viewport17EffectiveSelected
              : resolvedWall.Enabled;

          if (!viewport17NormalWall)
          {
            if (previewEnabledOverrideByPiece.TryGetValue(
                    piece, out bool manualNormalWallEnabled))
            {
              resolvedEnabled = manualNormalWallEnabled;
            }
            else if (IsFrontWallF1Card(piece)
                && TryGetFrontF1PreviewEnabledOverride(
                    out bool frontF1EnabledOverride))
            {
              resolvedEnabled = frontF1EnabledOverride;
            }
          }

          if (!resolvedEnabled)
            continue;

          // Geometry supplies the normal orientation. A ViewEdit-only checkbox
          // override may temporarily replace it until the preview pose changes.
          mirror = resolvedWall.Mirror;
          if (previewMirrorOverrideByPiece.TryGetValue(piece, out bool previewMirror))
            mirror = previewMirror;
          drawGraphic = resolvedWall.Graphic;
          if (previewGraphicOverrideByPiece.TryGetValue(
                  piece, out DungeonGraphicType previewGraphic))
            drawGraphic = previewGraphic;
          if (!IsWallF0LeftPiece(piece) && !IsWallF0RightPiece(piece)
              && !IsWallF1LeftPiece(piece) && !IsWallF1RightPiece(piece)
              && !IsWallF2LeftPiece(piece) && !IsWallF2RightPiece(piece)
              && !IsWallF3LeftPiece(piece) && !IsWallF3RightPiece(piece))
          {
            resolvedX = resolvedWall.X;
            resolvedY = resolvedWall.Y;
            if (previewPositionOverrideByPiece.TryGetValue(piece, out Vector2Int previewPosition))
            {
              resolvedX = previewPosition.x;
              resolvedY = previewPosition.y;
            }
          }
          resolvedF1Width = resolvedWall.FrontF1Width;
        }

        if (IsFrontWallF1Card(piece)
            && previewFrontF1WidthOverrideByPiece.TryGetValue(
                piece, out int manualFrontF1Width))
        {
          resolvedF1Width =
              StraightF1WallLogic.NormalizeFrontWallF1Width(
                  manualFrontF1Width);
        }

        // Side-wall dest is override else that piece's canonical Ref.
        // Mirror flips source pixels only; it never changes X/Y.
        // V17 owns F0 dest/mirror from live overlay; do not apply the
        // canonical edge-of-map geometry restriction.
        ResolvedNormalWallState liveF0 = default;
        if (viewport17WallAuthorityActive
            && (IsWallF0LeftPiece(piece) || IsWallF0RightPiece(piece))
            && TryGetResolvedNormalWallState(piece, out liveF0))
        {
          resolvedX = liveF0.X;
          resolvedY = liveF0.Y;
          if (previewPositionOverrideByPiece.TryGetValue(
                  piece, out Vector2Int f0Override))
          {
            resolvedX = f0Override.x;
            resolvedY = f0Override.y;
          }
          if (!previewMirrorOverrideByPiece.ContainsKey(piece))
            mirror = liveF0.Mirror;
        }
        else if (IsWallF0LeftPiece(piece) || IsWallF0RightPiece(piece)
            || IsWallF1LeftPiece(piece) || IsWallF1RightPiece(piece)
            || IsWallF2LeftPiece(piece) || IsWallF2RightPiece(piece)
            || IsWallF3LeftPiece(piece) || IsWallF3RightPiece(piece))
        {
          if (previewPositionOverrideByPiece.TryGetValue(
                  piece, out Vector2Int sideWallOverride))
          {
            resolvedX = sideWallOverride.x;
            resolvedY = sideWallOverride.y;
          }
          else if (TryGetCanonicalReferenceXY(
                       piece.Name, out int sideRefX, out int sideRefY)
                   || (TryGetSideWallCanonicalName(piece, out string sideCanonicalName)
                       && TryGetCanonicalReferenceXY(
                           sideCanonicalName, out sideRefX, out sideRefY)))
          {
            resolvedX = sideRefX;
            resolvedY = DisplayYToUnityY(
                sideRefY, GetPieceHeightForEditorY(piece));
          }

          if (!previewMirrorOverrideByPiece.ContainsKey(piece))
          {
            mirror = GetSideWallMirrorFromPose();
          }
        }

        // Temporary ViewEdit tests always win over canonical / pose
        // mirror for this stationary preview.
        if (!viewport17NormalWall
            && previewEnabledOverrideByPiece.TryGetValue(
                piece, out bool livePreviewEnabled)
            && IsNormalWallPiece(piece)
            && !livePreviewEnabled)
        {
          continue;
        }
        if (IsFrontWallF1Card(piece)
            && TryGetFrontF1PreviewMirrorOverride(
                piece, out bool frontF1PreviewMirror))
        {
          mirror = frontF1PreviewMirror;
        }
        else if (previewMirrorOverrideByPiece.TryGetValue(
                piece, out bool livePreviewMirror))
        {
          mirror = livePreviewMirror;
        }
        if (IsFrontWallF1Card(piece)
            && TryGetFrontF1PreviewPositionOverride(
                piece, out Vector2Int frontF1PreviewPosition))
        {
          resolvedX = frontF1PreviewPosition.x;
          resolvedY = frontF1PreviewPosition.y;
        }
        else if (previewPositionOverrideByPiece.TryGetValue(
                piece, out Vector2Int livePreviewPosition))
        {
          resolvedX = livePreviewPosition.x;
          resolvedY = livePreviewPosition.y;
        }
        if (IsFrontWallF1Card(piece)
            && TryGetFrontF1PreviewWidthOverride(
                piece, out int livePreviewWidth))
        {
          resolvedF1Width = livePreviewWidth;
        }

        // LeftS3 / RightS3 use handed-source mirroring.  The ViewEdit Mirror
        // checkbox is read directly here so no later resolver can replace it.
        // LeftS3 Mirror ON = mirror the RIGHT S3 source and blit it at the
        // LEFT S3 destination (normally X=0).  X/Y never swap sides.
        if (piece.Name == "LeftS3" || piece.Name == "RightS3")
        {
          bool handedMirror = mirror;
          if (previewMirrorOverrideByPiece.TryGetValue(
                  piece, out bool manualS3Mirror))
          {
            handedMirror = manualS3Mirror;
          }

          Texture2D wallS3Texture;
          if (piece.Name == "LeftS3")
          {
            wallS3Texture = handedMirror
                ? GetRight2STexture()
                : graphics.GetTexture(DungeonGraphicType.Left2S);
          }
          else
          {
            wallS3Texture = handedMirror
                ? graphics.GetTexture(DungeonGraphicType.Left2S)
                : GetRight2STexture();
          }

          if (wallS3Texture == null)
            continue;

          BlitPieceIntoPreview(
              pixels,
              wallS3Texture,
              resolvedX,
              resolvedY,
              handedMirror);
          continue;
        }

        // Native-only fallback for FrontF1 when Viewport-17 authority is OFF.
        // The production V17 path above already draws D1 L/R/C separately.
        if (StraightF1WallLogic.IsStraightF1FrontGraphic(piece.Graphic))
        {
          Texture2D f1Texture = GetReadableNativeFrontF1Texture();
          if (f1Texture == null)
            continue;

          BlitPieceIntoPreview(
              pixels,
              f1Texture,
              resolvedX,
              resolvedY,
              mirror);
          continue;
        }

        // Native-only fallback for FrontF2 when Viewport-17 authority is OFF.
        // The production V17 path above already draws D2 L/R/C separately.
        if (FrontWallF2Logic.IsFrontWallF2Graphic(piece.Graphic))
        {
          Texture2D f2Texture = GetReadableNativeFrontF2Texture();
          if (f2Texture == null)
            continue;

          BlitPieceIntoPreview(
              pixels,
              f2Texture,
              resolvedX,
              resolvedY,
              mirror);
          continue;
        }

        if (IsWallF0LeftPiece(piece) && mirror)
          drawGraphic = DungeonGraphicType.WallF0R;
        else if (IsWallF0RightPiece(piece) && mirror)
          drawGraphic = DungeonGraphicType.WallF0L;
        else if (IsWallF1LeftPiece(piece) && mirror)
          drawGraphic = DungeonGraphicType.WallF1R;
        else if (IsWallF1RightPiece(piece) && mirror)
          drawGraphic = DungeonGraphicType.WallF1L;
        else if (IsWallF2LeftPiece(piece) && mirror)
          drawGraphic = DungeonGraphicType.WallF2R;
        else if (IsWallF2RightPiece(piece) && mirror)
          drawGraphic = DungeonGraphicType.WallF2L;
        else if (IsWallF3LeftPiece(piece) && mirror)
          drawGraphic = DungeonGraphicType.WallF3R;
        else if (IsWallF3RightPiece(piece) && mirror)
          drawGraphic = DungeonGraphicType.WallF3L;
        // D3 uses the same handed-source mirror rule as every other left/right
        // wall pair: Mirror ON selects the opposite-side bitmap and then
        // horizontally mirrors it in place. Destination X/Y are unchanged.
        else if (IsLeftD3Piece(piece) && mirror)
          drawGraphic = DungeonGraphicType.WallD3R2;
        else if (IsRightD3Piece(piece) && mirror)
          drawGraphic = DungeonGraphicType.WallD3L2;

        // F2 door view: frames already blitted in kit order; BlackDoorF2
        // 63×59 1:1 last so it covers overlapping inner frame pixels.
        if (blackDoorF2Exception)
        {
          // Draw the two F2 frame pieces through the same live ViewEdit path
          // used by isolated composition, then place the front door over them.
          BlitBlackDoorF2FramesIntoPreview(pixels);

          // Dedicated front F2 door. At the verified F2 door view
          // exception pose the door is mandatory; do not gate it on the
          // stored Enabled flag.
          ViewportPiece doorF2 = FindLayoutPieceByName("BlackDoorF2");
          Texture2D f2Source = GetBlackDoorF2SourceTexture();
          if (f2Source != null)
          {
            int f2DoorX = piece.ResolvedBlackDoorF2X;
            int f2DoorY = piece.ResolvedBlackDoorF2Y;
            bool f2DoorMirror = blackDoorF2CardMirror;

            // If a real BlackDoorF2 card exists, keep its live ViewEdit
            // position/mirror values. A temporary position override wins.
            if (doorF2 != null)
            {
              f2DoorX = doorF2.X;
              f2DoorY = doorF2.Y;
              f2DoorMirror = doorF2.MirrorHorizontally;

              if (previewPositionOverrideByPiece.TryGetValue(
                      doorF2, out Vector2Int f2DoorOverride))
              {
                f2DoorX = f2DoorOverride.x;
                f2DoorY = f2DoorOverride.y;
              }
            }

            BlitPieceIntoPreview(
                pixels,
                f2Source,
                f2DoorX,
                f2DoorY,
                f2DoorMirror);
          }
          continue;
        }

        Texture2D texture = graphics.GetTexture(drawGraphic);

        if (texture == null)
          continue;

        if (D3R2NarrowWidthTest.ShouldReplace(piece.Graphic))
        {
          // No coordinate-specific (0,5) North RightD3 draw. Use the same
          // resolved V17/manual destination and mirror as every other D3 wall.
          BlitPieceIntoPreview(
              pixels,
              texture,
              resolvedX,
              resolvedY,
              mirror);

          continue;
        }

        if (StraightF1WallLogic.IsFloorOrCeilingGraphic(piece.Graphic))
        {
          StraightF1WallLogic.BlitViewportComponentToBuffer(
              texture,
              pixels,
              PreviewWidth,
              PreviewHeight,
              piece.EffectiveX,
              piece.EffectiveY,
              mirror);
          continue;
        }

        // (1,3) North: dedicated Black Door F1 96x88 source.
        // Keep X/Y from the existing BlackDoorF1 ViewEdit/layout piece so we
        // can visually tune placement next without changing the asset.
        if (blackDoorF1Exception)
        {
          // Original layering: draw the left/right F1 frame pieces first,
          // then draw the front Black Door over them.
          // The game only has one F1 frame graphic, so the right frame uses
          // the same left-frame texture mirrored horizontally.
          Texture2D leftFrameSource = GetBlackDoorFrameLeftF1SourceTexture();

          ViewportPiece leftFramePiece =
              FindLayoutPieceByName("Black Door Frame Left F1");
          if (leftFrameSource != null && leftFramePiece != null)
          {
            // Render state must respect the pose-resolved Enabled state.
            // A temporary ViewEdit toggle may still override it for this pose.
            bool leftFrameEnabled = leftFramePiece.Enabled;
            if (previewEnabledOverrideByPiece.TryGetValue(
                    leftFramePiece, out bool leftFrameEnabledOverride))
            {
              leftFrameEnabled = leftFrameEnabledOverride;
            }

            bool leftFrameMirror = leftFramePiece.MirrorHorizontally;
            if (previewMirrorOverrideByPiece.TryGetValue(
                    leftFramePiece, out bool leftFrameMirrorOverride))
            {
              leftFrameMirror = leftFrameMirrorOverride;
            }

            if (leftFrameEnabled)
            {
              BlitPieceIntoPreview(
                  pixels,
                  leftFrameSource,
                  leftFramePiece.EffectiveX,
                  leftFramePiece.EffectiveY,
                  leftFrameMirror);
            }
          }

          ViewportPiece rightFramePiece =
              FindLayoutPieceByName("Black Door Frame Right F1");
          if (leftFrameSource != null && rightFramePiece != null)
          {
            // Same rule for the right F1 frame: never draw a disabled piece.
            bool rightFrameEnabled = rightFramePiece.Enabled;
            if (previewEnabledOverrideByPiece.TryGetValue(
                    rightFramePiece, out bool rightFrameEnabledOverride))
            {
              rightFrameEnabled = rightFrameEnabledOverride;
            }

            // Automatic F1 right-frame default is mirrored because both sides
            // use the same extracted left-frame source. A ViewEdit Mirror click
            // temporarily overrides only this stationary pose.
            bool rightFrameMirror = true;
            if (previewMirrorOverrideByPiece.TryGetValue(
                    rightFramePiece, out bool rightFrameMirrorOverride))
            {
              rightFrameMirror = rightFrameMirrorOverride;
            }

            if (rightFrameEnabled)
            {
              BlitPieceIntoPreview(
                  pixels,
                  leftFrameSource,
                  rightFramePiece.EffectiveX,
                  rightFramePiece.EffectiveY,
                  rightFrameMirror);
            }
          }

          if (piece.Enabled)
          {
            Texture2D f1DoorSource = GetBlackDoorF1SourceTexture();
            if (f1DoorSource != null)
            {
              BlitPieceIntoPreview(
                  pixels,
                  f1DoorSource,
                  piece.EffectiveX,
                  piece.EffectiveY,
                  mirror);
            }
          }

          continue;
        }

        // F3 door view: frames first, then BlackDoorF3 45×39 1:1 on top.
        if (blackDoorF3Exception)
        {
          BlitBlackDoorF3FramesIntoPreview(pixels);
          ViewportPiece doorF3 = FindLayoutPieceByName("BlackDoorF3");
          Texture2D f3Source = GetBlackDoorF3SourceTexture();
          int f3X = doorF3 != null ? doorF3.X : blackDoorF3CardX;
          int f3Y = doorF3 != null ? doorF3.Y : blackDoorF3CardY;

          // F3 front-door view: start from canonical Ref X/Y.
          // A live ViewEdit position override wins so the card remains editable.
          if (f3Source != null
              && TryGetCanonicalReferenceXY("BlackDoorF3", out int f3RefX, out int f3RefY))
          {
            f3X = f3RefX;
            f3Y = DisplayYToUnityY(f3RefY, f3Source.height);
          }
          if (doorF3 != null
              && previewPositionOverrideByPiece.TryGetValue(
                  doorF3, out Vector2Int f3DoorOverride))
          {
            f3X = f3DoorOverride.x;
            f3Y = f3DoorOverride.y;
          }

          if (f3Source != null)
          {
            BlitPieceIntoPreview(
                pixels,
                f3Source,
                f3X,
                f3Y,
                mirror);
          }
          continue;
        }

        BlitPieceIntoPreview(
            pixels,
            texture,
            resolvedX,
            resolvedY,
            mirror);

        if (piece.Graphic == DungeonGraphicType.FrontWallF3)
        {
          ClearFrontWallOverflowIntoUi(
              pixels,
              piece.EffectiveY,
              texture.height);
        }
      }

      // Wall rendering is intentionally disabled. No special wall/door blits.
    }

    // Native D3 L/C/R is drawn in the normal far-to-near wall pass.

    // Final F2 door layering.
    // The earlier dedicated F2 composition occurs inside the far-to-near wall
    // pass, where native LeftF2/RightF2 can paint over the frame edges later.
    // Recompose the F2 door here after all walls: frames first, then door.
    if (IsDoorF2FrontView())
    {
      BlitBlackDoorF2FramesIntoPreview(pixels);
      BlitBlackDoorF2DoorIntoPreview(pixels);
    }

    // Black Door frames are map geometry. Never paint isolated F2/F3 frame
    // pieces in an unrelated pose: without a Door tile at the matching
    // relative depth/lane there is no door and therefore no frame/pillar.
    // F3 front/oblique doors are painted only by their valid depth-stage paths.

    // Stairs are map geometry, not wall ornaments. If the cell directly
    // ahead is a Stairs tile, draw the original F1 stairs front over the
    // completed corridor geometry. No Hall coordinate is hardcoded here.
    BlitStairsDownF1IntoPreview(pixels);

    // All floor features and wall ornaments are composed only after the full
    // map/wall/door image pass has finished. This keeps feature artwork out of
    // the geometry painter order and gives it one explicit post-map layer.
    BlitPostMapFeaturesAndOrnamentsIntoPreview(pixels);

    // Apply the selected original-DM light palette to the completed dungeon
    // scene before any HUD/debug redraws.  This is a pure in-place colour
    // remap of the already composed 224x136 dungeon viewport; it does not
    // resize, crop, move, or blit the framebuffer.
    ApplyDungeonViewportLightPalette(pixels, previewDungeonLightStage);

    // DIAGNOSTIC: redraw Champion Status Slot 4 once on top of the normal
    // composition, before pose/debug text. Slots 1–3 are not redrawn.
    ViewportPiece championStatusSlot4 =
        FindLayoutPieceByName("Champion Status Slot 4");
    if (championStatusSlot4 != null && graphics != null)
    {
      Texture2D slot4Texture = graphics.GetTexture(
          championStatusSlot4.Graphic != DungeonGraphicType.None
              ? championStatusSlot4.Graphic
              : DungeonGraphicType.ChampionStatusBackground);
      if (slot4Texture != null)
      {
        BlitPieceIntoPreview(
            pixels,
            slot4Texture,
            championStatusSlot4.EffectiveX,
            championStatusSlot4.EffectiveY,
            championStatusSlot4.MirrorHorizontally);
      }
    }

    DungeonBitmapFont bitmapFont = FindEditModeBitmapFont();
    if (bitmapFont != null)
    {
      bitmapFont.DrawPoseDebugText(
          pixels,
          PreviewWidth,
          PreviewHeight,
          previewX,
          previewY,
          previewFacing
      );
    }

    editModePreviewTexture.SetPixels32(pixels);
    editModePreviewTexture.Apply(false);
  }

  /// <summary>
  /// Post-map feature layer. This method is intentionally called only after
  /// floor/ceiling/walls/doors/stairs have completed their geometry pass.
  /// Preserve the order here because some ornaments intentionally overlap
  /// other feature artwork at the same depth.
  /// </summary>
  private void BlitPostMapFeaturesAndOrnamentsIntoPreview(Color32[] pixels)
  {
    // Floor features first, so wall-mounted artwork can sit above them.
    BlitPuddlesIntoPreview(pixels);
    BlitFloorItemsIntoPreview(pixels);

    // Champion wall decorations.
    BlitChampionMirrorD0RightIntoPreview(pixels);
    BlitChampionMirrorD1FramesIntoPreview(pixels);
    BlitChampionMirrorD1FrontIntoPreview(pixels);
    BlitChampionMirrorD2FrontIntoPreview(pixels);
    BlitChampionMirrorD3FrontIntoPreview(pixels);
    BlitChampionMirrorD2LeftIntoPreview(pixels);
    BlitChampionMirrorD2RightIntoPreview(pixels);
    BlitChampionMirrorD3LeftIntoPreview(pixels);
    BlitChampionMirrorD3RightIntoPreview(pixels);

    // Large wall fixtures.
    BlitViAltarD3FrontIntoPreview(pixels);
    BlitViAltarD2FrontIntoPreview(pixels);
    BlitViAltarD1FrontIntoPreview(pixels);

    // Hall / dungeon wall ornaments. Keep the existing verified order.
    BlitWoodRingD3SidesIntoPreview(pixels);
    BlitHookD3SidesIntoPreview(pixels);
    BlitGrateD3SidesIntoPreview(pixels);
    BlitSlimeD2SidesIntoPreview(pixels);
    BlitWoodRingD2SidesIntoPreview(pixels);
    BlitHookD2SidesIntoPreview(pixels);
    BlitGrateD2SidesIntoPreview(pixels);
    BlitHookStyleD1SidesIntoPreview(pixels);
    BlitManaclesD2SidesIntoPreview(pixels);
    BlitManaclesD1SidesIntoPreview(pixels);
    BlitGrateD1SidesIntoPreview(pixels);
    BlitSlimeD1SidesIntoPreview(pixels);
    BlitWoodRingD3FrontIntoPreview(pixels);
    BlitWoodRingD2FrontIntoPreview(pixels);
    BlitWoodRingD1FrontIntoPreview(pixels);
    BlitManaclesD3FrontIntoPreview(pixels);
    BlitManaclesD2FrontIntoPreview(pixels);
    BlitManaclesD1FrontIntoPreview(pixels);
    BlitSlimeD1FrontIntoPreview(pixels);
    BlitHookD2FrontIntoPreview(pixels);
    BlitHookD1FrontIntoPreview(pixels);
    BlitGrateD3FrontIntoPreview(pixels);
    BlitGrateD2FrontIntoPreview(pixels);
    BlitGrateD1FrontIntoPreview(pixels);

    // Vi Altar side projections. Draw far-to-near.
    BlitViAltarS3IntoPreview(pixels);
    BlitViAltarS2IntoPreview(pixels);
    BlitViAltarS1IntoPreview(pixels);
  }

  private static void ApplyDungeonViewportLightPalette(
      Color32[] pixels,
      int stage)
  {
    if (pixels == null || pixels.Length < PreviewWidth * PreviewHeight)
      return;

    int stageIndex = Mathf.Clamp(stage, 1, 6) - 1;
    if (stageIndex == 0)
      return;

    Color32[] brightPalette = DungeonViewportLightPalettes[0];
    Color32[] targetPalette = DungeonViewportLightPalettes[stageIndex];

    // The visible 224x136 dungeon view is screen X=0..223, Y=33..168.
    // Texture2D/preview-buffer Y uses a bottom-left origin, so that becomes
    // framebuffer Y=31..166 inclusive.
    const int dungeonScreenTop = 33;
    int minY = Mathf.Max(
        0,
        PreviewHeight - dungeonScreenTop - DungeonViewportHeight);
    int maxYExclusive = Mathf.Min(
        PreviewHeight,
        minY + DungeonViewportHeight);
    int maxX = Mathf.Min(DungeonViewportWidth, PreviewWidth);

    for (int y = minY; y < maxYExclusive; y++)
    {
      int row = y * PreviewWidth;
      for (int x = 0; x < maxX; x++)
      {
        int pixelOffset = row + x;
        Color32 source = pixels[pixelOffset];

        if (source.a == 0
            || (source.r == 255 && source.g == 0 && source.b == 255))
          continue;

        // The original renderer kept a 4-bit colour index and changed only
        // the active 16-colour viewport palette. Our Unity framebuffer is
        // RGBA, so recover the most likely Stage-1 DM palette index first,
        // then emit the colour at the same index from the requested stage.
        // Nearest-colour matching is intentional: screenshot-derived PNGs
        // and converted Atari colours can differ by one RGB quantisation step.
        int bestPaletteIndex = 0;
        int bestDistance = int.MaxValue;
        for (int paletteIndex = 0; paletteIndex < 16; paletteIndex++)
        {
          Color32 candidate = brightPalette[paletteIndex];
          int dr = source.r - candidate.r;
          int dg = source.g - candidate.g;
          int db = source.b - candidate.b;
          int distance = dr * dr + dg * dg + db * db;
          if (distance >= bestDistance)
            continue;

          bestDistance = distance;
          bestPaletteIndex = paletteIndex;
          if (distance == 0)
            break;
        }

        Color32 mapped = targetPalette[bestPaletteIndex];
        mapped.a = source.a;
        pixels[pixelOffset] = mapped;
      }
    }
  }

  private static string lastEditModeViewportLogMessage;
  private static int lastEditLoggedPoseX = int.MinValue;
  private static int lastEditLoggedPoseY = int.MinValue;
  private static DungeonFacing lastEditLoggedPoseFacing =
      (DungeonFacing)(-1);

  /// <summary>
  /// Allow the current Edit Mode POS/wall line to log again after an
  /// external Console clear (e.g. returning from Play Mode).
  /// </summary>
  public static void ResetEditModeViewportLogCache()
  {
    lastEditModeViewportLogMessage = null;
    lastEditLoggedPoseX = int.MinValue;
    lastEditLoggedPoseY = int.MinValue;
    lastEditLoggedPoseFacing = (DungeonFacing)(-1);
  }

  /// <summary>
  /// Console POS/wall line for Edit Mode (same FormatConsoleLine as Play).
  /// Uses live preview pose and Enabled layout pieces. Deduped until cache reset.
  /// Pose key (X/Y/Facing) always refreshes even when wall lists match.
  /// </summary>
  internal void LogCurrentViewportStateToConsole()
  {
    if (layout == null)
      return;

    List<ViewportWallDebugEntry> walls =
        new List<ViewportWallDebugEntry>(12);
    ViewportWallDebugText.CollectEnabledFromLayout(layout, walls);

    string message = ViewportWallDebugText.FormatConsoleLine(
        previewX,
        previewY,
        previewFacing,
        walls
    );

    bool poseChanged =
        previewX != lastEditLoggedPoseX
        || previewY != lastEditLoggedPoseY
        || previewFacing != lastEditLoggedPoseFacing;

    if (!poseChanged && message == lastEditModeViewportLogMessage)
      return;

    lastEditLoggedPoseX = previewX;
    lastEditLoggedPoseY = previewY;
    lastEditLoggedPoseFacing = previewFacing;
    lastEditModeViewportLogMessage = message;
  }

  private static DungeonBitmapFont FindEditModeBitmapFont()
  {
    DungeonBitmapFont[] fonts =
        Resources.FindObjectsOfTypeAll<DungeonBitmapFont>();

    for (int i = 0; i < fonts.Length; i++)
    {
      DungeonBitmapFont font = fonts[i];
      if (font == null)
        continue;

      if (font.AlphabetGrid == null)
        continue;

      if (EditorUtility.IsPersistent(font))
        continue;

      if (!font.gameObject.scene.IsValid() || !font.gameObject.scene.isLoaded)
        continue;

      return font;
    }

    return null;
  }
  /// <summary>
  /// Edit Mode draw gate.
  /// There is no per-view/per-pose visibility store anymore.
  /// </summary>
  private static bool IsWallRenderingPiece(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    if (IsNormalWallPiece(piece))
      return true;

    // LeftS3 / RightS3 are ViewEdit wall cards even though they are not part
    // of the normal V17 family classifier yet. Treat them as wall-rendering
    // pieces so Enabled/Mirror use the same temporary stationary-pose preview
    // override path as LeftF3/RightF3 instead of being reset by layout state.
    string name = piece.Name ?? string.Empty;
    if (name == "LeftS3" || name == "RightS3")
      return true;

    if (piece.Graphic == DungeonGraphicType.BlackDoor)
      return true;

    return name.StartsWith("BlackDoor", System.StringComparison.Ordinal)
        || name.StartsWith("Black Door", System.StringComparison.Ordinal)
        || name.Contains("Wall");
  }

  private void DisableAllWallRenderingPieces()
  {
    resolvedNormalWallByPiece.Clear();

    if (layout == null || layout.Pieces == null)
      return;

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece piece = layout.Pieces[i];
      if (!IsWallRenderingPiece(piece))
        continue;
      if (IsFrontWallF2Card(piece))
      {
        piece.PoseOffsetX = 0;
        piece.PoseOffsetY = 0;
        continue;
      }
      if (piece.Name == "BlackDoorF1"
          || piece.Name == "BlackDoorF2"
          || piece.Name == "BlackDoorF3"
          || piece.Name == "Black Door Frame Left F1"
          || piece.Name == "Black Door Frame Right F1"
          || piece.Name == "Black Door Frame Left F2"
          || piece.Name == "Black Door Frame Right F2"
          || piece.Name == "Black Door Frame Left F3"
          || piece.Name == "Black Door Frame Right F3")
        continue;

      piece.Enabled = false;
      piece.PoseOffsetX = 0;
      piece.PoseOffsetY = 0;
    }
  }

  private bool ShouldDrawPieceAtPreviewPose(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    if (previewDisableAllWalls
        && !IsDisableWallsKeeper(piece)
        && (!previewEnabledOverrideByPiece.TryGetValue(
                piece, out bool manuallyEnabledAfterDisable)
            || !manuallyEnabledAfterDisable))
    {
      return false;
    }

    // Normal walls draw only when the current minimap resolver explicitly
    // produced an enabled transient state. Black Door and all unresolved wall
    // pieces remain off.
    if (IsWallRenderingPiece(piece))
    {
      if (previewEnabledOverrideByPiece.TryGetValue(
              piece, out bool previewEnabled))
      {
        return previewEnabled;
      }

      return piece.Enabled
          && TryGetResolvedNormalWallState(
              piece,
              out ResolvedNormalWallState wallState)
          && wallState.Enabled;
    }

    if (piece.Graphic == DungeonGraphicType.None)
      return false;

    return piece.Enabled;
  }

  /// <summary>
  /// F1 door front view selected from the relative center tile.
  /// Uses the existing verified 96x88 door composition.
  /// </summary>
  private bool IsVerifiedBlackDoorF1Pose()
  {
    return IsDoorF1FrontView();
  }

  private bool IsBlackDoorF1ManualSideWallCandidate(ViewportPiece piece)
  {
    return IsVerifiedBlackDoorF1Pose()
        && piece != null
        && (IsWallF1LeftPiece(piece) || IsWallF1RightPiece(piece));
  }

  private bool IsBlackDoorF1PoseException(ViewportPiece piece)
  {
    if (piece == null || piece.Name != "BlackDoorF1")
      return false;

    return IsDoorF1FrontView();
  }

  /// <summary>
  /// F2 door front view. Selection is relative geometry only:
  /// a Door tile two cells straight ahead.
  /// </summary>
  private bool IsBlackDoorF2PoseException(ViewportPiece piece)
  {
    // F2 still uses BlackDoorF1 as its carrier piece for the existing draw path.
    if (piece == null || piece.Name != "BlackDoorF1")
      return false;

    return IsDoorF2FrontView();
  }

  /// <summary>
  /// F3 door front view. Draw may run even when the normal door Enabled flag
  /// is off. Selection is relative geometry only: Door at center depth 3.
  /// </summary>
  private bool IsBlackDoorF3PoseException(ViewportPiece piece)
  {
    if (piece == null)
      return false;

    if (piece.Graphic != DungeonGraphicType.BlackDoor)
      return false;

    return IsDoorF3FrontView();
  }


  private Texture2D GetRight2STexture()
  {
    if (right2SSourceTexture == null)
    {
      // First use the actual RightS3 ViewEdit piece if it already has a real
      // DungeonGraphicType assigned.  Older layout assets may still carry the
      // source under RightS2 / Right2S naming.
      ViewportPiece rightS3Piece = FindLayoutPieceByName("RightS3")
          ?? FindLayoutPieceByName("RightS2")
          ?? FindLayoutPieceByName("Right2S");
      if (rightS3Piece != null
          && rightS3Piece.Graphic != DungeonGraphicType.None
          && graphics != null)
      {
        right2SSourceTexture = graphics.GetTexture(rightS3Piece.Graphic);
      }

      // The right S3 source has existed under more than one filename during
      // extraction/authoring.  Try the known spellings before doing a broader
      // texture-name search.  This is preview-only and does not modify assets.
      if (right2SSourceTexture == null)
      {
        string[] knownPaths =
        {
          "Assets/Art/Walls/Right2S.png",
          "Assets/Art/Walls/Right 2S.png",
          "Assets/Art/Walls/RightS2.png",
          "Assets/Art/Walls/Right S2.png",
          "Assets/Art/Walls/RightS3.png",
          "Assets/Art/Walls/Right S3.png",
          "Assets/Art/Walls/Right3S.png",
          "Assets/Art/Walls/Right 3S.png"
        };

        for (int i = 0; i < knownPaths.Length; i++)
        {
          right2SSourceTexture =
              AssetDatabase.LoadAssetAtPath<Texture2D>(knownPaths[i]);
          if (right2SSourceTexture != null)
            break;
        }
      }

      if (right2SSourceTexture == null)
      {
        string[] guids = AssetDatabase.FindAssets(
            "t:Texture2D",
            new[] { "Assets/Art/Walls" });
        for (int i = 0; i < guids.Length; i++)
        {
          string candidatePath = AssetDatabase.GUIDToAssetPath(guids[i]);
          Texture2D candidate =
              AssetDatabase.LoadAssetAtPath<Texture2D>(candidatePath);
          if (candidate == null)
            continue;

          string normalizedName = (candidate.name ?? string.Empty)
              .Replace(" ", string.Empty)
              .Replace("_", string.Empty)
              .Replace("-", string.Empty);

          bool isRightS3Source =
              string.Equals(normalizedName, "Right2S", System.StringComparison.OrdinalIgnoreCase)
              || string.Equals(normalizedName, "RightS2", System.StringComparison.OrdinalIgnoreCase)
              || string.Equals(normalizedName, "RightS3", System.StringComparison.OrdinalIgnoreCase)
              || string.Equals(normalizedName, "Right3S", System.StringComparison.OrdinalIgnoreCase);
          if (!isRightS3Source)
            continue;

          right2SSourceTexture = candidate;
          break;
        }
      }
    }

    if (right2SSourceTexture == null)
      return null;

    if (right2SSourceTexture.isReadable)
      return right2SSourceTexture;

    if (cachedRight2SReadableCopy != null)
      return cachedRight2SReadableCopy;

    // Preview blitting uses GetPixels32().  If Unity imported the right S3
    // source as non-readable, load a temporary CPU-readable copy from the
    // exact asset path.  This does not modify the texture importer or asset.
    string assetPath = AssetDatabase.GetAssetPath(right2SSourceTexture);
    if (string.IsNullOrEmpty(assetPath))
      return null;

    string projectRoot = Path.GetDirectoryName(Application.dataPath);
    string absolutePath = string.IsNullOrEmpty(projectRoot)
        ? assetPath
        : Path.Combine(projectRoot, assetPath);

    if (!File.Exists(absolutePath))
      return null;

    byte[] pngBytes = File.ReadAllBytes(absolutePath);
    Texture2D readableCopy =
        new Texture2D(2, 2, TextureFormat.RGBA32, false);
    readableCopy.name = "RightS3_ReadablePreview";
    readableCopy.filterMode = FilterMode.Point;
    readableCopy.wrapMode = TextureWrapMode.Clamp;
    readableCopy.hideFlags = HideFlags.HideAndDontSave;

    if (!readableCopy.LoadImage(pngBytes, false))
    {
      DestroyImmediate(readableCopy);
      return null;
    }

    cachedRight2SReadableCopy = readableCopy;
    return cachedRight2SReadableCopy;
  }

  private Texture2D GetBlackDoorFrameF3SourceTexture()
  {
    if (blackDoorFrameF3SourceTexture == null)
    {
      blackDoorFrameF3SourceTexture =
          LoadDoorFrameTexture(
              "Assets/Art/Walls/Door_Frame_Left_10x42.png",
              "Door_Frame_Left_10x42");
    }

    return blackDoorFrameF3SourceTexture;
  }

  private static Texture2D LoadDoorFrameTexture(
      string preferredPath,
      string assetBaseName)
  {
    Texture2D texture =
        AssetDatabase.LoadAssetAtPath<Texture2D>(preferredPath);
    if (texture != null)
      return texture;

    // The F2 frame file is "Door Frame_Left_18x65.png" (space), while the
    // F1/F3 frames use "Door_Frame_Left_*.png". Accept both spellings.
    string spacedPath = preferredPath.Replace(
        "Door_Frame_Left_",
        "Door Frame_Left_");
    if (!string.Equals(
            spacedPath,
            preferredPath,
            System.StringComparison.Ordinal))
    {
      texture = AssetDatabase.LoadAssetAtPath<Texture2D>(spacedPath);
      if (texture != null)
        return texture;
    }

    // Git/reset history has used both the new generic filename and the older
    // "Black Door Frame_Left_*" filename for the exact same door-frame art.
    // Accept either physical filename; internal ViewEdit piece names stay
    // unchanged for layout compatibility.
    string legacyBaseName =
        assetBaseName.Replace(
            "Door_Frame_Left_",
            "Black Door Frame_Left_");
    string legacyPath =
        "Assets/Art/Walls/" + legacyBaseName + ".png";

    texture = AssetDatabase.LoadAssetAtPath<Texture2D>(legacyPath);
    if (texture != null)
      return texture;

    // Fallback for renamed/moved assets: locate either exact filename in the
    // Unity AssetDatabase.
    string[] searchNames =
    {
      assetBaseName,
      legacyBaseName
    };

    for (int n = 0; n < searchNames.Length; n++)
    {
      string searchName = searchNames[n];
      string[] guids =
          AssetDatabase.FindAssets(searchName + " t:Texture2D");

      for (int i = 0; i < guids.Length; i++)
      {
        string path = AssetDatabase.GUIDToAssetPath(guids[i]);
        if (string.IsNullOrEmpty(path))
          continue;

        string fileName =
            System.IO.Path.GetFileNameWithoutExtension(path);
        if (!string.Equals(
                fileName,
                searchName,
                System.StringComparison.OrdinalIgnoreCase))
        {
          continue;
        }

        texture = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
        if (texture != null)
          return texture;
      }
    }

    return null;
  }

  private Texture2D GetBlackDoorFrameLeftF1SourceTexture()
  {
    if (blackDoorFrameLeftF1SourceTexture == null)
    {
      blackDoorFrameLeftF1SourceTexture =
          LoadDoorFrameTexture(
              "Assets/Art/Walls/Door_Frame_Left_25x94.png",
              "Door_Frame_Left_25x94");
    }

    return blackDoorFrameLeftF1SourceTexture;
  }

  private Texture2D GetBlackDoorF1SourceTexture()
  {
    if (blackDoorF1SourceTexture == null)
    {
      blackDoorF1SourceTexture =
          AssetDatabase.LoadAssetAtPath<Texture2D>(
              "Assets/Art/Walls/Black Door 96x88.png");
    }

    return blackDoorF1SourceTexture;
  }

  private Texture2D GetBlackDoorF3SourceTexture()
  {
    if (blackDoorF3SourceTexture == null)
    {
      blackDoorF3SourceTexture =
          AssetDatabase.LoadAssetAtPath<Texture2D>(
              "Assets/Art/Walls/BlackDoorF3_45x39.png");
    }

    return blackDoorF3SourceTexture;
  }

  private Texture2D GetBlackDoorF2SourceTexture()
  {
    if (blackDoorF2SourceTexture == null)
    {
      blackDoorF2SourceTexture =
          AssetDatabase.LoadAssetAtPath<Texture2D>(
              "Assets/Art/Walls/BlackDoorF2_63x59.png");
    }

    return blackDoorF2SourceTexture;
  }

  /// <summary>
  /// (1,5) North Door F3 frames. Same 10×42 left source; right is
  /// mirrored. Not wall-geometry pieces. Does not write pose data.
  /// </summary>
  private void BlitBlackDoorF2FramesIntoPreview(Color32[] pixels)
  {
    if (pixels == null)
      return;

    Texture2D source =
        LoadDoorFrameTexture(
            "Assets/Art/Walls/Door_Frame_Left_18x65.png",
            "Door_Frame_Left_18x65");
    if (source == null)
      return;

    bool automaticF2DoorPose = IsDoorF2FrontView();
    if (!automaticF2DoorPose)
      return;

    ViewportPiece leftF2 =
        FindLayoutPieceByName("Black Door Frame Left F2");
    ViewportPiece rightF2 =
        FindLayoutPieceByName("Black Door Frame Right F2");

    // No special Black Door pose = no Black Door frame. In a valid pose the
    // pose-resolved piece.Enabled state is authoritative; a temporary ViewEdit
    // override may still change it for comparison.
    bool leftEnabled = automaticF2DoorPose && leftF2 != null && leftF2.Enabled;
    bool rightEnabled = automaticF2DoorPose && rightF2 != null && rightF2.Enabled;

    if (leftF2 != null
        && previewEnabledOverrideByPiece.TryGetValue(
            leftF2, out bool leftPreviewEnabled))
    {
      leftEnabled = leftPreviewEnabled;
    }

    if (rightF2 != null
        && previewEnabledOverrideByPiece.TryGetValue(
            rightF2, out bool rightPreviewEnabled))
    {
      rightEnabled = rightPreviewEnabled;
    }

    if (leftEnabled && leftF2 != null)
    {
      // Generic F2-door frame defaults.
      int leftX = 64;
      int leftY = DisplayYToUnityY(54, source.height);
      bool leftMirror = false;

      if (TryGetCanonicalReferenceXY(
              "Black Door Frame Left F2",
              out int leftRefX,
              out int leftRefY))
      {
        leftX = leftRefX;
        leftY = DisplayYToUnityY(leftRefY, source.height);
      }

      if (previewPositionOverrideByPiece.TryGetValue(
              leftF2, out Vector2Int leftPosition))
      {
        leftX = leftPosition.x;
        leftY = leftPosition.y;
      }

      if (previewMirrorOverrideByPiece.TryGetValue(
              leftF2, out bool leftMirrorOverride))
      {
        leftMirror = leftMirrorOverride;
      }

      BlitPieceIntoPreview(
          pixels,
          source,
          leftX,
          leftY,
          leftMirror);
    }

    if (rightEnabled && rightF2 != null)
    {
      // Generic F2-door frame defaults. The right side uses the same left
      // source mirrored horizontally.
      int rightX = 140;
      int rightY = DisplayYToUnityY(54, source.height);
      bool rightMirror = true;

      if (TryGetCanonicalReferenceXY(
              "Black Door Frame Right F2",
              out int rightRefX,
              out int rightRefY))
      {
        rightX = rightRefX;
        rightY = DisplayYToUnityY(rightRefY, source.height);
      }

      if (previewPositionOverrideByPiece.TryGetValue(
              rightF2, out Vector2Int rightPosition))
      {
        rightX = rightPosition.x;
        rightY = rightPosition.y;
      }

      if (previewMirrorOverrideByPiece.TryGetValue(
              rightF2, out bool rightMirrorOverride))
      {
        rightMirror = rightMirrorOverride;
      }

      BlitPieceIntoPreview(
          pixels,
          source,
          rightX,
          rightY,
          rightMirror);
    }
  }

  private void BlitBlackDoorF2DoorIntoPreview(Color32[] pixels)
  {
    if (pixels == null || !IsDoorF2FrontView())
      return;

    ViewportPiece carrier = FindLayoutPieceByName("BlackDoorF1");
    ViewportPiece doorF2 = FindLayoutPieceByName("BlackDoorF2");
    Texture2D f2Source = GetBlackDoorF2SourceTexture();
    if (f2Source == null)
      return;

    int f2DoorX = carrier != null ? carrier.ResolvedBlackDoorF2X : 0;
    int f2DoorY = carrier != null ? carrier.ResolvedBlackDoorF2Y : 0;
    bool f2DoorMirror = blackDoorF2CardMirror;

    if (doorF2 != null)
    {
      f2DoorX = doorF2.X;
      f2DoorY = doorF2.Y;
      f2DoorMirror = doorF2.MirrorHorizontally;

      if (previewPositionOverrideByPiece.TryGetValue(
              doorF2, out Vector2Int f2DoorOverride))
      {
        f2DoorX = f2DoorOverride.x;
        f2DoorY = f2DoorOverride.y;
      }

      if (previewMirrorOverrideByPiece.TryGetValue(
              doorF2, out bool f2DoorMirrorOverride))
      {
        f2DoorMirror = f2DoorMirrorOverride;
      }
    }

    BlitPieceIntoPreview(
        pixels,
        f2Source,
        f2DoorX,
        f2DoorY,
        f2DoorMirror);
  }

  private void BlitDoorF3RightObliqueAtD3Stage(Color32[] pixels)
  {
    if (pixels == null || !IsDoorF3RightObliqueView())
      return;

    // Minimap/relative-geometry rule:
    // relative (+1, 3) is a Door, so render the normal extracted F3 door and
    // the mirrored right F3 frame at the FAR D3 stage. Do not pre-crop a
    // 4-pixel strip and do not redraw anything after nearer walls.
    //
    // The later D2/D1 painter passes decide what remains visible.

    Texture2D door = GetBlackDoorF3SourceTexture();
    if (door != null
        && TryGetCanonicalReferenceXY(
            "BlackDoorF3", out int doorX, out int doorDisplayY))
    {
      BlitPieceIntoPreview(
          pixels,
          door,
          doorX,
          DisplayYToUnityY(doorDisplayY, door.height),
          false);
    }

    Texture2D frame = GetBlackDoorFrameF3SourceTexture();
    if (frame != null
        && TryGetCanonicalReferenceXY(
            "Black Door Frame Right F3",
            out int frameX,
            out int frameDisplayY))
    {
      BlitPieceIntoPreview(
          pixels,
          frame,
          frameX,
          DisplayYToUnityY(frameDisplayY, frame.height),
          true);
    }
  }

  private void BlitBlackDoorF3FramesIntoPreview(Color32[] pixels)
  {
    if (pixels == null)
      return;

    Texture2D source = GetBlackDoorFrameF3SourceTexture();
    if (source == null)
      return;

    bool automaticF3DoorPose = IsDoorF3FrontView();
    if (!automaticF3DoorPose)
      return;

    ViewportPiece leftF3 =
        FindLayoutPieceByName("Black Door Frame Left F3");
    ViewportPiece rightF3 =
        FindLayoutPieceByName("Black Door Frame Right F3");

    // No special Black Door pose = no Black Door frame. In a valid pose,
    // both the card state and the pose-resolved piece.Enabled state must agree.
    bool leftEnabled =
        automaticF3DoorPose
        && leftF3 != null
        && leftF3.Enabled
        && blackDoorFrameLeftF3CardEnabled;
    bool rightEnabled =
        automaticF3DoorPose
        && rightF3 != null
        && rightF3.Enabled
        && blackDoorFrameRightF3CardEnabled;

    if (leftF3 != null
        && previewEnabledOverrideByPiece.TryGetValue(
            leftF3, out bool leftPreviewEnabled))
    {
      leftEnabled = leftPreviewEnabled;
    }

    if (rightF3 != null
        && previewEnabledOverrideByPiece.TryGetValue(
            rightF3, out bool rightPreviewEnabled))
    {
      rightEnabled = rightPreviewEnabled;
    }

    if (leftEnabled && leftF3 != null)
    {
      int leftX = leftF3.X;
      int leftY = leftF3.Y;
      bool leftMirror = blackDoorFrameLeftF3CardMirror;

      if (previewPositionOverrideByPiece.TryGetValue(
              leftF3, out Vector2Int leftPosition))
      {
        leftX = leftPosition.x;
        leftY = leftPosition.y;
      }

      if (previewMirrorOverrideByPiece.TryGetValue(
              leftF3, out bool leftMirrorOverride))
      {
        leftMirror = leftMirrorOverride;
      }

      BlitPieceIntoPreview(
          pixels,
          source,
          leftX,
          leftY,
          leftMirror);
    }

    if (rightEnabled && rightF3 != null)
    {
      int rightX = rightF3.X;
      int rightY = rightF3.Y;
      bool rightMirror = true;

      if (previewPositionOverrideByPiece.TryGetValue(
              rightF3, out Vector2Int rightPosition))
      {
        rightX = rightPosition.x;
        rightY = rightPosition.y;
      }

      if (previewMirrorOverrideByPiece.TryGetValue(
              rightF3, out bool rightMirrorOverride))
      {
        rightMirror = rightMirrorOverride;
      }

      BlitPieceIntoPreview(
          pixels,
          source,
          rightX,
          rightY,
          rightMirror);
    }
  }

  /// <summary>
  /// Automatic preview mirror for walls that have a V17 geometry/pose rule.
  /// LeftD3/RightD3 use the outer-D3 handedness plus pose phase. F0 uses the
  /// side-wall phase. A ViewEdit checkbox override still wins later.
  /// </summary>
  private bool GetPreviewMirror(ViewportPiece piece, DungeonMap poseMap)
  {
    if (piece == null)
      return false;

    // F0 side walls use the deterministic pose phase. F1/F2/F3 keep their
    // current imported orientation until their mirror rules are verified.
    if (IsWallF0LeftPiece(piece) || IsWallF0RightPiece(piece))
      return GetF0MirrorFromPose();

    if (IsLeftD3Piece(piece))
      return GetViewport17D3OuterMirror(false);

    if (IsRightD3Piece(piece))
      return GetViewport17D3OuterMirror(true);

    if (IsWallF1LeftPiece(piece)
        || IsWallF1RightPiece(piece)
        || IsWallF2LeftPiece(piece)
        || IsWallF2RightPiece(piece)
        || IsWallF3LeftPiece(piece)
        || IsWallF3RightPiece(piece))
      return false;

    return piece.MirrorHorizontally;
  }

  private DungeonMap TryGetPreviewPoseMap()
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null)
      return null;

    previewMiniMap.SetPlayerPose(previewX, previewY, previewFacing);
    return previewMiniMap;
  }

  private static void ClearFrontWallOverflowIntoUi(
      Color32[] pixels,
      int destinationY,
      int height)
  {
    if (pixels == null || height <= 0)
      return;

    Color32 magenta = new Color32(255, 0, 255, 255);
    int startY = Mathf.Max(0, destinationY);
    int endY = Mathf.Min(PreviewHeight, destinationY + height);

    for (int y = startY; y < endY; y++)
    {
      int row = y * PreviewWidth;
      for (int x = 224; x < PreviewWidth; x++)
        pixels[row + x] = magenta;
    }
  }

  // Stage 6G: generic cropped-strip preview blitter for Viewport-17
  // calibration. Copies exactly sourceMinX..sourceMaxX into consecutive
  // destination columns. Mirror reverses only that selected strip.
  private static void BlitViewport17SourceStripPreview(
      Color32[] dest,
      Texture2D source,
      int sourceMinX,
      int sourceMaxX,
      int destinationStartX,
      int destinationY,
      bool mirrorHorizontally)
  {
    if (dest == null || source == null || !source.isReadable)
      return;

    sourceMinX = Mathf.Clamp(sourceMinX, 0, source.width - 1);
    sourceMaxX = Mathf.Clamp(sourceMaxX, sourceMinX, source.width - 1);
    int copyWidth = sourceMaxX - sourceMinX + 1;
    if (copyWidth <= 0)
      return;

    Color32[] sourcePixels = source.GetPixels32();

    for (int sourceY = 0; sourceY < source.height; sourceY++)
    {
      int targetY = destinationY + sourceY;
      if (targetY < 0 || targetY >= PreviewHeight)
        continue;

      int sourceRow = sourceY * source.width;
      int destRow = targetY * PreviewWidth;

      for (int i = 0; i < copyWidth; i++)
      {
        int targetX = destinationStartX + i;
        if (targetX < 0 || targetX >= StraightF1WallLogic.CompositeWidth)
          continue;

        int sourceX = mirrorHorizontally
            ? sourceMaxX - i
            : sourceMinX + i;

        Color32 colour = sourcePixels[sourceRow + sourceX];
        colour.a = 255;
        dest[destRow + targetX] = colour;
      }
    }
  }

  private Texture2D GetReadableNativeFrontF1Texture()
  {
    Texture2D asset =
        AssetDatabase.LoadAssetAtPath<Texture2D>(NativeFrontF1AssetPath);

    if (asset != null
        && asset.width == 160
        && asset.height == 111
        && asset.isReadable)
    {
      return asset;
    }

    if (cachedNativeFrontF1ReadableCopy != null)
      return cachedNativeFrontF1ReadableCopy;

    string projectRoot = Path.GetDirectoryName(Application.dataPath);
    string absolutePath = string.IsNullOrEmpty(projectRoot)
        ? NativeFrontF1AssetPath
        : Path.Combine(projectRoot, NativeFrontF1AssetPath);

    if (!File.Exists(absolutePath))
      return null;

    byte[] pngBytes = File.ReadAllBytes(absolutePath);
    Texture2D readableCopy =
        new Texture2D(2, 2, TextureFormat.RGBA32, false);
    readableCopy.name = "FrontF1_RAW_160x111_ReadablePreview";
    readableCopy.filterMode = FilterMode.Point;
    readableCopy.wrapMode = TextureWrapMode.Clamp;
    readableCopy.hideFlags = HideFlags.HideAndDontSave;

    if (!readableCopy.LoadImage(pngBytes, false)
        || readableCopy.width != 160
        || readableCopy.height != 111)
    {
      DestroyImmediate(readableCopy);
      return null;
    }

    cachedNativeFrontF1ReadableCopy = readableCopy;
    return cachedNativeFrontF1ReadableCopy;
  }

  private Texture2D GetReadableNativeFrontF2Texture()
  {
    Texture2D asset =
        AssetDatabase.LoadAssetAtPath<Texture2D>(NativeFrontF2AssetPath);

    if (asset != null
        && asset.width == 106
        && asset.height == 74
        && asset.isReadable)
    {
      return asset;
    }

    if (cachedNativeFrontF2ReadableCopy != null)
      return cachedNativeFrontF2ReadableCopy;

    string projectRoot = Path.GetDirectoryName(Application.dataPath);
    string absolutePath = string.IsNullOrEmpty(projectRoot)
        ? NativeFrontF2AssetPath
        : Path.Combine(projectRoot, NativeFrontF2AssetPath);

    if (!File.Exists(absolutePath))
      return null;

    byte[] pngBytes = File.ReadAllBytes(absolutePath);
    Texture2D readableCopy =
        new Texture2D(2, 2, TextureFormat.RGBA32, false);
    readableCopy.name = "FrontF2_RAW_106x74_ReadablePreview";
    readableCopy.filterMode = FilterMode.Point;
    readableCopy.wrapMode = TextureWrapMode.Clamp;
    readableCopy.hideFlags = HideFlags.HideAndDontSave;

    if (!readableCopy.LoadImage(pngBytes, false)
        || readableCopy.width != 106
        || readableCopy.height != 74)
    {
      DestroyImmediate(readableCopy);
      return null;
    }

    cachedNativeFrontF2ReadableCopy = readableCopy;
    return cachedNativeFrontF2ReadableCopy;
  }

  private Texture2D GetReadableNativeFrontF3Texture()
  {
    Texture2D asset =
        AssetDatabase.LoadAssetAtPath<Texture2D>(NativeFrontF3AssetPath);

    if (asset != null
        && asset.width == 70
        && asset.height == 49
        && asset.isReadable)
    {
      return asset;
    }

    if (cachedNativeFrontF3ReadableCopy != null)
      return cachedNativeFrontF3ReadableCopy;

    string projectRoot = Path.GetDirectoryName(Application.dataPath);
    string absolutePath = string.IsNullOrEmpty(projectRoot)
        ? NativeFrontF3AssetPath
        : Path.Combine(projectRoot, NativeFrontF3AssetPath);

    if (!File.Exists(absolutePath))
      return null;

    byte[] pngBytes = File.ReadAllBytes(absolutePath);
    Texture2D readableCopy =
        new Texture2D(2, 2, TextureFormat.RGBA32, false);
    readableCopy.name = "FrontF3_RAW_70x49_ReadablePreview";
    readableCopy.filterMode = FilterMode.Point;
    readableCopy.wrapMode = TextureWrapMode.Clamp;
    readableCopy.hideFlags = HideFlags.HideAndDontSave;

    if (!readableCopy.LoadImage(pngBytes, false)
        || readableCopy.width != 70
        || readableCopy.height != 49)
    {
      DestroyImmediate(readableCopy);
      return null;
    }

    cachedNativeFrontF3ReadableCopy = readableCopy;
    return cachedNativeFrontF3ReadableCopy;
  }

  /// <summary>
  /// ViewEdit-only manual controls for one V17 native wall image.
  /// Geometry/V17 supplies the default Enabled/Mirror state. While the pose
  /// remains stationary, an explicit checkbox click wins for that image only.
  ///
  /// Do not stop at the first family match: Black Door frame artwork can use
  /// an F1-like graphic and therefore look like the same normal-wall family.
  /// Instead, scan the real normal-wall cards and use whichever card actually
  /// owns the temporary ViewEdit override.
  /// </summary>
  /// <summary>
  /// Reads a temporary ViewEdit Enabled override by the exact card first, then
  /// by its normal-wall family. The family fallback is important for FrontF2:
  /// its native D2 preview can rebuild/resolve the card while staying on the
  /// same pose, but the user's temporary checkbox state must remain attached to
  /// the visible FrontF2 row until navigation changes the pose.
  /// </summary>
  private bool TryGetPreviewEnabledOverrideForPieceOrFamily(
      ViewportPiece piece, out bool enabled)
  {
    enabled = false;
    if (piece == null)
      return false;

    if (previewEnabledOverrideByPiece.TryGetValue(piece, out enabled))
      return true;

    string family = GetViewport17NormalWallFamily(piece);
    if (string.IsNullOrEmpty(family))
      return false;

    foreach (KeyValuePair<ViewportPiece, bool> entry in previewEnabledOverrideByPiece)
    {
      ViewportPiece overriddenPiece = entry.Key;
      if (overriddenPiece == null || IsBlackDoorEditorPiece(overriddenPiece))
        continue;

      if (string.Equals(
              GetViewport17NormalWallFamily(overriddenPiece),
              family,
              System.StringComparison.Ordinal))
      {
        enabled = entry.Value;
        return true;
      }
    }

    return false;
  }

  private bool HasPreviewEnabledOverrideForPieceOrFamily(ViewportPiece piece)
  {
    return TryGetPreviewEnabledOverrideForPieceOrFamily(piece, out _);
  }

  private void ApplyViewport17NativeManualControls(
      string pieceFamily,
      ref bool enabled,
      ref bool mirror)
  {
    if (previewDisableAllWalls)
      enabled = false;

    if (layout == null || layout.Pieces == null)
      return;

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece candidate = layout.Pieces[i];
      if (candidate == null || IsBlackDoorEditorPiece(candidate))
        continue;

      if (!string.Equals(
              GetViewport17NormalWallFamily(candidate),
              pieceFamily,
              System.StringComparison.Ordinal))
      {
        continue;
      }

      if (TryGetPreviewEnabledOverrideForPieceOrFamily(
              candidate, out bool manualEnabled))
      {
        enabled = manualEnabled;
      }

      if (previewMirrorOverrideByPiece.TryGetValue(
              candidate, out bool manualMirror))
      {
        mirror = manualMirror;
      }
    }
  }

  /// <summary>
  /// ViewEdit X/Y test for one V17 wall family. Returns the card dest the
  /// user set for this stationary pose, or false when geometry still owns dest.
  /// </summary>
  private bool TryGetViewport17FamilyPositionOverride(
      string pieceFamily,
      out int x,
      out int y)
  {
    x = 0;
    y = 0;
    if (layout == null || layout.Pieces == null || string.IsNullOrEmpty(pieceFamily))
      return false;

    for (int i = 0; i < layout.Pieces.Count; i++)
    {
      ViewportPiece candidate = layout.Pieces[i];
      if (candidate == null || IsBlackDoorEditorPiece(candidate))
        continue;

      if (!string.Equals(
              GetViewport17NormalWallFamily(candidate),
              pieceFamily,
              System.StringComparison.Ordinal))
      {
        continue;
      }

      if (previewPositionOverrideByPiece.TryGetValue(
              candidate, out Vector2Int previewPosition))
      {
        x = previewPosition.x;
        y = previewPosition.y;
        return true;
      }
    }

    return false;
  }

  private void ApplyViewport17FamilyDestOverride(
      string pieceFamily,
      ref int destX,
      ref int destY)
  {
    if (TryGetViewport17FamilyPositionOverride(pieceFamily, out int x, out int y))
    {
      destX = x;
      destY = y;
    }
  }

  /// <summary>
  /// Automatic FrontF3 source-image mirror before any ViewEdit override.
  /// Center uses the pose brick phase. A surviving left-only strip stays
  /// unmirrored (dest 0..31). A surviving right-only strip stays mirrored
  /// (dest 192..223).
  /// </summary>
  private bool GetViewport17FrontF3DefaultMirror(
      bool frontLeft,
      bool frontCenter,
      bool frontRight)
  {
    if (frontCenter)
      return GetSideWallMirrorFromPose();

    return !frontLeft && frontRight;
  }

  /// <summary>
  /// FrontF3 is one native source image that V17 may blit as a left 32px
  /// strip, the 70px center, a right 32px strip, or a combination of them.
  /// One ViewEdit FrontF3 checkbox therefore controls the whole source-image
  /// draw. Disabling it suppresses every surviving FrontF3 lane. Enabling it
  /// while geometry has no FrontF3 lane keeps the historical manual-test
  /// behavior by showing the center image.
  /// </summary>
  private void ApplyViewport17NativeFrontF3ManualControls(
      ref bool frontLeft,
      ref bool frontCenter,
      ref bool frontRight,
      ref bool centerMirror)
  {
    bool hadAutomaticLane = frontLeft || frontCenter || frontRight;
    bool sourceEnabled = hadAutomaticLane;

    ApplyViewport17NativeManualControls(
        "FrontF3", ref sourceEnabled, ref centerMirror);

    // FrontF3 card scan wins over family lookup so a stationary ViewEdit
    // Enabled/Mirror click cannot be missed by V17 geometry rebuilds.
    if (TryGetFrontF3PreviewEnabledOverride(out bool manualEnabled))
      sourceEnabled = manualEnabled;
    if (TryGetFrontF3PreviewMirrorOverride(out bool manualMirror))
      centerMirror = manualMirror;

    if (!sourceEnabled)
    {
      frontLeft = false;
      frontCenter = false;
      frontRight = false;
      return;
    }

    // Manual ON with no automatic lane remains a useful ViewEdit test: draw
    // the native center image rather than inventing a left/right strip.
    if (!hadAutomaticLane)
      frontCenter = true;
  }


  /// <summary>
  /// V17 native-DOS D1 renderer.  DOS draws D1L, D1R, then D1C.
  /// Native geometry is 60x111 / 160x111 / 60x111 at viewport X
  /// 0 / 32 / 164 and viewport Y 9 (Game/ViewEdit display Y 42).
  /// D1 side strips use the side-wall phase. The FrontF1 center uses the
  /// full FrontF1 parity phase: even (X + Y + facing) = mirrored. D1C is
  /// opaque and therefore drawn last.
  /// </summary>
  private void BlitViewport17NativeD1Walls(
      Color32[] pixels,
      Viewport17Inspection inspection,
      List<Viewport17RenderCommand> finalCommands,
      bool manualOnly = false,
      bool blackDoorSidesOnly = false)
  {
    if (pixels == null || graphics == null || inspection.Cells == null)
      return;

    Viewport17Cell leftCell =
        FindViewport17Cell(inspection.Cells, -1, 1);
    Viewport17Cell centerCell =
        FindViewport17Cell(inspection.Cells, 0, 1);
    Viewport17Cell rightCell =
        FindViewport17Cell(inspection.Cells, 1, 1);

    // Side-wall strips keep their side-wall phase, while the opaque center
    // FrontF1 uses the full X+Y+facing parity phase. These are independent
    // phases and must not be collapsed into one default mirror value.
    bool sideMirror = GetSideWallMirrorFromPose();
    GetViewport17FinalFrontLanes(
        finalCommands, 1, out bool frontLeft, out bool frontCenter, out bool frontRight);
    bool leftEnabled = manualOnly
        ? false
        : HasViewport17FinalFamily(finalCommands, "LeftF1") || frontLeft;
    bool centerEnabled = manualOnly ? false : frontCenter;
    bool rightEnabled = manualOnly
        ? false
        : HasViewport17FinalFamily(finalCommands, "RightF1") || frontRight;

    // The Black Door F1 front view replaces only the D1 center wall. Its
    // normal D1 side walls remain visible on both sides of the doorway.
    if (blackDoorSidesOnly)
    {
      leftEnabled = true;
      centerEnabled = false;
      rightEnabled = true;
    }

    bool leftMirror = sideMirror;
    bool centerMirror = GetFrontF1MirrorFromPose();
    bool rightMirror = sideMirror;

    ApplyViewport17NativeManualControls("LeftF1", ref leftEnabled, ref leftMirror);
    ApplyViewport17NativeManualControls("FrontF1", ref centerEnabled, ref centerMirror);
    ApplyViewport17NativeManualControls("RightF1", ref rightEnabled, ref rightMirror);

    const int displayY = 42;
    const int nativeHeight = 111;
    int destinationY = DisplayYToUnityY(displayY, nativeHeight);

    Texture2D leftSource = graphics.GetTexture(
        leftMirror ? DungeonGraphicType.WallF1R : DungeonGraphicType.WallF1L);
    Texture2D rightSource = graphics.GetTexture(
        rightMirror ? DungeonGraphicType.WallF1L : DungeonGraphicType.WallF1R);

    // DOS zones 713/714: D1L and D1R are full 60px native side walls.
    // They overlap the center region and are intentionally drawn first.
    if (leftEnabled
        && leftSource != null
        && leftSource.width == 60
        && leftSource.height == nativeHeight)
    {
      int leftX = 0;
      int leftY = destinationY;
      ApplyViewport17FamilyDestOverride("LeftF1", ref leftX, ref leftY);
      BlitPieceIntoPreview(
          pixels, leftSource, leftX, leftY, leftMirror);
    }

    if (rightEnabled
        && rightSource != null
        && rightSource.width == 60
        && rightSource.height == nativeHeight)
    {
      int rightX = 164;
      int rightY = destinationY;
      ApplyViewport17FamilyDestOverride("RightF1", ref rightX, ref rightY);
      BlitPieceIntoPreview(
          pixels, rightSource, rightX, rightY, rightMirror);
    }

    // DOS zone 712: D1C is the original 160x111 center at X=32.
    // Draw it last so it owns the 28px overlap with each side wall.
    if (centerEnabled)
    {
      Texture2D centerSource = GetReadableNativeFrontF1Texture();

      if (centerSource != null
          && centerSource.width == 160
          && centerSource.height == nativeHeight)
      {
        int centerX = 32;
        int centerY = destinationY;
        ApplyViewport17FamilyDestOverride("FrontF1", ref centerX, ref centerY);
        BlitPieceIntoPreview(
            pixels, centerSource, centerX, centerY, centerMirror);
      }
      else
      {
        Debug.LogError(
            "V17 native D1: Front_Wall_F1_RAW_160x111.png "
            + "is missing or not 160x111.");
      }
    }
  }

  /// <summary>
  /// V17 native-DOS D2 renderer. DOS GRAPHICS.DAT layout 696 places the
  /// original D2 wall graphics at viewport X 0 / 59 / 146 and viewport Y 19.
  /// The screen viewport starts at Y 33, so ViewEdit/Game display Y is 52.
  /// As with D3, left and right are drawn first and the center is drawn last.
  /// On the alternate wall phase the DOS engine swaps the side source and
  /// flips it, while the center source is flipped in place.
  /// </summary>
  private void BlitViewport17NativeD2Walls(
      Color32[] pixels,
      Viewport17Inspection inspection,
      List<Viewport17RenderCommand> finalCommands,
      bool suppressCenter = false)
  {
    if (pixels == null || graphics == null || inspection.Cells == null)
      return;

    Viewport17Cell leftCell =
        FindViewport17Cell(inspection.Cells, -1, 2);
    Viewport17Cell centerCell =
        FindViewport17Cell(inspection.Cells, 0, 2);
    Viewport17Cell rightCell =
        FindViewport17Cell(inspection.Cells, 1, 2);

    bool defaultMirror = GetSideWallMirrorFromPose();
    GetViewport17FinalFrontLanes(
        finalCommands, 2, out bool frontLeft, out bool frontCenter, out bool frontRight);
    bool leftEnabled = HasViewport17FinalFamily(finalCommands, "LeftF2") || frontLeft;
    bool centerEnabled = frontCenter && !suppressCenter;
    bool rightEnabled = HasViewport17FinalFamily(finalCommands, "RightF2") || frontRight;
    bool leftMirror = defaultMirror;
    bool centerMirror = defaultMirror;
    bool rightMirror = defaultMirror;

    ApplyViewport17NativeManualControls("LeftF2", ref leftEnabled, ref leftMirror);
    ApplyViewport17NativeManualControls("FrontF2", ref centerEnabled, ref centerMirror);
    ApplyViewport17NativeManualControls("RightF2", ref rightEnabled, ref rightMirror);

    // Cell-property authority wins over a temporary FrontF2 manual override.
    // A down-stair directly ahead replaces only the D2 center wall; the D2
    // left/right walls remain available at the edges of the stair opening.
    Viewport17Cell nearCenterCell =
        FindViewport17Cell(inspection.Cells, 0, 1);
    if (nearCenterCell.IsStairsDown)
      centerEnabled = false;

    const int displayY = 52;
    const int nativeHeight = 74;
    int destinationY = DisplayYToUnityY(displayY, nativeHeight);

    Texture2D leftSource = graphics.GetTexture(
        leftMirror ? DungeonGraphicType.WallF2R : DungeonGraphicType.WallF2L);
    Texture2D rightSource = graphics.GetTexture(
        rightMirror ? DungeonGraphicType.WallF2L : DungeonGraphicType.WallF2R);

    // DOS layout 696 zones 710/711: D2L at X=0, D2R at X=146.
    if (leftEnabled
        && leftSource != null
        && leftSource.width == 78
        && leftSource.height == nativeHeight)
    {
      int leftX = 0;
      int leftY = destinationY;
      ApplyViewport17FamilyDestOverride("LeftF2", ref leftX, ref leftY);
      BlitPieceIntoPreview(
          pixels, leftSource, leftX, leftY, leftMirror);
    }

    if (rightEnabled
        && rightSource != null
        && rightSource.width == 78
        && rightSource.height == nativeHeight)
    {
      int rightX = 146;
      int rightY = destinationY;
      ApplyViewport17FamilyDestOverride("RightF2", ref rightX, ref rightY);
      BlitPieceIntoPreview(
          pixels, rightSource, rightX, rightY, rightMirror);
    }

    // DOS layout 696 zone 709: D2C is centered at X=59. Draw it last so
    // the native center artwork owns the overlap with the side graphics.
    if (centerEnabled)
    {
      Texture2D centerSource = GetReadableNativeFrontF2Texture();

      if (centerSource != null
          && centerSource.width == 106
          && centerSource.height == nativeHeight)
      {
        int centerX = 59;
        int centerY = destinationY;
        ApplyViewport17FamilyDestOverride("FrontF2", ref centerX, ref centerY);
        BlitPieceIntoPreview(
            pixels, centerSource, centerX, centerY, centerMirror);
      }
      else
      {
        Debug.LogError(
            "V17 native D2: Front_Wall_F2_RECOVERED_CENTER_106x74.png "
            + "is missing or not 106x74.");
      }
    }
  }

  /// <summary>
  /// V17 native-DOS D3 renderer.  D3 is not one composite FrontF3 image:
  /// left, center, and right use the original 83x49 / 70x49 / 83x49
  /// graphics at display X 7 / 77 / 134 and display Y 58.  On the alternate
  /// wall phase the original engine uses the opposite side source and flips
  /// it; the center source is simply flipped.
  /// </summary>
  private void BlitViewport17NativeD3Walls(
      Color32[] pixels,
      Viewport17Inspection inspection,
      List<Viewport17RenderCommand> finalCommands,
      bool suppressCenter = false)
  {
    if (pixels == null || graphics == null || inspection.Cells == null)
      return;

    Viewport17Cell leftCell =
        FindViewport17Cell(inspection.Cells, -1, 3);
    Viewport17Cell centerCell =
        FindViewport17Cell(inspection.Cells, 0, 3);
    Viewport17Cell rightCell =
        FindViewport17Cell(inspection.Cells, 1, 3);

    bool defaultMirror = GetSideWallMirrorFromPose();
    GetViewport17FinalFrontLanes(
        finalCommands, 3, out bool frontLeft, out bool frontCenter, out bool frontRight);
    bool leftEnabled = HasViewport17FinalFamily(finalCommands, "LeftF3");
    bool rightEnabled = HasViewport17FinalFamily(finalCommands, "RightF3");

    // Relative (+1,3) is the D3-right cell. If it is a Door, that slot is
    // owned by the door compositor rather than the ordinary RightF3 wall.
    if (IsDoorF3RightObliqueView())
      rightEnabled = false;
    bool leftMirror = GetViewport17LeftF3Mirror();
    // This gutter is geometry-owned, not dependent on a surviving normal
    // FrontF3 final command. At poses such as 6,1 West the normal occlusion
    // pass removes the D3 front lane, but the original still exposes the
    // seven-pixel FrontF3 sliver immediately left of LeftF3.
    bool automaticLeftFrontGutter =
        IsViewport17D3LeftEdgeFrontGutter(inspection);
    bool automaticRightFrontGutter =
        IsViewport17D3RightEdgeFrontGutter(inspection);
    bool automaticRightOpenSlitFront =
        IsViewport17D3RightOpenSlitFront();
    if (automaticLeftFrontGutter)
        frontLeft = true;
    if (automaticRightFrontGutter || automaticRightOpenSlitFront)
        frontRight = true;
    bool centerMirror = (automaticLeftFrontGutter
        || automaticRightFrontGutter
        || automaticRightOpenSlitFront)
        ? false
        : GetViewport17FrontF3DefaultMirror(
            frontLeft, frontCenter, frontRight);
    bool rightMirror = defaultMirror;

    // Black Door F2 owns only the D3 center opening. The original view still
    // uses surviving FrontF3 edge strips and normal D3 side walls around it.
    if (suppressCenter)
      frontCenter = false;

    ApplyViewport17NativeManualControls("LeftF3", ref leftEnabled, ref leftMirror);
    ApplyViewport17NativeManualControls("RightF3", ref rightEnabled, ref rightMirror);
    ApplyViewport17NativeFrontF3ManualControls(
        ref frontLeft, ref frontCenter, ref frontRight, ref centerMirror);

    const int displayY = 58;
    const int nativeHeight = 49;
    int destinationY = DisplayYToUnityY(displayY, nativeHeight);

    Texture2D leftSource = graphics.GetTexture(
        leftMirror ? DungeonGraphicType.WallF3R : DungeonGraphicType.WallF3L);
    Texture2D rightSource = graphics.GetTexture(
        rightMirror ? DungeonGraphicType.WallF3L : DungeonGraphicType.WallF3R);

    // Original DOS D3 placement: draw both side walls first, then the
    // 70px center wall last so it covers the 13px overlap on each side.
    if (leftEnabled
        && leftSource != null
        && leftSource.width == 83
        && leftSource.height == nativeHeight)
    {
      int leftX = NativeD3LeftF3DestX;
      int leftY = destinationY;
      ApplyViewport17FamilyDestOverride("LeftF3", ref leftX, ref leftY);
      BlitPieceIntoPreview(
          pixels, leftSource, leftX, leftY, leftMirror);
    }

    if (rightEnabled
        && rightSource != null
        && rightSource.width == 83
        && rightSource.height == nativeHeight)
    {
      int rightX = 134;
      int rightY = destinationY;
      ApplyViewport17FamilyDestOverride("RightF3", ref rightX, ref rightY);
      BlitPieceIntoPreview(
          pixels, rightSource, rightX, rightY, rightMirror);
    }

    // A surviving D3 FRONT left/right lane without a center is a 32px edge
    // strip, not a full LeftF3/RightF3 side wall. The open-left / full-D3 /
    // nearer-center occupancy is the verified 7px gutter recipe instead:
    // FrontF3 width 14 at X=-7, Mirror OFF, so source columns 7..13 appear at
    // viewport X=0..6 before LeftF3 begins at X=7. When the center is present,
    // the 83px D3 side graphics already join the 70px center; drawing the
    // edge strips would leave a black gap between X=32 and the center at 77.
    bool leftFrontGutter = automaticLeftFrontGutter && frontLeft;
    bool rightFrontGutter = automaticRightFrontGutter && frontRight;
    bool rightOpenSlitFront = automaticRightOpenSlitFront && frontRight;
    Texture2D frontSource = GetReadableNativeFrontF3Texture();
    int frontLeftX = leftFrontGutter ? NativeD3LeftFrontGutterX : 0;
    int frontRightX = rightOpenSlitFront
        ? NativeD3RightOpenSlitFrontX
        : (rightFrontGutter ? NativeD3RightFrontGutterX : 192);
    int frontCenterX = 77;
    int frontY = destinationY;
    if (TryGetViewport17FamilyPositionOverride("FrontF3", out int frontOverrideX, out int frontOverrideY))
    {
      frontY = frontOverrideY;
      if (frontCenter)
        frontCenterX = frontOverrideX;
      else if (frontLeft)
        frontLeftX = frontOverrideX;
      else if (frontRight)
        frontRightX = frontOverrideX;
    }

    // Temporary ViewEdit FrontF3 Width inspection. This path is active only
    // after the user edits the Width field; untouched poses keep the normal
    // V17 native D3 compositor byte-for-byte. The width is a crop of the full
    // FrontF3 source, not a scaled image. Mirror behaves as if the complete
    // source were mirrored first and then its leftmost N destination pixels
    // were kept.
    if ((frontLeft || frontCenter || frontRight)
        && TryGetFrontF3PreviewWidthOverride(out int frontF3PreviewWidth))
    {
      Texture2D fullFrontF3Source =
          graphics.GetTexture(DungeonGraphicType.FrontWallF3);
      if (fullFrontF3Source == null
          || fullFrontF3Source.height != nativeHeight
          || !fullFrontF3Source.isReadable)
      {
        fullFrontF3Source = frontSource;
      }

      if (fullFrontF3Source != null
          && fullFrontF3Source.height == nativeHeight
          && fullFrontF3Source.isReadable)
      {
        int drawWidth = Mathf.Clamp(
            frontF3PreviewWidth, 1, fullFrontF3Source.width);
        int sourceMinX = centerMirror
            ? fullFrontF3Source.width - drawWidth
            : 0;
        int sourceMaxX = centerMirror
            ? fullFrontF3Source.width - 1
            : drawWidth - 1;
        int destinationX = frontCenter
            ? frontCenterX
            : (frontLeft ? frontLeftX : frontRightX);

        BlitViewport17SourceStripPreview(
            pixels,
            fullFrontF3Source,
            sourceMinX,
            sourceMaxX,
            destinationX,
            frontY,
            centerMirror);
        return;
      }
    }

    if (leftFrontGutter)
    {
      // Use the same source fallback as the live ViewEdit Width path.
      // Some projects expose FrontWallF3 here as the native 70x49 source
      // rather than the older 141x49 composite. Requiring exactly 141px
      // made the automatic 6,1-West-class gutter silently draw nothing even
      // though the identical manual Width=14 test worked. Any readable F3
      // source that is at least 14px wide can supply this verified sliver.
      Texture2D gutterSource =
          graphics.GetTexture(DungeonGraphicType.FrontWallF3);
      if (gutterSource == null
          || gutterSource.height != nativeHeight
          || gutterSource.width < NativeD3LeftFrontGutterWidth
          || !gutterSource.isReadable)
      {
        gutterSource = frontSource;
      }

      if (gutterSource != null
          && gutterSource.height == nativeHeight
          && gutterSource.width >= NativeD3LeftFrontGutterWidth
          && gutterSource.isReadable)
      {
        int drawWidth = NativeD3LeftFrontGutterWidth;
        int sourceMinX = centerMirror
            ? gutterSource.width - drawWidth
            : 0;
        int sourceMaxX = centerMirror
            ? gutterSource.width - 1
            : drawWidth - 1;
        BlitViewport17SourceStripPreview(
            pixels,
            gutterSource,
            sourceMinX,
            sourceMaxX,
            frontLeftX,
            frontY,
            centerMirror);
      }
    }

    if (rightOpenSlitFront)
    {
      // Verified 10,5-West recipe: use the full authored 141px FrontF3 at
      // X=185, Mirror OFF. Viewport clipping keeps only the visible far-right
      // portion of the source, matching the manually verified ViewEdit values.
      Texture2D slitSource =
          graphics.GetTexture(DungeonGraphicType.FrontWallF3);
      if (slitSource == null
          || slitSource.height != nativeHeight
          || slitSource.width < NativeD3RightOpenSlitFrontWidth
          || !slitSource.isReadable)
      {
        slitSource = frontSource;
      }

      if (slitSource != null
          && slitSource.height == nativeHeight
          && slitSource.width >= NativeD3RightOpenSlitFrontWidth
          && slitSource.isReadable)
      {
        BlitViewport17SourceStripPreview(
            pixels,
            slitSource,
            0,
            NativeD3RightOpenSlitFrontWidth - 1,
            frontRightX,
            frontY,
            false);
      }
    }

    if (rightFrontGutter)
    {
      // Verified 9,4-East recipe: use the full authored 141x49 FrontF3 at
      // X=216, Mirror OFF. The viewport clip keeps only the tiny right-edge
      // sliver that continues immediately after RightF3. This is deliberately
      // not RightS3: original-game comparison matches the FrontF3 source.
      Texture2D rightGutterSource =
          graphics.GetTexture(DungeonGraphicType.FrontWallF3);
      if (rightGutterSource != null
          && rightGutterSource.height == nativeHeight
          && rightGutterSource.isReadable)
      {
        int drawWidth = Mathf.Min(
            NativeD3RightFrontGutterWidth, rightGutterSource.width);
        if (drawWidth > 0)
        {
          BlitViewport17SourceStripPreview(
              pixels,
              rightGutterSource,
              0,
              drawWidth - 1,
              frontRightX,
              frontY,
              false);
        }
      }
    }

    if (frontSource != null
        && frontSource.width == 70
        && frontSource.height == nativeHeight)
    {
      const int stripWidth = 32;
      int sourceStart = frontSource.width - stripWidth;
      if (frontLeft && !frontCenter && !leftFrontGutter)
      {
        BlitViewport17SourceStripPreview(
            pixels, frontSource, sourceStart, frontSource.width - 1,
            frontLeftX, frontY, centerMirror);
      }
      if (frontRight
          && !frontCenter
          && !rightFrontGutter
          && !rightOpenSlitFront)
      {
        BlitViewport17SourceStripPreview(
            pixels, frontSource, sourceStart, frontSource.width - 1,
            frontRightX, frontY, centerMirror);
      }
    }

    if (frontCenter)
    {
      Texture2D centerSource = frontSource;

      if (centerSource != null
          && centerSource.width == 70
          && centerSource.height == nativeHeight)
      {
        BlitPieceIntoPreview(
            pixels, centerSource, frontCenterX, frontY, centerMirror);
      }
      else
      {
        Debug.LogError(
            "V17 native D3: Front_Wall_F3_RAW_70x49.png is missing or not 70x49.");
      }
    }
  }

  private void BlitChampionMirrorD0RightIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewChampionMirrors == null
        || previewChampionMirrors.Length == 0)
    {
      return;
    }

    // This F0-right glimpse uses the FRONT mirror perspective family, not
    // the native side/S1 artwork. Generate the distant front image from the
    // original 48x43 F1 source, then let the near RightF0 geometry clip it.
    Texture2D frontF3Mirror = GetChampionMirrorFrontF3Texture();
    if (frontF3Mirror == null || !frontF3Mirror.isReadable)
      return;

    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    // D0/F0-right is the wall tile immediately beside the party, not one
    // cell forward.  The stored wall face is parallel to the current facing.
    // Example: (9,6) North sees ZED at (10,6), wall North.
    int mirrorX = previewX + rightX;
    int mirrorY = previewY + rightY;
    if (!previewMiniMap.IsInside(mirrorX, mirrorY)
        || previewMiniMap.GetTile(mirrorX, mirrorY).Type != DungeonTileType.Wall)
    {
      return;
    }

    string expectedWallSide = FacingName(previewFacing);
    for (int i = 0; i < previewChampionMirrors.Length; i++)
    {
      ChampionMirrorPlacement mirror = previewChampionMirrors[i];
      if (mirror != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("ChampionMirror", mirror.x, mirror.y, mirror.wall)))
        continue;
      if (mirror == null || string.IsNullOrEmpty(mirror.wall))
        continue;

      if (mirror.x != mirrorX
          || mirror.y != mirrorY
          || !string.Equals(
              mirror.wall,
              expectedWallSide,
              System.StringComparison.OrdinalIgnoreCase))
      {
        continue;
      }

      // Use the generated FRONT-F3 image. Only the portion left of the near
      // RightF0 boundary is visible; this is geometric clipping, not a
      // hand-authored distance sprite or a crop from the side/S1 image.
      int clipX = DungeonViewportWidth - 1;
      if (TryGetCanonicalReferenceXY("RightF0", out int rightF0X, out _))
        clipX = rightF0X;

      string featureKey = MakePreviewFeatureKey(
          "ChampionMirror", mirror.x, mirror.y, mirror.wall);
      int renderX = championMirrorD0RightPreviewX;
      int renderY = ChampionMirrorD0RightY;
      bool renderMirror = championMirrorD0RightPreviewMirror;
      ApplyPreviewFeatureRenderOverrides(
          featureKey, ref renderX, ref renderY, ref renderMirror);

      int geometricVisibleWidth = clipX - renderX + 1;
      if (geometricVisibleWidth <= 0)
        return;

      int visibleWidth = Mathf.Clamp(
          championMirrorD0RightPreviewVisibleWidth,
          1,
          Mathf.Min(frontF3Mirror.width, geometricVisibleWidth));

      BlitPieceScaledIntoPreview(
          pixels,
          frontF3Mirror,
          renderX,
          renderY,
          visibleWidth,
          frontF3Mirror.height,
          renderMirror,
          0,
          0,
          visibleWidth,
          frontF3Mirror.height);
      return;
    }
  }

  private void BlitChampionMirrorD1FramesIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewChampionMirrors == null
        || previewChampionMirrors.Length == 0)
    {
      return;
    }

    Texture2D sideMirror = GetChampionMirrorSideTexture();
    if (sideMirror == null || !sideMirror.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    // A nearer front wall occludes both D1 side faces.
    int frontX = previewX + forwardX;
    int frontY = previewY + forwardY;
    if (!previewMiniMap.IsInside(frontX, frontY)
        || previewMiniMap.GetTile(frontX, frontY).Type == DungeonTileType.Wall)
    {
      return;
    }

    int leftTileX = frontX - rightX;
    int leftTileY = frontY - rightY;
    int rightTileX = frontX + rightX;
    int rightTileY = frontY + rightY;

    string leftWallSide = FacingName(TurnPreviewFacingRight(previewFacing));
    string rightWallSide = FacingName(TurnPreviewFacingLeft(previewFacing));

    for (int i = 0; i < previewChampionMirrors.Length; i++)
    {
      ChampionMirrorPlacement mirror = previewChampionMirrors[i];
      if (mirror != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("ChampionMirror", mirror.x, mirror.y, mirror.wall)))
        continue;
      if (mirror == null || string.IsNullOrEmpty(mirror.wall))
        continue;

      if (mirror.x == leftTileX
          && mirror.y == leftTileY
          && string.Equals(
              mirror.wall,
              leftWallSide,
              System.StringComparison.OrdinalIgnoreCase))
      {
        string featureKey = MakePreviewFeatureKey(
            "ChampionMirror", mirror.x, mirror.y, mirror.wall);
        int renderX = ChampionMirrorD1LeftX;
        int renderY = ChampionMirrorD1Y;
        bool renderMirror = false;
        ApplyPreviewFeatureRenderOverrides(
            featureKey, ref renderX, ref renderY, ref renderMirror);
        BlitPieceIntoPreview(
            pixels,
            sideMirror,
            renderX,
            renderY,
            renderMirror);
        continue;
      }

      if (mirror.x == rightTileX
          && mirror.y == rightTileY
          && string.Equals(
              mirror.wall,
              rightWallSide,
              System.StringComparison.OrdinalIgnoreCase))
      {
        string featureKey = MakePreviewFeatureKey(
            "ChampionMirror", mirror.x, mirror.y, mirror.wall);
        int renderX = ChampionMirrorD1RightX;
        int renderY = ChampionMirrorD1Y;
        bool renderMirror = true;
        ApplyPreviewFeatureRenderOverrides(
            featureKey, ref renderX, ref renderY, ref renderMirror);
        BlitPieceIntoPreview(
            pixels,
            sideMirror,
            renderX,
            renderY,
            renderMirror);
      }
    }
  }

  private bool TryGetCurrentD1FrontChampion(out string championName)
  {
    championName = null;
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewChampionMirrors == null
        || previewChampionMirrors.Length == 0)
    {
      return false;
    }

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    int frontX = previewX + forwardX;
    int frontY = previewY + forwardY;
    if (!previewMiniMap.IsInside(frontX, frontY)
        || previewMiniMap.GetTile(frontX, frontY).Type != DungeonTileType.Wall)
    {
      return false;
    }

    string frontWallSide = FacingName(OppositePreviewFacing(previewFacing));
    for (int i = 0; i < previewChampionMirrors.Length; i++)
    {
      ChampionMirrorPlacement mirror = previewChampionMirrors[i];
      if (mirror != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("ChampionMirror", mirror.x, mirror.y, mirror.wall)))
        continue;
      if (mirror == null
          || string.IsNullOrEmpty(mirror.wall)
          || string.IsNullOrEmpty(mirror.champion))
      {
        continue;
      }

      if (mirror.x == frontX
          && mirror.y == frontY
          && string.Equals(
              mirror.wall,
              frontWallSide,
              System.StringComparison.OrdinalIgnoreCase))
      {
        championName = mirror.champion;
        return true;
      }
    }

    return false;
  }

  private bool IsPreviewChampionTaken(string championName)
  {
    if (string.IsNullOrEmpty(championName))
      return false;

    string key = NormalizeChampionAssetKey(championName);
    return previewTakenChampionKeys.Contains(key);
  }

  private void BlitChampionMirrorD1FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewChampionMirrors == null
        || previewChampionMirrors.Length == 0)
    {
      return;
    }

    Texture2D frontMirror = GetChampionMirrorFrontTexture();
    if (frontMirror == null || !frontMirror.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    int frontX = previewX + forwardX;
    int frontY = previewY + forwardY;
    if (!previewMiniMap.IsInside(frontX, frontY)
        || previewMiniMap.GetTile(frontX, frontY).Type != DungeonTileType.Wall)
    {
      return;
    }

    // The visible face of the wall directly in front of the party points back
    // toward the party, i.e. opposite the viewing direction.
    string frontWallSide = FacingName(OppositePreviewFacing(previewFacing));

    for (int i = 0; i < previewChampionMirrors.Length; i++)
    {
      ChampionMirrorPlacement mirror = previewChampionMirrors[i];
      if (mirror != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("ChampionMirror", mirror.x, mirror.y, mirror.wall)))
        continue;
      if (mirror == null
          || string.IsNullOrEmpty(mirror.wall)
          || string.IsNullOrEmpty(mirror.champion))
      {
        continue;
      }

      if (mirror.x != frontX
          || mirror.y != frontY
          || !string.Equals(
              mirror.wall,
              frontWallSide,
              System.StringComparison.OrdinalIgnoreCase))
      {
        continue;
      }

      // Frame first; the portrait then replaces the turquoise mirror opening.
      string featureKey = MakePreviewFeatureKey(
          "ChampionMirror", mirror.x, mirror.y, mirror.wall);
      int renderX = ChampionMirrorD1FrontX;
      int renderY = ChampionMirrorD1FrontY;
      bool renderMirror = false;
      ApplyPreviewFeatureRenderOverrides(
          featureKey, ref renderX, ref renderY, ref renderMirror);

      BlitPieceIntoPreview(
          pixels,
          frontMirror,
          renderX,
          renderY,
          renderMirror);

      Texture2D portrait = GetChampionPortraitTexture(mirror.champion);
      if (!IsPreviewChampionTaken(mirror.champion)
          && portrait != null
          && portrait.isReadable
          && portrait.width == 32
          && portrait.height == 29)
      {
        BlitPieceIntoPreview(
            pixels,
            portrait,
            renderX + ChampionPortraitD1FrontOffsetX,
            renderY + ChampionPortraitD1FrontOffsetY,
            renderMirror);
      }

      return;
    }
  }

  private void BlitChampionMirrorD2FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewChampionMirrors == null
        || previewChampionMirrors.Length == 0)
    {
      return;
    }

    Texture2D frontMirror = GetChampionMirrorGeneratedF2Texture();
    if (frontMirror == null || !frontMirror.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    // All D2 front lanes are seen through the open D1 center. Lateral D2
    // mirrors additionally require their matching D1 side lane to be open;
    // otherwise that nearer wall occludes the decoration.
    int d1CenterX = previewX + forwardX;
    int d1CenterY = previewY + forwardY;
    if (!previewMiniMap.IsInside(d1CenterX, d1CenterY)
        || previewMiniMap.GetTile(d1CenterX, d1CenterY).Type == DungeonTileType.Wall)
    {
      return;
    }

    string frontWallSide = FacingName(OppositePreviewFacing(previewFacing));

    // localLane -1/0/+1 = screen-left / center / screen-right. The original
    // DOS projection clips the two lateral 29px frames at the viewport edges.
    for (int localLane = -1; localLane <= 1; localLane++)
    {
      if (localLane != 0)
      {
        int d1LaneX = d1CenterX + rightX * localLane;
        int d1LaneY = d1CenterY + rightY * localLane;
        if (!previewMiniMap.IsInside(d1LaneX, d1LaneY)
            || previewMiniMap.GetTile(d1LaneX, d1LaneY).Type == DungeonTileType.Wall)
        {
          continue;
        }
      }

      int d2X = previewX + forwardX * 2 + rightX * localLane;
      int d2Y = previewY + forwardY * 2 + rightY * localLane;
      if (!previewMiniMap.IsInside(d2X, d2Y)
          || previewMiniMap.GetTile(d2X, d2Y).Type != DungeonTileType.Wall)
      {
        continue;
      }

      int destinationX = localLane < 0
          ? ChampionMirrorD2FrontLeftX
          : localLane > 0
              ? ChampionMirrorD2FrontRightX
              : ChampionMirrorD2FrontX;

      for (int i = 0; i < previewChampionMirrors.Length; i++)
      {
        ChampionMirrorPlacement mirror = previewChampionMirrors[i];
      if (mirror != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("ChampionMirror", mirror.x, mirror.y, mirror.wall)))
        continue;
        if (mirror == null
            || string.IsNullOrEmpty(mirror.wall)
            || string.IsNullOrEmpty(mirror.champion))
        {
          continue;
        }

        if (mirror.x != d2X
            || mirror.y != d2Y
            || !string.Equals(
                mirror.wall,
                frontWallSide,
                System.StringComparison.OrdinalIgnoreCase))
        {
          continue;
        }

        // Generic wall-ornament path:
        // F1 48x43 -> generated F2 29x27 -> Medium distance palette.
        // The generated texture is already scaled and darkened, so draw it 1:1.
        // Lateral lanes are still clipped naturally by the 224px dungeon viewport.
        string featureKey = MakePreviewFeatureKey(
            "ChampionMirror", mirror.x, mirror.y, mirror.wall);
        int renderX = destinationX;
        int renderY = ChampionMirrorFrontWallOrnamentSet.f2.y;
        bool renderMirror = false;
        ApplyPreviewFeatureRenderOverrides(
            featureKey, ref renderX, ref renderY, ref renderMirror);
        BlitWallOrnamentIntoPreview(
            pixels,
            frontMirror,
            renderX,
            renderY,
            renderMirror);
        break;
      }
    }
  }

  private void BlitChampionMirrorD3FrontIntoPreview(Color32[] pixels)
  {
    // Load HallOfChampions.json (including championMirrors), but do not make
    // the F3 decoration depend on the minimap tile classifier.  The mirror
    // placement entry is the authoritative wall-decoration record.
    EnsurePreviewMiniMapLoaded();
    if (previewChampionMirrors == null
        || previewChampionMirrors.Length == 0)
    {
      return;
    }

    Texture2D frontMirror = GetChampionMirrorFrontF3Texture();
    if (frontMirror == null || !frontMirror.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    int expectedMirrorX = previewX + forwardX * 3;
    int expectedMirrorY = previewY + forwardY * 3;
    string expectedWallSide = FacingName(OppositePreviewFacing(previewFacing));

    for (int i = 0; i < previewChampionMirrors.Length; i++)
    {
      ChampionMirrorPlacement mirror = previewChampionMirrors[i];
      if (mirror != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("ChampionMirror", mirror.x, mirror.y, mirror.wall)))
        continue;
      if (mirror == null || string.IsNullOrEmpty(mirror.wall))
        continue;

      // Generic F3-front test: the stored Champion-mirror wall is exactly
      // three map cells in the viewing direction and faces back at the party.
      // Example: 9,7 South -> SYRA mirror at 9,10 North.
      if (mirror.x != expectedMirrorX
          || mirror.y != expectedMirrorY
          || !string.Equals(
              mirror.wall,
              expectedWallSide,
              System.StringComparison.OrdinalIgnoreCase))
      {
        continue;
      }

      string featureKey = MakePreviewFeatureKey(
          "ChampionMirror", mirror.x, mirror.y, mirror.wall);
      int renderX = ChampionMirrorD3FrontX;
      int renderY = ChampionMirrorD3FrontY;
      bool renderMirror = false;
      ApplyPreviewFeatureRenderOverrides(
          featureKey, ref renderX, ref renderY, ref renderMirror);
      BlitWallOrnamentIntoPreview(
          pixels,
          frontMirror,
          renderX,
          renderY,
          renderMirror);
      return;
    }
  }

  private void BlitChampionMirrorD2LeftIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewChampionMirrors == null
        || previewChampionMirrors.Length == 0)
    {
      return;
    }

    Texture2D sideMirror = GetChampionMirrorSideD2Texture();
    if (sideMirror == null || !sideMirror.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    int d1CenterX = previewX + forwardX;
    int d1CenterY = previewY + forwardY;
    int d2CenterX = previewX + forwardX * 2;
    int d2CenterY = previewY + forwardY * 2;
    if (!previewMiniMap.IsInside(d1CenterX, d1CenterY)
        || previewMiniMap.GetTile(d1CenterX, d1CenterY).Type == DungeonTileType.Wall
        || !previewMiniMap.IsInside(d2CenterX, d2CenterY)
        || previewMiniMap.GetTile(d2CenterX, d2CenterY).Type == DungeonTileType.Wall)
    {
      return;
    }

    int mirrorX = d2CenterX - rightX;
    int mirrorY = d2CenterY - rightY;
    if (!previewMiniMap.IsInside(mirrorX, mirrorY))
      return;

    // Screen-left side walls face inward toward the corridor: TurnRight.
    string leftWallSide = FacingName(TurnPreviewFacingRight(previewFacing));

    for (int i = 0; i < previewChampionMirrors.Length; i++)
    {
      ChampionMirrorPlacement mirror = previewChampionMirrors[i];
      if (mirror != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("ChampionMirror", mirror.x, mirror.y, mirror.wall)))
        continue;
      if (mirror == null || string.IsNullOrEmpty(mirror.wall))
        continue;

      if (mirror.x != mirrorX
          || mirror.y != mirrorY
          || !string.Equals(
              mirror.wall,
              leftWallSide,
              System.StringComparison.OrdinalIgnoreCase))
      {
        continue;
      }

      // All Champion side-mirror source artwork is canonical LEFT orientation.
      // Screen-left therefore uses the generated D2 projection as-is.
      string featureKey = MakePreviewFeatureKey(
          "ChampionMirror", mirror.x, mirror.y, mirror.wall);
      int renderX = ChampionMirrorD2LeftX;
      int renderY = ChampionMirrorD2SideY;
      bool renderMirror = false;
      ApplyPreviewFeatureRenderOverrides(
          featureKey, ref renderX, ref renderY, ref renderMirror);
      BlitPieceIntoPreview(
          pixels,
          sideMirror,
          renderX,
          renderY,
          renderMirror);
      return;
    }
  }

  private void BlitChampionMirrorD2RightIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewChampionMirrors == null
        || previewChampionMirrors.Length == 0)
    {
      return;
    }

    Texture2D rightMirror = GetChampionMirrorSideD2Texture();
    if (rightMirror == null || !rightMirror.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    // A D2 side mirror is visible only if the center sight line stays open
    // through D1 and D2. The decorated wall tile is one lane to screen-right
    // of the D2 center tile.
    int d1CenterX = previewX + forwardX;
    int d1CenterY = previewY + forwardY;
    int d2CenterX = previewX + forwardX * 2;
    int d2CenterY = previewY + forwardY * 2;
    if (!previewMiniMap.IsInside(d1CenterX, d1CenterY)
        || previewMiniMap.GetTile(d1CenterX, d1CenterY).Type == DungeonTileType.Wall
        || !previewMiniMap.IsInside(d2CenterX, d2CenterY)
        || previewMiniMap.GetTile(d2CenterX, d2CenterY).Type == DungeonTileType.Wall)
    {
      return;
    }

    int mirrorX = d2CenterX + rightX;
    int mirrorY = d2CenterY + rightY;
    if (!previewMiniMap.IsInside(mirrorX, mirrorY))
      return;

    // A screen-right side wall faces inward toward the corridor, which is
    // TurnLeft(viewFacing). This matches ELIJA's (8,7) East mirror when the
    // party is at (9,5) facing South.
    string rightWallSide = FacingName(TurnPreviewFacingLeft(previewFacing));

    for (int i = 0; i < previewChampionMirrors.Length; i++)
    {
      ChampionMirrorPlacement mirror = previewChampionMirrors[i];
      if (mirror != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("ChampionMirror", mirror.x, mirror.y, mirror.wall)))
        continue;
      if (mirror == null || string.IsNullOrEmpty(mirror.wall))
        continue;

      if (mirror.x != mirrorX
          || mirror.y != mirrorY
          || !string.Equals(
              mirror.wall,
              rightWallSide,
              System.StringComparison.OrdinalIgnoreCase))
      {
        continue;
      }

      // Code-generated 10x23 D2 side projection from the canonical LEFT-oriented
      // 16x35 S1 source. Screen-right must mirror that source horizontally.
      string featureKey = MakePreviewFeatureKey(
          "ChampionMirror", mirror.x, mirror.y, mirror.wall);
      int renderX = ChampionMirrorD2RightX;
      int renderY = ChampionMirrorD2SideY;
      bool renderMirror = true;
      ApplyPreviewFeatureRenderOverrides(
          featureKey, ref renderX, ref renderY, ref renderMirror);
      BlitPieceIntoPreview(
          pixels,
          rightMirror,
          renderX,
          renderY,
          renderMirror);
      return;
    }
  }

  private void DarkenChampionMirrorD2InteriorHighlights(
      Color32[] pixels,
      int destX,
      int destY,
      int destWidth,
      int destHeight)
  {
    if (pixels == null || pixels.Length != PreviewWidth * PreviewHeight)
      return;

    // The F2 mirror is already geometrically correct; this pass only nudges
    // the bright neutral glass highlights slightly darker so the reduced view
    // better matches the original DOS screenshot. Keep the brown frame and the
    // saturated cyan strokes intact by affecting only bright, low-saturation
    // pixels inside the scaled mirror's inner opening.
    int insetLeft = 4;
    int insetRight = 4;
    int insetBottom = 4;
    int insetTop = 0;

    int minX = Mathf.Clamp(destX + insetLeft, 0, PreviewWidth);
    int maxX = Mathf.Clamp(destX + destWidth - insetRight, 0, PreviewWidth);
    int minY = Mathf.Clamp(destY + insetBottom, 0, PreviewHeight);
    int maxY = Mathf.Clamp(destY + destHeight - insetTop, 0, PreviewHeight);

    for (int y = minY; y < maxY; y++)
    {
      int row = y * PreviewWidth;
      for (int x = minX; x < maxX; x++)
      {
        int index = row + x;
        Color32 c = pixels[index];
        if (c.a == 0)
          continue;

        int max = Mathf.Max(c.r, Mathf.Max(c.g, c.b));
        int min = Mathf.Min(c.r, Mathf.Min(c.g, c.b));
        int luminance = (c.r + c.g + c.b) / 3;

        // Only tone down the whitish/gray reflective pixels.
        if (luminance < 150 || max - min > 44)
          continue;

        c.r = (byte)((c.r * 86) / 100);
        c.g = (byte)((c.g * 86) / 100);
        c.b = (byte)((c.b * 86) / 100);
        pixels[index] = c;
      }
    }
  }

  private bool PreviewTileIsOpen(int x, int y)
  {
    return previewMiniMap != null
        && previewMiniMap.IsInside(x, y)
        && previewMiniMap.GetTile(x, y).Type != DungeonTileType.Wall;
  }

  private bool PreviewTileIsWall(int x, int y)
  {
    return previewMiniMap != null
        && previewMiniMap.IsInside(x, y)
        && previewMiniMap.GetTile(x, y).Type == DungeonTileType.Wall;
  }

  private bool TryBlitMatchingChampionMirror(
      Color32[] pixels,
      Texture2D texture,
      int tileX,
      int tileY,
      string wallSide,
      int destX,
      int destY,
      bool mirrorHorizontally)
  {
    if (pixels == null
        || texture == null
        || !texture.isReadable
        || previewChampionMirrors == null
        || string.IsNullOrEmpty(wallSide))
    {
      return false;
    }

    for (int i = 0; i < previewChampionMirrors.Length; i++)
    {
      ChampionMirrorPlacement mirror = previewChampionMirrors[i];
      if (mirror != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("ChampionMirror", mirror.x, mirror.y, mirror.wall)))
        continue;
      if (mirror == null || string.IsNullOrEmpty(mirror.wall))
        continue;

      if (mirror.x != tileX
          || mirror.y != tileY
          || !string.Equals(
              mirror.wall,
              wallSide,
              System.StringComparison.OrdinalIgnoreCase))
      {
        continue;
      }

      string featureKey = MakePreviewFeatureKey(
          "ChampionMirror", mirror.x, mirror.y, mirror.wall);
      int renderX = destX;
      int renderY = destY;
      bool renderMirror = mirrorHorizontally;
      ApplyPreviewFeatureRenderOverrides(
          featureKey, ref renderX, ref renderY, ref renderMirror);
      BlitPieceIntoPreview(
          pixels,
          texture,
          renderX,
          renderY,
          renderMirror);
      return true;
    }

    return false;
  }

  private void BlitChampionMirrorD3LeftIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewChampionMirrors == null
        || previewChampionMirrors.Length == 0)
    {
      return;
    }

    Texture2D f3Left = GetChampionMirrorSideDistantLeftTexture();
    Texture2D l2 = GetChampionMirrorSideDistantTexture();

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    string leftWallSide = FacingName(TurnPreviewFacingRight(previewFacing));

    int d1CenterX = previewX + forwardX;
    int d1CenterY = previewY + forwardY;
    int d2CenterX = previewX + forwardX * 2;
    int d2CenterY = previewY + forwardY * 2;
    int d3CenterX = previewX + forwardX * 3;
    int d3CenterY = previewY + forwardY * 3;

    // F3-left corridor/alcove: center line open through D3, decorated wall
    // is one lane left of D3. D1/D2 left may be walls (9,9 East LINFLAS) or
    // open (12,9 West SYRA). Code-generated 7x15 from S1, unmirrored.
    int f3LeftX = d3CenterX - rightX;
    int f3LeftY = d3CenterY - rightY;
    if (PreviewTileIsOpen(d1CenterX, d1CenterY)
        && PreviewTileIsOpen(d2CenterX, d2CenterY)
        && PreviewTileIsOpen(d3CenterX, d3CenterY)
        && PreviewTileIsWall(f3LeftX, f3LeftY))
    {
      TryBlitMatchingChampionMirror(
          pixels,
          f3Left,
          f3LeftX,
          f3LeftY,
          leftWallSide,
          ChampionMirrorD3LeftX,
          ChampionMirrorD3LeftY,
          false);
    }

    // D3L2 oblique: sight through the open left side-lane, decorated wall
    // two lanes left of D3. The 15x15 source is canonical LEFT orientation,
    // so the screen-left slot uses it as-is.
    int d1LeftX = d1CenterX - rightX;
    int d1LeftY = d1CenterY - rightY;
    int d2LeftX = d2CenterX - rightX;
    int d2LeftY = d2CenterY - rightY;
    int d3LeftX = d3CenterX - rightX;
    int d3LeftY = d3CenterY - rightY;
    int l2X = d3CenterX - rightX * 2;
    int l2Y = d3CenterY - rightY * 2;
    if (PreviewTileIsOpen(d1CenterX, d1CenterY)
        && PreviewTileIsOpen(d1LeftX, d1LeftY)
        && PreviewTileIsOpen(d2LeftX, d2LeftY)
        && PreviewTileIsOpen(d3LeftX, d3LeftY)
        && PreviewTileIsWall(l2X, l2Y))
    {
      TryBlitMatchingChampionMirror(
          pixels,
          l2,
          l2X,
          l2Y,
          leftWallSide,
          ChampionMirrorD3LeftL2X,
          ChampionMirrorD3LeftL2Y,
          false);
    }
  }

  private void BlitChampionMirrorD3RightIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewChampionMirrors == null
        || previewChampionMirrors.Length == 0)
    {
      return;
    }

    Texture2D f3LeftCutout = GetChampionMirrorSideDistantLeftTexture();
    Texture2D r2 = GetChampionMirrorSideDistantTexture();

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    string rightWallSide = FacingName(TurnPreviewFacingLeft(previewFacing));

    int d1CenterX = previewX + forwardX;
    int d1CenterY = previewY + forwardY;
    int d2CenterX = previewX + forwardX * 2;
    int d2CenterY = previewY + forwardY * 2;
    int d3CenterX = previewX + forwardX * 3;
    int d3CenterY = previewY + forwardY * 3;

    // F3-right corridor/alcove: center line open through D3, decorated wall
    // is one lane right of D3. Same code-generated 7x15 D3 projection as F3-left, mirrored.
    int f3RightX = d3CenterX + rightX;
    int f3RightY = d3CenterY + rightY;
    if (PreviewTileIsOpen(d1CenterX, d1CenterY)
        && PreviewTileIsOpen(d2CenterX, d2CenterY)
        && PreviewTileIsOpen(d3CenterX, d3CenterY)
        && PreviewTileIsWall(f3RightX, f3RightY))
    {
      TryBlitMatchingChampionMirror(
          pixels,
          f3LeftCutout,
          f3RightX,
          f3RightY,
          rightWallSide,
          ChampionMirrorD3RightF3X,
          ChampionMirrorD3RightF3Y,
          true);
    }

    // D3R2 oblique: sight through the open right side-lane, decorated wall
    // two lanes right of D3. The 15x15 source is canonical LEFT orientation,
    // so the screen-right slot is mirrored horizontally.
    int d1RightX = d1CenterX + rightX;
    int d1RightY = d1CenterY + rightY;
    int d2RightX = d2CenterX + rightX;
    int d2RightY = d2CenterY + rightY;
    int d3RightX = d3CenterX + rightX;
    int d3RightY = d3CenterY + rightY;
    int r2X = d3CenterX + rightX * 2;
    int r2Y = d3CenterY + rightY * 2;
    if (PreviewTileIsOpen(d1CenterX, d1CenterY)
        && PreviewTileIsOpen(d1RightX, d1RightY)
        && PreviewTileIsOpen(d2RightX, d2RightY)
        && PreviewTileIsOpen(d3RightX, d3RightY)
        && PreviewTileIsWall(r2X, r2Y))
    {
      TryBlitMatchingChampionMirror(
          pixels,
          r2,
          r2X,
          r2Y,
          rightWallSide,
          ChampionMirrorD3RightX,
          ChampionMirrorD3RightY,
          true);
    }
  }

  private Texture2D GetChampionMirrorGeneratedF2Texture()
  {
    if (cachedChampionMirrorGeneratedF2Texture != null)
      return cachedChampionMirrorGeneratedF2Texture;

    Texture2D source = GetChampionMirrorFrontTexture();
    if (source == null || !source.isReadable)
      return null;

    cachedChampionMirrorGeneratedF2Texture =
        GenerateWallOrnamentForDepth(
            source,
            ChampionMirrorFrontWallOrnamentSet.f2,
            WallOrnamentMediumColorMap,
            "Champion Mirror F2 Generated from F1");

    return cachedChampionMirrorGeneratedF2Texture;
  }

  private Texture2D GetChampionMirrorFrontF3Texture()
  {
    if (cachedChampionMirrorFrontF3Texture != null)
      return cachedChampionMirrorFrontF3Texture;

    Texture2D source = GetChampionMirrorFrontTexture();
    if (source == null || !source.isReadable)
      return null;

    cachedChampionMirrorFrontF3Texture = GenerateWallOrnamentForDepth(
        source,
        ChampionMirrorFrontWallOrnamentSet.f3,
        WallOrnamentFarColorMap,
        "Champion Mirror F3 Generated from F1");
    return cachedChampionMirrorFrontF3Texture;
  }

  private Texture2D GetChampionMirrorFrontTexture()
  {
    if (cachedChampionMirrorFrontTexture != null)
      return cachedChampionMirrorFrontTexture;

    Texture2D texture =
        AssetDatabase.LoadAssetAtPath<Texture2D>(ChampionMirrorFrontAssetPath);
    if (texture != null && texture.width == 48 && texture.height == 43)
    {
      cachedChampionMirrorFrontTexture = texture;
      return texture;
    }

    // Filename-independent fallback for the original 48x43 front mirror.
    string[] guids = AssetDatabase.FindAssets(
        "t:Texture2D",
        new[] { ChampionArtFolder });
    for (int i = 0; i < guids.Length; i++)
    {
      string path = AssetDatabase.GUIDToAssetPath(guids[i]);
      Texture2D candidate = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
      if (candidate == null || candidate.width != 48 || candidate.height != 43)
        continue;

      if (path.IndexOf(
              "mirror",
              System.StringComparison.OrdinalIgnoreCase) < 0)
      {
        continue;
      }

      cachedChampionMirrorFrontTexture = candidate;
      return candidate;
    }

    return null;
  }

  private Texture2D GetChampionPortraitTexture(string championName)
  {
    if (string.IsNullOrEmpty(championName))
      return null;

    string wantedKey = NormalizeChampionAssetKey(championName);
    if (string.IsNullOrEmpty(wantedKey))
      return null;

    if (cachedChampionPortraitTextures.TryGetValue(
            wantedKey,
            out Texture2D cached))
    {
      return cached;
    }

    Texture2D folderMatch = null;
    string[] guids = AssetDatabase.FindAssets(
        "t:Texture2D",
        new[] { ChampionArtFolder });
    for (int i = 0; i < guids.Length; i++)
    {
      string path = AssetDatabase.GUIDToAssetPath(guids[i]);
      if (path.IndexOf(
              "mirror",
              System.StringComparison.OrdinalIgnoreCase) >= 0)
      {
        continue;
      }

      Texture2D candidate = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
      if (candidate == null || candidate.width != 32 || candidate.height != 29)
        continue;

      string fileKey =
          NormalizeChampionAssetKey(Path.GetFileNameWithoutExtension(path));
      if (string.Equals(
              fileKey,
              wantedKey,
              System.StringComparison.OrdinalIgnoreCase))
      {
        cachedChampionPortraitTextures[wantedKey] = candidate;
        return candidate;
      }

      string directory = Path.GetDirectoryName(path);
      string folderName = string.IsNullOrEmpty(directory)
          ? string.Empty
          : Path.GetFileName(directory);
      string folderKey = NormalizeChampionAssetKey(folderName);
      if (folderMatch == null
          && string.Equals(
              folderKey,
              wantedKey,
              System.StringComparison.OrdinalIgnoreCase))
      {
        folderMatch = candidate;
      }
    }

    if (folderMatch != null)
      cachedChampionPortraitTextures[wantedKey] = folderMatch;

    return folderMatch;
  }

  private static string NormalizeChampionAssetKey(string value)
  {
    if (string.IsNullOrEmpty(value))
      return string.Empty;

    System.Text.StringBuilder builder = new System.Text.StringBuilder();
    for (int i = 0; i < value.Length; i++)
    {
      char c = value[i];
      if (char.IsLetterOrDigit(c))
        builder.Append(char.ToUpperInvariant(c));
    }

    return builder.ToString();
  }

  private static DungeonFacing OppositePreviewFacing(DungeonFacing facing)
  {
    return facing switch
    {
      DungeonFacing.North => DungeonFacing.South,
      DungeonFacing.East => DungeonFacing.West,
      DungeonFacing.South => DungeonFacing.North,
      DungeonFacing.West => DungeonFacing.East,
      _ => facing
    };
  }

  private Texture2D GetChampionMirrorSideD2Texture()
  {
    if (cachedChampionMirrorSideD2Texture != null)
      return cachedChampionMirrorSideD2Texture;

    // Champion mirrors have only two original source graphics: front F1 and
    // side S1.  D2/D3 variants are generated at runtime/editor-preview time;
    // never load hand-copied GIMP distance PNGs here.
    Texture2D source = GetChampionMirrorSideTexture();
    if (source == null || !source.isReadable)
      return null;

    cachedChampionMirrorSideD2Texture = GenerateDmScaledWallDecoration(
        source,
        ChampionMirrorD2SideWidth,
        ChampionMirrorD2SideHeight,
        WallOrnamentMediumColorMap,
        "Champion Mirror Side D2 Generated from S1");
    return cachedChampionMirrorSideD2Texture;
  }

  private Texture2D GetChampionMirrorSideDistantLeftTexture()
  {
    if (cachedChampionMirrorSideDistantLeftTexture != null)
      return cachedChampionMirrorSideDistantLeftTexture;

    Texture2D source = GetChampionMirrorSideTexture();
    if (source == null || !source.isReadable)
      return null;

    cachedChampionMirrorSideDistantLeftTexture = GenerateDmScaledWallDecoration(
        source,
        7,
        15,
        WallOrnamentFarColorMap,
        "Champion Mirror Side D3 Generated from S1");
    return cachedChampionMirrorSideDistantLeftTexture;
  }

  private Texture2D GetChampionMirrorSideDistantTexture()
  {
    if (cachedChampionMirrorSideDistantTexture != null)
      return cachedChampionMirrorSideDistantTexture;

    Texture2D source = GetChampionMirrorSideTexture();
    if (source == null || !source.isReadable)
      return null;

    cachedChampionMirrorSideDistantTexture = GenerateDmScaledWallDecoration(
        source,
        15,
        15,
        WallOrnamentFarColorMap,
        "Champion Mirror Side F3 Generated from F1");
    return cachedChampionMirrorSideDistantTexture;
  }

  private Texture2D GetChampionMirrorSideTexture()
  {
    if (cachedChampionMirrorSideTexture != null)
      return cachedChampionMirrorSideTexture;

    Texture2D texture =
        AssetDatabase.LoadAssetAtPath<Texture2D>(ChampionMirrorSideAssetPath);
    if (texture != null && texture.width == 16 && texture.height == 35)
    {
      cachedChampionMirrorSideTexture = texture;
      return texture;
    }

    // Filename-independent fallback: the original GRAPHICS.DAT contains one
    // 16x35 Champion side-mirror image. This lets the project keep a slightly
    // different filename without changing renderer code.
    string[] guids = AssetDatabase.FindAssets(
        "t:Texture2D",
        new[] { ChampionArtFolder });
    for (int i = 0; i < guids.Length; i++)
    {
      string path = AssetDatabase.GUIDToAssetPath(guids[i]);
      Texture2D candidate = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
      if (candidate == null || candidate.width != 16 || candidate.height != 35)
        continue;

      if (path.IndexOf(
              "mirror",
              System.StringComparison.OrdinalIgnoreCase) < 0)
      {
        continue;
      }

      cachedChampionMirrorSideTexture = candidate;
      return candidate;
    }

    return null;
  }

  private static int ResolveHallOfChampionsWallOrnamentSourceId(
      WallOrnamentPlacement ornament)
  {
    if (ornament == null || ornament.wallTilePlacement)
      return -1;

    int index = ornament.ornamentOrdinal - 1;
    if (index < 0 || index >= HallOfChampionsWallOrnamentSourceIds.Length)
      return -1;

    return HallOfChampionsWallOrnamentSourceIds[index];
  }

  private void BlitWoodRingD3FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D woodRingFront = GetWoodRingGeneratedF3FrontTexture();
    if (woodRingFront == null || !woodRingFront.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    int d1X = previewX + forwardX;
    int d1Y = previewY + forwardY;
    int d2X = previewX + forwardX * 2;
    int d2Y = previewY + forwardY * 2;
    int wallTileX = previewX + forwardX * 3;
    int wallTileY = previewY + forwardY * 3;
    if (!previewMiniMap.IsInside(d1X, d1Y)
        || previewMiniMap.GetTile(d1X, d1Y).Type == DungeonTileType.Wall
        || !previewMiniMap.IsInside(d2X, d2Y)
        || previewMiniMap.GetTile(d2X, d2Y).Type == DungeonTileType.Wall
        || !previewMiniMap.IsInside(wallTileX, wallTileY))
    {
      return;
    }

    string viewedWallSide = FacingName(previewFacing);
    string visiblePhysicalWallFace = OppositeFacingName(previewFacing);

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsWoodRingOrnament(ornament))
        continue;

      bool placementMatches;
      if (ornament.wallTilePlacement)
      {
        placementMatches =
            ornament.x == wallTileX
            && ornament.y == wallTileY
            && string.Equals(
                ornament.wall,
                visiblePhysicalWallFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        placementMatches =
            ornament.x == d2X
            && ornament.y == d2Y
            && string.Equals(
                ornament.wall,
                viewedWallSide,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (!placementMatches)
        continue;

      BlitWallOrnamentIntoPreview(
          pixels,
          woodRingFront,
          HookFrontWallOrnamentSet.f3.x,
          HookFrontWallOrnamentSet.f3.y,
          false);
      return;
    }
  }

  private Texture2D GetWoodRingGeneratedF3FrontTexture()
  {
    if (cachedWoodRingGeneratedF3FrontTexture != null)
      return cachedWoodRingGeneratedF3FrontTexture;

    Texture2D source = GetWoodRingFrontTexture();
    if (source == null || !source.isReadable)
      return null;

    cachedWoodRingGeneratedF3FrontTexture = GenerateDmScaledWallDecoration(
        source,
        HookFrontWallOrnamentSet.f3.width,
        HookFrontWallOrnamentSet.f3.height,
        WallOrnamentFarColorMap,
        "Wood Ring F3 Generated from F1");
    return cachedWoodRingGeneratedF3FrontTexture;
  }

  private void BlitWoodRingD2FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D woodRingFront = GetWoodRingGeneratedF2FrontTexture();
    if (woodRingFront == null || !woodRingFront.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    int d1X = previewX + forwardX;
    int d1Y = previewY + forwardY;
    int wallTileX = previewX + forwardX * 2;
    int wallTileY = previewY + forwardY * 2;
    if (!previewMiniMap.IsInside(d1X, d1Y)
        || previewMiniMap.GetTile(d1X, d1Y).Type == DungeonTileType.Wall
        || !previewMiniMap.IsInside(wallTileX, wallTileY))
    {
      return;
    }

    string viewedWallSide = FacingName(previewFacing);
    string visiblePhysicalWallFace = OppositeFacingName(previewFacing);

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsWoodRingOrnament(ornament))
        continue;

      bool placementMatches;
      if (ornament.wallTilePlacement)
      {
        placementMatches =
            ornament.x == wallTileX
            && ornament.y == wallTileY
            && string.Equals(
                ornament.wall,
                visiblePhysicalWallFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        placementMatches =
            ornament.x == d1X
            && ornament.y == d1Y
            && string.Equals(
                ornament.wall,
                viewedWallSide,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (!placementMatches)
        continue;

      // Wood Ring shares coordinate set 0 with the Hook, so the F2 front
      // uses that same measured slot.
      BlitWallOrnamentIntoPreview(
          pixels,
          woodRingFront,
          HookFrontWallOrnamentSet.f2.x,
          HookFrontWallOrnamentSet.f2.y,
          false);
      return;
    }
  }

  private Texture2D GetWoodRingGeneratedF2FrontTexture()
  {
    if (cachedWoodRingGeneratedF2FrontTexture != null)
      return cachedWoodRingGeneratedF2FrontTexture;

    Texture2D source = GetWoodRingFrontTexture();
    if (source == null || !source.isReadable)
      return null;

    cachedWoodRingGeneratedF2FrontTexture = GenerateDmScaledWallDecoration(
        source,
        HookFrontWallOrnamentSet.f2.width,
        HookFrontWallOrnamentSet.f2.height,
        WallOrnamentMediumColorMap,
        "Wood Ring F2 Generated from F1");
    return cachedWoodRingGeneratedF2FrontTexture;
  }

  private void BlitWoodRingD1FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D woodRingFront = GetWoodRingFrontTexture();
    if (woodRingFront == null || !woodRingFront.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    int wallTileX = previewX + forwardX;
    int wallTileY = previewY + forwardY;
    if (!previewMiniMap.IsInside(wallTileX, wallTileY)
        || previewMiniMap.GetTile(wallTileX, wallTileY).Type
            != DungeonTileType.Wall)
    {
      return;
    }

    string viewedWallSide = FacingName(previewFacing);

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsWoodRingOrnament(ornament))
        continue;

      bool placementMatches;
      if (ornament.wallTilePlacement)
      {
        // Random wall-decoration bits belong to the solid wall tile itself.
        string visiblePhysicalWallFace = OppositeFacingName(previewFacing);
        placementMatches =
            ornament.x == wallTileX
            && ornament.y == wallTileY
            && string.Equals(
                ornament.wall,
                visiblePhysicalWallFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        // Explicit mechanisms are stored on the passable cell and use the
        // direction from that cell toward the wall boundary.
        placementMatches =
            ornament.x == previewX
            && ornament.y == previewY
            && string.Equals(
                ornament.wall,
                viewedWallSide,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (!placementMatches)
        continue;

      // Initial D1-front calibration uses the same original wall-center anchor
      // as the verified 28x28 Hook: framebuffer center (112,114). Keeping the
      // anchor independent of texture size lets the native Wood Ring PNG draw
      // 1:1 without guessing or rescaling it. We can nudge X/Y after the first
      // original-vs-Unity comparison if the source artwork requires it.
      int x = 112 - (woodRingFront.width / 2);
      int y = 114 - (woodRingFront.height / 2);

      BlitPieceIntoPreview(
          pixels,
          woodRingFront,
          x,
          y,
          false);
      return;
    }
  }

  private static bool IsWoodRingOrnament(WallOrnamentPlacement ornament)
  {
    if (ornament == null)
      return false;

    if (string.Equals(
            ornament.type,
            "WoodRing",
            System.StringComparison.OrdinalIgnoreCase)
        || string.Equals(
            ornament.type,
            "Wood Ring",
            System.StringComparison.OrdinalIgnoreCase))
    {
      return true;
    }

    return ResolveHallOfChampionsWallOrnamentSourceId(ornament) == 6;
  }

  private Texture2D GetWoodRingFrontTexture()
  {
    if (cachedWoodRingFrontTexture != null)
      return cachedWoodRingFrontTexture;

    // Do not bake dimensions into the renderer. The original native source is
    // used 1:1. Accept WoodRing_Front..., Wood_Ring_Front..., or equivalent.
    string[] guids = AssetDatabase.FindAssets(
        "t:Texture2D",
        new[] { OrnamentArtFolder });

    Texture2D fallback = null;
    for (int i = 0; i < guids.Length; i++)
    {
      string path = AssetDatabase.GUIDToAssetPath(guids[i]);
      string lower = path.ToLowerInvariant();
      bool isWoodRing =
          lower.Contains("woodring")
          || (lower.Contains("wood") && lower.Contains("ring"));
      if (!isWoodRing)
        continue;

      Texture2D candidate = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
      if (candidate == null)
        continue;

      if (lower.Contains("front"))
      {
        cachedWoodRingFrontTexture = candidate;
        return candidate;
      }

      if (fallback == null && !lower.Contains("side"))
        fallback = candidate;
    }

    cachedWoodRingFrontTexture = fallback;
    return fallback;
  }

  private Texture2D GetWoodRingSideTexture()
  {
    if (cachedWoodRingSideTexture != null)
      return cachedWoodRingSideTexture;

    string[] guids = AssetDatabase.FindAssets(
        "t:Texture2D",
        new[] { OrnamentArtFolder });

    Texture2D fallback = null;
    for (int i = 0; i < guids.Length; i++)
    {
      string path = AssetDatabase.GUIDToAssetPath(guids[i]);
      string lower = path.ToLowerInvariant();
      bool isWoodRing =
          lower.Contains("woodring")
          || (lower.Contains("wood") && lower.Contains("ring"));
      if (!isWoodRing || !lower.Contains("side"))
        continue;

      Texture2D candidate = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
      if (candidate == null)
        continue;

      if (candidate.width == 14 && candidate.height == 19)
      {
        cachedWoodRingSideTexture = candidate;
        return candidate;
      }

      if (fallback == null)
        fallback = candidate;
    }

    cachedWoodRingSideTexture = fallback;
    return fallback;
  }

  private Texture2D GetWoodRingSide2Texture()
  {
    if (cachedWoodRingSide2Texture != null)
      return cachedWoodRingSide2Texture;

    // The F1 side extract is two pixels wide at the top, so a shrink cannot
    // rebuild the square top the original draws at (4,6) North. This 5x10
    // is that original result, at screen top-left (66, 73).
    Texture2D texture = AssetDatabase.LoadAssetAtPath<Texture2D>(
        "Assets/Art/Ornaments/Wood_Ring_Side2_5x10.png");
    if (texture != null && texture.width == 5 && texture.height == 10)
    {
      cachedWoodRingSide2Texture = texture;
      return texture;
    }

    return null;
  }

  private Texture2D GetWoodRingSide3Texture()
  {
    if (cachedWoodRingSide3Texture != null)
      return cachedWoodRingSide3Texture;

    // As with Side2, the distant Wood Ring side view is original authored
    // distance artwork. Shrinking the F1 side extract cannot reproduce the
    // exact 3x5 shape seen at (4,7) North.
    Texture2D texture = AssetDatabase.LoadAssetAtPath<Texture2D>(
        "Assets/Art/Ornaments/Wood_Ring_Side3_3x5.png");
    if (texture != null && texture.width == 3 && texture.height == 5)
    {
      cachedWoodRingSide3Texture = texture;
      return texture;
    }

    return null;
  }

  /// <summary>
  /// Loads resolved Level 0 wall/floor ornaments from the generated all-level
  /// placement database. This is the authoritative path when the database is
  /// present; the old Hall-specific derivation remains only as fallback.
  /// </summary>
  private bool LoadPreviewFeaturesFromDatabase()
  {
    if (!File.Exists(DungeonFeaturePlacementsPath))
      return false;

    try
    {
      DungeonFeaturePlacementDatabase database =
          DungeonFeaturePlacementDatabase.LoadFromFile(
              DungeonFeaturePlacementsPath);
      if (database == null || database.ornamentPlacements == null)
        return false;

      List<WallOrnamentPlacement> wallOrnaments =
          new List<WallOrnamentPlacement>();
      previewPuddleFloors.Clear();

      for (int i = 0; i < database.ornamentPlacements.Length; i++)
      {
        DungeonOrnamentPlacement placement =
            database.ornamentPlacements[i];
        if (placement == null
            || placement.level != previewDungeonLevel
            || placement.resolved == null
            || string.IsNullOrEmpty(placement.resolved.type))
        {
          continue;
        }

        if (string.Equals(
                placement.domain,
                "Floor",
                System.StringComparison.OrdinalIgnoreCase))
        {
          if (string.Equals(
                  placement.resolved.type,
                  "Puddle",
                  System.StringComparison.OrdinalIgnoreCase))
          {
            previewPuddleFloors.Add(
                PackPreviewTile(
                    placement.normalisedX,
                    placement.normalisedY));
          }
          continue;
        }

        if (!string.Equals(
                placement.domain,
                "Wall",
                System.StringComparison.OrdinalIgnoreCase))
        {
          continue;
        }

        string wallName = NormaliseFeatureFaceName(
            placement.normalisedFace);
        if (string.IsNullOrEmpty(wallName))
          continue;

        wallOrnaments.Add(
            new WallOrnamentPlacement
            {
              type = NormaliseFeatureTypeName(placement.resolved.type),
              ornamentOrdinal = placement.ornamentOrdinal,
              x = placement.normalisedX,
              y = placement.normalisedY,
              wall = wallName,
              wallTilePlacement = true
            });
      }

      previewWallOrnaments = wallOrnaments.ToArray();
      return true;
    }
    catch (System.Exception ex)
    {
      Debug.LogWarning(
          "ViewEdit feature database load failed; using Hall fallback: "
          + ex.Message);
      return false;
    }
  }

  private static string NormaliseFeatureTypeName(string type)
  {
    if (string.Equals(
            type,
            "WallGrate",
            System.StringComparison.OrdinalIgnoreCase))
      return "Grate";

    // The placement database uses AltarOfVi, while the live altar renderers
    // use ViAltar as their canonical type name. Normalise the database name
    // here so D1/D2/D3 all see the same type.
    if (string.Equals(
            type,
            "AltarOfVi",
            System.StringComparison.OrdinalIgnoreCase))
      return "ViAltar";

    return type;
  }

  private static string NormaliseFeatureFaceName(string face)
  {
    if (string.IsNullOrEmpty(face))
      return null;

    switch (char.ToUpperInvariant(face[0]))
    {
      case 'N': return "North";
      case 'E': return "East";
      case 'S': return "South";
      case 'W': return "West";
      default: return null;
    }
  }

  private void LoadPreviewPuddleFloors()
  {
    previewPuddleFloors.Clear();
    if (previewMiniMap == null)
      return;

    // Original engine corridor rule:
    // randomIndex = Hash(2000 + x*32 + y,
    //                    3000 + level*64 + width + height, 30).
    // If randomIndex < RandomFloorOrnamentCount, ordinal = index + 1.
    // Hall of Champions local floor-ornament ordinal 2 is Puddle.
    int value2 = 3000 + previewMiniMap.Width + previewMiniMap.Height;

    for (int y = 0; y < previewMiniMap.Height; y++)
    {
      for (int x = 0; x < previewMiniMap.Width; x++)
      {
        DungeonTile tile = previewMiniMap.GetTile(x, y);
        if (tile == null
            || tile.SourceType != DungeonSourceTileType.Floor
            || (tile.Raw & 0x08) == 0)
        {
          continue;
        }

        int randomIndex = HallOfChampionsRandomOrnamentHash(
            2000 + (x << 5) + y,
            value2,
            HallOfChampionsRandomOrnamentModulo);
        if (randomIndex >= HallOfChampionsRandomFloorOrnamentCount)
          continue;

        int ordinal = randomIndex + 1;
        if (ordinal == HallOfChampionsPuddleFloorOrnamentOrdinal)
          previewPuddleFloors.Add(PackPreviewTile(x, y));
      }
    }
  }

  private static int PackPreviewTile(int x, int y)
  {
    return (y << 8) | (x & 0xFF);
  }

  private bool IsPreviewPuddleFloor(int x, int y)
  {
    return previewPuddleFloors.Contains(PackPreviewTile(x, y))
        && IsPreviewFeatureEnabled(MakePreviewFeatureKey("Puddle", x, y, null));
  }


  private void ResetStairsDownF1PreviewControls()
  {
    // Match wall preview behavior: edits in ViewEdit are temporary for the
    // current pose only. Leaving the pose restores the code-assigned defaults.
    stairsDownF1PreviewEnabled = true;
    stairsDownF1PreviewX = StairsDownF1X;
    stairsDownF1PreviewDisplayY = StairsDownF1DisplayY;
    championMirrorD0RightPreviewX = ChampionMirrorD0RightX;
    championMirrorD0RightPreviewVisibleWidth = 7;
    championMirrorD0RightPreviewMirror = false;
    previewDisabledFeatureKeys.Clear();
    previewFeaturePositionOverrides.Clear();
    previewFeatureMirrorOverrides.Clear();
  }

  private bool IsStairsDownF1NeededForCurrentPose()
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null)
      return false;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    int stairsX = previewX + forwardX;
    int stairsY = previewY + forwardY;

    return previewMiniMap.IsInside(stairsX, stairsY)
        && previewMiniMap.GetTile(stairsX, stairsY)
            .TryGetStairsDirection(out bool stairsUp)
        && !stairsUp
        && IsPreviewFeatureEnabled(
            MakePreviewFeatureKey("StairsDown", stairsX, stairsY, null));
  }

  /// <summary>
  /// True when a down-stairs tile is immediately to the player's right.
  /// This is geometry-relative and contains no map-coordinate special case.
  /// </summary>
  private bool IsStairsDownRightD1ForCurrentPose()
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null)
      return false;

    // Generic viewport-relative geometry:
    // lane +1, depth 1 = one step forward and one step to the right.
    // The Hall 4,16 West reference resolves through this rule naturally;
    // there is no map-coordinate exception here.
    Viewport17Cell stairsCell = SampleViewport17Cell(1, 1);
    return stairsCell.IsInside && stairsCell.IsStairsDown;
  }

  /// <summary>
  /// Replace the RightF0 screen slot with the exact original down-stairs
  /// D1-right wall projection. The asset already contains the original
  /// depth/palette pixels and is therefore blitted 1:1 with no scaling or
  /// colour conversion.
  /// </summary>
  private void BlitStairsDownRightD1IntoPreview(Color32[] pixels)
  {
    if (pixels == null)
      return;

    if (!IsStairsDownRightD1ForCurrentPose())
      return;

    // Exact project asset path. Do not use a filename search here; this
    // reference crop is intentionally tied to the Stairs folder.
    Texture2D stairsWall = AssetDatabase.LoadAssetAtPath<Texture2D>(
        "Assets/Art/Walls/Stairs/Stairs_Down_Front_D1_32x91.png");

    if (stairsWall == null)
    {
      Debug.LogWarning(
          "STAIRS RIGHT D1: Stairs_Down_Front_D1_32x91.png was not found.");
      return;
    }

    if (stairsWall.width != 32 || stairsWall.height != 91)
    {
      Debug.LogWarning(
          "STAIRS RIGHT D1: asset loaded but imported size is "
          + stairsWall.width + "x" + stairsWall.height
          + " (expected 32x91).");
      return;
    }

    if (!stairsWall.isReadable)
    {
      string stairsPath = AssetDatabase.GetAssetPath(stairsWall);
      TextureImporter importer = AssetImporter.GetAtPath(stairsPath) as TextureImporter;
      if (importer != null)
      {
        importer.isReadable = true;
        importer.mipmapEnabled = false;
        importer.filterMode = FilterMode.Point;
        importer.SaveAndReimport();
        stairsWall = AssetDatabase.LoadAssetAtPath<Texture2D>(stairsPath);
      }
    }

    if (stairsWall == null || !stairsWall.isReadable)
    {
      Debug.LogWarning(
          "STAIRS RIGHT D1: asset is still not readable after importer refresh.");
      return;
    }

    // IMPORTANT: this exact reference crop is positioned in the native
    // 224x136 dungeon viewport. Do not convert its Y against the 320x200
    // output buffer; that places it 64 pixels too high.
    int destinationY = StairsDownRightD1FramebufferY;

    BlitPieceIntoPreview(
        pixels,
        stairsWall,
        StairsDownRightD1X,
        destinationY,
        false);
  }

  private static string MakePreviewFeatureKey(
      string family,
      int mapX,
      int mapY,
      string wall)
  {
    return (family ?? string.Empty)
        + ":" + mapX
        + ":" + mapY
        + ":" + (wall ?? string.Empty);
  }

  private bool IsPreviewFeatureEnabled(string key)
  {
    return string.IsNullOrEmpty(key)
        || !previewDisabledFeatureKeys.Contains(key);
  }

  private void SetPreviewFeatureEnabled(string key, bool enabled)
  {
    if (string.IsNullOrEmpty(key))
      return;

    if (enabled)
      previewDisabledFeatureKeys.Remove(key);
    else
      previewDisabledFeatureKeys.Add(key);
  }

  private void ApplyPreviewFeatureRenderOverrides(
      string key,
      ref int x,
      ref int y,
      ref bool mirror)
  {
    if (string.IsNullOrEmpty(key))
      return;

    if (previewFeaturePositionOverrides.TryGetValue(key, out Vector2Int pos))
    {
      x = pos.x;
      y = pos.y;
    }

    if (previewFeatureMirrorOverrides.TryGetValue(key, out bool mirrorOverride))
      mirror = mirrorOverride;
  }

  private bool TryGetChampionMirrorViewProjection(
      ChampionMirrorPlacement mirror,
      out int renderX,
      out int renderY,
      out bool renderMirror)
  {
    renderX = 0;
    renderY = 0;
    renderMirror = false;

    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || mirror == null
        || string.IsNullOrEmpty(mirror.wall))
    {
      return false;
    }

    DungeonMap.GetForwardOffset(previewFacing, out int forwardX, out int forwardY);
    DungeonMap.GetRightOffset(previewFacing, out int rightX, out int rightY);

    string frontWallSide = FacingName(OppositePreviewFacing(previewFacing));
    string leftWallSide = FacingName(TurnPreviewFacingRight(previewFacing));
    string rightWallSide = FacingName(TurnPreviewFacingLeft(previewFacing));
    string parallelWallSide = FacingName(previewFacing);

    int d1CenterX = previewX + forwardX;
    int d1CenterY = previewY + forwardY;
    int d2CenterX = previewX + forwardX * 2;
    int d2CenterY = previewY + forwardY * 2;
    int d3CenterX = previewX + forwardX * 3;
    int d3CenterY = previewY + forwardY * 3;

    // F0-right glimpse.
    int f0RightX = previewX + rightX;
    int f0RightY = previewY + rightY;
    if (mirror.x == f0RightX
        && mirror.y == f0RightY
        && string.Equals(mirror.wall, parallelWallSide, System.StringComparison.OrdinalIgnoreCase)
        && PreviewTileIsWall(f0RightX, f0RightY))
    {
      renderX = championMirrorD0RightPreviewX;
      renderY = ChampionMirrorD0RightY;
      renderMirror = championMirrorD0RightPreviewMirror;
      return true;
    }

    // D1 front.
    if (mirror.x == d1CenterX
        && mirror.y == d1CenterY
        && string.Equals(mirror.wall, frontWallSide, System.StringComparison.OrdinalIgnoreCase)
        && PreviewTileIsWall(d1CenterX, d1CenterY))
    {
      renderX = ChampionMirrorD1FrontX;
      renderY = ChampionMirrorD1FrontY;
      renderMirror = false;
      return true;
    }

    // D1 side frames require an open D1 center.
    if (PreviewTileIsOpen(d1CenterX, d1CenterY))
    {
      int d1LeftX = d1CenterX - rightX;
      int d1LeftY = d1CenterY - rightY;
      if (mirror.x == d1LeftX
          && mirror.y == d1LeftY
          && string.Equals(mirror.wall, leftWallSide, System.StringComparison.OrdinalIgnoreCase))
      {
        renderX = ChampionMirrorD1LeftX;
        renderY = ChampionMirrorD1Y;
        renderMirror = false;
        return true;
      }

      int d1RightX = d1CenterX + rightX;
      int d1RightY = d1CenterY + rightY;
      if (mirror.x == d1RightX
          && mirror.y == d1RightY
          && string.Equals(mirror.wall, rightWallSide, System.StringComparison.OrdinalIgnoreCase))
      {
        renderX = ChampionMirrorD1RightX;
        renderY = ChampionMirrorD1Y;
        renderMirror = true;
        return true;
      }
    }

    // D2 front lanes use an open D1 center, and lateral lanes also need the
    // corresponding D1 side lane open.
    if (PreviewTileIsOpen(d1CenterX, d1CenterY))
    {
      for (int lane = -1; lane <= 1; lane++)
      {
        if (lane != 0)
        {
          int d1LaneX = d1CenterX + rightX * lane;
          int d1LaneY = d1CenterY + rightY * lane;
          if (!PreviewTileIsOpen(d1LaneX, d1LaneY))
            continue;
        }

        int d2X = d2CenterX + rightX * lane;
        int d2Y = d2CenterY + rightY * lane;
        if (mirror.x == d2X
            && mirror.y == d2Y
            && string.Equals(mirror.wall, frontWallSide, System.StringComparison.OrdinalIgnoreCase)
            && PreviewTileIsWall(d2X, d2Y))
        {
          renderX = lane < 0
              ? ChampionMirrorD2FrontLeftX
              : lane > 0
                  ? ChampionMirrorD2FrontRightX
                  : ChampionMirrorD2FrontX;
          renderY = ChampionMirrorFrontWallOrnamentSet.f2.y;
          renderMirror = false;
          return true;
        }
      }
    }

    // D2 side mirrors require the center sight line to stay open through D2.
    if (PreviewTileIsOpen(d1CenterX, d1CenterY)
        && PreviewTileIsOpen(d2CenterX, d2CenterY))
    {
      int d2LeftX = d2CenterX - rightX;
      int d2LeftY = d2CenterY - rightY;
      if (mirror.x == d2LeftX
          && mirror.y == d2LeftY
          && string.Equals(mirror.wall, leftWallSide, System.StringComparison.OrdinalIgnoreCase))
      {
        renderX = ChampionMirrorD2LeftX;
        renderY = ChampionMirrorD2SideY;
        renderMirror = false;
        return true;
      }

      int d2RightX = d2CenterX + rightX;
      int d2RightY = d2CenterY + rightY;
      if (mirror.x == d2RightX
          && mirror.y == d2RightY
          && string.Equals(mirror.wall, rightWallSide, System.StringComparison.OrdinalIgnoreCase))
      {
        renderX = ChampionMirrorD2RightX;
        renderY = ChampionMirrorD2SideY;
        renderMirror = true;
        return true;
      }
    }

    // D3 front center.
    if (mirror.x == d3CenterX
        && mirror.y == d3CenterY
        && string.Equals(mirror.wall, frontWallSide, System.StringComparison.OrdinalIgnoreCase))
    {
      renderX = ChampionMirrorD3FrontX;
      renderY = ChampionMirrorD3FrontY;
      renderMirror = false;
      return true;
    }

    if (PreviewTileIsOpen(d1CenterX, d1CenterY)
        && PreviewTileIsOpen(d2CenterX, d2CenterY)
        && PreviewTileIsOpen(d3CenterX, d3CenterY))
    {
      int d3LeftX = d3CenterX - rightX;
      int d3LeftY = d3CenterY - rightY;
      if (mirror.x == d3LeftX
          && mirror.y == d3LeftY
          && string.Equals(mirror.wall, leftWallSide, System.StringComparison.OrdinalIgnoreCase)
          && PreviewTileIsWall(d3LeftX, d3LeftY))
      {
        renderX = ChampionMirrorD3LeftX;
        renderY = ChampionMirrorD3LeftY;
        renderMirror = false;
        return true;
      }

      int d3RightX = d3CenterX + rightX;
      int d3RightY = d3CenterY + rightY;
      if (mirror.x == d3RightX
          && mirror.y == d3RightY
          && string.Equals(mirror.wall, rightWallSide, System.StringComparison.OrdinalIgnoreCase)
          && PreviewTileIsWall(d3RightX, d3RightY))
      {
        renderX = ChampionMirrorD3RightF3X;
        renderY = ChampionMirrorD3RightF3Y;
        renderMirror = true;
        return true;
      }
    }

    // D3 second side lane / oblique projections.
    int d1LeftOpenX = d1CenterX - rightX;
    int d1LeftOpenY = d1CenterY - rightY;
    int d2LeftOpenX = d2CenterX - rightX;
    int d2LeftOpenY = d2CenterY - rightY;
    int d3LeftOpenX = d3CenterX - rightX;
    int d3LeftOpenY = d3CenterY - rightY;
    int d3L2X = d3CenterX - rightX * 2;
    int d3L2Y = d3CenterY - rightY * 2;
    if (PreviewTileIsOpen(d1CenterX, d1CenterY)
        && PreviewTileIsOpen(d1LeftOpenX, d1LeftOpenY)
        && PreviewTileIsOpen(d2LeftOpenX, d2LeftOpenY)
        && PreviewTileIsOpen(d3LeftOpenX, d3LeftOpenY)
        && PreviewTileIsWall(d3L2X, d3L2Y)
        && mirror.x == d3L2X
        && mirror.y == d3L2Y
        && string.Equals(mirror.wall, leftWallSide, System.StringComparison.OrdinalIgnoreCase))
    {
      renderX = ChampionMirrorD3LeftL2X;
      renderY = ChampionMirrorD3LeftL2Y;
      renderMirror = false;
      return true;
    }

    int d1RightOpenX = d1CenterX + rightX;
    int d1RightOpenY = d1CenterY + rightY;
    int d2RightOpenX = d2CenterX + rightX;
    int d2RightOpenY = d2CenterY + rightY;
    int d3RightOpenX = d3CenterX + rightX;
    int d3RightOpenY = d3CenterY + rightY;
    int d3R2X = d3CenterX + rightX * 2;
    int d3R2Y = d3CenterY + rightY * 2;
    if (PreviewTileIsOpen(d1CenterX, d1CenterY)
        && PreviewTileIsOpen(d1RightOpenX, d1RightOpenY)
        && PreviewTileIsOpen(d2RightOpenX, d2RightOpenY)
        && PreviewTileIsOpen(d3RightOpenX, d3RightOpenY)
        && PreviewTileIsWall(d3R2X, d3R2Y)
        && mirror.x == d3R2X
        && mirror.y == d3R2Y
        && string.Equals(mirror.wall, rightWallSide, System.StringComparison.OrdinalIgnoreCase))
    {
      renderX = ChampionMirrorD3RightX;
      renderY = ChampionMirrorD3RightY;
      renderMirror = true;
      return true;
    }

    return false;
  }

  private bool TryGetGrateViewProjection(
      WallOrnamentPlacement ornament,
      out string projectionName,
      out bool renderMirror)
  {
    projectionName = null;
    renderMirror = false;
    if (!IsGrateOrnament(ornament) || previewMiniMap == null)
      return false;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    string viewedWallSide = FacingName(previewFacing);
    string visiblePhysicalWallFace = OppositeFacingName(previewFacing);

    // Front F1.
    int d1X = previewX + forwardX;
    int d1Y = previewY + forwardY;
    if (previewMiniMap.IsInside(d1X, d1Y)
        && previewMiniMap.GetTile(d1X, d1Y).Type == DungeonTileType.Wall)
    {
      bool match = ornament.wallTilePlacement
          ? ornament.x == d1X
              && ornament.y == d1Y
              && string.Equals(
                  ornament.wall,
                  visiblePhysicalWallFace,
                  System.StringComparison.OrdinalIgnoreCase)
          : ornament.x == previewX
              && ornament.y == previewY
              && string.Equals(
                  ornament.wall,
                  viewedWallSide,
                  System.StringComparison.OrdinalIgnoreCase);
      if (match)
      {
        projectionName = "Grate - Front F1";
        renderMirror = false;
        return true;
      }
    }

    // Front F2.
    int d2X = previewX + forwardX * 2;
    int d2Y = previewY + forwardY * 2;
    if (previewMiniMap.IsInside(d1X, d1Y)
        && previewMiniMap.GetTile(d1X, d1Y).Type != DungeonTileType.Wall
        && previewMiniMap.IsInside(d2X, d2Y)
        && previewMiniMap.GetTile(d2X, d2Y).Type == DungeonTileType.Wall)
    {
      bool match = ornament.wallTilePlacement
          ? ornament.x == d2X
              && ornament.y == d2Y
              && string.Equals(
                  ornament.wall,
                  visiblePhysicalWallFace,
                  System.StringComparison.OrdinalIgnoreCase)
          : ornament.x == d1X
              && ornament.y == d1Y
              && string.Equals(
                  ornament.wall,
                  viewedWallSide,
                  System.StringComparison.OrdinalIgnoreCase);
      if (match)
      {
        projectionName = "Grate - Front F2";
        renderMirror = false;
        return true;
      }
    }

    // Front F3.
    int d3X = previewX + forwardX * 3;
    int d3Y = previewY + forwardY * 3;
    if (previewMiniMap.IsInside(d1X, d1Y)
        && previewMiniMap.GetTile(d1X, d1Y).Type != DungeonTileType.Wall
        && previewMiniMap.IsInside(d2X, d2Y)
        && previewMiniMap.GetTile(d2X, d2Y).Type != DungeonTileType.Wall
        && previewMiniMap.IsInside(d3X, d3Y)
        && previewMiniMap.GetTile(d3X, d3Y).Type == DungeonTileType.Wall)
    {
      bool match = ornament.wallTilePlacement
          ? ornament.x == d3X
              && ornament.y == d3Y
              && string.Equals(
                  ornament.wall,
                  visiblePhysicalWallFace,
                  System.StringComparison.OrdinalIgnoreCase)
          : ornament.x == d2X
              && ornament.y == d2Y
              && string.Equals(
                  ornament.wall,
                  viewedWallSide,
                  System.StringComparison.OrdinalIgnoreCase);
      if (match)
      {
        projectionName = "Grate - Front F3";
        renderMirror = false;
        return true;
      }
    }

    string leftPhysicalFace =
        FacingName(TurnPreviewFacingRight(previewFacing));
    string rightPhysicalFace =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string leftBoundaryDirection =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string rightBoundaryDirection =
        FacingName(TurnPreviewFacingRight(previewFacing));

    // Side projections at D1..D3. These intentionally use the same geometry
    // tests as the grate renderer so ViewEdit lists only an image that can
    // actually be drawn in the current pose.
    for (int depth = 1; depth <= 3; depth++)
    {
      bool corridorOpen = true;
      for (int step = 1; step <= depth; step++)
      {
        int cx = previewX + forwardX * step;
        int cy = previewY + forwardY * step;
        if (!previewMiniMap.IsInside(cx, cy)
            || previewMiniMap.GetTile(cx, cy).Type == DungeonTileType.Wall)
        {
          corridorOpen = false;
          break;
        }
      }
      if (!corridorOpen)
        continue;

      int centerX = previewX + forwardX * depth;
      int centerY = previewY + forwardY * depth;
      int leftWallX = centerX - rightX;
      int leftWallY = centerY - rightY;
      int rightWallX = centerX + rightX;
      int rightWallY = centerY + rightY;

      bool leftWallExists =
          previewMiniMap.IsInside(leftWallX, leftWallY)
          && previewMiniMap.GetTile(leftWallX, leftWallY).Type
              == DungeonTileType.Wall;
      bool rightWallExists =
          previewMiniMap.IsInside(rightWallX, rightWallY)
          && previewMiniMap.GetTile(rightWallX, rightWallY).Type
              == DungeonTileType.Wall;

      bool matchesLeft = ornament.wallTilePlacement
          ? leftWallExists
              && ornament.x == leftWallX
              && ornament.y == leftWallY
              && string.Equals(
                  ornament.wall,
                  leftPhysicalFace,
                  System.StringComparison.OrdinalIgnoreCase)
          : leftWallExists
              && ornament.x == centerX
              && ornament.y == centerY
              && string.Equals(
                  ornament.wall,
                  leftBoundaryDirection,
                  System.StringComparison.OrdinalIgnoreCase);

      if (matchesLeft)
      {
        projectionName = "Grate - Side" + depth;
        renderMirror = false;
        return true;
      }

      bool matchesRight = ornament.wallTilePlacement
          ? rightWallExists
              && ornament.x == rightWallX
              && ornament.y == rightWallY
              && string.Equals(
                  ornament.wall,
                  rightPhysicalFace,
                  System.StringComparison.OrdinalIgnoreCase)
          : rightWallExists
              && ornament.x == centerX
              && ornament.y == centerY
              && string.Equals(
                  ornament.wall,
                  rightBoundaryDirection,
                  System.StringComparison.OrdinalIgnoreCase);

      if (matchesRight)
      {
        projectionName = "Grate - Side" + depth;
        renderMirror = true;
        return true;
      }
    }

    return false;
  }

  private bool DrawGrateFeatureRow(WallOrnamentPlacement ornament)
  {
    if (!TryGetGrateViewProjection(
            ornament, out string projectionName, out bool defaultMirror))
    {
      return false;
    }

    string key = MakePreviewFeatureKey(
        "Ornament", ornament.x, ornament.y, ornament.wall);
    bool mirrorValue = defaultMirror;
    if (previewFeatureMirrorOverrides.TryGetValue(key, out bool mirrorOverride))
      mirrorValue = mirrorOverride;

    string name = projectionName + " (" + FacingName(previewFacing) + ")";

    EditorGUILayout.BeginHorizontal();

    float savedLabelWidth = EditorGUIUtility.labelWidth;
    EditorGUIUtility.labelWidth =
        EditorStyles.label.CalcSize(new GUIContent("X")).x;
    using (new EditorGUI.DisabledScope(true))
    {
      EditorGUILayout.IntField("X", previewX, GUILayout.Width(48f));
      EditorGUIUtility.labelWidth =
          EditorStyles.label.CalcSize(new GUIContent("Y")).x;
      EditorGUILayout.IntField("Y", previewY, GUILayout.Width(48f));
    }
    EditorGUIUtility.labelWidth = savedLabelWidth;

    GUIStyle featureStyle = new GUIStyle(EditorStyles.boldLabel);
    Color labelColor = new Color(1f, 0.65f, 0.1f);
    featureStyle.normal.textColor = labelColor;
    featureStyle.hover.textColor = labelColor;
    featureStyle.focused.textColor = labelColor;
    const float FeatureDescriptionWidth = 210f;
    GUILayout.Label(name, featureStyle, GUILayout.Width(FeatureDescriptionWidth));

    bool enabledBefore = IsPreviewFeatureEnabled(key);
    bool enabledAfter = DrawCompactMouseOnlyToggle(
        "Enabled", enabledBefore, false);
    bool mirrorAfter = DrawCompactMouseOnlyToggle(
        "Mirror", mirrorValue, true);

    EditorGUILayout.EndHorizontal();

    bool changed = false;
    if (mirrorAfter != mirrorValue)
    {
      if (mirrorAfter == defaultMirror)
        previewFeatureMirrorOverrides.Remove(key);
      else
        previewFeatureMirrorOverrides[key] = mirrorAfter;
      previewMirrorChangedThisFrame = true;
      changed = true;
    }

    if (enabledAfter != enabledBefore)
    {
      SetPreviewFeatureEnabled(key, enabledAfter);
      previewEnabledChangedThisFrame = true;
      changed = true;
    }

    if (changed)
    {
      RefreshEditModePreview();
      RepaintGameViews();
      Repaint();
    }

    return true;
  }

  private void DrawReadOnlyFeatureMapFields(int mapX, int mapY)
  {
    // Same minimum width as loose floor items. This left-aligns the feature
    // descriptions and the Enabled column across Champion Mirror, Wood Ring,
    // Slime, and the other ornament rows.
    EditorGUIUtility.labelWidth =
        EditorStyles.label.CalcSize(new GUIContent("X")).x;
    using (new EditorGUI.DisabledScope(true))
    {
      EditorGUILayout.IntField(
          "X", mapX, GUILayout.Width(FloorItemMapCoordFieldWidth));
      EditorGUIUtility.labelWidth =
          EditorStyles.label.CalcSize(new GUIContent("Y")).x;
      EditorGUILayout.IntField(
          "Y", mapY, GUILayout.Width(FloorItemMapCoordFieldWidth));
    }
  }

  private bool DrawFeatureEnabledToggle(bool enabledBefore)
  {
    const string EnabledLabel = "Enabled";
    const float ToggleBoxWidth = 18f;
    float enabledLabelWidth =
        EditorStyles.label.CalcSize(new GUIContent(EnabledLabel)).x;
    EditorGUIUtility.labelWidth = enabledLabelWidth;

    bool enabledAfter = DrawMouseOnlyToggle(
        EnabledLabel,
        enabledBefore,
        enabledBefore,
        GUILayout.Width(enabledLabelWidth + ToggleBoxWidth),
        GUILayout.ExpandWidth(false));
    NoteContentRight();
    return enabledAfter;
  }

  private bool DrawChampionMirrorFeatureRow(ChampionMirrorPlacement mirror)
  {
    if (!TryGetChampionMirrorViewProjection(
            mirror, out int defaultX, out int defaultY, out bool defaultMirror))
    {
      return false;
    }

    string key = MakePreviewFeatureKey(
        "ChampionMirror", mirror.x, mirror.y, mirror.wall);
    int x = defaultX;
    int y = defaultY;
    bool mirrorValue = defaultMirror;
    ApplyPreviewFeatureRenderOverrides(key, ref x, ref y, ref mirrorValue);

    string name = string.IsNullOrEmpty(mirror.champion)
        ? "ChampMirror"
        : "ChampMirror - " + mirror.champion;
    if (!string.IsNullOrEmpty(mirror.wall))
      name += " (" + mirror.wall + ")";

    EditorGUILayout.BeginHorizontal();

    float savedLabelWidth = EditorGUIUtility.labelWidth;
    DrawReadOnlyFeatureMapFields(mirror.x, mirror.y);

    GUIStyle featureStyle = new GUIStyle(EditorStyles.boldLabel);
    Color labelColor = new Color(0.15f, 0.85f, 1f);
    featureStyle.normal.textColor = labelColor;
    featureStyle.hover.textColor = labelColor;
    featureStyle.focused.textColor = labelColor;
    GUILayout.Label(
        name,
        featureStyle,
        GUILayout.Width(FeatureDescriptionWidth));

    bool enabledBefore = IsPreviewFeatureEnabled(key);
    bool enabledAfter = DrawFeatureEnabledToggle(enabledBefore);

    // Champion mirrors additionally expose Mirror immediately after Enabled.
    const string MirrorLabel = "Mirror";
    float mirrorLabelWidth =
        EditorStyles.label.CalcSize(new GUIContent(MirrorLabel)).x;
    EditorGUIUtility.labelWidth = mirrorLabelWidth;
    const float ToggleBoxWidth = 18f;
    bool mirrorAfter = DrawMouseOnlyToggle(
        MirrorLabel,
        mirrorValue,
        enabledAfter,
        GUILayout.Width(mirrorLabelWidth + ToggleBoxWidth),
        GUILayout.ExpandWidth(false));
    NoteContentRight();

    EditorGUIUtility.labelWidth = savedLabelWidth;
    EditorGUILayout.EndHorizontal();

    bool changed = false;

    if (mirrorAfter != mirrorValue)
    {
      if (mirrorAfter == defaultMirror)
        previewFeatureMirrorOverrides.Remove(key);
      else
        previewFeatureMirrorOverrides[key] = mirrorAfter;
      previewMirrorChangedThisFrame = true;
      changed = true;
    }

    if (enabledAfter != enabledBefore)
    {
      SetPreviewFeatureEnabled(key, enabledAfter);
      previewEnabledChangedThisFrame = true;
      changed = true;
    }

    if (changed)
    {
      RefreshEditModePreview();
      RepaintGameViews();
      Repaint();
    }

    return true;
  }

  private bool IsMapCellInCurrentFeatureCone(int mapX, int mapY)
  {
    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    int dx = mapX - previewX;
    int dy = mapY - previewY;
    int depth = dx * forwardX + dy * forwardY;
    int lane = dx * rightX + dy * rightY;

    // ViewEdit's current wall renderer reaches through D3 and also uses the
    // immediate left/right F0 cells. Keep the feature checklist to that same
    // local neighbourhood; exact rendering/occlusion remains owned by each
    // feature renderer.
    if (depth < 0 || depth > 3)
      return false;

    int maxLane = depth == 0 ? 1 : depth;
    return Mathf.Abs(lane) <= Mathf.Max(1, maxLane);
  }

  private void DrawFeatureChecklistRow(
      int mapX,
      int mapY,
      string displayName,
      string key,
      Color labelColor)
  {
    EditorGUILayout.BeginHorizontal();

    float savedLabelWidth = EditorGUIUtility.labelWidth;
    DrawReadOnlyFeatureMapFields(mapX, mapY);

    GUIStyle featureStyle = new GUIStyle(EditorStyles.boldLabel);
    featureStyle.normal.textColor = labelColor;
    featureStyle.hover.textColor = labelColor;
    featureStyle.focused.textColor = labelColor;
    GUILayout.Label(
        displayName,
        featureStyle,
        GUILayout.Width(FeatureDescriptionWidth));

    bool enabledBefore = IsPreviewFeatureEnabled(key);
    bool enabledAfter = DrawFeatureEnabledToggle(enabledBefore);

    EditorGUIUtility.labelWidth = savedLabelWidth;
    EditorGUILayout.EndHorizontal();

    if (enabledAfter == enabledBefore)
      return;

    SetPreviewFeatureEnabled(key, enabledAfter);
    previewEnabledChangedThisFrame = true;
    RefreshEditModePreview();
    RepaintGameViews();
    Repaint();
  }

  private bool IsCurrentPoseF0RightChampionMirror(ChampionMirrorPlacement mirror)
  {
    if (mirror == null || string.IsNullOrEmpty(mirror.wall))
      return false;

    DungeonMap.GetRightOffset(previewFacing, out int rightX, out int rightY);
    int expectedX = previewX + rightX;
    int expectedY = previewY + rightY;
    return mirror.x == expectedX
        && mirror.y == expectedY
        && string.Equals(
            mirror.wall,
            FacingName(previewFacing),
            System.StringComparison.OrdinalIgnoreCase);
  }

  private void DrawChampionMirrorF0RightCalibrationRow(ChampionMirrorPlacement mirror)
  {
    if (!IsCurrentPoseF0RightChampionMirror(mirror))
      return;

    EditorGUILayout.BeginHorizontal();

    GUIStyle style = new GUIStyle(EditorStyles.boldLabel);
    style.normal.textColor = new Color(1f, 0.5f, 0.1f);
    GUILayout.Label("F0R Mirror Cal", style, GUILayout.Width(110f));

    int x = championMirrorD0RightPreviewX;
    bool xChanged = DrawIntStepperInline(
        "X", ref x, snap, x != ChampionMirrorD0RightX, true);

    int width = championMirrorD0RightPreviewVisibleWidth;
    bool widthChanged = DrawIntStepperInline(
        "W", ref width, 1, width != 7, true);
    width = Mathf.Clamp(width, 1, ChampionMirrorD3FrontWidth);

    GUILayout.Space(8f);
    bool mirrorBefore = championMirrorD0RightPreviewMirror;
    bool mirrorAfter = EditorGUILayout.ToggleLeft(
        "Mirror", mirrorBefore, GUILayout.Width(70f));

    EditorGUILayout.EndHorizontal();

    if (!xChanged && !widthChanged && mirrorAfter == mirrorBefore)
      return;

    championMirrorD0RightPreviewX = x;
    championMirrorD0RightPreviewVisibleWidth = width;
    championMirrorD0RightPreviewMirror = mirrorAfter;
    previewPositionChangedThisFrame = true;
    RefreshEditModePreview();
    RepaintGameViews();
    Repaint();
  }

  private bool IsViAltarOrnament(WallOrnamentPlacement ornament)
  {
    return ornament != null
        && (string.Equals(ornament.type, "ViAltar", System.StringComparison.OrdinalIgnoreCase)
            || string.Equals(ornament.type, "AltarOfVi", System.StringComparison.OrdinalIgnoreCase));
  }

  private bool TryGetViAltarS1Projection(
      WallOrnamentPlacement ornament,
      out int anchorX,
      out int anchorY,
      out string viewFacing,
      out bool defaultMirror)
  {
    anchorX = 0;
    anchorY = 0;
    viewFacing = null;
    defaultMirror = false;

    if (!IsViAltarOrnament(ornament) || previewMiniMap == null)
      return false;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    // S1 is the first side projection: one open tile directly ahead, with
    // the altar mounted on either side boundary of that forward tile.
    int centerX = previewX + forwardX;
    int centerY = previewY + forwardY;
    if (!previewMiniMap.IsInside(centerX, centerY)
        || previewMiniMap.GetTile(centerX, centerY).Type == DungeonTileType.Wall)
    {
      return false;
    }

    int leftWallX = centerX - rightX;
    int leftWallY = centerY - rightY;
    int rightWallX = centerX + rightX;
    int rightWallY = centerY + rightY;

    bool leftWallExists =
        previewMiniMap.IsInside(leftWallX, leftWallY)
        && previewMiniMap.GetTile(leftWallX, leftWallY).Type
            == DungeonTileType.Wall;
    bool rightWallExists =
        previewMiniMap.IsInside(rightWallX, rightWallY)
        && previewMiniMap.GetTile(rightWallX, rightWallY).Type
            == DungeonTileType.Wall;

    string leftPhysicalFace =
        FacingName(TurnPreviewFacingRight(previewFacing));
    string rightPhysicalFace =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string leftBoundaryDirection =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string rightBoundaryDirection =
        FacingName(TurnPreviewFacingRight(previewFacing));

    bool matchesLeft = ornament.wallTilePlacement
        ? leftWallExists
            && ornament.x == leftWallX
            && ornament.y == leftWallY
            && string.Equals(
                ornament.wall,
                leftPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase)
        : leftWallExists
            && ornament.x == centerX
            && ornament.y == centerY
            && string.Equals(
                ornament.wall,
                leftBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);

    if (matchesLeft)
    {
      anchorX = centerX;
      anchorY = centerY;
      viewFacing = FacingName(previewFacing);
      // Verified S1 orientation: opposite-side projection uses the stored S1 asset.
      defaultMirror = false;
      return true;
    }

    bool matchesRight = ornament.wallTilePlacement
        ? rightWallExists
            && ornament.x == rightWallX
            && ornament.y == rightWallY
            && string.Equals(
                ornament.wall,
                rightPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase)
        : rightWallExists
            && ornament.x == centerX
            && ornament.y == centerY
            && string.Equals(
                ornament.wall,
                rightBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);

    if (matchesRight)
    {
      anchorX = centerX;
      anchorY = centerY;
      viewFacing = FacingName(previewFacing);
      // Verified S1 reference: 3,17 East / altar 4,17 must render mirrored.
      defaultMirror = true;
      return true;
    }

    return false;
  }

  private bool TryGetViAltarS3Projection(
      WallOrnamentPlacement ornament,
      out int anchorX,
      out int anchorY,
      out string viewFacing,
      out bool defaultMirror)
  {
    anchorX = 0;
    anchorY = 0;
    viewFacing = null;
    defaultMirror = false;

    if (!IsViAltarOrnament(ornament) || previewMiniMap == null)
      return false;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    // S3 is the third side projection. All three center corridor tiles must
    // remain open before the side wall at distance three can be visible.
    for (int distance = 1; distance <= 3; distance++)
    {
      int openX = previewX + forwardX * distance;
      int openY = previewY + forwardY * distance;
      if (!previewMiniMap.IsInside(openX, openY)
          || previewMiniMap.GetTile(openX, openY).Type == DungeonTileType.Wall)
      {
        return false;
      }
    }

    int centerX = previewX + forwardX * 3;
    int centerY = previewY + forwardY * 3;
    int leftWallX = centerX - rightX;
    int leftWallY = centerY - rightY;
    int rightWallX = centerX + rightX;
    int rightWallY = centerY + rightY;

    bool leftWallExists =
        previewMiniMap.IsInside(leftWallX, leftWallY)
        && previewMiniMap.GetTile(leftWallX, leftWallY).Type
            == DungeonTileType.Wall;
    bool rightWallExists =
        previewMiniMap.IsInside(rightWallX, rightWallY)
        && previewMiniMap.GetTile(rightWallX, rightWallY).Type
            == DungeonTileType.Wall;

    string leftPhysicalFace =
        FacingName(TurnPreviewFacingRight(previewFacing));
    string rightPhysicalFace =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string leftBoundaryDirection =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string rightBoundaryDirection =
        FacingName(TurnPreviewFacingRight(previewFacing));

    bool matchesLeft = ornament.wallTilePlacement
        ? leftWallExists
            && ornament.x == leftWallX
            && ornament.y == leftWallY
            && string.Equals(
                ornament.wall,
                leftPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase)
        : leftWallExists
            && ornament.x == centerX
            && ornament.y == centerY
            && string.Equals(
                ornament.wall,
                leftBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);

    if (matchesLeft)
    {
      anchorX = centerX;
      anchorY = centerY;
      viewFacing = FacingName(previewFacing);
      defaultMirror = false;
      return true;
    }

    bool matchesRight = ornament.wallTilePlacement
        ? rightWallExists
            && ornament.x == rightWallX
            && ornament.y == rightWallY
            && string.Equals(
                ornament.wall,
                rightPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase)
        : rightWallExists
            && ornament.x == centerX
            && ornament.y == centerY
            && string.Equals(
                ornament.wall,
                rightBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);

    if (matchesRight)
    {
      anchorX = centerX;
      anchorY = centerY;
      viewFacing = FacingName(previewFacing);
      defaultMirror = true;
      return true;
    }

    return false;
  }

  private bool DrawViAltarS3CalibrationRow(WallOrnamentPlacement ornament)
  {
    if (!TryGetViAltarS3Projection(
            ornament,
            out int anchorX,
            out int anchorY,
            out string viewFacing,
            out bool defaultMirror))
    {
      return false;
    }

    string key = MakePreviewFeatureKey(
        "ViAltarS3V2", anchorX, anchorY, viewFacing);

    int x = ViAltarS3RightX;
    int y = ViAltarS3Y;
    bool mirror = defaultMirror;
    ApplyPreviewFeatureRenderOverrides(key, ref x, ref y, ref mirror);

    EditorGUILayout.BeginHorizontal();
    float savedLabelWidth = EditorGUIUtility.labelWidth;

    GUIStyle featureStyle = new GUIStyle(EditorStyles.boldLabel);
    Color labelColor = Color.yellow;
    featureStyle.normal.textColor = labelColor;
    featureStyle.hover.textColor = labelColor;
    featureStyle.focused.textColor = labelColor;
    string viAltarLabel =
        "ViAltar S3 " + anchorX + "," + anchorY + " " + viewFacing;
    float featureLabelWidth =
        featureStyle.CalcSize(new GUIContent(viAltarLabel)).x;
    GUILayout.Label(
        viAltarLabel,
        featureStyle,
        GUILayout.Width(featureLabelWidth));

    EditorGUIUtility.labelWidth =
        EditorStyles.label.CalcSize(new GUIContent("X")).x;
    int editX = x;
    bool xChanged = DrawIntStepperInline(
        "X", ref editX, snap, false, true, 24f, 24f);

    EditorGUIUtility.labelWidth =
        EditorStyles.label.CalcSize(new GUIContent("Y")).x;
    int editY = y;
    bool yChanged = DrawIntStepperInline(
        "Y", ref editY, snap, false, true, 24f, 24f);

    bool enabledBefore = IsPreviewFeatureEnabled(key);
    bool enabledAfter = DrawFeatureEnabledToggle(enabledBefore);

    const string MirrorLabel = "Mirror";
    const float ToggleBoxWidth = 18f;
    float mirrorLabelWidth =
        EditorStyles.label.CalcSize(new GUIContent(MirrorLabel)).x;
    EditorGUIUtility.labelWidth = mirrorLabelWidth;
    bool mirrorAfter = DrawMouseOnlyToggle(
        MirrorLabel,
        mirror,
        enabledAfter,
        GUILayout.Width(mirrorLabelWidth + ToggleBoxWidth),
        GUILayout.ExpandWidth(false));
    NoteContentRight();

    EditorGUIUtility.labelWidth = savedLabelWidth;
    EditorGUILayout.EndHorizontal();

    bool changed = false;
    if (xChanged && editX != x)
    {
      previewFeaturePositionOverrides[key] = new Vector2Int(editX, editY);
      previewPositionChangedThisFrame = true;
      changed = true;
    }

    if (yChanged && editY != y)
    {
      previewFeaturePositionOverrides[key] = new Vector2Int(editX, editY);
      previewPositionChangedThisFrame = true;
      changed = true;
    }

    if (mirrorAfter != mirror)
    {
      if (mirrorAfter == defaultMirror)
        previewFeatureMirrorOverrides.Remove(key);
      else
        previewFeatureMirrorOverrides[key] = mirrorAfter;
      previewMirrorChangedThisFrame = true;
      changed = true;
    }

    if (enabledAfter != enabledBefore)
    {
      SetPreviewFeatureEnabled(key, enabledAfter);
      previewEnabledChangedThisFrame = true;
      changed = true;
    }

    if (changed)
    {
      RefreshEditModePreview();
      RepaintGameViews();
      Repaint();
    }

    return true;
  }

  private bool TryGetViAltarS2Projection(
      WallOrnamentPlacement ornament,
      out int anchorX,
      out int anchorY,
      out string viewFacing,
      out bool defaultMirror)
  {
    anchorX = 0;
    anchorY = 0;
    viewFacing = null;
    defaultMirror = false;

    if (!IsViAltarOrnament(ornament) || previewMiniMap == null)
      return false;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    for (int distance = 1; distance <= 2; distance++)
    {
      int openX = previewX + forwardX * distance;
      int openY = previewY + forwardY * distance;
      if (!previewMiniMap.IsInside(openX, openY)
          || previewMiniMap.GetTile(openX, openY).Type == DungeonTileType.Wall)
      {
        return false;
      }
    }

    int centerX = previewX + forwardX * 2;
    int centerY = previewY + forwardY * 2;
    int leftWallX = centerX - rightX;
    int leftWallY = centerY - rightY;
    int rightWallX = centerX + rightX;
    int rightWallY = centerY + rightY;

    bool leftWallExists =
        previewMiniMap.IsInside(leftWallX, leftWallY)
        && previewMiniMap.GetTile(leftWallX, leftWallY).Type == DungeonTileType.Wall;
    bool rightWallExists =
        previewMiniMap.IsInside(rightWallX, rightWallY)
        && previewMiniMap.GetTile(rightWallX, rightWallY).Type == DungeonTileType.Wall;

    string leftPhysicalFace = FacingName(TurnPreviewFacingRight(previewFacing));
    string rightPhysicalFace = FacingName(TurnPreviewFacingLeft(previewFacing));
    string leftBoundaryDirection = FacingName(TurnPreviewFacingLeft(previewFacing));
    string rightBoundaryDirection = FacingName(TurnPreviewFacingRight(previewFacing));

    bool matchesLeft = ornament.wallTilePlacement
        ? leftWallExists
            && ornament.x == leftWallX
            && ornament.y == leftWallY
            && string.Equals(ornament.wall, leftPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase)
        : leftWallExists
            && ornament.x == centerX
            && ornament.y == centerY
            && string.Equals(ornament.wall, leftBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);

    if (matchesLeft)
    {
      anchorX = centerX;
      anchorY = centerY;
      viewFacing = FacingName(previewFacing);
      // Verified S2 reference orientation: at 2,17 facing East, the
      // Vi Altar at 4,17 is drawn exactly as stored (Mirror OFF).
      defaultMirror = false;
      return true;
    }

    bool matchesRight = ornament.wallTilePlacement
        ? rightWallExists
            && ornament.x == rightWallX
            && ornament.y == rightWallY
            && string.Equals(ornament.wall, rightPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase)
        : rightWallExists
            && ornament.x == centerX
            && ornament.y == centerY
            && string.Equals(ornament.wall, rightBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);

    if (matchesRight)
    {
      anchorX = centerX;
      anchorY = centerY;
      viewFacing = FacingName(previewFacing);
      // Opposite side uses the horizontally flipped S2 reference.
      defaultMirror = true;
      return true;
    }

    return false;
  }

  private bool DrawViAltarS2CalibrationRow(WallOrnamentPlacement ornament)
  {
    if (!TryGetViAltarS2Projection(
            ornament,
            out int anchorX,
            out int anchorY,
            out string viewFacing,
            out bool defaultMirror))
    {
      return false;
    }

    string key = MakePreviewFeatureKey(
        "ViAltarS2", anchorX, anchorY, viewFacing);

    int x = ViAltarS2RightX;
    int y = ViAltarS2Y;
    bool mirror = defaultMirror;
    ApplyPreviewFeatureRenderOverrides(key, ref x, ref y, ref mirror);

    EditorGUILayout.BeginHorizontal();
    float savedLabelWidth = EditorGUIUtility.labelWidth;

    GUIStyle featureStyle = new GUIStyle(EditorStyles.boldLabel);
    Color labelColor = Color.yellow;
    featureStyle.normal.textColor = labelColor;
    featureStyle.hover.textColor = labelColor;
    featureStyle.focused.textColor = labelColor;
    string viAltarLabel =
        "ViAltar S2 " + anchorX + "," + anchorY + " " + viewFacing;
    float featureLabelWidth =
        featureStyle.CalcSize(new GUIContent(viAltarLabel)).x;
    GUILayout.Label(
        viAltarLabel,
        featureStyle,
        GUILayout.Width(featureLabelWidth));

    EditorGUIUtility.labelWidth =
        EditorStyles.label.CalcSize(new GUIContent("X")).x;
    int editX = x;
    bool xChanged = DrawIntStepperInline(
        "X", ref editX, snap, false, true, 24f, 24f);

    EditorGUIUtility.labelWidth =
        EditorStyles.label.CalcSize(new GUIContent("Y")).x;
    int editY = y;
    bool yChanged = DrawIntStepperInline(
        "Y", ref editY, snap, false, true, 24f, 24f);

    bool enabledBefore = IsPreviewFeatureEnabled(key);
    bool enabledAfter = DrawFeatureEnabledToggle(enabledBefore);

    const string MirrorLabel = "Mirror";
    const float ToggleBoxWidth = 18f;
    float mirrorLabelWidth =
        EditorStyles.label.CalcSize(new GUIContent(MirrorLabel)).x;
    EditorGUIUtility.labelWidth = mirrorLabelWidth;
    bool mirrorAfter = DrawMouseOnlyToggle(
        MirrorLabel,
        mirror,
        enabledAfter,
        GUILayout.Width(mirrorLabelWidth + ToggleBoxWidth),
        GUILayout.ExpandWidth(false));
    NoteContentRight();

    EditorGUIUtility.labelWidth = savedLabelWidth;
    EditorGUILayout.EndHorizontal();

    bool changed = false;
    if (xChanged && editX != x)
    {
      previewFeaturePositionOverrides[key] = new Vector2Int(editX, editY);
      previewPositionChangedThisFrame = true;
      changed = true;
    }

    if (yChanged && editY != y)
    {
      previewFeaturePositionOverrides[key] = new Vector2Int(editX, editY);
      previewPositionChangedThisFrame = true;
      changed = true;
    }

    if (mirrorAfter != mirror)
    {
      if (mirrorAfter == defaultMirror)
        previewFeatureMirrorOverrides.Remove(key);
      else
        previewFeatureMirrorOverrides[key] = mirrorAfter;
      previewMirrorChangedThisFrame = true;
      changed = true;
    }

    if (enabledAfter != enabledBefore)
    {
      SetPreviewFeatureEnabled(key, enabledAfter);
      previewEnabledChangedThisFrame = true;
      changed = true;
    }

    if (changed)
    {
      RefreshEditModePreview();
      RepaintGameViews();
      Repaint();
    }

    return true;
  }

  private bool DrawViAltarS1CalibrationRow(WallOrnamentPlacement ornament)
  {
    if (!TryGetViAltarS1Projection(
            ornament,
            out int anchorX,
            out int anchorY,
            out string viewFacing,
            out bool defaultMirror))
    {
      return false;
    }

    string key = MakePreviewFeatureKey(
        "ViAltarS1", anchorX, anchorY, viewFacing);

    int x = ViAltarS1RightX;
    int y = ViAltarS1Y;
    bool mirror = defaultMirror;
    ApplyPreviewFeatureRenderOverrides(key, ref x, ref y, ref mirror);

    EditorGUILayout.BeginHorizontal();
    float savedLabelWidth = EditorGUIUtility.labelWidth;

    GUIStyle featureStyle = new GUIStyle(EditorStyles.boldLabel);
    Color labelColor = Color.yellow;
    featureStyle.normal.textColor = labelColor;
    featureStyle.hover.textColor = labelColor;
    featureStyle.focused.textColor = labelColor;
    string viAltarLabel =
        "ViAltar S1 " + anchorX + "," + anchorY + " " + viewFacing;
    float featureLabelWidth =
        featureStyle.CalcSize(new GUIContent(viAltarLabel)).x;
    GUILayout.Label(
        viAltarLabel,
        featureStyle,
        GUILayout.Width(featureLabelWidth));

    EditorGUIUtility.labelWidth =
        EditorStyles.label.CalcSize(new GUIContent("X")).x;
    int editX = x;
    bool xChanged = DrawIntStepperInline(
        "X", ref editX, snap, false, true, 24f, 24f);

    EditorGUIUtility.labelWidth =
        EditorStyles.label.CalcSize(new GUIContent("Y")).x;
    int editY = y;
    bool yChanged = DrawIntStepperInline(
        "Y", ref editY, snap, false, true, 24f, 24f);

    bool enabledBefore = IsPreviewFeatureEnabled(key);
    bool enabledAfter = DrawFeatureEnabledToggle(enabledBefore);

    const string MirrorLabel = "Mirror";
    const float ToggleBoxWidth = 18f;
    float mirrorLabelWidth =
        EditorStyles.label.CalcSize(new GUIContent(MirrorLabel)).x;
    EditorGUIUtility.labelWidth = mirrorLabelWidth;
    bool mirrorAfter = DrawMouseOnlyToggle(
        MirrorLabel,
        mirror,
        enabledAfter,
        GUILayout.Width(mirrorLabelWidth + ToggleBoxWidth),
        GUILayout.ExpandWidth(false));
    NoteContentRight();

    EditorGUIUtility.labelWidth = savedLabelWidth;
    EditorGUILayout.EndHorizontal();

    bool changed = false;
    if (xChanged && editX != x)
    {
      previewFeaturePositionOverrides[key] = new Vector2Int(editX, editY);
      previewPositionChangedThisFrame = true;
      changed = true;
    }

    if (yChanged && editY != y)
    {
      previewFeaturePositionOverrides[key] = new Vector2Int(editX, editY);
      previewPositionChangedThisFrame = true;
      changed = true;
    }

    if (mirrorAfter != mirror)
    {
      if (mirrorAfter == defaultMirror)
        previewFeatureMirrorOverrides.Remove(key);
      else
        previewFeatureMirrorOverrides[key] = mirrorAfter;
      previewMirrorChangedThisFrame = true;
      changed = true;
    }

    if (enabledAfter != enabledBefore)
    {
      SetPreviewFeatureEnabled(key, enabledAfter);
      previewEnabledChangedThisFrame = true;
      changed = true;
    }

    if (changed)
    {
      RefreshEditModePreview();
      RepaintGameViews();
      Repaint();
    }

    return true;
  }

  private bool IsHookProjectionVisibleInCurrentPose(WallOrnamentPlacement ornament)
  {
    if (!IsHookOrnament(ornament) || previewMiniMap == null)
      return false;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    string viewedWallSide = FacingName(previewFacing);
    string visibleFrontFace = OppositeFacingName(previewFacing);

    // F1 front.
    int f1X = previewX + forwardX;
    int f1Y = previewY + forwardY;
    if (PreviewTileIsWall(f1X, f1Y))
    {
      if (ornament.wallTilePlacement)
      {
        if (ornament.x == f1X
            && ornament.y == f1Y
            && string.Equals(ornament.wall, visibleFrontFace,
                System.StringComparison.OrdinalIgnoreCase))
          return true;
      }
      else if (ornament.x == previewX
          && ornament.y == previewY
          && string.Equals(ornament.wall, viewedWallSide,
              System.StringComparison.OrdinalIgnoreCase))
      {
        return true;
      }
    }

    // F2 front.
    int f2X = previewX + forwardX * 2;
    int f2Y = previewY + forwardY * 2;
    bool d1Open = PreviewTileIsOpen(f1X, f1Y);
    if (d1Open && previewMiniMap.IsInside(f2X, f2Y))
    {
      if (ornament.wallTilePlacement)
      {
        if (ornament.x == f2X
            && ornament.y == f2Y
            && string.Equals(ornament.wall, visibleFrontFace,
                System.StringComparison.OrdinalIgnoreCase))
          return true;
      }
      else if (ornament.x == f1X
          && ornament.y == f1Y
          && string.Equals(ornament.wall, viewedWallSide,
              System.StringComparison.OrdinalIgnoreCase))
      {
        return true;
      }
    }

    // Side projections S1/S2/S3. These exactly mirror the Hook side renderer:
    // at each depth only the immediate left/right wall beside the lane center
    // can carry the visible side hook.
    for (int distance = 1; distance <= 3; distance++)
    {
      bool corridorOpen = true;
      for (int d = 1; d <= distance; d++)
      {
        int cx = previewX + forwardX * d;
        int cy = previewY + forwardY * d;
        if (!PreviewTileIsOpen(cx, cy))
        {
          corridorOpen = false;
          break;
        }
      }
      if (!corridorOpen)
        continue;

      int centerX = previewX + forwardX * distance;
      int centerY = previewY + forwardY * distance;
      int leftWallX = centerX - rightX;
      int leftWallY = centerY - rightY;
      int rightWallX = centerX + rightX;
      int rightWallY = centerY + rightY;

      string leftPhysicalFace =
          FacingName(TurnPreviewFacingRight(previewFacing));
      string rightPhysicalFace =
          FacingName(TurnPreviewFacingLeft(previewFacing));
      string leftBoundaryDirection =
          FacingName(TurnPreviewFacingLeft(previewFacing));
      string rightBoundaryDirection =
          FacingName(TurnPreviewFacingRight(previewFacing));

      if (ornament.wallTilePlacement)
      {
        if (PreviewTileIsWall(leftWallX, leftWallY)
            && ornament.x == leftWallX
            && ornament.y == leftWallY
            && string.Equals(ornament.wall, leftPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase))
          return true;

        if (PreviewTileIsWall(rightWallX, rightWallY)
            && ornament.x == rightWallX
            && ornament.y == rightWallY
            && string.Equals(ornament.wall, rightPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase))
          return true;
      }
      else
      {
        if (ornament.x == centerX
            && ornament.y == centerY
            && (string.Equals(ornament.wall, leftBoundaryDirection,
                    System.StringComparison.OrdinalIgnoreCase)
                || string.Equals(ornament.wall, rightBoundaryDirection,
                    System.StringComparison.OrdinalIgnoreCase)))
          return true;
      }
    }

    return false;
  }

  private bool IsSlimeProjectionVisibleInCurrentPose(WallOrnamentPlacement ornament)
  {
    if (!IsSlimeOrnament(ornament) || previewMiniMap == null)
      return false;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    int d1CenterX = previewX + forwardX;
    int d1CenterY = previewY + forwardY;
    string viewedWallSide = FacingName(previewFacing);
    string visibleFrontFace = OppositeFacingName(previewFacing);

    // Slime front projection: exactly the same D1 geometry used by
    // BlitSlimeD1FrontIntoPreview().
    if (PreviewTileIsWall(d1CenterX, d1CenterY))
    {
      if (ornament.wallTilePlacement)
      {
        if (ornament.x == d1CenterX
            && ornament.y == d1CenterY
            && string.Equals(
                ornament.wall,
                visibleFrontFace,
                System.StringComparison.OrdinalIgnoreCase))
          return true;
      }
      else if (ornament.x == previewX
          && ornament.y == previewY
          && string.Equals(
              ornament.wall,
              viewedWallSide,
              System.StringComparison.OrdinalIgnoreCase))
      {
        return true;
      }
    }

    string leftPhysicalFace =
        FacingName(TurnPreviewFacingRight(previewFacing));
    string rightPhysicalFace =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string leftBoundaryDirection =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string rightBoundaryDirection =
        FacingName(TurnPreviewFacingRight(previewFacing));

    // Current Slime renderer has side projections only at D1 and D2.
    // Match those exact wall cells and require the center corridor to stay open.
    for (int depth = 1; depth <= 2; depth++)
    {
      bool corridorOpen = true;
      for (int step = 1; step <= depth; step++)
      {
        int cx = previewX + forwardX * step;
        int cy = previewY + forwardY * step;
        if (!PreviewTileIsOpen(cx, cy))
        {
          corridorOpen = false;
          break;
        }
      }
      if (!corridorOpen)
        continue;

      int centerX = previewX + forwardX * depth;
      int centerY = previewY + forwardY * depth;
      int leftWallX = centerX - rightX;
      int leftWallY = centerY - rightY;
      int rightWallX = centerX + rightX;
      int rightWallY = centerY + rightY;

      if (ornament.wallTilePlacement)
      {
        if (PreviewTileIsWall(leftWallX, leftWallY)
            && ornament.x == leftWallX
            && ornament.y == leftWallY
            && string.Equals(
                ornament.wall,
                leftPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase))
          return true;

        if (PreviewTileIsWall(rightWallX, rightWallY)
            && ornament.x == rightWallX
            && ornament.y == rightWallY
            && string.Equals(
                ornament.wall,
                rightPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase))
          return true;
      }
      else
      {
        if (ornament.x == centerX
            && ornament.y == centerY
            && (string.Equals(
                    ornament.wall,
                    leftBoundaryDirection,
                    System.StringComparison.OrdinalIgnoreCase)
                || string.Equals(
                    ornament.wall,
                    rightBoundaryDirection,
                    System.StringComparison.OrdinalIgnoreCase)))
          return true;
      }
    }

    return false;
  }

  private void DrawCurrentPoseFeatureRows()
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null)
      return;

    // Loose-item calibrations from the original Level 0 DUNGEON.DAT.
    DrawFloorItemRows();

    // Champion Mirrors. Only rows that correspond to a mirror projection the
    // renderer can actually draw for this pose are shown. X/Y are framebuffer
    // map coordinates and are temporary per-pose identifiers.
    if (previewChampionMirrors != null)
    {
      for (int i = 0; i < previewChampionMirrors.Length; i++)
      {
        ChampionMirrorPlacement mirror = previewChampionMirrors[i];
        if (mirror == null)
          continue;

        DrawChampionMirrorFeatureRow(mirror);
      }
    }

    // Ordinary wall ornaments.
    if (previewWallOrnaments != null)
    {
      for (int i = 0; i < previewWallOrnaments.Length; i++)
      {
        WallOrnamentPlacement ornament = previewWallOrnaments[i];
        if (ornament == null)
          continue;

        // Vi Altar side projections use exact geometry before the broad
        // feature-cone filter.
        if (DrawViAltarS3CalibrationRow(ornament))
          continue;
        if (DrawViAltarS2CalibrationRow(ornament))
          continue;
        if (DrawViAltarS1CalibrationRow(ornament))
          continue;

        if (!IsMapCellInCurrentFeatureCone(ornament.x, ornament.y))
          continue;

        // Hooks must obey the exact same front/side projection geometry as
        // the renderer.  The broad feature cone also contains outer cells
        // that are not valid Hook projection slots (for example 5,15 West
        // from pose 3,17 East), so those must not become ViewEdit rows.
        if (IsHookOrnament(ornament)
            && !IsHookProjectionVisibleInCurrentPose(ornament))
        {
          continue;
        }

        // Slime rows must obey the exact same F1/S1/S2 geometry as the
        // Slime renderer. The broad feature cone can include adjacent cells
        // that are not drawable Slime projection slots (for example 2,18
        // North from pose 2,17 East), so those must not appear in ViewEdit.
        if (IsSlimeOrnament(ornament)
            && !IsSlimeProjectionVisibleInCurrentPose(ornament))
        {
          continue;
        }

        // Grates have their own rendered-projection ViewEdit row. Only show
        // the grate if this exact ornament is actually drawable in this pose.
        if (IsGrateOrnament(ornament))
        {
          DrawGrateFeatureRow(ornament);
          continue;
        }

        // Champion Mirrors have their own dedicated ViewEdit row above.
        // Do not also show the generic wall-ornament entry for the same
        // physical mirror, otherwise ViewEdit contains two redundant rows.
        if (!string.IsNullOrEmpty(ornament.type)
            && ornament.type.IndexOf(
                "ChampionMirror",
                System.StringComparison.OrdinalIgnoreCase) >= 0)
        {
          bool hasDedicatedMirror = false;
          if (previewChampionMirrors != null)
          {
            for (int m = 0; m < previewChampionMirrors.Length; m++)
            {
              ChampionMirrorPlacement mirror = previewChampionMirrors[m];
              if (mirror == null)
                continue;

              if (mirror.x == ornament.x
                  && mirror.y == ornament.y
                  && string.Equals(
                      mirror.wall,
                      ornament.wall,
                      System.StringComparison.OrdinalIgnoreCase))
              {
                hasDedicatedMirror = true;
                break;
              }
            }
          }

          if (hasDedicatedMirror)
            continue;
        }

        string key = MakePreviewFeatureKey(
            "Ornament", ornament.x, ornament.y, ornament.wall);

        // A Manacles row should exist only when the Manacles are actually
        // visible in the current pose. This mirrors BlitManaclesD1FrontIntoPreview:
        // wall-tile Manacles must be on the wall cell directly in front of the
        // party and on the physical wall face visible from the current facing.
        //
        // Example:
        //   pose 4,9 West  -> wall storage 3,9 East -> visible as F1
        //   pose 4,9 North -> same Manacles are not on the front wall -> hidden
        //
        // ViewEdit displays viewpoint coordinates/facing rather than the
        // underlying storage-wall coordinates.
        int displayMapX = ornament.x;
        int displayMapY = ornament.y;
        string displayWall = ornament.wall;
        string manaclesDepthLabel = null;
        if (IsManaclesOrnament(ornament))
        {
          DungeonMap.GetForwardOffset(
              previewFacing,
              out int manaclesForwardX,
              out int manaclesForwardY);

          if (ornament.wallTilePlacement)
          {
            int directFrontWallX = previewX + manaclesForwardX;
            int directFrontWallY = previewY + manaclesForwardY;
            int f2FrontWallX = previewX + manaclesForwardX * 2;
            int f2FrontWallY = previewY + manaclesForwardY * 2;
            int f3FrontWallX = previewX + manaclesForwardX * 3;
            int f3FrontWallY = previewY + manaclesForwardY * 3;
            string visibleFace = OppositeFacingName(previewFacing);
            bool visibleAsF1 =
                ornament.x == directFrontWallX
                && ornament.y == directFrontWallY
                && string.Equals(
                    ornament.wall,
                    visibleFace,
                    System.StringComparison.OrdinalIgnoreCase);
            bool d1Open =
                previewMiniMap != null
                && previewMiniMap.IsInside(directFrontWallX, directFrontWallY)
                && previewMiniMap.GetTile(
                    directFrontWallX, directFrontWallY).Type
                    != DungeonTileType.Wall;
            bool d2Open =
                d1Open
                && previewMiniMap.IsInside(f2FrontWallX, f2FrontWallY)
                && previewMiniMap.GetTile(
                    f2FrontWallX, f2FrontWallY).Type
                    != DungeonTileType.Wall;
            bool visibleAsF2 =
                d1Open
                && ornament.x == f2FrontWallX
                && ornament.y == f2FrontWallY
                && string.Equals(
                    ornament.wall,
                    visibleFace,
                    System.StringComparison.OrdinalIgnoreCase);
            bool visibleAsF3 =
                d2Open
                && ornament.x == f3FrontWallX
                && ornament.y == f3FrontWallY
                && string.Equals(
                    ornament.wall,
                    visibleFace,
                    System.StringComparison.OrdinalIgnoreCase);

            bool visibleAsS1 = false;
            if (!visibleAsF1 && !visibleAsF2 && !visibleAsF3 && d1Open)
            {
              DungeonMap.GetRightOffset(
                  previewFacing,
                  out int manaclesRightX,
                  out int manaclesRightY);
              int leftWallX = directFrontWallX - manaclesRightX;
              int leftWallY = directFrontWallY - manaclesRightY;
              int rightWallX = directFrontWallX + manaclesRightX;
              int rightWallY = directFrontWallY + manaclesRightY;
              string leftFace = FacingName(TurnPreviewFacingRight(previewFacing));
              string rightFace = FacingName(TurnPreviewFacingLeft(previewFacing));
              visibleAsS1 =
                  (ornament.x == leftWallX
                      && ornament.y == leftWallY
                      && string.Equals(
                          ornament.wall,
                          leftFace,
                          System.StringComparison.OrdinalIgnoreCase))
                  || (ornament.x == rightWallX
                      && ornament.y == rightWallY
                      && string.Equals(
                          ornament.wall,
                          rightFace,
                          System.StringComparison.OrdinalIgnoreCase));
            }

            bool visibleAsS2 = false;
            if (!visibleAsF1 && !visibleAsF2 && !visibleAsF3 && !visibleAsS1 && d2Open)
            {
              DungeonMap.GetRightOffset(
                  previewFacing,
                  out int manaclesRightX,
                  out int manaclesRightY);
              int leftWallX = f2FrontWallX - manaclesRightX;
              int leftWallY = f2FrontWallY - manaclesRightY;
              int rightWallX = f2FrontWallX + manaclesRightX;
              int rightWallY = f2FrontWallY + manaclesRightY;
              string leftFace = FacingName(TurnPreviewFacingRight(previewFacing));
              string rightFace = FacingName(TurnPreviewFacingLeft(previewFacing));
              visibleAsS2 =
                  (ornament.x == leftWallX
                      && ornament.y == leftWallY
                      && string.Equals(
                          ornament.wall,
                          leftFace,
                          System.StringComparison.OrdinalIgnoreCase))
                  || (ornament.x == rightWallX
                      && ornament.y == rightWallY
                      && string.Equals(
                          ornament.wall,
                          rightFace,
                          System.StringComparison.OrdinalIgnoreCase));
            }

            if (!visibleAsF1 && !visibleAsF2 && !visibleAsF3
                && !visibleAsS1 && !visibleAsS2)
              continue;

            displayMapX = previewX;
            displayMapY = previewY;
            displayWall = FacingName(previewFacing);
            manaclesDepthLabel = visibleAsS1
                ? " / S1"
                : visibleAsS2
                    ? " / S2"
                    : visibleAsF1
                        ? " / F1"
                        : visibleAsF2 ? " / F2" : " / F3";
          }
          else
          {
            bool visibleInCurrentPose =
                ornament.x == previewX
                && ornament.y == previewY
                && string.Equals(
                    ornament.wall,
                    FacingName(previewFacing),
                    System.StringComparison.OrdinalIgnoreCase);

            if (!visibleInCurrentPose)
              continue;
          }
        }

        string name = string.IsNullOrEmpty(ornament.type)
            ? "Ornament"
            : ornament.type;
        if (!string.IsNullOrEmpty(displayWall))
          name += " (" + displayWall + ")";

        // ViewEdit labels use the current-view depth classification.
        // F1 is the wall one step ahead; F2 is two steps ahead.
        if (manaclesDepthLabel != null)
          name += manaclesDepthLabel;
        else if (IsManaclesOrnament(ornament)
            && displayMapX == previewX
            && displayMapY == previewY
            && string.Equals(
                displayWall,
                FacingName(previewFacing),
                System.StringComparison.OrdinalIgnoreCase))
        {
          name += " / F1";
        }

        DrawFeatureChecklistRow(
            displayMapX,
            displayMapY,
            name,
            key,
            new Color(1f, 0.65f, 0.1f));
      }
    }

    // Floor puddles are ornaments too, but they are stored separately from
    // wallOrnaments in the parsed map data. Only list projections that the
    // puddle renderer can actually draw in the current pose. In particular,
    // there is no F0 puddle projection, so a puddle beside/under the player
    // must not appear in ViewEdit just because it is nearby on the map.
    DungeonMap.GetForwardOffset(
        previewFacing,
        out int puddleForwardX,
        out int puddleForwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int puddleRightX,
        out int puddleRightY);

    for (int depth = 1; depth <= 3; depth++)
    {
      int minLane = depth == 3 ? 0 : -1;
      int maxLane = depth == 3 ? 0 : 1;

      for (int lane = minLane; lane <= maxLane; lane++)
      {
        int x = previewX + puddleForwardX * depth + puddleRightX * lane;
        int y = previewY + puddleForwardY * depth + puddleRightY * lane;
        if (!IsPuddleProjectionVisibleInCurrentPose(x, y, depth, lane))
          continue;

        string key = MakePreviewFeatureKey("Puddle", x, y, null);
        DrawFeatureChecklistRow(
            x,
            y,
            "Puddle",
            key,
            new Color(0.3f, 0.75f, 1f));
      }
    }

    // Stairs Up / Down in the same current-view neighbourhood.
    for (int depth = 0; depth <= 3; depth++)
    {
      int maxLane = depth == 0 ? 1 : Mathf.Max(1, depth);
      DungeonMap.GetForwardOffset(
          previewFacing,
          out int forwardX,
          out int forwardY);
      DungeonMap.GetRightOffset(
          previewFacing,
          out int rightX,
          out int rightY);

      for (int lane = -maxLane; lane <= maxLane; lane++)
      {
        int x = previewX + forwardX * depth + rightX * lane;
        int y = previewY + forwardY * depth + rightY * lane;
        if (!previewMiniMap.IsInside(x, y))
          continue;

        DungeonTile tile = previewMiniMap.GetTile(x, y);
        if (tile == null || !tile.TryGetStairsDirection(out bool stairsUp))
          continue;

        string family = stairsUp ? "StairsUp" : "StairsDown";
        string key = MakePreviewFeatureKey(family, x, y, null);
        DrawFeatureChecklistRow(
            x,
            y,
            stairsUp ? "Stairs Up" : "Stairs Down",
            key,
            stairsUp ? new Color(0.25f, 0.6f, 1f) : Color.magenta);
      }
    }
  }

  private void DrawStairsDownF1ControlRow()
  {
    if (!IsStairsDownF1NeededForCurrentPose())
      return;

    EditorGUILayout.BeginHorizontal();
    EditorGUILayout.LabelField(
        "Stairs Down",
        GetPieceFamilyHeaderStyle(Color.magenta),
        GUILayout.Width(110f));

    float savedLabelWidth = EditorGUIUtility.labelWidth;
    const float ToggleBoxWidth = 18f;
    const string EnabledLabel = "Enabled";
    float enabledLabelWidth =
        EditorStyles.label.CalcSize(new GUIContent(EnabledLabel)).x;
    EditorGUIUtility.labelWidth = enabledLabelWidth;

    bool enabledBefore = stairsDownF1PreviewEnabled;
    bool enabledAfter = DrawMouseOnlyToggle(
        EnabledLabel,
        enabledBefore,
        enabledBefore,
        GUILayout.Width(enabledLabelWidth + ToggleBoxWidth),
        GUILayout.ExpandWidth(false));

    GUILayout.Space(10f);
    EditorGUIUtility.labelWidth =
        EditorStyles.label.CalcSize(new GUIContent("X")).x;

    int xBefore = stairsDownF1PreviewX;
    int editX = xBefore;
    bool xChanged = DrawIntStepperInline(
        "X",
        ref editX,
        snap,
        false,
        true);

    EditorGUIUtility.labelWidth =
        EditorStyles.label.CalcSize(new GUIContent("Y")).x;
    int displayYBefore = stairsDownF1PreviewDisplayY;
    int editUnityY = DisplayYToUnityY(displayYBefore, 92);
    bool yChanged = DrawTopDownYStepperInline(
        ref editUnityY,
        92,
        snap,
        false,
        true);
    int displayYAfter = UnityYToDisplayY(editUnityY, 92);

    EditorGUIUtility.labelWidth = savedLabelWidth;
    EditorGUILayout.EndHorizontal();

    bool controlChanged = false;
    if (enabledAfter != enabledBefore)
    {
      stairsDownF1PreviewEnabled = enabledAfter;
      previewEnabledChangedThisFrame = true;
      controlChanged = true;
    }

    if (xChanged && editX != xBefore)
    {
      stairsDownF1PreviewX = editX;
      previewPositionChangedThisFrame = true;
      controlChanged = true;
    }

    if (yChanged && displayYAfter != displayYBefore)
    {
      stairsDownF1PreviewDisplayY = displayYAfter;
      previewPositionChangedThisFrame = true;
      controlChanged = true;
    }

    if (controlChanged)
    {
      RefreshEditModePreview();
      RepaintGameViews();
      Repaint();
    }
  }

  /// <summary>
  /// Down-stairs front when the cell one step ahead is a stairs tile
  /// whose raw direction bit is down.
  /// </summary>
  private void BlitStairsDownF1IntoPreview(Color32[] pixels)
  {
    if (pixels == null
        || !stairsDownF1PreviewEnabled
        || !IsStairsDownF1NeededForCurrentPose())
    {
      return;
    }

    Texture2D stairs = AssetDatabase.LoadAssetAtPath<Texture2D>(
        StairsDownF1AssetPath);
    if (stairs == null
        || stairs.width != 152
        || stairs.height != 92
        || !stairs.isReadable)
    {
      return;
    }

    int destinationY =
        DisplayYToUnityY(stairsDownF1PreviewDisplayY, stairs.height);

    BlitPieceIntoPreview(
        pixels,
        stairs,
        stairsDownF1PreviewX,
        destinationY,
        false);
  }

  private enum FloorItemDepth
  {
    SameTile = 0,
    OneAhead = 1,
    TwoAhead = 2
  }

  private static bool TryGetFloorItemSubSquareOffset(
      string cell,
      out int offsetX,
      out int offsetY)
  {
    // Dungeon Master N/E/S/W floor-item positions are corner slots.
    // Map Y increases south: N=NW, E=NE, S=SE, W=SW.
    offsetX = 0;
    offsetY = 0;
    switch ((cell ?? string.Empty).ToUpperInvariant())
    {
      case "N": offsetX = -1; offsetY = -1; return true;
      case "E": offsetX =  1; offsetY = -1; return true;
      case "S": offsetX =  1; offsetY =  1; return true;
      case "W": offsetX = -1; offsetY =  1; return true;
      default: return false;
    }
  }

  private static void GetFloorItemViewBasis(
      DungeonFacing facing,
      out int forwardX,
      out int forwardY,
      out int rightX,
      out int rightY)
  {
    switch (facing)
    {
      case DungeonFacing.North:
        forwardX = 0; forwardY = -1; rightX = 1; rightY = 0; break;
      case DungeonFacing.East:
        forwardX = 1; forwardY = 0; rightX = 0; rightY = 1; break;
      case DungeonFacing.South:
        forwardX = 0; forwardY = 1; rightX = -1; rightY = 0; break;
      default: // West
        forwardX = -1; forwardY = 0; rightX = 0; rightY = -1; break;
    }
  }

  private FloorItemPlacement[] GetCurrentFloorItems()
  {
    return previewDungeonLevel == 0
        ? HallOfChampionsFloorItems
        : new FloorItemPlacement[0];
  }

  private bool TryProjectFloorItem(
      FloorItemPlacement item,
      out FloorItemDepth depth,
      out bool isRight)
  {
    depth = FloorItemDepth.SameTile;
    isRight = false;
    if (item == null || previewMiniMap == null)
      return false;

    GetFloorItemViewBasis(
        previewFacing,
        out int forwardX,
        out int forwardY,
        out int rightX,
        out int rightY);

    int dx = item.x - previewX;
    int dy = item.y - previewY;
    int forwardDistance = dx * forwardX + dy * forwardY;
    int lateralTileDistance = dx * rightX + dy * rightY;

    // This pass handles the center corridor tile at the current square and
    // the next two map squares. Side-tile floor items can be added later as
    // a separate occlusion-aware projection, without coordinate hardcodes.
    if (lateralTileDistance != 0 || forwardDistance < 0 || forwardDistance > 2)
      return false;

    if (!TryGetFloorItemSubSquareOffset(
            item.cell,
            out int cornerX,
            out int cornerY))
      return false;

    int cornerAhead = cornerX * forwardX + cornerY * forwardY;
    int cornerLateral = cornerX * rightX + cornerY * rightY;

    // On the party's own square only the front half of the floor is visible.
    if (forwardDistance == 0 && cornerAhead <= 0)
      return false;
    if (cornerLateral == 0)
      return false;

    isRight = cornerLateral > 0;
    depth = forwardDistance == 0
        ? FloorItemDepth.SameTile
        : forwardDistance == 1
            ? FloorItemDepth.OneAhead
            : FloorItemDepth.TwoAhead;
    return true;
  }

  private string GetFloorItemFeatureKey(FloorItemPlacement item)
  {
    return MakePreviewFeatureKey(
        "Item-" + item.type,
        item.x,
        item.y,
        item.cell);
  }

  private Texture2D GetFloorItemTexture(FloorItemPlacement item)
  {
    if (item == null)
      return null;

    if (string.Equals(item.type, "Apple", System.StringComparison.OrdinalIgnoreCase))
    {
      if (cachedAppleGroundTexture == null)
        cachedAppleGroundTexture = AssetDatabase.LoadAssetAtPath<Texture2D>(AppleGroundAssetPath);
      return cachedAppleGroundTexture;
    }

    if (string.Equals(item.type, "Bread", System.StringComparison.OrdinalIgnoreCase))
    {
      if (cachedBreadGroundTexture == null)
        cachedBreadGroundTexture = AssetDatabase.LoadAssetAtPath<Texture2D>(BreadGroundAssetPath);
      return cachedBreadGroundTexture;
    }

    return null;
  }

  private void BlitFloorItemsIntoPreview(Color32[] pixels)
  {
    if (pixels == null)
      return;

    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null)
      return;

    FloorItemPlacement[] items = GetCurrentFloorItems();
    for (int i = 0; i < items.Length; i++)
    {
      FloorItemPlacement item = items[i];
      if (!TryProjectFloorItem(item, out FloorItemDepth depth, out bool isRight))
        continue;
      if (!IsPreviewFeatureEnabled(GetFloorItemFeatureKey(item)))
        continue;

      Texture2D texture = GetFloorItemTexture(item);
      if (texture == null || !texture.isReadable || texture.width <= 0 || texture.height <= 0)
        continue;

      BlitProjectedFloorItem(pixels, item, texture, depth, isRight);
    }
  }

  private void BlitProjectedFloorItem(
      Color32[] pixels,
      FloorItemPlacement item,
      Texture2D texture,
      FloorItemDepth depth,
      bool isRight)
  {
    bool apple = string.Equals(item.type, "Apple", System.StringComparison.OrdinalIgnoreCase);
    bool bread = string.Equals(item.type, "Bread", System.StringComparison.OrdinalIgnoreCase);
    if (!apple && !bread)
      return;

    if (depth == FloorItemDepth.SameTile)
    {
      int x = apple
          ? (isRight ? appleF0RightPreviewX : appleF0FrontPreviewX)
          : (isRight ? breadF0RightPreviewX : breadF0LeftPreviewX);
      int top = apple
          ? (isRight ? appleF0RightPreviewScreenTop : appleF0FrontPreviewScreenTop)
          : (isRight ? breadF0RightPreviewScreenTop : breadF0LeftPreviewScreenTop);
      BlitPieceIntoPreview(pixels, texture, x, PreviewHeight - top - texture.height, false);
      return;
    }

    if (depth == FloorItemDepth.OneAhead)
    {
      int width = apple ? AppleF2Width : BreadF2Width;
      int height = apple ? AppleF2Height : BreadF2Height;
      int x = apple
          ? (isRight ? appleF2RightPreviewX : appleF2LeftPreviewX)
          : (isRight ? breadF2RightPreviewX : breadF2LeftPreviewX);
      int top = apple
          ? (isRight ? appleF2RightPreviewScreenTop : appleF2LeftPreviewScreenTop)
          : (isRight ? breadF2RightPreviewScreenTop : breadF2LeftPreviewScreenTop);
      BlitPieceScaledIntoPreview(
          pixels, texture, x, PreviewHeight - top - height, width, height, false,
          skipCyanTransparencyKey: apple,
          colorMap: WallOrnamentMediumColorMap);
      return;
    }

    // F3 is calibrated from the Apple source today. Keep the generic map
    // projection active, but do not invent an unverified Bread F3 pixel slot.
    if (!apple)
      return;

    int f3X = isRight ? appleF3RightPreviewX : appleF3LeftPreviewX;
    int f3Top = isRight ? appleF3RightPreviewScreenTop : appleF3LeftPreviewScreenTop;
    BlitPieceScaledIntoPreview(
        pixels, texture, f3X, PreviewHeight - f3Top - AppleF3Height,
        AppleF3Width, AppleF3Height, false,
        skipCyanTransparencyKey: true,
        colorMap: WallOrnamentFarColorMap);
  }

  private void DrawFloorItemRows()
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null)
      return;

    FloorItemPlacement[] items = GetCurrentFloorItems();
    for (int i = 0; i < items.Length; i++)
    {
      FloorItemPlacement item = items[i];
      if (!TryProjectFloorItem(item, out FloorItemDepth depth, out bool isRight))
        continue;

      // Bread F3 has no verified pixel calibration yet, so it is not drawn
      // and should not appear as an active ViewEdit feature row.
      if (depth == FloorItemDepth.TwoAhead
          && string.Equals(item.type, "Bread", System.StringComparison.OrdinalIgnoreCase))
        continue;

      string key = GetFloorItemFeatureKey(item);
      EditorGUILayout.BeginHorizontal();

      float savedLabelWidth = EditorGUIUtility.labelWidth;
      EditorGUIUtility.labelWidth = EditorStyles.label.CalcSize(new GUIContent("X")).x;
      using (new EditorGUI.DisabledScope(true))
      {
        EditorGUILayout.IntField("X", item.x, GUILayout.Width(FloorItemMapCoordFieldWidth));
        EditorGUIUtility.labelWidth = EditorStyles.label.CalcSize(new GUIContent("Y")).x;
        EditorGUILayout.IntField("Y", item.y, GUILayout.Width(FloorItemMapCoordFieldWidth));
      }
      EditorGUIUtility.labelWidth = savedLabelWidth;

      string depthLabel = depth == FloorItemDepth.SameTile
          ? "F1"
          : depth == FloorItemDepth.OneAhead ? "F2" : "F3";
      GUILayout.Label(
          item.type + " [" + item.cell + "] - " + depthLabel + " " + (isRight ? "Right" : "Left"),
          EditorStyles.boldLabel,
          GUILayout.Width(210f));

      bool enabledBefore = IsPreviewFeatureEnabled(key);
      bool enabledAfter = DrawCompactMouseOnlyToggle("Enabled", enabledBefore, false);
      EditorGUILayout.EndHorizontal();

      if (enabledAfter != enabledBefore)
      {
        SetPreviewFeatureEnabled(key, enabledAfter);
        previewEnabledChangedThisFrame = true;
        RefreshEditModePreview();
        RepaintGameViews();
        Repaint();
      }
    }
  }

  private bool IsPuddleProjectionVisibleInCurrentPose(
      int mapX,
      int mapY,
      int depth,
      int lane)
  {
    if (previewMiniMap == null
        || !previewMiniMap.IsInside(mapX, mapY)
        || !previewPuddleFloors.Contains(PackPreviewTile(mapX, mapY)))
      return false;

    // The renderer has center projections at F1/F2/F3. A center puddle is
    // visible only while every nearer center tile stays open. This prevents a
    // floor ornament at D2/D3 from being drawn through a nearer front wall
    // (for example 7,10 West: the 4,10 puddle is behind the front wall).
    if (lane == 0)
    {
      if (depth < 1 || depth > 3)
        return false;

      DungeonMap.GetForwardOffset(
          previewFacing,
          out int centerForwardX,
          out int centerForwardY);

      for (int nearerDepth = 1; nearerDepth < depth; nearerDepth++)
      {
        int nearerX = previewX + centerForwardX * nearerDepth;
        int nearerY = previewY + centerForwardY * nearerDepth;
        if (!PreviewTileIsOpen(nearerX, nearerY))
          return false;
      }

      return true;
    }

    if (Mathf.Abs(lane) != 1 || depth < 1 || depth > 2)
      return false;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    int side = lane < 0 ? -1 : 1;
    int f0SideX = previewX + rightX * side;
    int f0SideY = previewY + rightY * side;
    bool f0SideOpen =
        previewMiniMap.IsInside(f0SideX, f0SideY)
        && previewMiniMap.GetTile(f0SideX, f0SideY).Type != DungeonTileType.Wall;
    if (!f0SideOpen)
      return false;

    if (depth == 1)
      return true;

    int f1SideX = previewX + forwardX + rightX * side;
    int f1SideY = previewY + forwardY + rightY * side;
    return previewMiniMap.IsInside(f1SideX, f1SideY)
        && previewMiniMap.GetTile(f1SideX, f1SideY).Type != DungeonTileType.Wall;
  }

  private void BlitPuddlesIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null || previewPuddleFloors.Count == 0)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    int f1X = previewX + forwardX;
    int f1Y = previewY + forwardY;
    int f2X = previewX + forwardX * 2;
    int f2Y = previewY + forwardY * 2;
    int f3X = previewX + forwardX * 3;
    int f3Y = previewY + forwardY * 3;

    if (IsPuddleProjectionVisibleInCurrentPose(f3X, f3Y, 3, 0))
    {
      BlitPuddleFloor(
          pixels, f3X, f3Y, PuddleF3AssetPath, ref cachedPuddleF3Texture,
          PuddleF3ScreenTop, true, 0, false);
    }

    // Side-floor puddles must have an unobstructed same-side sight line.
    // D1 side tiles need the adjacent F0 side open. D2 side tiles need both
    // the adjacent F0 side and the F1 side cell open; otherwise a nearer side
    // wall hides the floor ornament behind it.
    int f0LeftX = previewX - rightX;
    int f0LeftY = previewY - rightY;
    int f0RightX = previewX + rightX;
    int f0RightY = previewY + rightY;
    int f1LeftX = f1X - rightX;
    int f1LeftY = f1Y - rightY;
    int f1RightX = f1X + rightX;
    int f1RightY = f1Y + rightY;

    bool f0LeftOpen =
        previewMiniMap.IsInside(f0LeftX, f0LeftY)
        && previewMiniMap.GetTile(f0LeftX, f0LeftY).Type != DungeonTileType.Wall;
    bool f0RightOpen =
        previewMiniMap.IsInside(f0RightX, f0RightY)
        && previewMiniMap.GetTile(f0RightX, f0RightY).Type != DungeonTileType.Wall;
    bool f1LeftOpen =
        previewMiniMap.IsInside(f1LeftX, f1LeftY)
        && previewMiniMap.GetTile(f1LeftX, f1LeftY).Type != DungeonTileType.Wall;
    bool f1RightOpen =
        previewMiniMap.IsInside(f1RightX, f1RightY)
        && previewMiniMap.GetTile(f1RightX, f1RightY).Type != DungeonTileType.Wall;

    if (f0LeftOpen && f1LeftOpen)
    {
      BlitPuddleFloor(
          pixels, f2X - rightX, f2Y - rightY, PuddleS2AssetPath,
          ref cachedPuddleS2Texture, PuddleS2ScreenTop, false,
          PuddleS2LeftScreenX, false);
    }

    if (f0RightOpen && f1RightOpen)
    {
      BlitPuddleFloor(
          pixels, f2X + rightX, f2Y + rightY, PuddleS2AssetPath,
          ref cachedPuddleS2Texture, PuddleS2ScreenTop, false,
          PuddleS2LeftScreenX, true);
    }

    if (IsPuddleProjectionVisibleInCurrentPose(f2X, f2Y, 2, 0))
    {
      BlitPuddleFloor(
          pixels, f2X, f2Y, PuddleF2AssetPath, ref cachedPuddleF2Texture,
          PuddleF2ScreenTop, true, 0, false);
    }

    if (f0LeftOpen)
    {
      BlitPuddleF1Side(
          pixels, f1X - rightX, f1Y - rightY, false);
    }

    if (f0RightOpen)
    {
      BlitPuddleF1Side(
          pixels, f1X + rightX, f1Y + rightY, true);
    }
    if (IsPuddleProjectionVisibleInCurrentPose(f1X, f1Y, 1, 0))
    {
      BlitPuddleFloor(
          pixels, f1X, f1Y, PuddleF1AssetPath, ref cachedPuddleF1Texture,
          PuddleF1ScreenTop, true, 0, false);
    }
  }


  private void BlitPuddleF1Side(
      Color32[] pixels,
      int mapX,
      int mapY,
      bool rightSide)
  {
    if (!previewMiniMap.IsInside(mapX, mapY)
        || !IsPreviewPuddleFloor(mapX, mapY))
    {
      return;
    }

    Texture2D texture = GetPuddleTexture(
        PuddleF1SideAssetPath,
        ref cachedPuddleF1SideTexture);
    if (texture == null || !texture.isReadable || texture.width <= 0)
      return;

    int x = rightSide
        ? DungeonViewportWidth - texture.width
        : 0;
    int y = PreviewHeight - PuddleF1ScreenTop - texture.height + 1;

    BlitPieceIntoPreview(pixels, texture, x, y, rightSide);
  }

  private void BlitPuddleFloor(
      Color32[] pixels,
      int mapX,
      int mapY,
      string assetPath,
      ref Texture2D cache,
      int screenTop,
      bool centerInViewport,
      int leftScreenX,
      bool mirror)
  {
    if (!previewMiniMap.IsInside(mapX, mapY)
        || !IsPreviewPuddleFloor(mapX, mapY))
    {
      return;
    }

    Texture2D texture = GetPuddleTexture(assetPath, ref cache);
    if (texture == null || !texture.isReadable || texture.width <= 0)
      return;

    int x = centerInViewport
        ? (DungeonViewportWidth - texture.width) / 2
        : leftScreenX;
    if (mirror)
      x = DungeonViewportWidth - leftScreenX - texture.width;

    int y = PreviewHeight - screenTop - texture.height;
    BlitPieceIntoPreview(pixels, texture, x, y, mirror);
  }

  private Texture2D GetPuddleTexture(string assetPath, ref Texture2D cache)
  {
    if (cache != null)
      return cache;

    cache = AssetDatabase.LoadAssetAtPath<Texture2D>(assetPath);
    return cache;
  }


  private Texture2D GetViAltarS1Texture()
  {
    if (cachedViAltarS1Texture != null)
      return cachedViAltarS1Texture;

    const string exactPath =
        "Assets/Art/Ornaments/Altar_of_Vi_S1_20x48.png";

    TextureImporter importer =
        AssetImporter.GetAtPath(exactPath) as TextureImporter;
    if (importer != null && !importer.isReadable)
    {
      importer.isReadable = true;
      importer.SaveAndReimport();
    }

    cachedViAltarS1Texture =
        AssetDatabase.LoadAssetAtPath<Texture2D>(exactPath);
    return cachedViAltarS1Texture;
  }

  private Texture2D GetViAltarS3Texture()
  {
    if (cachedViAltarS3Texture != null)
      return cachedViAltarS3Texture;

    TextureImporter importer =
        AssetImporter.GetAtPath(ViAltarS3AssetPath) as TextureImporter;
    if (importer != null)
    {
      bool changed = false;
      if (!importer.isReadable)
      {
        importer.isReadable = true;
        changed = true;
      }
      if (importer.filterMode != FilterMode.Point)
      {
        importer.filterMode = FilterMode.Point;
        changed = true;
      }
      if (importer.mipmapEnabled)
      {
        importer.mipmapEnabled = false;
        changed = true;
      }
      if (changed)
        importer.SaveAndReimport();
    }

    cachedViAltarS3Texture =
        AssetDatabase.LoadAssetAtPath<Texture2D>(ViAltarS3AssetPath);
    if (cachedViAltarS3Texture != null)
    {
      cachedViAltarS3Texture.filterMode = FilterMode.Point;
      cachedViAltarS3Texture.wrapMode = TextureWrapMode.Clamp;
    }
    return cachedViAltarS3Texture;
  }

  private void BlitViAltarS3IntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D altar = GetViAltarS3Texture();
    if (altar == null || !altar.isReadable)
      return;

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (!TryGetViAltarS3Projection(
              ornament,
              out int anchorX,
              out int anchorY,
              out string viewFacing,
              out bool defaultMirror))
      {
        continue;
      }

      string key = MakePreviewFeatureKey(
          "ViAltarS3V2", anchorX, anchorY, viewFacing);
      if (!IsPreviewFeatureEnabled(key))
        continue;

      int x = ViAltarS3RightX;
      int y = ViAltarS3Y;
      bool mirror = defaultMirror;
      ApplyPreviewFeatureRenderOverrides(key, ref x, ref y, ref mirror);

      // Generic S3 render: every Vi Altar that resolves through the S3
      // projection uses this exact 6x19 crop at 1:1. The crop already contains
      // the original far-distance palette, so do not scale or palette-remap it.
      // defaultMirror comes from the projected wall side (right=ON, left=OFF).
      BlitPieceIntoPreview(pixels, altar, x, y, mirror);
    }
  }

  private Texture2D GetViAltarS2Texture()
  {
    if (cachedViAltarS2Texture != null)
      return cachedViAltarS2Texture;

    TextureImporter importer =
        AssetImporter.GetAtPath(ViAltarS2AssetPath) as TextureImporter;
    if (importer != null)
    {
      bool changed = false;
      if (!importer.isReadable)
      {
        importer.isReadable = true;
        changed = true;
      }
      if (importer.filterMode != FilterMode.Point)
      {
        importer.filterMode = FilterMode.Point;
        changed = true;
      }
      if (importer.mipmapEnabled)
      {
        importer.mipmapEnabled = false;
        changed = true;
      }
      if (changed)
        importer.SaveAndReimport();
    }

    cachedViAltarS2Texture =
        AssetDatabase.LoadAssetAtPath<Texture2D>(ViAltarS2AssetPath);
    if (cachedViAltarS2Texture != null)
    {
      cachedViAltarS2Texture.filterMode = FilterMode.Point;
      cachedViAltarS2Texture.wrapMode = TextureWrapMode.Clamp;
    }
    return cachedViAltarS2Texture;
  }

  private void BlitViAltarS2IntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D altar = GetViAltarS2Texture();
    if (altar == null || !altar.isReadable)
      return;

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (!TryGetViAltarS2Projection(
              ornament,
              out int anchorX,
              out int anchorY,
              out string viewFacing,
              out bool defaultMirror))
      {
        continue;
      }

      string key = MakePreviewFeatureKey(
          "ViAltarS2", anchorX, anchorY, viewFacing);
      if (!IsPreviewFeatureEnabled(key))
        continue;

      int x = ViAltarS2RightX;
      int y = ViAltarS2Y;
      bool mirror = defaultMirror;
      ApplyPreviewFeatureRenderOverrides(key, ref x, ref y, ref mirror);

      // Direct 1:1 blit of the verified 12x31 S2 asset. No scaling or palette
      // conversion is performed here. Do not return after the first match:
      // more than one Vi Altar can project into valid S2 side slots in a
      // generic map/pose, so render every visible occurrence.
      BlitPieceIntoPreview(pixels, altar, x, y, mirror);
    }
  }

  private void BlitViAltarS1IntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D altar = GetViAltarS1Texture();
    if (altar == null || !altar.isReadable)
      return;

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (!TryGetViAltarS1Projection(
              ornament,
              out int anchorX,
              out int anchorY,
              out string viewFacing,
              out bool defaultMirror))
      {
        continue;
      }

      string key = MakePreviewFeatureKey(
          "ViAltarS1", anchorX, anchorY, viewFacing);
      if (!IsPreviewFeatureEnabled(key))
        continue;

      int x = ViAltarS1RightX;
      int y = ViAltarS1Y;
      bool mirror = defaultMirror;
      ApplyPreviewFeatureRenderOverrides(key, ref x, ref y, ref mirror);

      BlitPieceIntoPreview(
          pixels,
          altar,
          x,
          y,
          mirror);
      return;
    }
  }

  private void BlitViAltarD2FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D altar = previewUseEngineViAltarSlots
        ? GetViAltarEngineF2TestTexture()
        : GetViAltarGeneratedF2TestTexture();
    if (altar == null || !altar.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    int nearX = previewX + forwardX;
    int nearY = previewY + forwardY;
    int wallTileX = previewX + forwardX * 2;
    int wallTileY = previewY + forwardY * 2;
    if (!previewMiniMap.IsInside(nearX, nearY)
        || previewMiniMap.GetTile(nearX, nearY).Type
            == DungeonTileType.Wall
        || !previewMiniMap.IsInside(wallTileX, wallTileY)
        || previewMiniMap.GetTile(wallTileX, wallTileY).Type
            != DungeonTileType.Wall)
    {
      return;
    }

    string visiblePhysicalWallFace =
        OppositeFacingName(previewFacing);

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (ornament == null
          || !string.Equals(
              ornament.type,
              "ViAltar",
              System.StringComparison.OrdinalIgnoreCase))
      {
        continue;
      }

      if (ornament.x != wallTileX
          || ornament.y != wallTileY
          || !string.Equals(
              ornament.wall,
              visiblePhysicalWallFace,
              System.StringComparison.OrdinalIgnoreCase))
      {
        continue;
      }

      int altarX = previewUseEngineViAltarSlots
          ? ViAltarEngineF2FrontX
          : ViAltarWallOrnamentSet.f2.x;
      int altarY = previewUseEngineViAltarSlots
          ? ViAltarEngineF2FrontY
          : ViAltarWallOrnamentSet.f2.y;
      BlitPieceIntoPreview(
          pixels,
          altar,
          altarX,
          altarY,
          false);
      return;
    }
  }

  private void BlitViAltarD3FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D altar = previewUseEngineViAltarSlots
        ? GetViAltarEngineF3TestTexture()
        : GetViAltarGeneratedF3TestTexture();
    if (altar == null || !altar.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    int near1X = previewX + forwardX;
    int near1Y = previewY + forwardY;
    int near2X = previewX + forwardX * 2;
    int near2Y = previewY + forwardY * 2;
    int wallTileX = previewX + forwardX * 3;
    int wallTileY = previewY + forwardY * 3;
    if (!previewMiniMap.IsInside(near1X, near1Y)
        || previewMiniMap.GetTile(near1X, near1Y).Type
            == DungeonTileType.Wall
        || !previewMiniMap.IsInside(near2X, near2Y)
        || previewMiniMap.GetTile(near2X, near2Y).Type
            == DungeonTileType.Wall
        || !previewMiniMap.IsInside(wallTileX, wallTileY)
        || previewMiniMap.GetTile(wallTileX, wallTileY).Type
            != DungeonTileType.Wall)
    {
      return;
    }

    string visiblePhysicalWallFace =
        OppositeFacingName(previewFacing);

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (ornament == null
          || !string.Equals(
              ornament.type,
              "ViAltar",
              System.StringComparison.OrdinalIgnoreCase))
      {
        continue;
      }

      if (ornament.x != wallTileX
          || ornament.y != wallTileY
          || !string.Equals(
              ornament.wall,
              visiblePhysicalWallFace,
              System.StringComparison.OrdinalIgnoreCase))
      {
        continue;
      }

      int altarX = previewUseEngineViAltarSlots
          ? ViAltarEngineF3FrontX
          : ViAltarWallOrnamentSet.f3.x;
      int altarY = previewUseEngineViAltarSlots
          ? ViAltarEngineF3FrontY
          : ViAltarWallOrnamentSet.f3.y;
      BlitPieceIntoPreview(
          pixels,
          altar,
          altarX,
          altarY,
          false);
      return;
    }
  }

  private void BlitViAltarD1FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D altar = GetViAltarFrontTexture();
    if (altar == null || !altar.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    int wallTileX = previewX + forwardX;
    int wallTileY = previewY + forwardY;
    if (!previewMiniMap.IsInside(wallTileX, wallTileY)
        || previewMiniMap.GetTile(wallTileX, wallTileY).Type
            != DungeonTileType.Wall)
    {
      return;
    }

    string visiblePhysicalWallFace =
        OppositeFacingName(previewFacing);

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (ornament == null
          || !string.Equals(
              ornament.type,
              "ViAltar",
              System.StringComparison.OrdinalIgnoreCase))
      {
        continue;
      }

      if (ornament.x != wallTileX
          || ornament.y != wallTileY
          || !string.Equals(
              ornament.wall,
              visiblePhysicalWallFace,
              System.StringComparison.OrdinalIgnoreCase))
      {
        continue;
      }

      BlitPieceIntoPreview(
          pixels,
          altar,
          ViAltarD1FrontX,
          ViAltarD1FrontY,
          false);
      return;
    }
  }

  private Texture2D GetViAltarFrontTexture()
  {
    if (cachedViAltarFrontTexture != null)
      return cachedViAltarFrontTexture;

    string[] guids = AssetDatabase.FindAssets(
        "t:Texture2D",
        new[] { "Assets" });

    Texture2D best = null;
    int bestScore = int.MinValue;
    for (int i = 0; i < guids.Length; i++)
    {
      string path = AssetDatabase.GUIDToAssetPath(guids[i]);
      Texture2D candidate =
          AssetDatabase.LoadAssetAtPath<Texture2D>(path);
      if (candidate == null
          || candidate.width != 96
          || candidate.height != 56)
      {
        continue;
      }

      string lower = Path.GetFileNameWithoutExtension(path)
          .ToLowerInvariant();
      if (!lower.Contains("altar") || !lower.Contains("vi"))
        continue;

      int score = 100;
      if (lower.Contains("altar_of_vi")) score += 50;
      if (lower.Contains("96x56") || lower.Contains("96,56")) score += 25;
      if (score <= bestScore)
        continue;

      best = candidate;
      bestScore = score;
    }

    cachedViAltarFrontTexture = best;
    return cachedViAltarFrontTexture;
  }


  // Original Dungeon Master wall-ornament distance colour maps recovered
  // from the wall-decoration data. These maps are shared by the generic
  // wall-ornament renderer; the ornament's coordinate set supplies the target
  // rectangle, while the depth selects Medium (F2) or Far (F3).
  // Stored values 0,10,20,...150 become final 4-bit palette indices / 10.
  private static readonly byte[] WallOrnamentMediumColorMap =
  {
    0, 12, 1, 3,
    4, 3, 6, 7,
    5, 9, 10, 11,
    0, 2, 14, 13
  };

  private static readonly byte[] WallOrnamentFarColorMap =
  {
    0, 0, 12, 3,
    4, 3, 0, 6,
    3, 9, 10, 11,
    0, 1, 0, 2
  };

  private struct WallOrnamentDepthSlot
  {
    public int width;
    public int height;
    public int x;
    public int y;

    public WallOrnamentDepthSlot(int width, int height, int x, int y)
    {
      this.width = width;
      this.height = height;
      this.x = x;
      this.y = y;
    }
  }

  private struct WallOrnamentCoordinateSet
  {
    public WallOrnamentDepthSlot f1;
    public WallOrnamentDepthSlot f2;
    public WallOrnamentDepthSlot f3;

    public WallOrnamentCoordinateSet(
        WallOrnamentDepthSlot f1,
        WallOrnamentDepthSlot f2,
        WallOrnamentDepthSlot f3)
    {
      this.f1 = f1;
      this.f2 = f2;
      this.f3 = f3;
    }
  }

  // First generic coordinate-set profile: VI Altar.
  // These are the currently visually verified/tuned original-DM targets.
  // Adding another wall ornament should mean defining another coordinate set,
  // not adding another scaling algorithm.
  private static readonly WallOrnamentCoordinateSet ViAltarWallOrnamentSet =
      new WallOrnamentCoordinateSet(
          new WallOrnamentDepthSlot(
              96, 56, ViAltarD1FrontX, ViAltarD1FrontY),
          new WallOrnamentDepthSlot(
              63, 37, ViAltarD2GeneratedFrontX, ViAltarD2GeneratedFrontY),
          new WallOrnamentDepthSlot(
              42, 24, ViAltarD3GeneratedFrontX, ViAltarD3GeneratedFrontY));


  // Generic wall-ornament coordinate profile: Champion Mirror front.
  // F2 is the first non-altar validation of the shared renderer.
  // F3 is recorded here for the next test, but its existing path is left
  // untouched in this change.
  private static readonly WallOrnamentCoordinateSet ChampionMirrorFrontWallOrnamentSet =
      new WallOrnamentCoordinateSet(
          new WallOrnamentDepthSlot(
              48, 43, ChampionMirrorD1FrontX, ChampionMirrorD1FrontY),
          new WallOrnamentDepthSlot(
              ChampionMirrorD2FrontWidth,
              ChampionMirrorD2FrontHeight,
              ChampionMirrorD2FrontX,
              ChampionMirrorD2FrontY),
          new WallOrnamentDepthSlot(
              ChampionMirrorD3FrontWidth,
              ChampionMirrorD3FrontHeight,
              ChampionMirrorD3FrontX,
              ChampionMirrorD3FrontY));


  // Generic wall-ornament coordinate profile: Hook front.
  // F2 is generated from the single 28x28 F1 source.
  private static readonly WallOrnamentCoordinateSet HookFrontWallOrnamentSet =
      new WallOrnamentCoordinateSet(
          new WallOrnamentDepthSlot(
              28, 28, HookD1FrontX, HookD1FrontY),
          new WallOrnamentDepthSlot(
              HookD2FrontWidth,
              HookD2FrontHeight,
              HookD2FrontX,
              HookD2FrontY),
          new WallOrnamentDepthSlot(
              HookD3FrontWidth,
              HookD3FrontHeight,
              HookD3FrontX,
              HookD3FrontY));

  /// <summary>
  /// Shared generated wall-ornament path.
  /// The source art stays ornament-specific, but the scaling/palette algorithm
  /// is common. The coordinate set supplies the depth-specific destination size.
  /// </summary>
  private static Texture2D GenerateWallOrnamentForDepth(
      Texture2D source,
      WallOrnamentDepthSlot slot,
      byte[] colorMap,
      string textureName)
  {
    return GenerateDmScaledWallDecoration(
        source,
        slot.width,
        slot.height,
        colorMap,
        textureName);
  }

  private static void BlitWallOrnamentIntoPreview(
      Color32[] dest,
      Texture2D source,
      int destinationX,
      int destinationY,
      bool mirrorHorizontally = false)
  {
    if (source == null || !source.isReadable)
      return;

    Color32[] sourcePixels = source.GetPixels32();

    for (int sourceY = 0; sourceY < source.height; sourceY++)
    {
      int targetY = destinationY + sourceY;
      if (targetY < 0 || targetY >= PreviewHeight)
        continue;

      for (int column = 0; column < source.width; column++)
      {
        int sourceX = mirrorHorizontally
            ? source.width - 1 - column
            : column;
        int targetX = destinationX + column;

        // Generic dungeon-wall rule: never paint into the HUD/right UI area.
        if (targetX < 0 || targetX >= DungeonViewportWidth)
          continue;

        Color32 sourceColour =
            sourcePixels[sourceY * source.width + sourceX];
        if (sourceColour.a == 0)
          continue;

        dest[targetY * PreviewWidth + targetX] = sourceColour;
      }
    }
  }

  /// <summary>
  /// VI Altar F2 scaled from the 96x56 F1 altar with the medium colour map.
  /// </summary>
  private Texture2D GetViAltarGeneratedF2TestTexture()
  {
    if (cachedViAltarGeneratedF2TestTexture != null)
      return cachedViAltarGeneratedF2TestTexture;

    Texture2D source = GetViAltarFrontTexture();
    if (source == null || !source.isReadable)
      return null;

    cachedViAltarGeneratedF2TestTexture =
        GenerateWallOrnamentForDepth(
            source,
            ViAltarWallOrnamentSet.f2,
            WallOrnamentMediumColorMap,
            "VI Altar F2 Generated from F1");
    return cachedViAltarGeneratedF2TestTexture;
  }

  /// <summary>
  /// VI Altar F3 original-DM comparison test.
  /// Generate F3 directly from the full-size F1 altar and compare a
  /// 42x24 result against the original screenshot.
  /// </summary>
  private Texture2D GetViAltarGeneratedF3TestTexture()
  {
    if (cachedViAltarGeneratedF3TestTexture != null)
      return cachedViAltarGeneratedF3TestTexture;

    Texture2D source = GetViAltarFrontTexture();
    if (source == null || !source.isReadable)
      return null;

    cachedViAltarGeneratedF3TestTexture =
        GenerateWallOrnamentForDepth(
            source,
            ViAltarWallOrnamentSet.f3,
            WallOrnamentFarColorMap,
            "VI Altar F3 Generated from F1 42x24");
    return cachedViAltarGeneratedF3TestTexture;
  }

  /// <summary>
  /// ViewEdit test. Shrinks the 96x56 extract into the original F2 slot,
  /// 64x37, with the medium-distance colour map.
  /// </summary>
  private Texture2D GetViAltarEngineF2TestTexture()
  {
    if (cachedViAltarEngineF2TestTexture != null)
      return cachedViAltarEngineF2TestTexture;

    Texture2D source = GetViAltarFrontTexture();
    if (source == null || !source.isReadable)
      return null;

    cachedViAltarEngineF2TestTexture = GenerateDmScaledWallDecoration(
        source,
        ViAltarEngineF2Width,
        ViAltarEngineF2Height,
        WallOrnamentMediumColorMap,
        "VI Altar Engine F2 64x37");
    return cachedViAltarEngineF2TestTexture;
  }

  /// <summary>
  /// ViewEdit test. Shrinks the 96x56 extract into the measured F3 slot,
  /// 42x24, with the far-distance colour map.
  /// </summary>
  private Texture2D GetViAltarEngineF3TestTexture()
  {
    if (cachedViAltarEngineF3TestTexture != null)
      return cachedViAltarEngineF3TestTexture;

    Texture2D source = GetViAltarFrontTexture();
    if (source == null || !source.isReadable)
      return null;

    cachedViAltarEngineF3TestTexture = GenerateDmScaledWallDecoration(
        source,
        ViAltarEngineF3Width,
        ViAltarEngineF3Height,
        WallOrnamentFarColorMap,
        "VI Altar Engine F3 42x24");
    return cachedViAltarEngineF3TestTexture;
  }

  /// <summary>
  /// Applies a Dungeon Master distance colour map to an already-sized wall
  /// decoration. Pixel positions are preserved 1:1; there is no scaling.
  /// </summary>
  private static Texture2D ApplyDmWallDecorationColorMap(
      Texture2D source,
      byte[] colorMap,
      string textureName)
  {
    if (source == null
        || !source.isReadable
        || colorMap == null
        || colorMap.Length < 16)
    {
      return null;
    }

    Color32[] sourcePixels = source.GetPixels32();
    Color32[] targetPixels = new Color32[sourcePixels.Length];
    Color32[] brightPalette = DungeonViewportLightPalettes[0];

    for (int i = 0; i < sourcePixels.Length; i++)
    {
      Color32 sourcePixel = sourcePixels[i];
      if (sourcePixel.a == 0)
      {
        targetPixels[i] = new Color32(0, 0, 0, 0);
        continue;
      }

      int sourcePaletteIndex = FindExactDmPaletteIndexOrNearest(
          sourcePixel,
          brightPalette);
      int mappedPaletteIndex = colorMap[sourcePaletteIndex];
      mappedPaletteIndex = Mathf.Clamp(mappedPaletteIndex, 0, 15);

      // Original wall-decoration blit uses palette index 10 as transparent.
      if (mappedPaletteIndex == 10)
      {
        targetPixels[i] = new Color32(0, 0, 0, 0);
        continue;
      }

      Color32 mapped = brightPalette[mappedPaletteIndex];
      mapped.a = sourcePixel.a;
      targetPixels[i] = mapped;
    }

    Texture2D generated = new Texture2D(
        source.width,
        source.height,
        TextureFormat.RGBA32,
        false);
    generated.name = textureName;
    generated.filterMode = FilterMode.Point;
    generated.wrapMode = TextureWrapMode.Clamp;
    generated.SetPixels32(targetPixels);
    generated.Apply(false, false);
    return generated;
  }


  /// <summary>
  /// Unity-friendly port of CSBwin Graphics.cpp ShrinkBLT for an already
  /// unpacked RGBA source texture. The original routine samples a 4-bit
  /// planar bitmap with 16.16 fixed-point stepping. We reproduce the exact
  /// source-coordinate sequence and colour-map lookup, then emulate the
  /// original wall-decoration blit transparency key (palette index 10).
  /// </summary>
  private static Texture2D CropWallDecorationToOpaqueBounds(Texture2D source)
  {
    if (source == null || !source.isReadable)
      return source;

    Color32[] pixels = source.GetPixels32();
    int width = source.width;
    int height = source.height;
    int minX = width;
    int minY = height;
    int maxX = -1;
    int maxY = -1;

    for (int y = 0; y < height; y++)
    {
      int row = y * width;
      for (int x = 0; x < width; x++)
      {
        if (pixels[row + x].a == 0)
          continue;

        if (x < minX)
          minX = x;
        if (x > maxX)
          maxX = x;
        if (y < minY)
          minY = y;
        if (y > maxY)
          maxY = y;
      }
    }

    if (maxX < minX || maxY < minY)
      return source;

    int cropWidth = maxX - minX + 1;
    int cropHeight = maxY - minY + 1;
    if (cropWidth == width && cropHeight == height)
      return source;

    Color32[] croppedPixels = new Color32[cropWidth * cropHeight];
    for (int y = 0; y < cropHeight; y++)
    {
      int sourceRow = (minY + y) * width + minX;
      int targetRow = y * cropWidth;
      for (int x = 0; x < cropWidth; x++)
        croppedPixels[targetRow + x] = pixels[sourceRow + x];
    }

    Texture2D cropped = new Texture2D(
        cropWidth,
        cropHeight,
        TextureFormat.RGBA32,
        false);
    cropped.name = source.name + " Opaque";
    cropped.filterMode = FilterMode.Point;
    cropped.wrapMode = TextureWrapMode.Clamp;
    cropped.SetPixels32(croppedPixels);
    cropped.Apply(false, false);
    return cropped;
  }

  private static Texture2D GenerateDmScaledWallDecoration(
      Texture2D source,
      int targetWidth,
      int targetHeight,
      byte[] colorMap,
      string textureName,
      int? roundBiasOverride = null)
  {
    if (source == null
        || !source.isReadable
        || targetWidth <= 0
        || targetHeight <= 0
        || colorMap == null
        || colorMap.Length < 16)
    {
      return null;
    }

    Color32[] sourcePixels = source.GetPixels32();
    Color32[] targetPixels = new Color32[targetWidth * targetHeight];

    // CSBwin ShrinkBLT:
    // step = (((sourceSize << 10) / destinationSize) << 6)
    //      = floor(sourceSize * 65536 / destinationSize)
    // The integer source coordinate is the upper 16 bits of the accumulator.
    // F2 keeps the rounded start (step/2 + 0x7fff). F3 uses step/2 alone:
    // the extra round pulls in the gray highlight row (which the far map
    // turns black) and the green pixels beside the yellow gems.
    int stepX = ((source.width << 10) / targetWidth) << 6;
    int stepY = ((source.height << 10) / targetHeight) << 6;
    bool farDistance = ReferenceEquals(colorMap, WallOrnamentFarColorMap);
    int roundBias = roundBiasOverride ?? (farDistance ? 0 : 0x7fff);
    int startX = (stepX >> 1) + roundBias;
    int startY = (stepY >> 1) + roundBias;

    Color32[] brightPalette = DungeonViewportLightPalettes[0];

    for (int y = 0; y < targetHeight; y++)
    {
      int sourceY = (startY + y * stepY) >> 16;
      sourceY = Mathf.Clamp(sourceY, 0, source.height - 1);
      int sourceRow = sourceY * source.width;
      int targetRow = y * targetWidth;

      for (int x = 0; x < targetWidth; x++)
      {
        int sourceX = (startX + x * stepX) >> 16;
        sourceX = Mathf.Clamp(sourceX, 0, source.width - 1);

        Color32 sourcePixel = sourcePixels[sourceRow + sourceX];
        if (sourcePixel.a == 0)
        {
          targetPixels[targetRow + x] = new Color32(0, 0, 0, 0);
          continue;
        }

        int sourcePaletteIndex = FindExactDmPaletteIndexOrNearest(
            sourcePixel,
            brightPalette);
        int mappedPaletteIndex = colorMap[sourcePaletteIndex];
        mappedPaletteIndex = Mathf.Clamp(mappedPaletteIndex, 0, 15);

        // CSBwin DrawWallDecoration() does not blit the ShrinkBLT result
        // opaquely. It calls TAG0088b2(..., transparentColor: 10).
        // Therefore palette index 10 in the distance-scaled bitmap is a
        // transparency key and must reveal the wall behind the ornament.
        if (mappedPaletteIndex == 10)
        {
          targetPixels[targetRow + x] = new Color32(0, 0, 0, 0);
          continue;
        }

        Color32 mapped = brightPalette[mappedPaletteIndex];
        mapped.a = sourcePixel.a;
        targetPixels[targetRow + x] = mapped;
      }
    }

    if (farDistance)
      MatchFarTopRowBlackToNeighbors(targetPixels, targetWidth, targetHeight);

    Texture2D generated = new Texture2D(
        targetWidth,
        targetHeight,
        TextureFormat.RGBA32,
        false);
    generated.name = textureName;
    generated.filterMode = FilterMode.Point;
    generated.wrapMode = TextureWrapMode.Clamp;
    generated.SetPixels32(targetPixels);
    generated.Apply(false, false);
    return generated;
  }

  /// <summary>
  /// The far-distance map turns a few gray samples on the top edge black.
  /// Those pixels should keep the colour of the other pixels on that row.
  /// A fully black top row is cleared so the wall colour shows through.
  /// </summary>
  private static void MatchFarTopRowBlackToNeighbors(
      Color32[] pixels,
      int width,
      int height)
  {
    int row = (height - 1) * width;
    for (int x = 0; x < width; x++)
    {
      Color32 pixel = pixels[row + x];
      if (pixel.a == 0 || pixel.r != 0 || pixel.g != 0 || pixel.b != 0)
        continue;

      bool found = false;
      Color32 replacement = pixel;
      for (int distance = 1; distance < width; distance++)
      {
        int left = x - distance;
        if (left >= 0 && IsOpaqueNonBlack(pixels[row + left]))
        {
          replacement = pixels[row + left];
          found = true;
          break;
        }

        int right = x + distance;
        if (right < width && IsOpaqueNonBlack(pixels[row + right]))
        {
          replacement = pixels[row + right];
          found = true;
          break;
        }
      }

      pixels[row + x] = found
          ? replacement
          : new Color32(0, 0, 0, 0);
    }
  }

  private static bool IsOpaqueNonBlack(Color32 pixel)
  {
    return pixel.a != 0
        && (pixel.r != 0 || pixel.g != 0 || pixel.b != 0);
  }

  /// <summary>
  /// Recover exact original DM palette indices whenever the RGBA source pixel
  /// matches a known stage-1 palette colour. This is shared by generated wall
  /// ornaments; nearest-colour matching is only a fallback for unexpected RGBs.
  /// </summary>
  private static int FindExactDmPaletteIndexOrNearest(
      Color32 source,
      Color32[] palette)
  {
    if (TryGetExactDmPaletteIndex(source, out int exactPaletteIndex))
      return exactPaletteIndex;

    return FindNearestDmPaletteIndexFallback(source, palette);
  }

  private static bool TryGetExactDmPaletteIndex(
      Color32 source,
      out int paletteIndex)
  {
    // Ignore alpha for the source-palette lookup. Imported textures may carry
    // alpha 254 on some opaque pixels, but their RGB still identifies the
    // exact original DM palette colour.
    int rgb = (source.r << 16) | (source.g << 8) | source.b;
    switch (rgb)
    {
      case (0 << 16) | (0 << 8) | 0:
        paletteIndex = 0;
        return true;
      case (109 << 16) | (109 << 8) | 109:
        paletteIndex = 1;
        return true;
      case (146 << 16) | (146 << 8) | 146:
        paletteIndex = 2;
        return true;
      case (0 << 16) | (146 << 8) | 0:
        paletteIndex = 6;
        return true;
      case (0 << 16) | (219 << 8) | 0:
        paletteIndex = 7;
        return true;
      case (255 << 16) | (0 << 8) | 0:
        paletteIndex = 8;
        return true;
      case (219 << 16) | (146 << 8) | 109:
        paletteIndex = 10;
        return true;
      case (255 << 16) | (255 << 8) | 0:
        paletteIndex = 11;
        return true;
      case (73 << 16) | (73 << 8) | 73:
        paletteIndex = 12;
        return true;
      case (182 << 16) | (182 << 8) | 182:
        paletteIndex = 13;
        return true;
      case (255 << 16) | (255 << 8) | 255:
        paletteIndex = 15;
        return true;
      default:
        paletteIndex = 0;
        return false;
    }
  }

  private static int FindNearestDmPaletteIndexFallback(
      Color32 source,
      Color32[] palette)
  {
    int bestPaletteIndex = 0;
    int bestDistance = int.MaxValue;

    for (int paletteIndex = 0; paletteIndex < 16; paletteIndex++)
    {
      Color32 candidate = palette[paletteIndex];
      int dr = source.r - candidate.r;
      int dg = source.g - candidate.g;
      int db = source.b - candidate.b;
      int distance = dr * dr + dg * dg + db * db;
      if (distance >= bestDistance)
        continue;

      bestDistance = distance;
      bestPaletteIndex = paletteIndex;
      if (distance == 0)
        break;
    }

    return bestPaletteIndex;
  }

  private void BlitSlimeD1FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D slimeFront = GetSlimeFrontTexture();
    if (slimeFront == null || !slimeFront.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    int wallTileX = previewX + forwardX;
    int wallTileY = previewY + forwardY;
    if (!previewMiniMap.IsInside(wallTileX, wallTileY)
        || previewMiniMap.GetTile(wallTileX, wallTileY).Type
            != DungeonTileType.Wall)
    {
      return;
    }

    string viewedWallSide = FacingName(previewFacing);

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsSlimeOrnament(ornament))
        continue;

      bool placementMatches;
      if (ornament.wallTilePlacement)
      {
        string visiblePhysicalWallFace = OppositeFacingName(previewFacing);
        placementMatches =
            ornament.x == wallTileX
            && ornament.y == wallTileY
            && string.Equals(
                ornament.wall,
                visiblePhysicalWallFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        placementMatches =
            ornament.x == previewX
            && ornament.y == previewY
            && string.Equals(
                ornament.wall,
                viewedWallSide,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (!placementMatches)
        continue;

      // Same D1 front wall-center anchor used by the verified Hook/Wood Ring.
      // Native Slime front PNG is drawn 1:1.
      // Original-vs-Unity comparison at (4,5) East showed the sprite shape
      // and X position were already exact, but Unity was 59 screen pixels too
      // high. Preview framebuffer Y runs opposite the screen direction here,
      // so move the ornament anchor from Y=114 down to framebuffer Y=55.
      int x = 112 - (slimeFront.width / 2);
      int y = 55 - (slimeFront.height / 2);

      BlitPieceIntoPreview(
          pixels,
          slimeFront,
          x,
          y,
          false);
      return;
    }
  }

  private static bool IsSlimeOrnament(WallOrnamentPlacement ornament)
  {
    if (ornament == null)
      return false;

    if (string.Equals(
            ornament.type,
            "Slime",
            System.StringComparison.OrdinalIgnoreCase))
    {
      return true;
    }

    return ResolveHallOfChampionsWallOrnamentSourceId(ornament) == 33;
  }

  private Texture2D GetSlimeFrontTexture()
  {
    if (cachedSlimeFrontTexture != null)
      return cachedSlimeFrontTexture;

    string[] guids = AssetDatabase.FindAssets(
        "Slime t:Texture2D",
        new[] { OrnamentArtFolder });

    Texture2D fallback = null;
    for (int i = 0; i < guids.Length; i++)
    {
      string path = AssetDatabase.GUIDToAssetPath(guids[i]);
      string lower = path.ToLowerInvariant();
      if (!lower.Contains("slime"))
        continue;

      Texture2D candidate = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
      if (candidate == null)
        continue;

      if (lower.Contains("front"))
      {
        cachedSlimeFrontTexture = candidate;
        return candidate;
      }

      if (fallback == null && !lower.Contains("side"))
        fallback = candidate;
    }

    cachedSlimeFrontTexture = fallback;
    return fallback;
  }

  private Texture2D GetSlimeSide1Texture()
  {
    if (cachedSlimeSide1Texture != null)
      return cachedSlimeSide1Texture;

    Texture2D exact = AssetDatabase.LoadAssetAtPath<Texture2D>(
        SlimeSide1AssetPath);
    if (exact != null && exact.width == 16 && exact.height == 10)
    {
      cachedSlimeSide1Texture = exact;
      return exact;
    }

    string[] guids = AssetDatabase.FindAssets(
        "Slime t:Texture2D",
        new[] { OrnamentArtFolder });
    for (int i = 0; i < guids.Length; i++)
    {
      string assetPath = AssetDatabase.GUIDToAssetPath(guids[i]);
      string lower = assetPath.ToLowerInvariant();
      if (!lower.Contains("slime") || !lower.Contains("side"))
        continue;

      Texture2D candidate = AssetDatabase.LoadAssetAtPath<Texture2D>(assetPath);
      if (candidate != null
          && candidate.width == 16
          && candidate.height == 10)
      {
        cachedSlimeSide1Texture = candidate;
        return candidate;
      }
    }

    return null;
  }

  private Texture2D GetSlimeSide2Texture()
  {
    if (cachedSlimeSide2Texture != null)
      return cachedSlimeSide2Texture;

    Texture2D source = GetSlimeSide1Texture();
    if (source == null || !source.isReadable)
      return null;

    cachedSlimeSide2Texture = GenerateDmScaledWallDecoration(
        source,
        4,
        3,
        WallOrnamentMediumColorMap,
        "Slime Side F2 Generated from F1");
    return cachedSlimeSide2Texture;
  }

  private void BlitSlimeD1SidesIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D side1 = GetSlimeSide1Texture();
    if (side1 == null
        || !side1.isReadable
        || side1.width != 16
        || side1.height != 10)
    {
      return;
    }

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    int frontX = previewX + forwardX;
    int frontY = previewY + forwardY;
    if (!previewMiniMap.IsInside(frontX, frontY)
        || previewMiniMap.GetTile(frontX, frontY).Type == DungeonTileType.Wall)
    {
      return;
    }

    int leftWallTileX = frontX - rightX;
    int leftWallTileY = frontY - rightY;
    int rightWallTileX = frontX + rightX;
    int rightWallTileY = frontY + rightY;

    bool leftWallExists =
        previewMiniMap.IsInside(leftWallTileX, leftWallTileY)
        && previewMiniMap.GetTile(leftWallTileX, leftWallTileY).Type
            == DungeonTileType.Wall;
    bool rightWallExists =
        previewMiniMap.IsInside(rightWallTileX, rightWallTileY)
        && previewMiniMap.GetTile(rightWallTileX, rightWallTileY).Type
            == DungeonTileType.Wall;

    string leftPhysicalFace =
        FacingName(TurnPreviewFacingRight(previewFacing));
    string rightPhysicalFace =
        FacingName(TurnPreviewFacingLeft(previewFacing));

    string leftBoundaryDirection =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string rightBoundaryDirection =
        FacingName(TurnPreviewFacingRight(previewFacing));

    bool leftDrawn = false;
    bool rightDrawn = false;

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsSlimeOrnament(ornament))
        continue;

      bool matchesLeft;
      bool matchesRight;
      if (ornament.wallTilePlacement)
      {
        matchesLeft =
            leftWallExists
            && ornament.x == leftWallTileX
            && ornament.y == leftWallTileY
            && string.Equals(
                ornament.wall,
                leftPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == rightWallTileX
            && ornament.y == rightWallTileY
            && string.Equals(
                ornament.wall,
                rightPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        matchesLeft =
            leftWallExists
            && ornament.x == frontX
            && ornament.y == frontY
            && string.Equals(
                ornament.wall,
                leftBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == frontX
            && ornament.y == frontY
            && string.Equals(
                ornament.wall,
                rightBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (matchesLeft && !leftDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            side1,
            SlimeD1SideLeftX,
            SlimeD1SideY,
            false);
        leftDrawn = true;
      }

      if (matchesRight && !rightDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            side1,
            SlimeD1SideRightX,
            SlimeD1SideY,
            true);
        rightDrawn = true;
      }

      if (leftDrawn && rightDrawn)
        return;
    }
  }

  private void BlitSlimeD2SidesIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D side2 = GetSlimeSide2Texture();
    if (side2 == null
        || !side2.isReadable
        || side2.width != 4
        || side2.height != 3)
    {
      return;
    }

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    int d1CenterX = previewX + forwardX;
    int d1CenterY = previewY + forwardY;
    int d2CenterX = previewX + forwardX * 2;
    int d2CenterY = previewY + forwardY * 2;
    if (!previewMiniMap.IsInside(d1CenterX, d1CenterY)
        || previewMiniMap.GetTile(d1CenterX, d1CenterY).Type
            == DungeonTileType.Wall
        || !previewMiniMap.IsInside(d2CenterX, d2CenterY)
        || previewMiniMap.GetTile(d2CenterX, d2CenterY).Type
            == DungeonTileType.Wall)
    {
      return;
    }

    int leftWallTileX = d2CenterX - rightX;
    int leftWallTileY = d2CenterY - rightY;
    int rightWallTileX = d2CenterX + rightX;
    int rightWallTileY = d2CenterY + rightY;

    bool leftWallExists =
        previewMiniMap.IsInside(leftWallTileX, leftWallTileY)
        && previewMiniMap.GetTile(leftWallTileX, leftWallTileY).Type
            == DungeonTileType.Wall;
    bool rightWallExists =
        previewMiniMap.IsInside(rightWallTileX, rightWallTileY)
        && previewMiniMap.GetTile(rightWallTileX, rightWallTileY).Type
            == DungeonTileType.Wall;

    string leftPhysicalFace =
        FacingName(TurnPreviewFacingRight(previewFacing));
    string rightPhysicalFace =
        FacingName(TurnPreviewFacingLeft(previewFacing));

    string leftBoundaryDirection =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string rightBoundaryDirection =
        FacingName(TurnPreviewFacingRight(previewFacing));

    bool leftDrawn = false;
    bool rightDrawn = false;

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsSlimeOrnament(ornament))
        continue;

      bool matchesLeft;
      bool matchesRight;
      if (ornament.wallTilePlacement)
      {
        matchesLeft =
            leftWallExists
            && ornament.x == leftWallTileX
            && ornament.y == leftWallTileY
            && string.Equals(
                ornament.wall,
                leftPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == rightWallTileX
            && ornament.y == rightWallTileY
            && string.Equals(
                ornament.wall,
                rightPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        matchesLeft =
            leftWallExists
            && ornament.x == d2CenterX
            && ornament.y == d2CenterY
            && string.Equals(
                ornament.wall,
                leftBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == d2CenterX
            && ornament.y == d2CenterY
            && string.Equals(
                ornament.wall,
                rightBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (matchesLeft && !leftDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            side2,
            SlimeD2SideLeftX,
            SlimeD2SideY,
            true);
        leftDrawn = true;
      }

      if (matchesRight && !rightDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            side2,
            SlimeD2SideRightX,
            SlimeD2SideY,
            false);
        rightDrawn = true;
      }

      if (leftDrawn && rightDrawn)
        return;
    }
  }

  private void BlitWoodRingD3SidesIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D side3 = GetWoodRingSide3Texture();
    if (side3 == null
        || !side3.isReadable
        || side3.width != 3
        || side3.height != 5)
    {
      return;
    }

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    // D3 side face is visible only through open D1, D2 and D3 center cells.
    int d1CenterX = previewX + forwardX;
    int d1CenterY = previewY + forwardY;
    int d2CenterX = previewX + forwardX * 2;
    int d2CenterY = previewY + forwardY * 2;
    int d3CenterX = previewX + forwardX * 3;
    int d3CenterY = previewY + forwardY * 3;

    if (!previewMiniMap.IsInside(d1CenterX, d1CenterY)
        || previewMiniMap.GetTile(d1CenterX, d1CenterY).Type
            == DungeonTileType.Wall
        || !previewMiniMap.IsInside(d2CenterX, d2CenterY)
        || previewMiniMap.GetTile(d2CenterX, d2CenterY).Type
            == DungeonTileType.Wall
        || !previewMiniMap.IsInside(d3CenterX, d3CenterY)
        || previewMiniMap.GetTile(d3CenterX, d3CenterY).Type
            == DungeonTileType.Wall)
    {
      return;
    }

    int leftWallTileX = d3CenterX - rightX;
    int leftWallTileY = d3CenterY - rightY;
    int rightWallTileX = d3CenterX + rightX;
    int rightWallTileY = d3CenterY + rightY;

    bool leftWallExists =
        previewMiniMap.IsInside(leftWallTileX, leftWallTileY)
        && previewMiniMap.GetTile(leftWallTileX, leftWallTileY).Type
            == DungeonTileType.Wall;
    bool rightWallExists =
        previewMiniMap.IsInside(rightWallTileX, rightWallTileY)
        && previewMiniMap.GetTile(rightWallTileX, rightWallTileY).Type
            == DungeonTileType.Wall;

    string leftPhysicalFace =
        FacingName(TurnPreviewFacingRight(previewFacing));
    string rightPhysicalFace =
        FacingName(TurnPreviewFacingLeft(previewFacing));

    string leftBoundaryDirection =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string rightBoundaryDirection =
        FacingName(TurnPreviewFacingRight(previewFacing));

    bool leftDrawn = false;
    bool rightDrawn = false;

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsWoodRingOrnament(ornament))
        continue;

      bool matchesLeft;
      bool matchesRight;
      if (ornament.wallTilePlacement)
      {
        matchesLeft =
            leftWallExists
            && ornament.x == leftWallTileX
            && ornament.y == leftWallTileY
            && string.Equals(
                ornament.wall,
                leftPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == rightWallTileX
            && ornament.y == rightWallTileY
            && string.Equals(
                ornament.wall,
                rightPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        matchesLeft =
            leftWallExists
            && ornament.x == d3CenterX
            && ornament.y == d3CenterY
            && string.Equals(
                ornament.wall,
                leftBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == d3CenterX
            && ornament.y == d3CenterY
            && string.Equals(
                ornament.wall,
                rightBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (matchesLeft && !leftDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            side3,
            WoodRingD3SideLeftX,
            WoodRingD3SideY,
            false);
        leftDrawn = true;
      }

      if (matchesRight && !rightDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            side3,
            WoodRingD3SideRightX,
            WoodRingD3SideY,
            true);
        rightDrawn = true;
      }

      if (leftDrawn && rightDrawn)
        return;
    }
  }

  private void BlitWoodRingD2SidesIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D side2 = GetWoodRingSide2Texture();
    if (side2 == null
        || !side2.isReadable
        || side2.width != 5
        || side2.height != 10)
    {
      return;
    }

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    // The D2 side face is visible only through open D1 and D2 center cells.
    int d1CenterX = previewX + forwardX;
    int d1CenterY = previewY + forwardY;
    int d2CenterX = previewX + forwardX * 2;
    int d2CenterY = previewY + forwardY * 2;
    if (!previewMiniMap.IsInside(d1CenterX, d1CenterY)
        || previewMiniMap.GetTile(d1CenterX, d1CenterY).Type
            == DungeonTileType.Wall
        || !previewMiniMap.IsInside(d2CenterX, d2CenterY)
        || previewMiniMap.GetTile(d2CenterX, d2CenterY).Type
            == DungeonTileType.Wall)
    {
      return;
    }

    int leftWallTileX = d2CenterX - rightX;
    int leftWallTileY = d2CenterY - rightY;
    int rightWallTileX = d2CenterX + rightX;
    int rightWallTileY = d2CenterY + rightY;

    bool leftWallExists =
        previewMiniMap.IsInside(leftWallTileX, leftWallTileY)
        && previewMiniMap.GetTile(leftWallTileX, leftWallTileY).Type
            == DungeonTileType.Wall;
    bool rightWallExists =
        previewMiniMap.IsInside(rightWallTileX, rightWallTileY)
        && previewMiniMap.GetTile(rightWallTileX, rightWallTileY).Type
            == DungeonTileType.Wall;

    // Screen-left solid wall faces inward with TurnRight(viewFacing), while
    // screen-right faces inward with TurnLeft(viewFacing).
    string leftPhysicalFace =
        FacingName(TurnPreviewFacingRight(previewFacing));
    string rightPhysicalFace =
        FacingName(TurnPreviewFacingLeft(previewFacing));

    // Keep compatibility with legacy/passable-cell Sensor representation.
    string leftBoundaryDirection =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string rightBoundaryDirection =
        FacingName(TurnPreviewFacingRight(previewFacing));

    bool leftDrawn = false;
    bool rightDrawn = false;

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsWoodRingOrnament(ornament))
        continue;

      bool matchesLeft;
      bool matchesRight;
      if (ornament.wallTilePlacement)
      {
        matchesLeft =
            leftWallExists
            && ornament.x == leftWallTileX
            && ornament.y == leftWallTileY
            && string.Equals(
                ornament.wall,
                leftPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == rightWallTileX
            && ornament.y == rightWallTileY
            && string.Equals(
                ornament.wall,
                rightPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        matchesLeft =
            leftWallExists
            && ornament.x == d2CenterX
            && ornament.y == d2CenterY
            && string.Equals(
                ornament.wall,
                leftBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == d2CenterX
            && ornament.y == d2CenterY
            && string.Equals(
                ornament.wall,
                rightBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (matchesLeft && !leftDrawn)
      {
        // Native Side2 art is already the verified left-side perspective.
        BlitPieceIntoPreview(
            pixels,
            side2,
            WoodRingD2SideLeftX,
            WoodRingD2SideY,
            false);
        leftDrawn = true;
      }

      if (matchesRight && !rightDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            side2,
            WoodRingD2SideRightX,
            WoodRingD2SideY,
            true);
        rightDrawn = true;
      }

      if (leftDrawn && rightDrawn)
        return;
    }
  }

  private void BlitHookD3SidesIntoPreview(Color32[] pixels)
  {
    BlitHookSidesAtDistance(
        pixels,
        3,
        HookD3SideWidth,
        HookD3SideHeight,
        HookD3SideLeftX,
        HookD3SideRightX,
        HookD3SideY);
  }

  private void BlitHookD2SidesIntoPreview(Color32[] pixels)
  {
    BlitHookSidesAtDistance(
        pixels,
        2,
        HookD2SideWidth,
        HookD2SideHeight,
        HookD2SideLeftX,
        HookD2SideRightX,
        HookD2SideY);
  }

  private void BlitHookSidesAtDistance(
      Color32[] pixels,
      int distance,
      int destWidth,
      int destHeight,
      int leftX,
      int rightX,
      int y)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0
        || distance < 2
        || distance > 3)
    {
      return;
    }

    Texture2D side = distance == 3
        ? GetHookSide3Texture()
        : GetHookSide2Texture();
    if (side == null
        || !side.isReadable
        || side.width != destWidth
        || side.height != destHeight)
    {
      return;
    }

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightOffsetX,
        out int rightOffsetY);

    int d1CenterX = previewX + forwardX;
    int d1CenterY = previewY + forwardY;
    int d2CenterX = previewX + forwardX * 2;
    int d2CenterY = previewY + forwardY * 2;
    int d3CenterX = previewX + forwardX * 3;
    int d3CenterY = previewY + forwardY * 3;

    if (!PreviewTileIsOpen(d1CenterX, d1CenterY)
        || !PreviewTileIsOpen(d2CenterX, d2CenterY)
        || (distance >= 3 && !PreviewTileIsOpen(d3CenterX, d3CenterY)))
    {
      return;
    }

    int laneCenterX = distance == 3 ? d3CenterX : d2CenterX;
    int laneCenterY = distance == 3 ? d3CenterY : d2CenterY;
    int leftWallTileX = laneCenterX - rightOffsetX;
    int leftWallTileY = laneCenterY - rightOffsetY;
    int rightWallTileX = laneCenterX + rightOffsetX;
    int rightWallTileY = laneCenterY + rightOffsetY;

    bool leftWallExists = PreviewTileIsWall(leftWallTileX, leftWallTileY);
    bool rightWallExists = PreviewTileIsWall(rightWallTileX, rightWallTileY);

    string leftPhysicalFace =
        FacingName(TurnPreviewFacingRight(previewFacing));
    string rightPhysicalFace =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string leftBoundaryDirection =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string rightBoundaryDirection =
        FacingName(TurnPreviewFacingRight(previewFacing));

    bool leftDrawn = false;
    bool rightDrawn = false;

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsHookOrnament(ornament))
        continue;

      bool matchesLeft;
      bool matchesRight;
      if (ornament.wallTilePlacement)
      {
        matchesLeft =
            leftWallExists
            && ornament.x == leftWallTileX
            && ornament.y == leftWallTileY
            && string.Equals(
                ornament.wall,
                leftPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == rightWallTileX
            && ornament.y == rightWallTileY
            && string.Equals(
                ornament.wall,
                rightPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        matchesLeft =
            leftWallExists
            && ornament.x == laneCenterX
            && ornament.y == laneCenterY
            && string.Equals(
                ornament.wall,
                leftBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == laneCenterX
            && ornament.y == laneCenterY
            && string.Equals(
                ornament.wall,
                rightBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (matchesLeft && !leftDrawn)
      {
        // Supplied D2/D3 art is the right-wall crop, so the left slot is mirrored.
        BlitPieceIntoPreview(
            pixels,
            side,
            leftX,
            y,
            true);
        leftDrawn = true;
      }

      if (matchesRight && !rightDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            side,
            rightX,
            y,
            false);
        rightDrawn = true;
      }

      if (leftDrawn && rightDrawn)
        return;
    }
  }

  private void BlitHookStyleD1SidesIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    // D1 side faces are only visible through an open D1 center square.
    int frontX = previewX + forwardX;
    int frontY = previewY + forwardY;
    if (!previewMiniMap.IsInside(frontX, frontY)
        || previewMiniMap.GetTile(frontX, frontY).Type == DungeonTileType.Wall)
    {
      return;
    }

    int leftWallTileX = frontX - rightX;
    int leftWallTileY = frontY - rightY;
    int rightWallTileX = frontX + rightX;
    int rightWallTileY = frontY + rightY;

    bool leftWallExists =
        previewMiniMap.IsInside(leftWallTileX, leftWallTileY)
        && previewMiniMap.GetTile(leftWallTileX, leftWallTileY).Type
            == DungeonTileType.Wall;
    bool rightWallExists =
        previewMiniMap.IsInside(rightWallTileX, rightWallTileY)
        && previewMiniMap.GetTile(rightWallTileX, rightWallTileY).Type
            == DungeonTileType.Wall;

    // Physical faces on the solid wall tiles.
    string leftPhysicalFace =
        FacingName(TurnPreviewFacingRight(previewFacing));
    string rightPhysicalFace =
        FacingName(TurnPreviewFacingLeft(previewFacing));

    // Equivalent directions when an explicit Sensor is stored on the
    // passable D1 center tile instead of on the wall tile itself.
    string leftBoundaryDirection =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string rightBoundaryDirection =
        FacingName(TurnPreviewFacingRight(previewFacing));

    bool leftDrawn = false;
    bool rightDrawn = false;

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (ornament == null)
        continue;

      // Hook uses native 16x19 1:1; Wood Ring keeps its 14x19 cutout.
      Texture2D sideTexture = null;
      int sideY = HookD1SideY;
      int sideLeftX = HookD1SideLeftX;
      int sideRightX = HookD1SideRightX;
      int expectedWidth = 16;
      int expectedHeight = 19;
      if (IsHookOrnament(ornament))
      {
        sideTexture = GetHookSideTexture();
      }
      else if (IsWoodRingOrnament(ornament))
      {
        sideTexture = GetWoodRingSideTexture();
        sideY = WoodRingD1SideY;
        sideLeftX = WoodRingD1SideLeftX;
        sideRightX = WoodRingD1SideRightX;
        expectedWidth = 14;
      }
      else
      {
        continue;
      }

      if (sideTexture == null
          || !sideTexture.isReadable
          || sideTexture.width != expectedWidth
          || sideTexture.height != expectedHeight)
      {
        continue;
      }

      bool matchesLeft;
      bool matchesRight;
      if (ornament.wallTilePlacement)
      {
        matchesLeft =
            leftWallExists
            && ornament.x == leftWallTileX
            && ornament.y == leftWallTileY
            && string.Equals(
                ornament.wall,
                leftPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == rightWallTileX
            && ornament.y == rightWallTileY
            && string.Equals(
                ornament.wall,
                rightPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        matchesLeft =
            leftWallExists
            && ornament.x == frontX
            && ornament.y == frontY
            && string.Equals(
                ornament.wall,
                leftBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == frontX
            && ornament.y == frontY
            && string.Equals(
                ornament.wall,
                rightBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (matchesLeft && !leftDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            sideTexture,
            sideLeftX,
            sideY,
            false);
        leftDrawn = true;
      }

      if (matchesRight && !rightDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            sideTexture,
            sideRightX,
            sideY,
            true);
        rightDrawn = true;
      }

      if (leftDrawn && rightDrawn)
        return;
    }
  }

  private void BlitHookD2FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D hookFront = GetHookGeneratedF2FrontTexture();
    if (hookFront == null || !hookFront.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    int d1X = previewX + forwardX;
    int d1Y = previewY + forwardY;
    int wallTileX = previewX + forwardX * 2;
    int wallTileY = previewY + forwardY * 2;

    // The authoritative ornament database already tells us that the feature
    // belongs to a wall face. For F2 projection we only need an open D1 view
    // corridor and the ornament's normalized D2 position. Do not require the
    // minimap tile classifier to also call the D2 coordinate a Wall; that extra
    // gate can incorrectly hide valid wall ornaments.
    if (!previewMiniMap.IsInside(d1X, d1Y)
        || previewMiniMap.GetTile(d1X, d1Y).Type == DungeonTileType.Wall
        || !previewMiniMap.IsInside(wallTileX, wallTileY))
    {
      return;
    }

    string viewedWallSide = FacingName(previewFacing);
    string visiblePhysicalWallFace = OppositeFacingName(previewFacing);

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsHookOrnament(ornament))
        continue;

      bool placementMatches;
      if (ornament.wallTilePlacement)
      {
        placementMatches =
            ornament.x == wallTileX
            && ornament.y == wallTileY
            && string.Equals(
                ornament.wall,
                visiblePhysicalWallFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        // Explicit mechanisms at F2 are stored on the open cell one step
        // before the decorated wall boundary.
        placementMatches =
            ornament.x == d1X
            && ornament.y == d1Y
            && string.Equals(
                ornament.wall,
                viewedWallSide,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (!placementMatches)
        continue;

      BlitWallOrnamentIntoPreview(
          pixels,
          hookFront,
          HookFrontWallOrnamentSet.f2.x,
          HookFrontWallOrnamentSet.f2.y,
          false);
      return;
    }
  }

  private void BlitManaclesD2SidesIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D side = GetManaclesGeneratedD2SideTexture();
    if (side == null || !side.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    int d1X = previewX + forwardX;
    int d1Y = previewY + forwardY;
    int d2X = previewX + forwardX * 2;
    int d2Y = previewY + forwardY * 2;
    if (!PreviewTileIsOpen(d1X, d1Y) || !PreviewTileIsOpen(d2X, d2Y))
      return;

    int leftWallTileX = d2X - rightX;
    int leftWallTileY = d2Y - rightY;
    int rightWallTileX = d2X + rightX;
    int rightWallTileY = d2Y + rightY;
    bool leftWallExists = PreviewTileIsWall(leftWallTileX, leftWallTileY);
    bool rightWallExists = PreviewTileIsWall(rightWallTileX, rightWallTileY);

    string leftPhysicalFace =
        FacingName(TurnPreviewFacingRight(previewFacing));
    string rightPhysicalFace =
        FacingName(TurnPreviewFacingLeft(previewFacing));

    bool leftDrawn = false;
    bool rightDrawn = false;

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsManaclesOrnament(ornament) || !ornament.wallTilePlacement)
        continue;

      bool matchesLeft =
          leftWallExists
          && ornament.x == leftWallTileX
          && ornament.y == leftWallTileY
          && string.Equals(
              ornament.wall,
              leftPhysicalFace,
              System.StringComparison.OrdinalIgnoreCase);
      bool matchesRight =
          rightWallExists
          && ornament.x == rightWallTileX
          && ornament.y == rightWallTileY
          && string.Equals(
              ornament.wall,
              rightPhysicalFace,
              System.StringComparison.OrdinalIgnoreCase);

      if (matchesLeft && !leftDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            side,
            ManaclesD2SideLeftX,
            ManaclesD2SideY,
            false);
        leftDrawn = true;
      }

      if (matchesRight && !rightDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            side,
            ManaclesD2SideRightX,
            ManaclesD2SideY,
            true);
        rightDrawn = true;
      }

      if (leftDrawn && rightDrawn)
        return;
    }
  }

  private Texture2D GetManaclesGeneratedD2SideTexture()
  {
    if (cachedManaclesGeneratedD2SideTexture != null)
      return cachedManaclesGeneratedD2SideTexture;

    Texture2D source = GetManaclesS1Texture();
    if (source == null || !source.isReadable)
      return null;

    cachedManaclesGeneratedD2SideTexture = GenerateManaclesSideScaled(
        source,
        ManaclesD2SideWidth,
        ManaclesD2SideHeight,
        "Manacles S2 Generated from S1");
    return cachedManaclesGeneratedD2SideTexture;
  }

  // The shared wall-ornament shrink remaps this side graphic's metal greys
  // onto wall greys and samples through the chains, so the D2 shackles
  // draw as separate specks. Cover each destination pixel with the opaque
  // source colour that actually occupies that cell and keep the S1 palette.
  private static Texture2D GenerateManaclesSideScaled(
      Texture2D source,
      int targetWidth,
      int targetHeight,
      string textureName)
  {
    if (source == null
        || !source.isReadable
        || targetWidth <= 0
        || targetHeight <= 0)
    {
      return null;
    }

    Color32[] sourcePixels = source.GetPixels32();
    Color32[] targetPixels = new Color32[targetWidth * targetHeight];
    Color32[] palette = DungeonViewportLightPalettes[0];
    int sourceWidth = source.width;
    int sourceHeight = source.height;

    for (int y = 0; y < targetHeight; y++)
    {
      int sourceY0 = y * sourceHeight / targetHeight;
      int sourceY1 = (y + 1) * sourceHeight / targetHeight;
      if (sourceY1 <= sourceY0)
        sourceY1 = sourceY0 + 1;

      for (int x = 0; x < targetWidth; x++)
      {
        int sourceX0 = x * sourceWidth / targetWidth;
        int sourceX1 = (x + 1) * sourceWidth / targetWidth;
        if (sourceX1 <= sourceX0)
          sourceX1 = sourceX0 + 1;

        int[] counts = new int[16];
        int bestIndex = -1;
        int bestCount = 0;
        for (int sourceY = sourceY0; sourceY < sourceY1; sourceY++)
        {
          int sourceRow = sourceY * sourceWidth;
          for (int sourceX = sourceX0; sourceX < sourceX1; sourceX++)
          {
            Color32 sourcePixel = sourcePixels[sourceRow + sourceX];
            if (sourcePixel.a == 0)
              continue;

            int paletteIndex = FindExactDmPaletteIndexOrNearest(
                sourcePixel,
                palette);
            counts[paletteIndex]++;
            if (counts[paletteIndex] <= bestCount)
              continue;

            bestCount = counts[paletteIndex];
            bestIndex = paletteIndex;
          }
        }

        int destination = y * targetWidth + x;
        if (bestIndex < 0)
        {
          targetPixels[destination] = new Color32(0, 0, 0, 0);
          continue;
        }

        Color32 mapped = palette[bestIndex];
        mapped.a = 255;
        targetPixels[destination] = mapped;
      }
    }

    Texture2D generated = new Texture2D(
        targetWidth,
        targetHeight,
        TextureFormat.RGBA32,
        false);
    generated.name = textureName;
    generated.filterMode = FilterMode.Point;
    generated.wrapMode = TextureWrapMode.Clamp;
    generated.SetPixels32(targetPixels);
    generated.Apply(false, false);
    return generated;
  }

  private void BlitManaclesD1SidesIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D side = GetManaclesS1Texture();
    if (side == null || !side.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    int frontX = previewX + forwardX;
    int frontY = previewY + forwardY;
    if (!previewMiniMap.IsInside(frontX, frontY)
        || previewMiniMap.GetTile(frontX, frontY).Type == DungeonTileType.Wall)
    {
      return;
    }

    int leftWallTileX = frontX - rightX;
    int leftWallTileY = frontY - rightY;
    int rightWallTileX = frontX + rightX;
    int rightWallTileY = frontY + rightY;

    bool leftWallExists =
        previewMiniMap.IsInside(leftWallTileX, leftWallTileY)
        && previewMiniMap.GetTile(leftWallTileX, leftWallTileY).Type
            == DungeonTileType.Wall;
    bool rightWallExists =
        previewMiniMap.IsInside(rightWallTileX, rightWallTileY)
        && previewMiniMap.GetTile(rightWallTileX, rightWallTileY).Type
            == DungeonTileType.Wall;

    string leftPhysicalFace =
        FacingName(TurnPreviewFacingRight(previewFacing));
    string rightPhysicalFace =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string leftBoundaryDirection =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string rightBoundaryDirection =
        FacingName(TurnPreviewFacingRight(previewFacing));

    bool leftDrawn = false;
    bool rightDrawn = false;

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsManaclesOrnament(ornament))
        continue;

      bool matchesLeft;
      bool matchesRight;
      if (ornament.wallTilePlacement)
      {
        matchesLeft =
            leftWallExists
            && ornament.x == leftWallTileX
            && ornament.y == leftWallTileY
            && string.Equals(
                ornament.wall,
                leftPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == rightWallTileX
            && ornament.y == rightWallTileY
            && string.Equals(
                ornament.wall,
                rightPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        matchesLeft =
            leftWallExists
            && ornament.x == frontX
            && ornament.y == frontY
            && string.Equals(
                ornament.wall,
                leftBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == frontX
            && ornament.y == frontY
            && string.Equals(
                ornament.wall,
                rightBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (matchesLeft && !leftDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            side,
            ManaclesD1SideLeftX,
            ManaclesD1SideY,
            false);
        leftDrawn = true;
      }

      if (matchesRight && !rightDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            side,
            ManaclesD1SideRightX,
            ManaclesD1SideY,
            true);
        rightDrawn = true;
      }

      if (leftDrawn && rightDrawn)
        return;
    }
  }

  private Texture2D GetManaclesS1Texture()
  {
    if (cachedManaclesS1Texture != null)
      return cachedManaclesS1Texture;

    Texture2D texture =
        AssetDatabase.LoadAssetAtPath<Texture2D>(ManaclesS1AssetPath);
    if (texture != null
        && texture.width == ManaclesD1SideWidth
        && texture.height == ManaclesD1SideHeight)
    {
      cachedManaclesS1Texture = texture;
      return texture;
    }

    return null;
  }

  private void BlitManaclesD3FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D manacles = GetManaclesGeneratedF3FrontTexture();
    if (manacles == null || !manacles.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    int d1X = previewX + forwardX;
    int d1Y = previewY + forwardY;
    int d2X = previewX + forwardX * 2;
    int d2Y = previewY + forwardY * 2;
    int wallTileX = previewX + forwardX * 3;
    int wallTileY = previewY + forwardY * 3;

    // F3 manacles are on the wall three steps ahead. Both nearer cells
    // must stay open.
    if (!previewMiniMap.IsInside(d1X, d1Y)
        || previewMiniMap.GetTile(d1X, d1Y).Type == DungeonTileType.Wall
        || !previewMiniMap.IsInside(d2X, d2Y)
        || previewMiniMap.GetTile(d2X, d2Y).Type == DungeonTileType.Wall
        || !previewMiniMap.IsInside(wallTileX, wallTileY))
    {
      return;
    }

    string viewedWallSide = FacingName(previewFacing);
    string visiblePhysicalWallFace = OppositeFacingName(previewFacing);

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsManaclesOrnament(ornament))
        continue;

      bool placementMatches;
      if (ornament.wallTilePlacement)
      {
        placementMatches =
            ornament.x == wallTileX
            && ornament.y == wallTileY
            && string.Equals(
                ornament.wall,
                visiblePhysicalWallFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        placementMatches =
            ornament.x == d2X
            && ornament.y == d2Y
            && string.Equals(
                ornament.wall,
                viewedWallSide,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (!placementMatches)
        continue;

      BlitWallOrnamentIntoPreview(
          pixels,
          manacles,
          ManaclesD3FrontX,
          ManaclesD3FrontY,
          false);
      return;
    }
  }

  private Texture2D GetManaclesGeneratedF3FrontTexture()
  {
    if (cachedManaclesGeneratedF3FrontTexture != null)
      return cachedManaclesGeneratedF3FrontTexture;

    Texture2D source = GetManaclesF1Texture();
    if (source == null || !source.isReadable)
      return null;

    cachedManaclesGeneratedF3FrontTexture = GenerateDmScaledWallDecoration(
        source,
        ManaclesD3FrontWidth,
        ManaclesD3FrontHeight,
        WallOrnamentFarColorMap,
        "Manacles F3 Generated from F1");
    return cachedManaclesGeneratedF3FrontTexture;
  }

  private void BlitManaclesD2FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D manacles = GetManaclesGeneratedF2FrontTexture();
    if (manacles == null || !manacles.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    int d1X = previewX + forwardX;
    int d1Y = previewY + forwardY;
    int wallTileX = previewX + forwardX * 2;
    int wallTileY = previewY + forwardY * 2;

    // F2 manacles are on the wall two steps ahead. The one-step cell must
    // stay open or the nearer wall hides them.
    if (!previewMiniMap.IsInside(d1X, d1Y)
        || previewMiniMap.GetTile(d1X, d1Y).Type == DungeonTileType.Wall
        || !previewMiniMap.IsInside(wallTileX, wallTileY))
    {
      return;
    }

    string viewedWallSide = FacingName(previewFacing);
    string visiblePhysicalWallFace = OppositeFacingName(previewFacing);

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsManaclesOrnament(ornament))
        continue;

      bool placementMatches;
      if (ornament.wallTilePlacement)
      {
        placementMatches =
            ornament.x == wallTileX
            && ornament.y == wallTileY
            && string.Equals(
                ornament.wall,
                visiblePhysicalWallFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        placementMatches =
            ornament.x == d1X
            && ornament.y == d1Y
            && string.Equals(
                ornament.wall,
                viewedWallSide,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (!placementMatches)
        continue;

      BlitWallOrnamentIntoPreview(
          pixels,
          manacles,
          ManaclesD2FrontX,
          ManaclesD2FrontY,
          false);
      return;
    }
  }

  private Texture2D GetManaclesGeneratedF2FrontTexture()
  {
    if (cachedManaclesGeneratedF2FrontTexture != null)
      return cachedManaclesGeneratedF2FrontTexture;

    Texture2D source = GetManaclesF1Texture();
    if (source == null || !source.isReadable)
      return null;

    cachedManaclesGeneratedF2FrontTexture = GenerateDmScaledWallDecoration(
        source,
        ManaclesD2FrontWidth,
        ManaclesD2FrontHeight,
        WallOrnamentMediumColorMap,
        "Manacles F2 Generated from F1");
    return cachedManaclesGeneratedF2FrontTexture;
  }

  private void BlitManaclesD1FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D manacles = GetManaclesF1Texture();
    if (manacles == null || !manacles.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    int wallTileX = previewX + forwardX;
    int wallTileY = previewY + forwardY;
    if (!previewMiniMap.IsInside(wallTileX, wallTileY)
        || previewMiniMap.GetTile(wallTileX, wallTileY).Type
            != DungeonTileType.Wall)
    {
      return;
    }

    string viewedWallSide = FacingName(previewFacing);
    string visiblePhysicalWallFace = OppositeFacingName(previewFacing);

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsManaclesOrnament(ornament))
        continue;

      bool placementMatches;
      if (ornament.wallTilePlacement)
      {
        placementMatches =
            ornament.x == wallTileX
            && ornament.y == wallTileY
            && string.Equals(
                ornament.wall,
                visiblePhysicalWallFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        placementMatches =
            ornament.x == previewX
            && ornament.y == previewY
            && string.Equals(
                ornament.wall,
                viewedWallSide,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (!placementMatches)
        continue;

      // D1/front wall ornaments are centered on the 224px dungeon viewport.
      // Keep the native F1 artwork 1:1. The vertical anchor is shared by all
      // Manacles F1 placements and can be pixel-calibrated from the original.
      int destinationX = (DungeonViewportWidth - manacles.width) / 2;
      const int destinationY = 77;
      BlitWallOrnamentIntoPreview(
          pixels,
          manacles,
          destinationX,
          destinationY,
          false);
      return;
    }
  }

  private static bool IsManaclesOrnament(WallOrnamentPlacement ornament)
  {
    return ornament != null
        && !string.IsNullOrEmpty(ornament.type)
        && ornament.type.IndexOf(
            "Manacles",
            System.StringComparison.OrdinalIgnoreCase) >= 0;
  }

  private Texture2D GetManaclesF1Texture()
  {
    if (cachedManaclesF1Texture != null)
      return cachedManaclesF1Texture;

    Texture2D exact =
        AssetDatabase.LoadAssetAtPath<Texture2D>(ManaclesF1AssetPath);
    if (exact != null)
    {
      cachedManaclesF1Texture = exact;
      return exact;
    }

    // Filename-independent fallback in the ornament folder.
    string[] guids = AssetDatabase.FindAssets(
        "Manacles t:Texture2D",
        new[] { OrnamentArtFolder });
    for (int i = 0; i < guids.Length; i++)
    {
      string path = AssetDatabase.GUIDToAssetPath(guids[i]);
      Texture2D candidate = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
      if (candidate == null)
        continue;

      if (path.IndexOf(
              "manacles",
              System.StringComparison.OrdinalIgnoreCase) < 0
          || path.IndexOf(
              "f1",
              System.StringComparison.OrdinalIgnoreCase) < 0)
      {
        continue;
      }

      cachedManaclesF1Texture = candidate;
      return candidate;
    }

    return null;
  }

  private void BlitHookD1FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D hookFront = GetHookFrontTexture();
    if (hookFront == null || !hookFront.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    // A D1 front ornament can come from either an explicit mechanism on the
    // party's current passable cell or a decoration encoded on the solid wall
    // tile itself. In both cases the tile immediately ahead must be wall.
    int wallTileX = previewX + forwardX;
    int wallTileY = previewY + forwardY;
    if (!previewMiniMap.IsInside(wallTileX, wallTileY)
        || previewMiniMap.GetTile(wallTileX, wallTileY).Type
            != DungeonTileType.Wall)
    {
      return;
    }

    string viewedWallSide = FacingName(previewFacing);

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsHookOrnament(ornament))
        continue;

      bool placementMatches;
      if (ornament.wallTilePlacement)
      {
        // Random wall-decoration bits belong to the solid wall tile. When the
        // party looks North, for example, it sees that wall tile's South face.
        string visiblePhysicalWallFace = OppositeFacingName(previewFacing);
        placementMatches =
            ornament.x == wallTileX
            && ornament.y == wallTileY
            && string.Equals(
                ornament.wall,
                visiblePhysicalWallFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        // Explicit mechanisms are stored on the passable cell and use the
        // direction from that cell toward the wall boundary.
        placementMatches =
            ornament.x == previewX
            && ornament.y == previewY
            && string.Equals(
                ornament.wall,
                viewedWallSide,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (!placementMatches)
        continue;

      BlitPieceIntoPreview(
          pixels,
          hookFront,
          HookD1FrontX,
          HookD1FrontY,
          false);
      return;
    }
  }

  private static bool IsHookOrnament(WallOrnamentPlacement ornament)
  {
    if (ornament == null)
      return false;

    if (string.Equals(
            ornament.type,
            "Hook",
            System.StringComparison.OrdinalIgnoreCase))
    {
      return true;
    }

    // Explicit Sensor ordinals are level-local. On Hall of Champions local
    // ordinal 1 resolves to global wall ornament source ID 4 = Hook.
    return ResolveHallOfChampionsWallOrnamentSourceId(ornament) == 4;
  }

  private Texture2D GetHookGeneratedF2FrontTexture()
  {
    if (cachedHookGeneratedF2FrontTexture != null)
      return cachedHookGeneratedF2FrontTexture;

    Texture2D source = GetHookFrontTexture();
    if (source == null || !source.isReadable)
      return null;

    cachedHookGeneratedF2FrontTexture =
        GenerateWallOrnamentForDepth(
            source,
            HookFrontWallOrnamentSet.f2,
            WallOrnamentMediumColorMap,
            "Hook F2 Generated from F1");

    return cachedHookGeneratedF2FrontTexture;
  }

  private Texture2D GetHookFrontTexture()
  {
    if (cachedHookFrontTexture != null)
      return cachedHookFrontTexture;

    Texture2D texture =
        AssetDatabase.LoadAssetAtPath<Texture2D>(HookFrontAssetPath);
    if (texture != null && texture.width == 28 && texture.height == 28)
    {
      cachedHookFrontTexture = texture;
      return texture;
    }

    // Filename-independent fallback inside Assets/Art/Ornaments.
    string[] guids = AssetDatabase.FindAssets(
        "Hook t:Texture2D",
        new[] { OrnamentArtFolder });
    for (int i = 0; i < guids.Length; i++)
    {
      string path = AssetDatabase.GUIDToAssetPath(guids[i]);
      Texture2D candidate = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
      if (candidate == null || candidate.width != 28 || candidate.height != 28)
        continue;

      if (path.IndexOf(
              "hook",
              System.StringComparison.OrdinalIgnoreCase) < 0
          || path.IndexOf(
              "front",
              System.StringComparison.OrdinalIgnoreCase) < 0)
      {
        continue;
      }

      cachedHookFrontTexture = candidate;
      return candidate;
    }

    return null;
  }

  private Texture2D GetHookSideTexture()
  {
    if (cachedHookSideTexture != null)
      return cachedHookSideTexture;

    Texture2D texture =
        AssetDatabase.LoadAssetAtPath<Texture2D>(HookSideAssetPath);
    if (texture != null && texture.width == 16 && texture.height == 19)
    {
      cachedHookSideTexture = texture;
      return texture;
    }

    string[] guids = AssetDatabase.FindAssets(
        "Hook t:Texture2D",
        new[] { OrnamentArtFolder });
    for (int i = 0; i < guids.Length; i++)
    {
      string path = AssetDatabase.GUIDToAssetPath(guids[i]);
      Texture2D candidate = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
      if (candidate == null || candidate.width != 16 || candidate.height != 19)
        continue;

      if (path.IndexOf(
              "hook",
              System.StringComparison.OrdinalIgnoreCase) < 0
          || path.IndexOf(
              "side",
              System.StringComparison.OrdinalIgnoreCase) < 0)
      {
        continue;
      }

      cachedHookSideTexture = candidate;
      return candidate;
    }

    return null;
  }

  private Texture2D GetHookSide2Texture()
  {
    if (cachedHookSide2Texture != null)
      return cachedHookSide2Texture;

    Texture2D source = GetHookSideTexture();
    if (source == null || !source.isReadable)
      return null;

    cachedHookSide2Texture = GenerateDmScaledWallDecoration(
        source,
        HookD2SideWidth,
        HookD2SideHeight,
        WallOrnamentMediumColorMap,
        "Hook Side F2 Generated from F1");
    return cachedHookSide2Texture;
  }

  private Texture2D GetHookSide3Texture()
  {
    if (cachedHookSide3Texture != null)
      return cachedHookSide3Texture;

    Texture2D source = GetHookSideTexture();
    if (source == null || !source.isReadable)
      return null;

    cachedHookSide3Texture = GenerateDmScaledWallDecoration(
        source,
        HookD3SideWidth,
        HookD3SideHeight,
        WallOrnamentFarColorMap,
        "Hook Side F3 Generated from F1");
    return cachedHookSide3Texture;
  }

  private void BlitGrateD3SidesIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D side3 = GetGrateSide3Texture();
    if (side3 == null
        || !side3.isReadable
        || side3.width != 4
        || side3.height != 4)
    {
      return;
    }

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    // D3 side faces are visible only through open D1, D2, and D3 centers.
    int d1CenterX = previewX + forwardX;
    int d1CenterY = previewY + forwardY;
    int d2CenterX = previewX + forwardX * 2;
    int d2CenterY = previewY + forwardY * 2;
    int d3CenterX = previewX + forwardX * 3;
    int d3CenterY = previewY + forwardY * 3;
    if (!previewMiniMap.IsInside(d1CenterX, d1CenterY)
        || previewMiniMap.GetTile(d1CenterX, d1CenterY).Type
            == DungeonTileType.Wall
        || !previewMiniMap.IsInside(d2CenterX, d2CenterY)
        || previewMiniMap.GetTile(d2CenterX, d2CenterY).Type
            == DungeonTileType.Wall
        || !previewMiniMap.IsInside(d3CenterX, d3CenterY)
        || previewMiniMap.GetTile(d3CenterX, d3CenterY).Type
            == DungeonTileType.Wall)
    {
      return;
    }

    int leftWallTileX = d3CenterX - rightX;
    int leftWallTileY = d3CenterY - rightY;
    int rightWallTileX = d3CenterX + rightX;
    int rightWallTileY = d3CenterY + rightY;

    bool leftWallExists =
        previewMiniMap.IsInside(leftWallTileX, leftWallTileY)
        && previewMiniMap.GetTile(leftWallTileX, leftWallTileY).Type
            == DungeonTileType.Wall;
    bool rightWallExists =
        previewMiniMap.IsInside(rightWallTileX, rightWallTileY)
        && previewMiniMap.GetTile(rightWallTileX, rightWallTileY).Type
            == DungeonTileType.Wall;

    string leftPhysicalFace =
        FacingName(TurnPreviewFacingRight(previewFacing));
    string rightPhysicalFace =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string leftBoundaryDirection =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string rightBoundaryDirection =
        FacingName(TurnPreviewFacingRight(previewFacing));

    bool leftDrawn = false;
    bool rightDrawn = false;

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsGrateOrnament(ornament))
        continue;

      bool matchesLeft;
      bool matchesRight;
      if (ornament.wallTilePlacement)
      {
        matchesLeft =
            leftWallExists
            && ornament.x == leftWallTileX
            && ornament.y == leftWallTileY
            && string.Equals(
                ornament.wall,
                leftPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == rightWallTileX
            && ornament.y == rightWallTileY
            && string.Equals(
                ornament.wall,
                rightPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        matchesLeft =
            leftWallExists
            && ornament.x == d3CenterX
            && ornament.y == d3CenterY
            && string.Equals(
                ornament.wall,
                leftBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == d3CenterX
            && ornament.y == d3CenterY
            && string.Equals(
                ornament.wall,
                rightBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (matchesLeft && !leftDrawn)
      {
        // Native Side3 art is the left-wall perspective.
        BlitPieceIntoPreview(
            pixels,
            side3,
            GrateD3SideLeftX,
            GrateD3SideY,
            GetPreviewFeatureMirrorValue(ornament, false));
        leftDrawn = true;
      }

      if (matchesRight && !rightDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            side3,
            GrateD3SideRightX,
            GrateD3SideY,
            GetPreviewFeatureMirrorValue(ornament, true));
        rightDrawn = true;
      }

      if (leftDrawn && rightDrawn)
        return;
    }
  }

  private Texture2D GetGrateSide3Texture()
  {
    if (cachedGrateSide3Texture != null)
      return cachedGrateSide3Texture;

    Texture2D source = GetGrateSide1Texture();
    if (source == null || !source.isReadable)
      return null;

    cachedGrateSide3Texture = GenerateDmScaledWallDecoration(
        source,
        4,
        4,
        WallOrnamentFarColorMap,
        "Grate Side F3 Generated from F1");
    return cachedGrateSide3Texture;
  }

  private void BlitGrateD2SidesIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D side2 = GetGrateSide2Texture();
    if (side2 == null
        || !side2.isReadable
        || side2.width != 6
        || side2.height != 11)
    {
      return;
    }

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    // D2 side faces are visible only through open D1 and D2 center cells.
    int d1CenterX = previewX + forwardX;
    int d1CenterY = previewY + forwardY;
    int d2CenterX = previewX + forwardX * 2;
    int d2CenterY = previewY + forwardY * 2;
    if (!previewMiniMap.IsInside(d1CenterX, d1CenterY)
        || previewMiniMap.GetTile(d1CenterX, d1CenterY).Type
            == DungeonTileType.Wall
        || !previewMiniMap.IsInside(d2CenterX, d2CenterY)
        || previewMiniMap.GetTile(d2CenterX, d2CenterY).Type
            == DungeonTileType.Wall)
    {
      return;
    }

    int leftWallTileX = d2CenterX - rightX;
    int leftWallTileY = d2CenterY - rightY;
    int rightWallTileX = d2CenterX + rightX;
    int rightWallTileY = d2CenterY + rightY;

    bool leftWallExists =
        previewMiniMap.IsInside(leftWallTileX, leftWallTileY)
        && previewMiniMap.GetTile(leftWallTileX, leftWallTileY).Type
            == DungeonTileType.Wall;
    bool rightWallExists =
        previewMiniMap.IsInside(rightWallTileX, rightWallTileY)
        && previewMiniMap.GetTile(rightWallTileX, rightWallTileY).Type
            == DungeonTileType.Wall;

    string leftPhysicalFace =
        FacingName(TurnPreviewFacingRight(previewFacing));
    string rightPhysicalFace =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string leftBoundaryDirection =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string rightBoundaryDirection =
        FacingName(TurnPreviewFacingRight(previewFacing));

    bool leftDrawn = false;
    bool rightDrawn = false;

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsGrateOrnament(ornament))
        continue;

      bool matchesLeft;
      bool matchesRight;
      if (ornament.wallTilePlacement)
      {
        matchesLeft =
            leftWallExists
            && ornament.x == leftWallTileX
            && ornament.y == leftWallTileY
            && string.Equals(
                ornament.wall,
                leftPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == rightWallTileX
            && ornament.y == rightWallTileY
            && string.Equals(
                ornament.wall,
                rightPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        matchesLeft =
            leftWallExists
            && ornament.x == d2CenterX
            && ornament.y == d2CenterY
            && string.Equals(
                ornament.wall,
                leftBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == d2CenterX
            && ornament.y == d2CenterY
            && string.Equals(
                ornament.wall,
                rightBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (matchesLeft && !leftDrawn)
      {
        // Native Side2 art is the left-wall perspective.
        BlitPieceIntoPreview(
            pixels,
            side2,
            GrateD2SideLeftX,
            GrateD2SideY,
            GetPreviewFeatureMirrorValue(ornament, false));
        leftDrawn = true;
      }

      if (matchesRight && !rightDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            side2,
            GrateD2SideRightX,
            GrateD2SideY,
            GetPreviewFeatureMirrorValue(ornament, true));
        rightDrawn = true;
      }

      if (leftDrawn && rightDrawn)
        return;
    }
  }

  private Texture2D GetGrateSide2Texture()
  {
    if (cachedGrateSide2Texture != null)
      return cachedGrateSide2Texture;

    Texture2D source = GetGrateSide1Texture();
    if (source == null || !source.isReadable)
      return null;

    cachedGrateSide2Texture = GenerateDmScaledWallDecoration(
        source,
        6,
        11,
        WallOrnamentMediumColorMap,
        "Grate Side F2 Generated from F1");
    return cachedGrateSide2Texture;
  }

  private void BlitGrateD1SidesIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D side1 = GetGrateSide1Texture();
    if (side1 == null
        || !side1.isReadable
        || side1.width != 16
        || side1.height != 19)
    {
      return;
    }

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);
    DungeonMap.GetRightOffset(
        previewFacing,
        out int rightX,
        out int rightY);

    // D1 side faces are visible only when the square directly ahead is open.
    int frontX = previewX + forwardX;
    int frontY = previewY + forwardY;
    if (!previewMiniMap.IsInside(frontX, frontY)
        || previewMiniMap.GetTile(frontX, frontY).Type == DungeonTileType.Wall)
    {
      return;
    }

    int leftWallTileX = frontX - rightX;
    int leftWallTileY = frontY - rightY;
    int rightWallTileX = frontX + rightX;
    int rightWallTileY = frontY + rightY;

    bool leftWallExists =
        previewMiniMap.IsInside(leftWallTileX, leftWallTileY)
        && previewMiniMap.GetTile(leftWallTileX, leftWallTileY).Type
            == DungeonTileType.Wall;
    bool rightWallExists =
        previewMiniMap.IsInside(rightWallTileX, rightWallTileY)
        && previewMiniMap.GetTile(rightWallTileX, rightWallTileY).Type
            == DungeonTileType.Wall;

    string leftPhysicalFace =
        FacingName(TurnPreviewFacingRight(previewFacing));
    string rightPhysicalFace =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string leftBoundaryDirection =
        FacingName(TurnPreviewFacingLeft(previewFacing));
    string rightBoundaryDirection =
        FacingName(TurnPreviewFacingRight(previewFacing));

    bool leftDrawn = false;
    bool rightDrawn = false;

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsGrateOrnament(ornament))
        continue;

      bool matchesLeft;
      bool matchesRight;
      if (ornament.wallTilePlacement)
      {
        matchesLeft =
            leftWallExists
            && ornament.x == leftWallTileX
            && ornament.y == leftWallTileY
            && string.Equals(
                ornament.wall,
                leftPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == rightWallTileX
            && ornament.y == rightWallTileY
            && string.Equals(
                ornament.wall,
                rightPhysicalFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        matchesLeft =
            leftWallExists
            && ornament.x == frontX
            && ornament.y == frontY
            && string.Equals(
                ornament.wall,
                leftBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
        matchesRight =
            rightWallExists
            && ornament.x == frontX
            && ornament.y == frontY
            && string.Equals(
                ornament.wall,
                rightBoundaryDirection,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (matchesLeft && !leftDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            side1,
            GrateD1SideLeftX,
            GrateD1SideY,
            GetPreviewFeatureMirrorValue(ornament, false));
        leftDrawn = true;
      }

      if (matchesRight && !rightDrawn)
      {
        BlitPieceIntoPreview(
            pixels,
            side1,
            GrateD1SideRightX,
            GrateD1SideY,
            GetPreviewFeatureMirrorValue(ornament, true));
        rightDrawn = true;
      }

      if (leftDrawn && rightDrawn)
        return;
    }
  }

  private Texture2D GetGrateSide1Texture()
  {
    if (cachedGrateSide1Texture != null)
      return cachedGrateSide1Texture;

    Texture2D texture =
        AssetDatabase.LoadAssetAtPath<Texture2D>(GrateSide1AssetPath);
    if (texture != null && texture.width == 16 && texture.height == 19)
    {
      cachedGrateSide1Texture = texture;
      return texture;
    }

    string[] guids = AssetDatabase.FindAssets(
        "Grate t:Texture2D",
        new[] { OrnamentArtFolder });
    for (int i = 0; i < guids.Length; i++)
    {
      string path = AssetDatabase.GUIDToAssetPath(guids[i]);
      Texture2D candidate = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
      if (candidate == null || candidate.width != 16 || candidate.height != 19)
        continue;

      string lower = path.ToLowerInvariant();
      if (!lower.Contains("grate") || !lower.Contains("side1"))
        continue;

      cachedGrateSide1Texture = candidate;
      return candidate;
    }

    return null;
  }

  private void BlitGrateD3FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D grateFront = GetGrateFront3Texture();
    if (grateFront == null
        || !grateFront.isReadable
        || grateFront.width != 14
        || grateFront.height != 9)
    {
      return;
    }

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    // F3 front is the wall three steps ahead, seen through open D1 and D2.
    int d1X = previewX + forwardX;
    int d1Y = previewY + forwardY;
    int d2X = previewX + forwardX * 2;
    int d2Y = previewY + forwardY * 2;
    int wallTileX = previewX + forwardX * 3;
    int wallTileY = previewY + forwardY * 3;
    if (!previewMiniMap.IsInside(d1X, d1Y)
        || previewMiniMap.GetTile(d1X, d1Y).Type == DungeonTileType.Wall
        || !previewMiniMap.IsInside(d2X, d2Y)
        || previewMiniMap.GetTile(d2X, d2Y).Type == DungeonTileType.Wall
        || !previewMiniMap.IsInside(wallTileX, wallTileY)
        || previewMiniMap.GetTile(wallTileX, wallTileY).Type
            != DungeonTileType.Wall)
    {
      return;
    }

    string viewedWallSide = FacingName(previewFacing);

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsGrateOrnament(ornament))
        continue;

      bool placementMatches;
      if (ornament.wallTilePlacement)
      {
        string visiblePhysicalWallFace = OppositeFacingName(previewFacing);
        placementMatches =
            ornament.x == wallTileX
            && ornament.y == wallTileY
            && string.Equals(
                ornament.wall,
                visiblePhysicalWallFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        placementMatches =
            ornament.x == d2X
            && ornament.y == d2Y
            && string.Equals(
                ornament.wall,
                viewedWallSide,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (!placementMatches)
        continue;

      BlitPieceIntoPreview(
          pixels,
          grateFront,
          GrateD3FrontX,
          GrateD3FrontY,
          GetPreviewFeatureMirrorValue(ornament, false));
      return;
    }
  }

  private Texture2D GetGrateFront3Texture()
  {
    if (cachedGrateFront3Texture != null)
      return cachedGrateFront3Texture;

    Texture2D source = GetGrateFrontTexture();
    if (source == null || !source.isReadable)
      return null;

    cachedGrateFront3Texture = GenerateDmScaledWallDecoration(
        source,
        14,
        9,
        WallOrnamentFarColorMap,
        "Grate F3 Generated from F1");
    return cachedGrateFront3Texture;
  }

  private void BlitGrateD2FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D grateFront = GetGrateFront2Texture();
    if (grateFront == null
        || !grateFront.isReadable
        || grateFront.width != 21
        || grateFront.height != 13)
    {
      return;
    }

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    // F2 front is the wall two steps ahead, seen through an open D1 cell.
    int openX = previewX + forwardX;
    int openY = previewY + forwardY;
    int wallTileX = previewX + forwardX * 2;
    int wallTileY = previewY + forwardY * 2;
    if (!previewMiniMap.IsInside(openX, openY)
        || previewMiniMap.GetTile(openX, openY).Type == DungeonTileType.Wall
        || !previewMiniMap.IsInside(wallTileX, wallTileY)
        || previewMiniMap.GetTile(wallTileX, wallTileY).Type
            != DungeonTileType.Wall)
    {
      return;
    }

    string viewedWallSide = FacingName(previewFacing);

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsGrateOrnament(ornament))
        continue;

      bool placementMatches;
      if (ornament.wallTilePlacement)
      {
        string visiblePhysicalWallFace = OppositeFacingName(previewFacing);
        placementMatches =
            ornament.x == wallTileX
            && ornament.y == wallTileY
            && string.Equals(
                ornament.wall,
                visiblePhysicalWallFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        placementMatches =
            ornament.x == openX
            && ornament.y == openY
            && string.Equals(
                ornament.wall,
                viewedWallSide,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (!placementMatches)
        continue;

      BlitPieceIntoPreview(
          pixels,
          grateFront,
          GrateD2FrontX,
          GrateD2FrontY,
          GetPreviewFeatureMirrorValue(ornament, false));
      return;
    }
  }

  private Texture2D GetGrateFront2Texture()
  {
    if (cachedGrateFront2Texture != null)
      return cachedGrateFront2Texture;

    Texture2D source = GetGrateFrontTexture();
    if (source == null || !source.isReadable)
      return null;

    cachedGrateFront2Texture = GenerateDmScaledWallDecoration(
        source,
        21,
        13,
        WallOrnamentMediumColorMap,
        "Grate F2 Generated from F1");
    return cachedGrateFront2Texture;
  }

  private void BlitGrateD1FrontIntoPreview(Color32[] pixels)
  {
    EnsurePreviewMiniMapLoaded();
    if (previewMiniMap == null
        || previewWallOrnaments == null
        || previewWallOrnaments.Length == 0)
    {
      return;
    }

    Texture2D grateFront = GetGrateFrontTexture();
    if (grateFront == null || !grateFront.isReadable)
      return;

    DungeonMap.GetForwardOffset(
        previewFacing,
        out int forwardX,
        out int forwardY);

    int wallTileX = previewX + forwardX;
    int wallTileY = previewY + forwardY;
    if (!previewMiniMap.IsInside(wallTileX, wallTileY)
        || previewMiniMap.GetTile(wallTileX, wallTileY).Type
            != DungeonTileType.Wall)
    {
      return;
    }

    string viewedWallSide = FacingName(previewFacing);

    for (int i = 0; i < previewWallOrnaments.Length; i++)
    {
      WallOrnamentPlacement ornament = previewWallOrnaments[i];
      if (ornament != null
          && !IsPreviewFeatureEnabled(
              MakePreviewFeatureKey("Ornament", ornament.x, ornament.y, ornament.wall)))
        continue;
      if (!IsGrateOrnament(ornament))
        continue;

      bool placementMatches;
      if (ornament.wallTilePlacement)
      {
        string visiblePhysicalWallFace = OppositeFacingName(previewFacing);
        placementMatches =
            ornament.x == wallTileX
            && ornament.y == wallTileY
            && string.Equals(
                ornament.wall,
                visiblePhysicalWallFace,
                System.StringComparison.OrdinalIgnoreCase);
      }
      else
      {
        placementMatches =
            ornament.x == previewX
            && ornament.y == previewY
            && string.Equals(
                ornament.wall,
                viewedWallSide,
                System.StringComparison.OrdinalIgnoreCase);
      }

      if (!placementMatches)
        continue;

      BlitPieceIntoPreview(
          pixels,
          grateFront,
          GrateD1FrontX,
          GrateD1FrontY,
          GetPreviewFeatureMirrorValue(ornament, false));
      return;
    }
  }

  private bool GetPreviewFeatureMirrorValue(
      WallOrnamentPlacement ornament,
      bool defaultMirror)
  {
    if (ornament == null)
      return defaultMirror;

    string key = MakePreviewFeatureKey(
        "Ornament", ornament.x, ornament.y, ornament.wall);
    return previewFeatureMirrorOverrides.TryGetValue(key, out bool value)
        ? value
        : defaultMirror;
  }

  private static bool IsGrateOrnament(WallOrnamentPlacement ornament)
  {
    if (ornament == null)
      return false;

    if (string.Equals(
            ornament.type,
            "Grate",
            System.StringComparison.OrdinalIgnoreCase))
    {
      return true;
    }

    // Hall of Champions local ordinal 3 -> global source ID 34 = Grate.
    return ResolveHallOfChampionsWallOrnamentSourceId(ornament) == 34;
  }

  private Texture2D GetGrateFrontTexture()
  {
    if (cachedGrateFrontTexture != null)
      return cachedGrateFrontTexture;

    Texture2D texture =
        AssetDatabase.LoadAssetAtPath<Texture2D>(GrateFrontAssetPath);
    if (texture != null && texture.width == 32 && texture.height == 28)
    {
      cachedGrateFrontTexture = texture;
      return texture;
    }

    string[] guids = AssetDatabase.FindAssets(
        "Grate t:Texture2D",
        new[] { OrnamentArtFolder });
    for (int i = 0; i < guids.Length; i++)
    {
      string path = AssetDatabase.GUIDToAssetPath(guids[i]);
      Texture2D candidate = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
      if (candidate == null || candidate.width != 32 || candidate.height != 28)
        continue;

      if (path.IndexOf(
              "grate",
              System.StringComparison.OrdinalIgnoreCase) < 0
          || path.IndexOf(
              "front",
              System.StringComparison.OrdinalIgnoreCase) < 0)
      {
        continue;
      }

      cachedGrateFrontTexture = candidate;
      return candidate;
    }

    return texture;
  }

  private static string FacingName(DungeonFacing facing)
  {
    return facing switch
    {
      DungeonFacing.North => "North",
      DungeonFacing.East => "East",
      DungeonFacing.South => "South",
      DungeonFacing.West => "West",
      _ => string.Empty
    };
  }

  private static string OppositeFacingName(DungeonFacing facing)
  {
    return facing switch
    {
      DungeonFacing.North => "South",
      DungeonFacing.East => "West",
      DungeonFacing.South => "North",
      DungeonFacing.West => "East",
      _ => string.Empty
    };
  }

  private static void BlitPieceIntoPreview(
      Color32[] dest,
      Texture2D source,
      int destinationX,
      int destinationY,
      bool mirrorHorizontally = false)
  {
    if (!source.isReadable)
      return;

    Color32[] sourcePixels = source.GetPixels32();

    for (int sourceY = 0; sourceY < source.height; sourceY++)
    {
      int targetY = destinationY + sourceY;
      if (targetY < 0 || targetY >= PreviewHeight)
        continue;

      for (int column = 0; column < source.width; column++)
      {
        int sourceX = mirrorHorizontally
            ? source.width - 1 - column
            : column;
        int targetX = destinationX + column;

        // Dungeon/map graphics are clipped to the original 224-pixel viewport.
        // Right-side walls may extend geometrically past X=223, but they must
        // never paint into the HUD / magenta border at X>=224.
        if (targetX < 0 || targetX >= DungeonViewportWidth)
          continue;

        Color32 sourceColour =
            sourcePixels[sourceY * source.width + sourceX];
        if (sourceColour.a == 0)
          continue;

        dest[targetY * PreviewWidth + targetX] = sourceColour;
      }
    }
  }

  private static void BlitPieceScaledIntoPreview(
      Color32[] dest,
      Texture2D source,
      int destinationX,
      int destinationY,
      int destWidth,
      int destHeight,
      bool mirrorHorizontally = false,
      bool skipCyanTransparencyKey = false,
      byte[] colorMap = null)
  {
    if (source == null)
      return;

    BlitPieceScaledIntoPreview(
        dest,
        source,
        destinationX,
        destinationY,
        destWidth,
        destHeight,
        mirrorHorizontally,
        0,
        0,
        source.width,
        source.height,
        skipCyanTransparencyKey,
        colorMap);
  }

  private static void BlitPieceScaledIntoPreview(
      Color32[] dest,
      Texture2D source,
      int destinationX,
      int destinationY,
      int destWidth,
      int destHeight,
      bool mirrorHorizontally,
      int sourceX,
      int sourceY,
      int sourceWidth,
      int sourceHeight,
      bool skipCyanTransparencyKey = false,
      byte[] colorMap = null)
  {
    if (!source.isReadable
        || destWidth <= 0
        || destHeight <= 0
        || sourceWidth <= 0
        || sourceHeight <= 0)
    {
      return;
    }

    Color32[] sourcePixels = source.GetPixels32();

    for (int destRow = 0; destRow < destHeight; destRow++)
    {
      int targetY = destinationY + destRow;
      if (targetY < 0 || targetY >= PreviewHeight)
        continue;

      int sampleY = sourceY + destRow * sourceHeight / destHeight;
      if (sampleY < 0 || sampleY >= source.height)
        continue;

      for (int destCol = 0; destCol < destWidth; destCol++)
      {
        int offsetX = destCol * sourceWidth / destWidth;
        int sampleX = mirrorHorizontally
            ? sourceX + sourceWidth - 1 - offsetX
            : sourceX + offsetX;
        if (sampleX < 0 || sampleX >= source.width)
          continue;

        int targetX = destinationX + destCol;

        // Scaled dungeon/map graphics obey the same hard X=224 viewport clip.
        if (targetX < 0 || targetX >= DungeonViewportWidth)
          continue;

        Color32 sourceColour =
            sourcePixels[sampleY * source.width + sampleX];
        if (sourceColour.a == 0)
          continue;

        // Some original Dungeon Master item artwork uses pure cyan as its
        // transparency key instead of alpha. Keep this opt-in so wall and
        // ornament scaling is unchanged; generated floor-item depths can
        // discard the key colour before writing into the framebuffer.
        if (skipCyanTransparencyKey
            && sourceColour.r == 0
            && sourceColour.g == 255
            && sourceColour.b == 255)
        {
          continue;
        }

        // Optional Dungeon Master distance-palette remap. The F2 apple uses
        // the recovered Medium map, which turns the bright source red into
        // the darker brown/orange seen in the original DOS F2 view.
        if (colorMap != null && colorMap.Length >= 16)
        {
          Color32[] brightPalette = DungeonViewportLightPalettes[0];
          int sourcePaletteIndex =
              FindExactDmPaletteIndexOrNearest(sourceColour, brightPalette);
          int mappedPaletteIndex =
              Mathf.Clamp(colorMap[sourcePaletteIndex], 0, 15);
          sourceColour = brightPalette[mappedPaletteIndex];
        }

        dest[targetY * PreviewWidth + targetX] = sourceColour;
      }
    }
  }

  private void StealViewportTextureIfNeeded(RawImage dungeonImage)
  {
    if (viewportTextureStolen)
      return;

    savedViewportTexture = dungeonImage.texture;
    viewportTextureStolen = true;
  }

  private void RestoreViewportTextureAndDestroyPreview()
  {
    RestoreEditModePresentationOverrides();

    if (TryGetViewportRawImage(out RawImage dungeonImage)
        && viewportTextureStolen)
    {
      dungeonImage.texture = savedViewportTexture;
    }

    savedViewportTexture = null;
    viewportTextureStolen = false;
    cachedViewportImage = null;

    if (editModePreviewTexture != null)
    {
      Object.DestroyImmediate(editModePreviewTexture);
      editModePreviewTexture = null;
    }
  }

  private static void RefreshDungeonRenderer()
  {
    if (!Application.isPlaying)
      return;

    DungeonRenderer renderer =
        Object.FindAnyObjectByType<DungeonRenderer>();

    if (renderer == null)
      return;

    renderer.RequestRedraw();
  }

  private static int DrawDelayedIntFieldMaybeRed(
      string label,
      int value,
      bool valueDiffersFromRef,
      bool immediate = false,
      float fieldWidth = 36f)
  {
    Color previousGuiColor = GUI.color;
    Color previousContentColor = GUI.contentColor;
    GUIStyle fieldStyle = EditorStyles.numberField;
    if (valueDiffersFromRef)
    {
      fieldStyle = new GUIStyle(EditorStyles.numberField);
      Color red = Color.red;
      fieldStyle.normal.textColor = red;
      fieldStyle.hover.textColor = red;
      fieldStyle.focused.textColor = red;
      fieldStyle.active.textColor = red;
    }

    EditorGUILayout.LabelField(label, GUILayout.Width(12f));
    int result = immediate
        ? EditorGUILayout.IntField(value, fieldStyle, GUILayout.Width(fieldWidth))
        : EditorGUILayout.DelayedIntField(
            value, fieldStyle, GUILayout.Width(fieldWidth));
    GUI.color = previousGuiColor;
    GUI.contentColor = previousContentColor;
    return result;
  }

  private static bool DrawIntStepperInline(
      string label,
      ref int value,
      int step,
      bool valueDiffersFromRef = false,
      bool immediate = false,
      float buttonWidth = 36f,
      float fieldWidth = 36f)
  {
    EditorGUI.BeginChangeCheck();
    value = DrawDelayedIntFieldMaybeRed(
        label, value, valueDiffersFromRef, immediate, fieldWidth);

    bool changed = EditorGUI.EndChangeCheck();

    if (GUILayout.Button($"-{step}", GUILayout.Width(buttonWidth)))
    {
      value -= step;
      changed = true;
    }

    if (GUILayout.Button($"+{step}", GUILayout.Width(buttonWidth)))
    {
      value += step;
      changed = true;
    }

    return changed;
  }

  private static bool DrawTopDownYStepperInline(
      ref int unityY,
      int pieceHeight,
      int step,
      bool valueDiffersFromRef = false,
      bool immediate = false)
  {
    int oldUnityY = unityY;
    int displayY = UnityYToDisplayY(unityY, pieceHeight);

    EditorGUI.BeginChangeCheck();
    displayY = DrawDelayedIntFieldMaybeRed(
        "Y", displayY, valueDiffersFromRef, immediate);

    if (GUILayout.Button($"-{step}", GUILayout.Width(36f)))
      displayY -= step;

    if (GUILayout.Button($"+{step}", GUILayout.Width(36f)))
      displayY += step;

    int maxDisplayY = Mathf.Max(0, PreviewHeight - Mathf.Max(1, pieceHeight));
    displayY = Mathf.Clamp(displayY, 0, maxDisplayY);
    unityY = DisplayYToUnityY(displayY, pieceHeight);

    return EditorGUI.EndChangeCheck() || unityY != oldUnityY;
  }

  private static bool DrawIntStepper(
      string label,
      ref int value,
      int step,
      bool valueDiffersFromRef = false)
  {
    EditorGUILayout.BeginHorizontal(GUILayout.ExpandWidth(false));
    EditorGUI.BeginChangeCheck();
    value = DrawDelayedIntFieldMaybeRed(
        label, value, valueDiffersFromRef);

    bool changed = EditorGUI.EndChangeCheck();

    if (GUILayout.Button($"-{step}", GUILayout.Width(36)))
    {
      value -= step;
      changed = true;
    }

    if (GUILayout.Button($"+{step}", GUILayout.Width(36)))
    {
      value += step;
      changed = true;
    }

    EditorGUILayout.EndHorizontal();
    return changed;
  }

  private void RefreshTemporaryNormalWallPreview()
  {
    if (Application.isPlaying)
      return;

    // Enabled/Mirror/X/Y tests are a ViewEdit overlay only. Do NOT rebuild the
    // automatic wall recipe here: after navigation that would switch away from
    // the destination pose's normal navigation state and could change the
    // default walls. Compose reads the temporary override dictionaries directly.
    ResetEditModeViewportLogCache();
    DestroyEditModePreviewTextureOnly();
    RefreshEditModePreview();
    RepaintGameViews();
    Repaint();
  }

  /// <summary>
  /// Temporary normal-wall Y editor. The value is Unity bottom-origin, while
  /// ViewEdit displays GIMP/top-origin Y. No layout field is mutated.
  /// </summary>
  private static bool DrawTopDownYStepper(
      ref int unityY,
      int pieceHeight,
      int step,
      bool valueDiffersFromRef = false)
  {
    int oldUnityY = unityY;
    int displayY = UnityYToDisplayY(unityY, pieceHeight);

    EditorGUI.BeginChangeCheck();
    EditorGUILayout.BeginHorizontal(GUILayout.ExpandWidth(false));
    displayY = DrawDelayedIntFieldMaybeRed(
        "Y", displayY, valueDiffersFromRef);

    if (GUILayout.Button($"-{step}", GUILayout.Width(36)))
      displayY -= step;

    if (GUILayout.Button($"+{step}", GUILayout.Width(36)))
      displayY += step;

    EditorGUILayout.EndHorizontal();

    int maxDisplayY = Mathf.Max(0, PreviewHeight - Mathf.Max(1, pieceHeight));
    displayY = Mathf.Clamp(displayY, 0, maxDisplayY);
    unityY = DisplayYToUnityY(displayY, pieceHeight);

    return EditorGUI.EndChangeCheck() || unityY != oldUnityY;
  }

  /// <summary>
  /// Editor-only Y: show/edit top-down (GIMP) coords. Storage stays Unity
  /// bottom-up framebuffer Y used by blit. displayY = 200 - unityY - h.
  /// </summary>
  private bool DrawTopDownYStepper(ViewportPiece piece, int step)
  {
    if (piece == null)
      return false;

    int pieceHeight = GetPieceHeightForEditorY(piece);
    int oldUnityY = piece.Y;
    int displayY = UnityYToDisplayY(oldUnityY, pieceHeight);

    EditorGUI.BeginChangeCheck();
    EditorGUILayout.BeginHorizontal();
    displayY = EditorGUILayout.IntField("Y", displayY);

    if (GUILayout.Button($"-{step}", GUILayout.Width(36)))
      displayY -= step;

    if (GUILayout.Button($"+{step}", GUILayout.Width(36)))
      displayY += step;

    EditorGUILayout.EndHorizontal();

    int maxDisplayY = Mathf.Max(0, PreviewHeight - pieceHeight);
    displayY = Mathf.Clamp(displayY, 0, maxDisplayY);
    piece.Y = DisplayYToUnityY(displayY, pieceHeight);

    return EditorGUI.EndChangeCheck() || piece.Y != oldUnityY;
  }

  private int GetPieceHeightForEditorY(ViewportPiece piece)
  {
    if (piece == null || graphics == null)
      return 1;

    if (piece.Name == "BlackDoorF3")
    {
      Texture2D f3Texture = GetBlackDoorF3SourceTexture();
      if (f3Texture != null && f3Texture.height > 0)
        return f3Texture.height;
    }

    if (IsFrontWallF1Card(piece))
    {
      Texture2D f1Texture = GetReadableNativeFrontF1Texture();
      if (f1Texture != null && f1Texture.height > 0)
        return f1Texture.height;
    }

    if (IsFrontWallF2Card(piece))
    {
      Texture2D f2Texture = GetReadableNativeFrontF2Texture();
      if (f2Texture != null && f2Texture.height > 0)
        return f2Texture.height;
      return 74;
    }

    if (IsFrontWallF3Card(piece))
    {
      Texture2D f3Texture = GetReadableNativeFrontF3Texture();
      if (f3Texture != null && f3Texture.height > 0)
        return f3Texture.height;
      return 49;
    }

    if (piece.Name == "RightS3")
    {
      Texture2D rightS3Texture = GetRight2STexture();
      if (rightS3Texture != null && rightS3Texture.height > 0)
        return rightS3Texture.height;
    }

    Texture2D texture = graphics.GetTexture(piece.Graphic);
    if (texture == null || texture.height <= 0)
      return 1;

    return texture.height;
  }

  private static int UnityYToDisplayY(int storedUnityY, int pieceHeight)
  {
    int height = Mathf.Max(1, pieceHeight);
    return PreviewHeight - storedUnityY - height;
  }

  private static int DisplayYToUnityY(int displayY, int pieceHeight)
  {
    int height = Mathf.Max(1, pieceHeight);
    return PreviewHeight - displayY - height;
  }
}
