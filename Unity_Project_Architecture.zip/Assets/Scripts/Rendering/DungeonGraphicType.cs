namespace DM.Rendering
{
  public enum DungeonGraphicType
  {
    None,

    Ceiling,
    Floor,

    WallF0L,
    WallF0R,

    WallF1L,
    WallF1R,

    WallF2L,
    WallF2R,

    WallF3L,
    WallF3R,

    // 11 / 12 were WallS2L / WallS2R — keep numeric IDs stable for serialization.
    WallD3L2 = 13,
    WallD3R2 = 14,

    DoorClosed,
    DoorOpen,

    Alcove,
    WallSwitch,
    TorchHolder,
    WallOrnament,

    CeilingStrip84,
    CeilingStrip85,

    FrontWallF1,
    FrontWallF2,
    FrontWallF3,

    MovementArrows,

    FrontWallF1_A,
    FrontWallF1_B,

    ChampionStatusBackground,

    /// <summary>
    /// Hall of Champions entrance front-wall overlay (1,2 North only).
    /// </summary>
    BlackDoor,

    /// <summary>
    /// Hall of Champions entrance door side frame (shared L/R via mirror).
    /// </summary>
    BlackDoorFrameLeft,

    /// <summary>
    /// F2 left door frame (native 18×65). (1,4) North for now.
    /// </summary>
    BlackDoorFrameLeftF2,

    /// <summary>
    /// F2 right door frame (native 18×65, same source as left F2).
    /// (1,4) North for now.
    /// </summary>
    BlackDoorFrameRightF2,

    /// <summary>
    /// Manual ViewEdit Left2S wall image. Not LeftF2 / WallF2L.
    /// </summary>
    Left2S
  }
}