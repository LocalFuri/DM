using DM.Dungeon;
using UnityEngine;

namespace DM.Rendering
{
  /// <summary>
  /// Front Wall F1 1:1 blit helpers + Floor/Ceiling environment phase.
  /// Front F1 texture is the authored 224×111 composite.
  /// </summary>
  public static class StraightF1WallLogic
  {
    public const int CompositeWidth = 224;
    public const int CompositeWidth191 = 192;
    public const int CompositeWidth160 = 160;
    public const int CompositeDestX191 = 0;
    public const int DefaultFrontWallF1Width = 192;
    public const int CompositeHeight = 111;

    public static int NormalizeFrontWallF1Width(int width)
    {
      if (width == CompositeWidth160 || width == CompositeWidth)
        return width;

      return DefaultFrontWallF1Width;
    }

    public static int FrontWallF1DestX(int width, int authoredX)
    {
      int normalized = NormalizeFrontWallF1Width(width);
      if (normalized == CompositeWidth)
        return 0;

      return authoredX;
    }

    public static bool IsStraightF1FrontGraphic(DungeonGraphicType graphic)
    {
      return graphic == DungeonGraphicType.FrontWallF1
          || graphic == DungeonGraphicType.FrontWallF1_A
          || graphic == DungeonGraphicType.FrontWallF1_B;
    }

    public static bool IsF1WallGroupGraphic(DungeonGraphicType graphic)
    {
      return graphic == DungeonGraphicType.WallF1L
          || graphic == DungeonGraphicType.WallF1R
          || IsStraightF1FrontGraphic(graphic);
    }

    /// <summary>
    /// Floor/Ceiling only — Front F1 uses authored MirrorHorizontally.
    /// </summary>
    public static bool IsEnvironmentPhaseGraphic(DungeonGraphicType graphic)
    {
      return graphic == DungeonGraphicType.Floor
          || graphic == DungeonGraphicType.Ceiling;
    }

    public static bool IsFloorOrCeilingGraphic(DungeonGraphicType graphic)
    {
      return graphic == DungeonGraphicType.Floor
          || graphic == DungeonGraphicType.Ceiling;
    }

    /// <summary>
    /// Parity formula (cell at depth 1 ahead of the player):
    /// North/South → use cell X; East/West → use cell Y.
    /// Even → Phase A (normal); odd → Phase B (mirrored).
    /// </summary>
    public static bool PreferVariantB(
        DungeonFacing facing,
        int wallTileX,
        int wallTileY)
    {
      bool northSouth =
          facing == DungeonFacing.North
          || facing == DungeonFacing.South;

      int parityAxis = northSouth ? wallTileX : wallTileY;
      return (parityAxis & 1) == 1;
    }

    /// <summary>
    /// FrontF1 / FrontF2 brick phase from player tile + facing.
    /// North/South uses player X; East/West uses player Y.
    /// Even → mirrored. (0,5) West stays unmirrored.
    /// Independent of saved per-pose MirrorHorizontally.
    /// </summary>
    public static bool GetFrontF2LateralMirrorPhase(
        int playerX,
        int playerY,
        DungeonFacing facing)
    {
      int lateralCoordinate =
          facing == DungeonFacing.North || facing == DungeonFacing.South
          ? playerX
          : playerY;

      return (lateralCoordinate & 1) == 0;
    }

    /// <summary>
    /// Environment phase for Floor and Ceiling.
    /// Uses the depth-1 cell ahead of the player (same axis as PreferVariantB).
    /// </summary>
    public static bool IsEnvironmentPhaseB(
        DungeonFacing facing,
        int playerX,
        int playerY)
    {
      DungeonMap.GetForwardOffset(facing, out int forwardX, out int forwardY);
      return PreferVariantB(
          facing,
          playerX + forwardX,
          playerY + forwardY);
    }

    public static bool IsVariantVisibleForWall(
        DungeonGraphicType graphic,
        DungeonFacing facing,
        int wallTileX,
        int wallTileY,
        bool centerWallPresent)
    {
      if (!centerWallPresent)
        return false;

      if (graphic == DungeonGraphicType.FrontWallF1)
        return true;

      bool wantB = PreferVariantB(facing, wallTileX, wallTileY);

      if (graphic == DungeonGraphicType.FrontWallF1_A)
        return !wantB;

      if (graphic == DungeonGraphicType.FrontWallF1_B)
        return wantB;

      return false;
    }

    /// <summary>
    /// Mirror across the 224px dungeon viewport by reversing write columns.
    /// </summary>
    public static int WriteDestX(int destX, bool mirrorHorizontally)
    {
      if (!mirrorHorizontally)
        return destX;

      return CompositeWidth - 1 - destX;
    }

    /// <summary>
    /// Copy a Front Wall F1 texture into the buffer at destinationX/Y.
    /// Writes destinationX + i for each source column. Clips writes to
    /// dungeon viewport columns 0..223.
    /// When mirrored, samples source right-to-left inside the texture;
    /// the destination rectangle is unchanged.
    /// </summary>
    public static void BlitCompositeToBuffer(
        Texture2D source,
        Color32[] destPixels,
        int bufferWidth,
        int bufferHeight,
        int destinationX,
        int destinationY,
        bool mirrorHorizontally,
        int requestedWidth = 0)
    {
      if (source == null || destPixels == null)
        return;

      if (!source.isReadable)
        return;

      if (source.height <= 0 || source.width <= 0)
        return;

      Color32[] sourcePixels = source.GetPixels32();
      int sourceWidth = source.width;
      int copyWidth = requestedWidth <= 0
          ? sourceWidth
          : Mathf.Min(requestedWidth, sourceWidth);
      int sourceHeight = source.height;

      for (int row = 0; row < sourceHeight; row++)
      {
        int targetY = destinationY + row;
        if (targetY < 0 || targetY >= bufferHeight)
          continue;

        int sourceRow = row * sourceWidth;
        int destRow = targetY * bufferWidth;

        for (int i = 0; i < copyWidth; i++)
        {
          int destX = destinationX + i;
          if (destX < 0 || destX >= CompositeWidth)
            continue;

          int sourceX = mirrorHorizontally
              ? sourceWidth - 1 - i
              : i;

          Color32 colour = sourcePixels[sourceRow + sourceX];
          colour.a = 255;
          destPixels[destRow + destX] = colour;
        }
      }
    }

    /// <summary>
    /// Copy FrontF1 starting at the right edge of the 224px dungeon viewport
    /// and writing destination columns right-to-left.
    /// Source column 0 is written at x=223, source column 1 at x=222, etc.
    /// </summary>
    public static void BlitCompositeRightToLeftToBuffer(
        Texture2D source,
        Color32[] destPixels,
        int bufferWidth,
        int bufferHeight,
        int destinationRightX,
        int destinationY,
        bool mirrorHorizontally,
        int requestedWidth = 0)
    {
      if (source == null || destPixels == null)
        return;

      if (!source.isReadable)
        return;

      if (source.height <= 0 || source.width <= 0)
        return;

      Color32[] sourcePixels = source.GetPixels32();
      int sourceWidth = source.width;
      int copyWidth = requestedWidth <= 0
          ? sourceWidth
          : Mathf.Min(requestedWidth, sourceWidth);
      int sourceHeight = source.height;

      for (int row = 0; row < sourceHeight; row++)
      {
        int targetY = destinationY + row;
        if (targetY < 0 || targetY >= bufferHeight)
          continue;

        int sourceRow = row * sourceWidth;
        int destRow = targetY * bufferWidth;

        for (int i = 0; i < copyWidth; i++)
        {
          int destX = destinationRightX - i;
          if (destX < 0 || destX >= CompositeWidth)
            continue;

          int sourceX = mirrorHorizontally
              ? copyWidth - 1 - i
              : i;

          Color32 colour = sourcePixels[sourceRow + sourceX];
          colour.a = 255;
          destPixels[destRow + destX] = colour;
        }
      }
    }

    /// <summary>
    /// Blit a floor/ceiling sprite into the buffer, optionally mirroring
    /// across the full 224px dungeon viewport (columns 0..223).
    /// </summary>
    public static void BlitViewportComponentToBuffer(
        Texture2D source,
        Color32[] destPixels,
        int bufferWidth,
        int bufferHeight,
        int destinationX,
        int destinationY,
        bool mirrorHorizontally)
    {
      if (source == null || destPixels == null)
        return;

      if (!source.isReadable)
        return;

      Color32[] sourcePixels = source.GetPixels32();
      int sourceWidth = source.width;
      int sourceHeight = source.height;

      for (int row = 0; row < sourceHeight; row++)
      {
        int targetY = destinationY + row;
        if (targetY < 0 || targetY >= bufferHeight)
          continue;

        int sourceRow = row * sourceWidth;
        int destRow = targetY * bufferWidth;

        for (int column = 0; column < sourceWidth; column++)
        {
          int destX = destinationX + column;
          if (destX < 0 || destX >= CompositeWidth)
            continue;

          int writeX = WriteDestX(destX, mirrorHorizontally);
          if (writeX < 0 || writeX >= bufferWidth)
            continue;

          Color32 colour = sourcePixels[sourceRow + column];
          if (colour.a == 0)
            continue;

          destPixels[destRow + writeX] = colour;
        }
      }
    }
  }
}
