using System.Collections.Generic;
using System.IO;
using DM.Dungeon;
using UnityEditor;
using UnityEngine;

public class DungeonFeatureEditor : EditorWindow
{
  private const string HallOfChampionsMapPath =
      "Assets/Data/Maps/DungeonMaster_Level00.json";
  private const string DungeonFeaturePlacementsPath =
      "Assets/Data/Features/DungeonFeaturePlacements.json";
  private const string DungeonInscriptionsPath =
      "Assets/Editor/DungeonInscriptions.json";

  [System.Serializable]
  private sealed class DungeonInscriptionRecord
  {
    public int level;
    public int x;
    public int y;
    public string wall;
    public bool initiallyHidden;
    public string text;
  }

  [System.Serializable]
  private sealed class DungeonInscriptionCollection
  {
    public DungeonInscriptionRecord[] inscriptions;
  }

  private List<DungeonInscriptionRecord> GetInscriptionRecordsAt(int x, int y)
  {
    List<DungeonInscriptionRecord> matches = new List<DungeonInscriptionRecord>();
    if (!File.Exists(DungeonInscriptionsPath))
      return matches;
    try
    {
      DungeonInscriptionCollection data = JsonUtility.FromJson<DungeonInscriptionCollection>(
          File.ReadAllText(DungeonInscriptionsPath));
      if (data != null && data.inscriptions != null)
      {
        foreach (DungeonInscriptionRecord record in data.inscriptions)
          if (record != null && record.level == currentDungeonLevel
              && record.x == x && record.y == y)
            matches.Add(record);
      }
    }
    catch (System.Exception ex)
    {
      Debug.LogError("Dungeon Features: Unable to read inscription details: " + ex);
    }
    return matches;
  }

  private void DrawSelectedInscriptionPreview(Rect mapRect)
  {
    List<DungeonInscriptionRecord> entries = GetInscriptionRecordsAt(
        inspectedInscriptionX, inspectedInscriptionY);
    if (entries.Count == 0)
      return;

    // The inspection panel must stay at native UI size even when the map fits.
    float unit = 1f;
    float width = 235f * unit;
    GUIStyle bodyStyle = new GUIStyle(EditorStyles.label)
    {
      alignment = TextAnchor.UpperLeft,
      wordWrap = false,
      normal = { textColor = Color.white }
    };
    GUIStyle centeredInscriptionStyle = new GUIStyle(bodyStyle)
    {
      alignment = TextAnchor.UpperCenter
    };
    GUIStyle titleStyle = new GUIStyle(EditorStyles.boldLabel)
    {
      normal = { textColor = Color.white }
    };
    float lineHeight = Mathf.Max(16f, centeredInscriptionStyle.lineHeight);
    // Measure every actual text row; multiple inscriptions on one tile are supported.
    float height = 6f + 24f; // top inset + title
    foreach (DungeonInscriptionRecord entry in entries)
    {
      string inscriptionText = string.IsNullOrEmpty(entry.text)
          ? "[Text missing in DungeonInscriptions.json]" : entry.text;
      string[] rows = inscriptionText.Replace("\\r\\n", "\\n")
          .Replace("\\r", "\\n").Split('\n');
      height += lineHeight + 3f; // wall/direction/status
      height += rows.Length * lineHeight + 6f; // text rows and bottom gap
    }
    height += 6f; // ensure the bottom line never touches the border
    Rect panel = new Rect(mapRect.xMax + 8f,
        mapRect.y - (LabelTopMargin + OutsideFeatureVerticalMargin) * mapZoom
            + 2f * mapZoom, width, height);
    EditorGUI.DrawRect(panel, new Color(0.15f, 0.15f, 0.15f, 1f));
    Color border = new Color(0.45f, 0.45f, 0.45f, 1f);
    EditorGUI.DrawRect(new Rect(panel.x, panel.y, panel.width, 1f), border);
    EditorGUI.DrawRect(new Rect(panel.x, panel.yMax - 1f, panel.width, 1f), border);
    EditorGUI.DrawRect(new Rect(panel.x, panel.y, 1f, panel.height), border);
    EditorGUI.DrawRect(new Rect(panel.xMax - 1f, panel.y, 1f, panel.height), border);
    float y = panel.y + 6f * unit;
    GUI.Label(new Rect(panel.x + 7f * unit, y, width - 14f * unit,
        20f * unit), "INS (" + inspectedInscriptionX + ","
        + inspectedInscriptionY + ") – " + entries.Count, titleStyle);
    y += 24f * unit;
    foreach (DungeonInscriptionRecord entry in entries)
    {
      string status = entry.initiallyHidden ? "Hidden initially" : "Visible initially";
      GUI.Label(new Rect(panel.x + 7f * unit, y, width - 14f * unit,
          lineHeight), "Wall: " + entry.wall + "  |  " + status, bodyStyle);
      y += lineHeight + 3f * unit;
      string inscriptionText = string.IsNullOrEmpty(entry.text)
          ? "[Text missing in DungeonInscriptions.json]" : entry.text;
      string[] rows = inscriptionText.Replace("\\r\\n", "\\n")
          .Replace("\\r", "\\n").Split('\n');
      foreach (string row in rows)
      {
        GUI.Label(new Rect(panel.x + 7f, y, width - 14f, lineHeight),
            row, centeredInscriptionStyle);
        y += lineHeight;
      }
      y += 6f;
    }
  }

  private void DrawInscriptionMarkers(Rect mapRect)
  {
    if (!File.Exists(DungeonInscriptionsPath))
    {
      Debug.LogError("Dungeon Features: Missing inscription positions: "
          + DungeonInscriptionsPath);
      return;
    }

    DungeonInscriptionCollection data;
    try
    {
      data = JsonUtility.FromJson<DungeonInscriptionCollection>(
          File.ReadAllText(DungeonInscriptionsPath));
    }
    catch (System.Exception ex)
    {
      Debug.LogError("Dungeon Features: Cannot parse inscription positions: " + ex);
      return;
    }
    if (data == null || data.inscriptions == null)
    {
      Debug.LogError("Dungeon Features: Inscription positions contain no inscriptions array.");
      return;
    }

    GUIStyle style = new GUIStyle(GUI.skin.label)
    {
      alignment = TextAnchor.MiddleCenter,
      fontStyle = FontStyle.Bold,
      fontSize = Mathf.Max(5, Mathf.RoundToInt(11f * mapZoom)),
      clipping = TextClipping.Clip,
      padding = new RectOffset(0, 0, 0, 0)
    };
    style.normal.textColor = Color.white;
    HashSet<string> drawn = new HashSet<string>();
    foreach (DungeonInscriptionRecord entry in data.inscriptions)
    {
      if (entry == null || entry.level != currentDungeonLevel)
        continue;
      if (!map.IsInside(entry.x, entry.y))
      {
        Debug.LogError("Dungeon Features: Inscription outside level "
            + entry.level + " at " + entry.x + "," + entry.y);
        continue;
      }
      string tileKey = entry.x + "," + entry.y;
      if (!drawn.Add(tileKey))
        continue; // Multiple inscriptions can share one tile (Level 12).
      Rect tile = new Rect(mapRect.x + entry.x * CellSize,
          mapRect.y + entry.y * CellSize, CellSize, CellSize);
      Rect marker = new Rect(tile.x + 2f * mapZoom,
          tile.y + 8f * mapZoom,
          tile.width - 4f * mapZoom, 16f * mapZoom);
      EditorGUI.DrawRect(marker, new Color(0f, 0f, 0.9f, 1f));
      GUI.Label(marker, "INS", style);
    }
  }

  private const int HallOfChampionsLevel = 0;
  private const int MaxDungeonLevel = 13;
  private const string MossF1AssetName = "Moss_F1_56x19";
  private const string PuddleF1AssetPath =
      "Assets/Art/Ornaments/Flooritem Puddle_F1.png";

  // Hall of Champions uses three random floor ornaments. The level-local
  // FloorOrnate table is Moss, Puddle, Floor Crack for ordinals 1..3.
  // Puddles therefore resolve from random floor ornament ordinal 2.
  private const int HallOfChampionsRandomFloorOrnamentCount = 3;
  private const int HallOfChampionsPuddleFloorOrnamentOrdinal = 2;
  private const int HallOfChampionsRandomOrnamentModulo = 30;
  private const int HallOfChampionsDungeonSeed = 99;

  // Shared ViewEdit preview pose. Dungeon Features reads these to follow
  // ViewEdit and writes X/Y when the user clicks a map tile.
  private const string ViewEditPreviewXKey =
      "ViewportLayoutEditor.PreviewX";
  private const string ViewEditPreviewYKey =
      "ViewportLayoutEditor.PreviewY";
  private const string ViewEditPreviewFacingKey =
      "ViewportLayoutEditor.PreviewFacing";
  private const string ViewEditPreviewLevelKey =
      "ViewportLayoutEditor.PreviewLevel";

  private const float BaseCellSize = 32f;
  private const int MaxMapZoomStep = 1;
  private const int MaximumDungeonTilesPerAxis = 32;
  private const string MapZoomPreferenceKey = "DungeonFeatureEditor.MapZoomOutStep";
  // Two wheel positions: normal 1x and fit a full 32x32 map in the viewport.
  private float mapZoom => searchOverviewActive
      ? GetFitMapZoom() : GetZoomForStep(mapZoomStep);
  private float GetFitMapZoom()
  {
    // Reserve space for map coordinates, wall labels, scrollbars and header.
    // Keep room for the fixed-width matching-item preview to the right.
    float availableWidth = Mathf.Max(1f, position.width
        - (searchOverviewActive ? 180f : 24f));
    float availableHeight = Mathf.Max(1f, position.height - 110f);
    float requiredWidth = LabelLeftMargin
        + Mathf.Max(MaximumDungeonTilesPerAxis, OutsideNameColumnX + 2) * BaseCellSize;
    float requiredHeight = LabelTopMargin + 2f * OutsideFeatureVerticalMargin
        + MaximumDungeonTilesPerAxis * BaseCellSize;
    return Mathf.Clamp(Mathf.Min(availableWidth / requiredWidth,
        availableHeight / requiredHeight), 0.01f, 1f);
  }

  private float GetZoomForStep(int step)
  {
    return step >= MaxMapZoomStep ? GetFitMapZoom() : 1f;
  }
  private float CellSize => BaseCellSize * mapZoom;
  private const float LabelLeftMargin = 28f;
  private const float LabelTopMargin = 20f;
  // Extra vertical canvas above/below the map for labels that are drawn
  // outside a wall face. This also keeps y=0 and y=31 labels fully visible
  // on 32-row dungeon levels.
  private const float OutsideFeatureVerticalMargin = 32f;
  // Virtual column just past the Hall of Champions map (x = 0..17).
  private const int OutsideNameColumnX = 18;

  private static readonly Color WallColor = new Color(0.22f, 0.22f, 0.22f);
  private static readonly Color FloorColor = new Color(0.78f, 0.78f, 0.78f);
  private static readonly Color CellBorderColor = new Color(0.08f, 0.08f, 0.08f);
  private static readonly Color SelectionFillColor =
      new Color(0.35f, 0.75f, 1f, 0.35f);
  private static readonly Color SelectionBorderColor =
      new Color(0.2f, 0.85f, 1f, 1f);
  private static readonly Color StairDownTileColor =
      new Color(0f, 1f, 0f, 1f);
  private static readonly Color ManaclesHighlightBackgroundColor =
      new Color(1f, 165f / 255f, 0f, 1f);
  private static readonly Color LordOrderOutsideMarkerColor =
      new Color(0.6f, 0f, 0.8f, 1f);

  // Champion mirror map marker: full-edge blue wall-face bar with a small yellow center.
  private static readonly Color ChampionMirrorLineColor =
      new Color(0.0f, 0.0f, 1.0f, 1f);
  private static readonly Color ChampionMirrorDotColor =
      new Color(1.0f, 0.9f, 0.0f, 1f);
  private static readonly Color ChampionNameColor =
      new Color(0f, 1f, 0f, 1f);
  private static readonly Color VerifiedChampionTileColor =
      new Color(0f, 1f, 0f, 1f);

  private enum WallSide
  {
    North,
    East,
    South,
    West
  }

  private sealed class ChampionMirrorMarker
  {
    public int X;
    public int Y;
    public WallSide Side;
    public string Champion;

    public ChampionMirrorMarker(
        int x,
        int y,
        WallSide side,
        string champion)
    {
      X = x;
      Y = y;
      Side = side;
      Champion = champion;
    }
  }

  // Hall of Champions mirror positions extracted from the original
  // direction-aware level data. Direction is the wall face on which the
  // champion portrait/mirror appears.
  private sealed class OriginalWallOrnamentMarker
  {
    public string Type;
    public int X;
    public int Y;
    public WallSide Side;
    public bool WallTilePlacement;

    public OriginalWallOrnamentMarker(
        string type,
        int x,
        int y,
        WallSide side,
        bool wallTilePlacement)
    {
      Type = type;
      X = x;
      Y = y;
      Side = side;
      WallTilePlacement = wallTilePlacement;
    }
  }

  // Every Hall of Champions wall ornament is drawn on the impassable grey
  // wall tile, on the face stored in the raw direction bits. Those faces are
  // the directions that are not a possible walk. The sensor wood ring at
  // (6,8) South is not a random face bit, so it is added explicitly.
  private OriginalWallOrnamentMarker[] resolvedWallOrnaments =
      new OriginalWallOrnamentMarker[0];
  private readonly HashSet<int> resolvedPuddleFloors = new HashSet<int>();
  private readonly HashSet<int> resolvedMossFloors = new HashSet<int>();

  // Read-only floor-item map layer sourced from all 14 levels of the
  // placement database. Never turn wall-linked inventory into floor loot.
  [System.Serializable]
  private sealed class FloorItemPlacementRecord
  {
    public string id;
    public int level;
    public int localX;
    public int localY;
    public string recordType;
    public string tileClass;
    public string direction;
    public FloorThingRecord thing;
  }

  [System.Serializable]
  private sealed class FloorThingRecord
  {
    public int Type;
    public int Next;
  }

  [System.Serializable]
  private sealed class FloorItemPlacementDatabase
  {
    public FloorItemPlacementRecord[] placements;
  }

  private readonly Dictionary<int, List<FloorItemPlacementRecord>>
      resolvedFloorItems = new Dictionary<int, List<FloorItemPlacementRecord>>();
  private static readonly Color FloorItemMapColor = new Color(0.05f, 0.35f, 0.85f, 1f);
  private const string ShowFloorItemsPreferenceKey = "DungeonFeatureEditor.ShowFloorItems";
  private bool showFloorItems = true;
  private int inspectedFloorItemX = -1;
  private int inspectedFloorItemY = -1;
  private int inspectedOrnamentX = -1;
  private int inspectedOrnamentY = -1;
  private int inspectedInscriptionX = -1;
  private int inspectedInscriptionY = -1;

  private static bool IsFloorItemRecordType(string recordType)
  {
    switch (recordType)
    {
      case "Junk":
      case "Weapon":
      case "Armour":
      case "Potion":
      case "Scroll":
      case "Container":
        return true;
      default:
        return false;
    }
  }

  private void LoadFloorItemMapLayer()
  {
    resolvedFloorItems.Clear();
    if (!File.Exists(DungeonFeaturePlacementsPath))
    {
      Debug.LogError("Dungeon Features: Missing floor-item placements: "
          + DungeonFeaturePlacementsPath);
      return;
    }

    try
    {
      FloorItemPlacementDatabase database = JsonUtility.FromJson<FloorItemPlacementDatabase>(
          File.ReadAllText(DungeonFeaturePlacementsPath));
      if (database == null || database.placements == null)
      {
        Debug.LogError("Dungeon Features: Floor-item placements array is missing.");
        return;
      }

      foreach (FloorItemPlacementRecord entry in database.placements)
      {
        if (entry == null || entry.level != currentDungeonLevel
            || entry.tileClass != "Floor" || !IsFloorItemRecordType(entry.recordType))
          continue;
        if (!map.IsInside(entry.localX, entry.localY))
        {
          Debug.LogError("Dungeon Features: Floor item " + entry.id
              + " lies outside Level " + entry.level + " map at ("
              + entry.localX + "," + entry.localY + ").");
          continue;
        }
        int tile = PackFloorFeatureTile(entry.localX, entry.localY);
        if (!resolvedFloorItems.TryGetValue(tile, out List<FloorItemPlacementRecord> list))
        {
          list = new List<FloorItemPlacementRecord>();
          resolvedFloorItems.Add(tile, list);
        }
        list.Add(entry);
      }
    }
    catch (System.Exception ex)
    {
      resolvedFloorItems.Clear();
      Debug.LogError("Dungeon Features: Could not read floor-item database: " + ex);
    }
  }

  private void DrawFloorItemMapIcons(Rect mapRect)
  {
    if (!showFloorItems)
      return;
    foreach (var pair in resolvedFloorItems)
    {
      List<FloorItemPlacementRecord> list = pair.Value;
      if (list == null || list.Count == 0)
        continue;
      int x = list[0].localX;
      int y = list[0].localY;

      if (list.Count == 1)
      {
        Texture2D itemIcon = GetFloorItemInventoryMapIcon(list[0]);
        if (itemIcon != null)
        {
          // Reserve the cell's existing 1px grid line plus a further 1px
          // clear gap inside it, even for artwork that fills its source image.
          // Inset only the single-item sprite; do not change map tile size.
          float iconMargin = 2f * mapZoom;
          float iconSize = Mathf.Max(1f, CellSize - iconMargin * 2f);
          Rect iconRect = new Rect(
              mapRect.x + x * CellSize + iconMargin,
              mapRect.y + y * CellSize + iconMargin,
              iconSize,
              iconSize);
          GUI.DrawTexture(iconRect, itemIcon, ScaleMode.StretchToFill, true);
          continue;
        }
      }

      // Multiple floor items fill the tile in orange with a centered white count.
      // A single item with missing artwork retains the existing small count marker.
      bool multipleItems = list.Count > 1;
      float markerSize = multipleItems ? CellSize : CellSize * 0.42f;
      Rect marker = new Rect(
          mapRect.x + x * CellSize + (CellSize - markerSize) * 0.5f,
          mapRect.y + y * CellSize + (CellSize - markerSize) * 0.5f,
          markerSize, markerSize);
      EditorGUI.DrawRect(marker, multipleItems
          ? new Color(1f, 0.55f, 0f, 1f) : FloorItemMapColor);
      GUIStyle style = new GUIStyle(EditorStyles.whiteMiniLabel)
      {
        alignment = TextAnchor.MiddleCenter,
        fontStyle = FontStyle.Bold,
        normal = { textColor = Color.white },
        fontSize = Mathf.Max(7, Mathf.RoundToInt(14 * mapZoom))
      };
      GUI.Label(marker, list.Count.ToString(), style);
    }
  }

  private Texture2D GetFloorItemInventoryMapIcon(FloorItemPlacementRecord entry)
  {
    if (entry == null)
      return null;

    int type = entry.thing != null ? entry.thing.Type : -1;
    string cacheKey = entry.recordType + ":" + type.ToString();
    if (floorItemInventoryIconCache.TryGetValue(cacheKey, out Texture2D cached))
      return cached;

    string decodedName = DecodeFloorItemName(entry.recordType, type);
    Texture2D resolved = ResolveInventoryItemIcon(decodedName, entry.recordType);
    if (resolved == null)
      Debug.Log("<color=cyan>Dungeon Features: Missing 16x16 inventory map icon for '"
          + decodedName + "' (" + entry.recordType + " Type " + type
          + ", record " + entry.id + ", level " + entry.level
          + ", tile (" + entry.localX + "," + entry.localY
          + ")). No replacement art is used.</color>");
    else if (resolved.width != 16 || resolved.height != 16)
    {
      Debug.Log("<color=cyan>Dungeon Features: Inventory map icon for '" + decodedName
          + "' must be 16x16, got " + resolved.width + "x" + resolved.height
          + " (asset " + resolved.name + "). No replacement art is used.</color>");
      resolved = null;
    }
    floorItemInventoryIconCache[cacheKey] = resolved;
    return resolved;
  }

  private Texture2D ResolveInventoryItemIcon(string decodedName, string recordType)
  {
    if (string.IsNullOrEmpty(decodedName))
      return null;

    // Verified art filename for Junk Type 1. The displayed item name remains
    // Waterskin; the inventory sprite asset is named Waterskin_empty_16x16.
    // Strict lookup: do not substitute any other sprite when it is absent.
    if (string.Equals(recordType, "Junk", System.StringComparison.OrdinalIgnoreCase)
        && string.Equals(decodedName, "Waterskin", System.StringComparison.OrdinalIgnoreCase))
      return FindExactTextureByName("Waterskin_empty_16x16");

    // Verified art filename in Assets/MISC.
    if (string.Equals(recordType, "Scroll", System.StringComparison.OrdinalIgnoreCase)
        && string.Equals(decodedName, "Scroll", System.StringComparison.OrdinalIgnoreCase))
      return FindExactTextureByName("Scroll_16x16");

    // Verified Potion Type 20: Empty Flask inventory art in Assets/Art/Potions.
    if (string.Equals(recordType, "Potion", System.StringComparison.OrdinalIgnoreCase)
        && string.Equals(decodedName, "Empty Flask", System.StringComparison.OrdinalIgnoreCase))
      return FindExactTextureByName("Potion_Empty_16x16");

    // CSBwin Junk Type 35 (Shank) uses the verified Drumstick inventory art.
    // This is an explicit asset alias; keep the decoded item name and ID.
    if (string.Equals(recordType, "Junk", System.StringComparison.OrdinalIgnoreCase)
        && string.Equals(decodedName, "Shank", System.StringComparison.OrdinalIgnoreCase))
      return FindExactTextureByName("Drumstick_16x16");

    string sanitized = SanitizeItemNameForAsset(decodedName);
    string underscored = decodedName.Replace(" ", "_");
    string sanitizedUnderscored = SanitizeItemNameForAsset(underscored);

    List<string> candidates = new List<string>();
    AddUniqueCandidate(candidates, decodedName + "_16x16");
    AddUniqueCandidate(candidates, underscored + "_16x16");
    AddUniqueCandidate(candidates, sanitized + "_16x16");
    AddUniqueCandidate(candidates, sanitizedUnderscored + "_16x16");
    AddUniqueCandidate(candidates, decodedName);
    AddUniqueCandidate(candidates, underscored);
    AddUniqueCandidate(candidates, sanitized);
    AddUniqueCandidate(candidates, sanitizedUnderscored);

    if (string.Equals(recordType, "Container", System.StringComparison.OrdinalIgnoreCase))
    {
      AddUniqueCandidate(candidates, "Chest_16x16");
      AddUniqueCandidate(candidates, "Chest");
    }
    else if (string.Equals(recordType, "Scroll", System.StringComparison.OrdinalIgnoreCase))
    {
      AddUniqueCandidate(candidates, "Scroll_16x16");
      AddUniqueCandidate(candidates, "Scroll");
    }

    for (int i = 0; i < candidates.Count; i++)
    {
      Texture2D texture = FindExactTextureByName(candidates[i]);
      if (texture != null)
        return texture;
    }

    return null;
  }

  private static void AddUniqueCandidate(List<string> candidates, string candidate)
  {
    if (string.IsNullOrEmpty(candidate))
      return;
    for (int i = 0; i < candidates.Count; i++)
    {
      if (string.Equals(candidates[i], candidate, System.StringComparison.OrdinalIgnoreCase))
        return;
    }
    candidates.Add(candidate);
  }

  private static string SanitizeItemNameForAsset(string value)
  {
    if (string.IsNullOrEmpty(value))
      return string.Empty;

    System.Text.StringBuilder builder = new System.Text.StringBuilder(value.Length);
    bool previousUnderscore = false;
    for (int i = 0; i < value.Length; i++)
    {
      char c = value[i];
      if (char.IsLetterOrDigit(c))
      {
        builder.Append(c);
        previousUnderscore = false;
      }
      else if (char.IsWhiteSpace(c) || c == '-' || c == (char)39 || c == '(' || c == ')' || c == '/')
      {
        if (!previousUnderscore)
        {
          builder.Append('_');
          previousUnderscore = true;
        }
      }
    }

    return builder.ToString().Trim('_');
  }


  // Exact numeric item enums from LocalFuri CSBwin Objects.h.
  // Never infer names from a numeric type without its record category.
  private static string DecodeFloorItemName(string recordType, int type)
  {
    switch (recordType)
    {
      case "Weapon":
        switch (type)
        {
          case 0: return "Eye Of Time";
          case 1: return "Storm Ring";
          case 2: return "Torch";
          case 3: return "Flamitt";
          case 4: return "Staff Of Claws";
          case 5: return "Storm";
          case 6: return "Ra Blade";
          case 7: return "The Firestaff A";
          case 8: return "Dagger";
          case 9: return "Falchion";
          case 10: return "Sword";
          case 11: return "Rapier";
          case 12: return "Biter";
          case 13: return "Samurai Sword";
          case 14: return "Side Splitter";
          case 15: return "Diamond Edge";
          case 16: return "Vorpal Blade";
          case 17: return "Dragon Fang";
          case 18: return "Axe";
          case 19: return "Executioner";
          case 20: return "Mace";
          case 21: return "Mace Of Order";
          case 22: return "Morningstar";
          case 23: return "Club";
          case 24: return "Stone Club";
          case 25: return "Claw Bow";
          case 26: return "Crossbow";
          case 27: return "Arrow";
          case 28: return "Slayer";
          case 29: return "Sling";
          case 30: return "Rock";
          case 31: return "Poison Dart";
          case 32: return "Throwing Star";
          case 33: return "Stick";
          case 34: return "Staff";
          case 35: return "Wand";
          case 36: return "Teo Wand";
          case 37: return "Yew Staff";
          case 38: return "Staff Of Irra";
          case 39: return "Cross Of Neta";
          case 40: return "Serpent Staff";
          case 41: return "Dragon Spit";
          case 42: return "Sceptre Of Lyf";
          case 43: return "Horn Of Fear";
          case 44: return "Speedbow";
          case 45: return "The Firestaff B";
        }
        break;
      case "Armour":
        switch (type)
        {
          case 0: return "Cape";
          case 1: return "Cloak Of Night";
          case 2: return "Tattered Pants";
          case 3: return "Sandals";
          case 4: return "Leather Boots";
          case 5: return "Tattered Shirt";
          case 6: return "Robe";
          case 7: return "Fine Robe A";
          case 8: return "Fine Robe B";
          case 9: return "Kirtle";
          case 10: return "Silk Shirt";
          case 11: return "Tabard";
          case 12: return "Gunna";
          case 13: return "Elven Doublet";
          case 14: return "Elven Huke";
          case 15: return "Elven Boots";
          case 16: return "Leather Jerkin";
          case 17: return "Leather Pants";
          case 18: return "Suede Boots";
          case 19: return "Blue Pants";
          case 20: return "Tunic";
          case 21: return "Ghi";
          case 22: return "Ghi Trousers";
          case 23: return "Calista";
          case 24: return "Crown Of Nerra";
          case 25: return "Berserker Helm";
          case 26: return "Helmet";
          case 27: return "Basinet";
          case 28: return "Neta Shield";
          case 29: return "Crystal Shield";
          case 30: return "Wooden Shield";
          case 31: return "Small Shield";
          case 32: return "Mail Aketon";
          case 33: return "Leg Mail";
          case 34: return "Mithral Aketon";
          case 35: return "Mithral Mail";
          case 36: return "Casque NCoif";
          case 37: return "Hosen";
          case 38: return "Armet";
          case 39: return "Torso Plate";
          case 40: return "Leg Plate";
          case 41: return "Foot Plate";
          case 42: return "Sar Shield";
          case 43: return "Helm Of Ra";
          case 44: return "Plate Of Ra";
          case 45: return "Poleyn Of Ra";
          case 46: return "Greave Of Ra";
          case 47: return "Shield Of Ra";
          case 48: return "Dragon Helm";
          case 49: return "Dragon Plate";
          case 50: return "Dragon Poleyn";
          case 51: return "Dragon Greave";
          case 52: return "Dragon Shield";
          case 53: return "Dexhelm";
          case 54: return "Flamebain";
          case 55: return "Power Towers";
          case 56: return "Boots Of Speed";
          case 57: return "Halter";
        }
        break;
      case "Junk":
        switch (type)
        {
          case 0: return "Compass";
          case 1: return "Waterskin";
          case 2: return "Jewel Symal";
          case 3: return "Illumulet";
          case 4: return "Ashes";
          case 5: return "Bones Of Hero";
          case 6: return "Sar Coin";
          case 7: return "Silver Coin";
          case 8: return "Gor Coin";
          case 9: return "Iron Key";
          case 10: return "Key Of B";
          case 11: return "Solid Key";
          case 12: return "Square Key";
          case 13: return "Tourquoise Key";
          case 14: return "Cross Key";
          case 15: return "Onyx Key";
          case 16: return "Skeleton Key";
          case 17: return "Gold Key";
          case 18: return "Winged Key";
          case 19: return "Topaz Key";
          case 20: return "Sapphire Key";
          case 21: return "Emerald Key";
          case 22: return "Ruby Key";
          case 23: return "Ra Key";
          case 24: return "Master Key";
          case 25: return "Boulder";
          case 26: return "Blue Gem";
          case 27: return "Orange Gem";
          case 28: return "Green Gem";
          case 29: return "Apple";
          case 30: return "Corn";
          case 31: return "Bread";
          case 32: return "Cheese";
          case 33: return "Screamer Slice";
          case 34: return "Worm Round";
          case 35: return "Shank";
          case 36: return "Dragon Steak";
          case 37: return "Gem Of Ages";
          case 38: return "Ekkhard Cross";
          case 39: return "Moonstone";
          case 40: return "The Hellion";
          case 41: return "Pendant Feral";
          case 42: return "Magical Box A";
          case 43: return "Magical Box B";
          case 44: return "Mirror Of Dawn";
          case 45: return "Rope";
          case 46: return "Rabbits Foot";
          case 47: return "Corbum";
          case 48: return "Choker";
          case 49: return "Lock Picks";
          case 50: return "Magnifier";
          case 51: return "Zokathra Spell";
          case 52: return "Bones";
        }
        break;
      case "Potion":
        switch (type)
        {
          case 0: return "Mon Potion A";
          case 1: return "Um Potion";
          case 2: return "Des Potion";
          case 3: return "Ven Potion";
          case 4: return "Sar Potion";
          case 5: return "Zo Potion";
          case 6: return "Ros Potion";
          case 7: return "Ku Potion";
          case 8: return "Dane Potion";
          case 9: return "Neta Potion";
          case 10: return "Anti Venin";
          case 11: return "Mon Potion B";
          case 12: return "Ya Potion";
          case 13: return "EEPotion";
          case 14: return "Vi Potion";
          case 15: return "Water Flask";
          case 16: return "Kath Bomb";
          case 17: return "Pew Bomb";
          case 18: return "Ra Bomb";
          case 19: return "Ful Bomb";
          case 20: return "Empty Flask";
        }
        break;
      case "Scroll":
        switch (type)
        {
          case 0: return "Scroll";
        }
        break;
      case "Container":
        switch (type)
        {
          case 0: return "Chest";
        }
        break;
    }
    return null;
  }

  private List<FloorItemPlacementRecord> GetInspectedFloorItems()
  {
    if (inspectedFloorItemX < 0 || inspectedFloorItemY < 0)
      return null;

    resolvedFloorItems.TryGetValue(
        PackFloorFeatureTile(inspectedFloorItemX, inspectedFloorItemY),
        out List<FloorItemPlacementRecord> records);
    return records;
  }

  private List<FloorItemPlacementRecord> GetFloorSearchOverviewRecords()
  {
    List<FloorItemPlacementRecord> records = GetInspectedFloorItems();
    if (records != null && records.Count > 0)
      return records;

    if (floorSearchOverviewItem == null)
      return null;

    return new List<FloorItemPlacementRecord> { floorSearchOverviewItem };
  }

  private static string GetFloorItemDisplayName(FloorItemPlacementRecord entry)
  {
    if (entry == null)
      return string.Empty;

    bool singleSubtype = entry.recordType == "Scroll"
        || entry.recordType == "Container";
    string label = (entry.thing != null || singleSubtype)
        ? DecodeFloorItemName(entry.recordType,
            singleSubtype ? 0 : entry.thing.Type)
        : null;
    if (!string.IsNullOrEmpty(label))
      return label;

    string type = entry.thing != null
        ? entry.thing.Type.ToString() : "missing";
    return entry.recordType + " (Type " + type + ")";
  }


  // Display-only compact record ID. The source record identifier retains
  // its original leading zeroes for lookup and diagnostics.
  private static string GetCompactFloorItemId(string id)
  {
    if (string.IsNullOrEmpty(id) || id.Length < 2)
      return id;
    char prefix = id[0];
    if (!char.IsLetter(prefix))
      return id;
    for (int i = 1; i < id.Length; i++)
      if (id[i] < '0' || id[i] > '9')
        return id;
    int firstDigit = 1;
    while (firstDigit < id.Length - 1 && id[firstDigit] == '0')
      firstDigit++;
    return prefix + id.Substring(firstDigit);
  }

  // Compact one-line tile summary. The tooltip retains the complete list
  // without pushing the map down or crowding its cells.
  private GUIContent GetSelectedFloorItemsSummary()
  {
    List<FloorItemPlacementRecord> records = GetInspectedFloorItems();
    if (records == null || records.Count == 0)
      return GUIContent.none;

    var brief = new System.Text.StringBuilder();
    brief.Append(" | <color=#00FF00>(").Append(inspectedFloorItemX).Append(",")
        .Append(inspectedFloorItemY).Append(")</color>: ");
    var tooltip = new System.Text.StringBuilder();
    tooltip.Append("Floor items at (").Append(inspectedFloorItemX)
        .Append(",").Append(inspectedFloorItemY).Append(") — ")
        .Append(records.Count).Append(" record(s)");
    for (int i = 0; i < records.Count; i++)
    {
      FloorItemPlacementRecord entry = records[i];
      string label = GetFloorItemDisplayName(entry);
      string compactId = GetCompactFloorItemId(entry.id);
      string description = label + " [" + compactId + "]";
      tooltip.Append("\n").Append(i + 1).Append(". ").Append(description);
      if (i < 2)
      {
        if (i > 0)
          brief.Append(", ");
        brief.Append("<color=#00FF00>").Append(label)
            .Append("</color> [").Append(compactId).Append("]");
      }
    }
    if (records.Count > 2)
      brief.Append(" — 2 items + ").Append(records.Count - 2).Append(" more");
    return new GUIContent(brief.ToString(), tooltip.ToString());
  }


  // Verification restarts for each champion: visual equipment, pickup,
  // floor drop, and throwing must all be tested before marking green.
  private static readonly string[] VerifiedChampionEquipmentNames =
  {
    "Iaido",
    "Halk",
    "Zed",
    "Hawk",
    "Chani",
    "Alex",
    "Nabi",
    "Wu Tse",
    "Daroou",
    "Stamm",
    "Wuuf",
    "Mophus",
    "Leif",
    "Boris",
    "Elija",
    "Linflas",
    "Azizi",
    "Tiggy",
    "Hissssa",
    "Gothmog",
    "Gando",
    "Leyla",
    "Sonja",
    "Syra",
  };

  private static readonly ChampionMirrorMarker[] ChampionMirrorMarkers =
  {
    new ChampionMirrorMarker(10, 4, WallSide.North, "Iaido"),
    new ChampionMirrorMarker(10, 5, WallSide.South, "Zed"),
    new ChampionMirrorMarker(14, 3, WallSide.North, "Chani"),
    new ChampionMirrorMarker(15, 4, WallSide.East, "Hawk"),
    new ChampionMirrorMarker(14, 6, WallSide.South, "Boris"),
    new ChampionMirrorMarker(16, 8, WallSide.North, "Alex"),
    new ChampionMirrorMarker(17, 9, WallSide.South, "Nabi"),
    new ChampionMirrorMarker(16, 14, WallSide.South, "Hissssa"),
    new ChampionMirrorMarker(16, 17, WallSide.North, "Gothmog"),
    new ChampionMirrorMarker(14, 12, WallSide.East, "Sonja"),
    new ChampionMirrorMarker(13, 12, WallSide.North, "Leyla"),
    new ChampionMirrorMarker(13, 14, WallSide.East, "Mophus"),
    new ChampionMirrorMarker(12, 13, WallSide.West, "Wuuf"),
    new ChampionMirrorMarker(11, 15, WallSide.South, "Stamm"),
    new ChampionMirrorMarker(7, 16, WallSide.South, "Azizi"),
    new ChampionMirrorMarker(8, 15, WallSide.North, "Leif"),
    new ChampionMirrorMarker(9, 13, WallSide.East, "Tiggy"),
    new ChampionMirrorMarker(7, 13, WallSide.South, "Wu Tse"),
    new ChampionMirrorMarker(6, 13, WallSide.West, "Daroou"),
    new ChampionMirrorMarker(7, 9, WallSide.North, "Halk"),
    new ChampionMirrorMarker(9, 9, WallSide.South, "Syra"),
    new ChampionMirrorMarker(11, 10, WallSide.South, "Gando"),
    new ChampionMirrorMarker(12, 9, WallSide.North, "Linflas"),
    new ChampionMirrorMarker(9, 7, WallSide.West, "Elija")
  };

  private DungeonMap map;
  [System.Serializable] private sealed class DoorTocRoot
  {
    public DoorTocEntry[] levelOrnamentTables;
  }
  [System.Serializable] private sealed class DoorTocEntry
  {
    public int level;
    public bool resolved;
    public int[] door;
  }
  private int[] doorOrnamentToc;
  private int inspectedDoorX = -1, inspectedDoorY = -1;
  private void LoadDoorToc()
  {
    doorOrnamentToc = null;
    inspectedDoorX = inspectedDoorY = -1;
    if (!File.Exists(DungeonFeaturePlacementsPath)) return;
    try
    {
      var root = JsonUtility.FromJson<DoorTocRoot>(File.ReadAllText(DungeonFeaturePlacementsPath));
      if (root == null || root.levelOrnamentTables == null) return;
      foreach (var entry in root.levelOrnamentTables)
        if (entry != null && entry.level == currentDungeonLevel && entry.resolved)
        { doorOrnamentToc = entry.door; break; }
    }
    catch (System.Exception ex)
    { Debug.Log("<color=cyan>Dungeon Features: Door TOC unavailable: " + ex.Message + "</color>"); }
  }
  private int DoorOrnamentId(DungeonMap.DoorData door)
  {
    int index = door.OrnamentOrdinal - 1;
    return doorOrnamentToc != null && index >= 0 && index < doorOrnamentToc.Length
        ? doorOrnamentToc[index] : -1;
  }
  private string DoorName(DungeonMap.DoorData door)
  {
    // Set 1 is the wooden base panel; the unornamented variant is verified in CSBwin.
    if (door.GraphicSet == 1 && (door.OrnamentOrdinal == 0 || DoorOrnamentId(door) == 3)) return "Wooden Door";
    if (DoorOrnamentId(door) == 7) return "Black Door";
    if (door.OrnamentOrdinal == 0 && door.GraphicSet == 0) return "Portcullis";
    return "Door S" + door.GraphicSet + (door.OrnamentOrdinal == 0 ? ""
        : DoorOrnamentId(door) >= 0 ? " O" + DoorOrnamentId(door)
        : " L" + door.OrnamentOrdinal);
  }
  private string DoorDetails(int x, int y, DungeonMap.DoorData door)
  {
    return DoorName(door) + " (" + x + "," + y + ") | Set " + door.GraphicSet
        + " | Ornament " + (door.OrnamentOrdinal == 0 ? "none" : DoorOrnamentId(door) >= 0
            ? DoorOrnamentId(door).ToString() : "local " + door.OrnamentOrdinal)
        + " | " + (door.OpensVertically ? "Upward" : "Sideways")
        + " | " + ((map.GetTile(x,y).Raw & 8) != 0 ? "Axis N/S" : "Axis E/W")
        + (door.HasButton ? " | Button" : "");
  }
  private static string DoorPreviewAssetPath(string name)
  {
    if (name == "Portcullis") return "Assets/Art/Doors/Door Portcullis_F1_96x88.png";
    if (name == "Black Door") return "Assets/Art/Doors/Black Door 96x88.png";
    if (name == "Wooden Door") return "Assets/Art/Doors/Door Wooden_F1_96x88.png";
    return null;
  }
  private void DrawDoorMapMarkers(Rect mapRect)
  {
    var style = new GUIStyle(EditorStyles.miniBoldLabel)
    {
      alignment = TextAnchor.MiddleCenter,
      fontSize = Mathf.Max(5, Mathf.RoundToInt(9f * mapZoom)),
      padding = new RectOffset(0,0,0,0),
      clipping = TextClipping.Clip
    };
    style.normal.textColor = Color.white;
    for (int y = 0; y < map.Height; y++)
      for (int x = 0; x < map.Width; x++)
      {
        if (!map.TryGetDoorData(x,y,out var door)) continue;
        Rect tile = new Rect(mapRect.x + x * CellSize, mapRect.y + y * CellSize, CellSize, CellSize);
        Rect mark = new Rect(tile.x + 2f * mapZoom, tile.y + 2f * mapZoom,
            tile.width - 4f * mapZoom, 13f * mapZoom);
        string name = DoorName(door);
        string code = name == "Black Door" ? "BD" : name == "Portcullis" ? "PC"
            : door.OrnamentOrdinal == 0 ? "S" + door.GraphicSet
            : DoorOrnamentId(door) >= 0 ? "O" + DoorOrnamentId(door) : "L" + door.OrnamentOrdinal;
        string assetPath = DoorPreviewAssetPath(name);
        Texture2D texture = assetPath != null
            ? AssetDatabase.LoadAssetAtPath<Texture2D>(assetPath) : null;
        if (texture != null)
        {
          // Same inset as the single floor-item icon, but preserve door proportions.
          float iconMargin = 2f * mapZoom;
          float iconSize = Mathf.Max(1f, CellSize - iconMargin * 2f);
          mark = new Rect(tile.center.x - iconSize * .5f,
              tile.center.y - iconSize * .5f, iconSize, iconSize);
          GUI.DrawTexture(mark, texture, ScaleMode.ScaleToFit, true);
          GUI.Label(mark, new GUIContent(string.Empty, DoorDetails(x,y,door)));
        }
        else
        {
          if (assetPath != null) ReportMissingMapIcon(assetPath, "door map icon");
          EditorGUI.DrawRect(mark, name == "Black Door" ? new Color(.15f,.15f,.15f)
              : name == "Portcullis" ? new Color(.30f,.43f,.55f) : new Color(.46f,.28f,.12f));
          GUI.Label(mark, new GUIContent(code, DoorDetails(x,y,door)), style);
        }
        if (TryGetSelectedSearchTile(out Vector2Int selectedDoor)
            && selectedDoor.x == x && selectedDoor.y == y)
        {
          Color pulse = new Color(0f, 1f, 0f, Mathf.Clamp01(GetSelectedSearchConnectorPulse()));
          float line = Mathf.Min(2f, mark.height * .25f);
          EditorGUI.DrawRect(new Rect(mark.x,mark.y,mark.width,line),pulse);
          EditorGUI.DrawRect(new Rect(mark.x,mark.yMax-line,mark.width,line),pulse);
        }
      }
  }
  private bool TryGetInspectedDoor(out DungeonMap.DoorData door)
  {
    door = default(DungeonMap.DoorData);
    return map != null && map.IsInside(inspectedDoorX, inspectedDoorY)
        && map.TryGetDoorData(inspectedDoorX, inspectedDoorY, out door);
  }
  private float GetDoorPopupWidth(DungeonMap.DoorData door)
  {
    var style = new GUIStyle(EditorStyles.label) { fontStyle = FontStyle.Bold };
    return Mathf.Max(112f, Mathf.Ceil(style.CalcSize(new GUIContent(DoorName(door))).x) + 24f);
  }
  private void DrawSelectedDoorPopup(Rect popup, Vector3 tileCenter, DungeonMap.DoorData door)
  {
    Handles.BeginGUI();
    Color previous = Handles.color;
    Handles.color = new Color(1f, 0.55f, 0f, 1f);
    Handles.DrawAAPolyLine(3f, tileCenter, new Vector3(popup.xMin, popup.center.y, 0f));
    Handles.color = previous;
    Handles.EndGUI();
    EditorGUI.DrawRect(popup, new Color(.15f,.15f,.15f,1f));
    Color border = new Color(.45f,.45f,.45f,1f);
    EditorGUI.DrawRect(new Rect(popup.x,popup.y,popup.width,1f),border);
    EditorGUI.DrawRect(new Rect(popup.x,popup.yMax-1f,popup.width,1f),border);
    EditorGUI.DrawRect(new Rect(popup.x,popup.y,1f,popup.height),border);
    EditorGUI.DrawRect(new Rect(popup.xMax-1f,popup.y,1f,popup.height),border);
    GUI.Label(new Rect(popup.x+8f,popup.y+8f,popup.width-16f,18f),
        "("+inspectedDoorX+","+inspectedDoorY+")  1 door", EditorStyles.miniBoldLabel);
    var style = new GUIStyle(EditorStyles.label) { alignment = TextAnchor.MiddleCenter,
        fontStyle = FontStyle.Bold, normal = { textColor = Color.green } };
    GUI.Label(new Rect(popup.x+8f,popup.y+26f,popup.width-16f,26f),
        new GUIContent(DoorName(door), DoorDetails(inspectedDoorX,inspectedDoorY,door)),style);
    string path = DoorPreviewAssetPath(DoorName(door));
    Texture2D texture = path != null ? AssetDatabase.LoadAssetAtPath<Texture2D>(path) : null;
    Rect icon = new Rect(popup.center.x-24f,popup.y+54f,48f,48f);
    if (texture != null) GUI.DrawTexture(icon,texture,ScaleMode.ScaleToFit,true);
    else
    {
      if (path != null) ReportMissingMapIcon(path,"door inspection icon");
      GUI.Label(icon, new GUIContent("Door",DoorDetails(inspectedDoorX,inspectedDoorY,door)),EditorStyles.centeredGreyMiniLabel);
    }
  }
  private string mapLoadError;
  private Vector2 mapScroll;
  private int mapZoomStep = 0;
  private int selectedX = 1;
  private int selectedY = 2;
  private DungeonFacing selectedFacing = DungeonFacing.North;
  // Search the feature names on the currently displayed dungeon level.
  // Searching only changes inspection/highlight; the ViewEdit player pose stays put.
  private string featureSearchText = string.Empty;
  private readonly List<Vector2Int> featureSearchTiles = new List<Vector2Int>();
  private int featureSearchIndex = -1;
  // Reset the selected green connector's pulse whenever navigation changes
  // the highlighted tile, including wrapping from the last match to the first.
  private double selectedConnectorPulseStartTime;
  // Matching floor-item or wall-ornament tiles can share one right-side
  // preview and orange-connector overview; other feature searches keep their
  // original single-tile behavior.
  private readonly List<Vector2Int> floorSearchOverviewTiles =
      new List<Vector2Int>();
  private FloorItemPlacementRecord floorSearchOverviewItem;
  private readonly List<Vector2Int> wallSearchOverviewTiles =
      new List<Vector2Int>();
  private OriginalWallOrnamentMarker wallSearchOverviewMarker;
  private bool searchOverviewActive;
  private bool focusSearchOnMouse5;
  private bool replaceSearchTextOnNextGui;
  private bool scrollToSearchTile;
  private static readonly Color FeatureSearchBorderColor = new Color(0f, 1f, 0f, 1f);
  private int currentDungeonLevel = HallOfChampionsLevel;

  private bool ornamentTexturesResolved;
  private readonly Dictionary<string, Texture2D> floorItemInventoryIconCache =
      new Dictionary<string, Texture2D>();
  private Texture2D viAltarMapIcon;
  private Texture2D hookMapIcon;
  private Texture2D woodRingMapIcon;
  private Texture2D slimeMapIcon;
  private Texture2D grateMapIcon;
  private Texture2D manaclesMapIcon;
  private Texture2D fullTorchHolderMapIcon;
  private Texture2D puddleMapIcon;
  private Texture2D mossMapIcon;
  private Texture2D stairDownMapIcon;
  // Report missing icons once per editor-window lifetime, not every repaint.
  private readonly HashSet<string> missingMapIconErrors =
      new HashSet<string>();

  [MenuItem("Tools/Dungeon Feature Editor &f")]
  public static void Open()
  {
    DungeonFeatureEditor window =
        GetWindow<DungeonFeatureEditor>("Dungeon Features");
    window.minSize = new Vector2(1200f, 800f);
    window.Focus();
  }

  // Called by ViewEdit after opening/maximizing this window with a thumb
  // button. The existing deferred IMGUI focus mechanism handles the repaint.
  public void FocusSearchItem()
  {
    focusSearchOnMouse5 = true;
    Focus();
    Repaint();
  }

  private void OnEnable()
  {
    showFloorItems = true; // Floor-item badges are always visible.
    mapZoomStep = Mathf.Clamp(EditorPrefs.GetInt(MapZoomPreferenceKey, 0), 0, MaxMapZoomStep);
    ornamentTexturesResolved = false;
    floorItemInventoryIconCache.Clear();
    missingMapIconErrors.Clear();
    viAltarMapIcon = null;
    hookMapIcon = null;
    woodRingMapIcon = null;
    slimeMapIcon = null;
    grateMapIcon = null;
    manaclesMapIcon = null;
    fullTorchHolderMapIcon = null;
    puddleMapIcon = null;
    mossMapIcon = null;
    stairDownMapIcon = null;

    currentDungeonLevel = Mathf.Clamp(
        EditorPrefs.GetInt(
            ViewEditPreviewLevelKey,
            HallOfChampionsLevel),
        HallOfChampionsLevel,
        MaxDungeonLevel);

    LoadMapForLevel(currentDungeonLevel);
    SyncSelectionFromViewEdit();
  }

  private void OnInspectorUpdate()
  {
    bool changed = SyncLevelFromViewEdit();
    changed |= SyncSelectionFromViewEdit();
    if (changed || searchOverviewActive || (map != null && TryGetSelectedSearchTile(out Vector2Int doorTile) && map.TryGetDoorData(doorTile.x, doorTile.y, out _)))
      Repaint();
  }

  private static string GetMapPathForLevel(int level)
  {
    if (level == HallOfChampionsLevel)
      return HallOfChampionsMapPath;

    return $"Assets/Data/Maps/DungeonMaster_Level{level:00}.json";
  }

  private bool SyncLevelFromViewEdit()
  {
    int requestedLevel = Mathf.Clamp(
        EditorPrefs.GetInt(
            ViewEditPreviewLevelKey,
            currentDungeonLevel),
        HallOfChampionsLevel,
        MaxDungeonLevel);

    if (requestedLevel == currentDungeonLevel)
      return false;

    if (!LoadMapForLevel(requestedLevel))
      return false;

    return true;
  }

  private bool LoadMapForLevel(int level)
  {
    string mapPath = GetMapPathForLevel(level);
    if (!File.Exists(mapPath))
    {
      mapLoadError = "Map not found at " + mapPath;
      return false;
    }

    DungeonMap previousMap = map;
    int previousLevel = currentDungeonLevel;

    try
    {
      string json = File.ReadAllText(mapPath);
      DungeonMap loadedMap = DungeonMap.LoadFromJsonText(json);

      map = loadedMap;
      currentDungeonLevel = level;
      LoadDoorToc();
      mapLoadError = null;

      resolvedWallOrnaments = new OriginalWallOrnamentMarker[0];
      resolvedPuddleFloors.Clear();
      resolvedMossFloors.Clear();
      LoadFloorItemMapLayer();
      inspectedFloorItemX = -1;
      inspectedFloorItemY = -1;

      if (!LoadResolvedFeaturesFromDatabase())
      {
        if (level == HallOfChampionsLevel)
        {
          resolvedWallOrnaments = BuildGreyWallOrnaments(map);
          BuildHallOfChampionsPuddleFloors(map, resolvedPuddleFloors);
        }
      }

      // The shared pose is applied immediately after this load. Use the map's
      // own start only as a safe temporary value while the level changes.
      selectedX = map.StartX;
      selectedY = map.StartY;
      selectedFacing = map.StartFacing;
      RebuildFeatureSearch();
      return true;
    }
    catch (System.Exception ex)
    {
      map = previousMap;
      currentDungeonLevel = previousLevel;
      resolvedWallOrnaments = new OriginalWallOrnamentMarker[0];
      resolvedPuddleFloors.Clear();
      resolvedMossFloors.Clear();
      resolvedFloorItems.Clear();
      mapLoadError = ex.Message;
      Debug.LogWarning(
          "Dungeon Features: Could not load level " + level
          + " from " + mapPath + ": " + ex.Message);
      return false;
    }
  }

  private bool SyncSelectionFromViewEdit()
  {
    if (map == null
        || !EditorPrefs.HasKey(ViewEditPreviewXKey)
        || !EditorPrefs.HasKey(ViewEditPreviewYKey))
    {
      return false;
    }

    int viewEditX = EditorPrefs.GetInt(ViewEditPreviewXKey, selectedX);
    int viewEditY = EditorPrefs.GetInt(ViewEditPreviewYKey, selectedY);
    DungeonFacing viewEditFacing = (DungeonFacing)EditorPrefs.GetInt(
        ViewEditPreviewFacingKey,
        (int)selectedFacing);

    if (!map.IsInside(viewEditX, viewEditY))
      return false;

    bool changed =
        selectedX != viewEditX
        || selectedY != viewEditY
        || selectedFacing != viewEditFacing;

    if (!changed)
      return false;

    selectedX = viewEditX;
    selectedY = viewEditY;
    selectedFacing = viewEditFacing;
    return true;
  }

  private bool HandleRightMouseWindowSwitch()
  {
    Event current = Event.current;
    if (current == null
        || current.type != EventType.MouseDown
        || current.button != 1)
    {
      return false;
    }

    current.Use();
    EditorApplication.delayCall += ViewportLayoutEditor.Open;
    return true;
  }

  private void OnGUI()
  {
    if (HandleRightMouseWindowSwitch())
      return;

    // Unity reports auxiliary thumb buttons as 3/4; mouse-driver mappings vary.
    // Queue the focus until the next Repaint: focusing during MouseDown can be
    // undone by IMGUI's own mouse/keyboard focus handling in the same event.
    Event mouseEvent = Event.current;
    if (mouseEvent != null && mouseEvent.type == EventType.MouseDown
        && (mouseEvent.button == 3 || mouseEvent.button == 4))
    {
      focusSearchOnMouse5 = true;
      mouseEvent.Use();
      Repaint();
    }

    Event current = Event.current;
    if (current.type == EventType.KeyDown
        && current.keyCode == KeyCode.Escape)
    {
      current.Use();
      Close();
      return;
    }

    if (map == null)
    {
      EditorGUILayout.HelpBox(
          string.IsNullOrEmpty(mapLoadError)
              ? "Could not load Hall of Champions map."
              : mapLoadError,
          MessageType.Error);
      return;
    }

    GUIStyle poseStyle = new GUIStyle(EditorStyles.boldLabel)
    {
      fontSize = 14
    };

    EditorGUILayout.BeginHorizontal();
    GUILayout.Label("Map", GUILayout.Width(28f));

    if (GUILayout.Button("<", GUILayout.Width(24f)))
      SetDungeonLevelFromUi(currentDungeonLevel - 1);

    EditorGUI.BeginChangeCheck();
    int requestedLevel = EditorGUILayout.DelayedIntField(
        currentDungeonLevel,
        GUILayout.Width(34f));
    if (EditorGUI.EndChangeCheck())
    {
      SetDungeonLevelFromUi(requestedLevel);
      GUI.FocusControl(null);
    }

    if (GUILayout.Button(">", GUILayout.Width(24f)))
      SetDungeonLevelFromUi(currentDungeonLevel + 1);

    GUILayout.Space(10f);
    GUILayout.Label(
        $"{selectedX} X / Y {selectedY} {selectedFacing}",
        poseStyle,
        GUILayout.ExpandWidth(false),
        GUILayout.Height(20f));
    GUIContent floorSummary = GetSelectedFloorItemsSummary();
    if (!string.IsNullOrEmpty(floorSummary.text))
    {
      GUIStyle coloredItemSummaryStyle = new GUIStyle(EditorStyles.label)
      {
        richText = true
      };
      GUILayout.Label(floorSummary, coloredItemSummaryStyle,
          GUILayout.ExpandWidth(false), GUILayout.Height(20f));
    }
    GUILayout.FlexibleSpace();
    DrawFeatureSearchToolbar();
    EditorGUILayout.EndHorizontal();

    DrawMapGrid();
  }

  // Search controls share the map/pose header row, aligned to its right edge.
  private void DrawFeatureSearchToolbar()
  {
    // Handle Enter BEFORE TextField receives the event. Unity's IMGUI
    // TextField can consume Return to commit editing, which previously
    // required a second press to advance to the next search result.
    Event keyEvent = Event.current;
    bool resetThisPass = false;
    // A map click may have changed the query between GUI passes. Flush the
    // cached IMGUI text editor before it can restore the previous word.
    if (replaceSearchTextOnNextGui)
    {
      GUI.FocusControl(null);
      replaceSearchTextOnNextGui = false;
      focusSearchOnMouse5 = true;
    }
    if (keyEvent.type == EventType.KeyDown
        && GUI.GetNameOfFocusedControl() == "DungeonFeaturesSearchItem")
    {
      if (keyEvent.keyCode == KeyCode.Backspace)
      {
        ResetFeatureSearch();
        resetThisPass = true;
        keyEvent.Use();
      }
      else if (keyEvent.keyCode == KeyCode.Return
          || keyEvent.keyCode == KeyCode.KeypadEnter)
      {
        NavigateFeatureSearch(1);
        keyEvent.Use();
      }
    }

    // Keep Reset immediately to the left of the search caption.
    if (GUILayout.Button("Reset", GUILayout.Width(48f)))
    {
      ResetFeatureSearch();
      resetThisPass = true;
    }
    GUILayout.Label("Search item", GUILayout.Width(76f));
    GUI.SetNextControlName("DungeonFeaturesSearchItem");
    EditorGUI.BeginChangeCheck();
    string requested = EditorGUILayout.TextField(featureSearchText,
        GUILayout.Width(112f));
    // GUI controls are fully registered by Repaint. Defer keyboard focus to
    // this pass instead of applying it during the thumb-button MouseDown.
    if (focusSearchOnMouse5 && Event.current.type == EventType.Repaint)
    {
      GUI.FocusControl("DungeonFeaturesSearchItem");
      EditorGUI.FocusTextInControl("DungeonFeaturesSearchItem");
      focusSearchOnMouse5 = false;
    }
    // Do not let an old IMGUI TextField edit buffer re-apply stale text
    // during the same event that Reset was triggered.
    if (resetThisPass)
      requested = string.Empty;
    // Limit query length to twelve characters, including pasted input.
    if (requested.Length > 12)
      requested = requested.Substring(0, 12);
    if (EditorGUI.EndChangeCheck() || requested != featureSearchText)
    {
      featureSearchText = requested;
      RebuildFeatureSearch();
    }

    bool hasMatches = featureSearchTiles.Count > 0;
    EditorGUI.BeginDisabledGroup(!hasMatches);
    if (GUILayout.Button("<", GUILayout.Width(24f)))
      NavigateFeatureSearch(-1);
    if (GUILayout.Button(">", GUILayout.Width(24f)))
      NavigateFeatureSearch(1);
    EditorGUI.EndDisabledGroup();
    GUILayout.Label(string.IsNullOrWhiteSpace(featureSearchText)
            ? "0 / 0"
            : hasMatches
                ? (featureSearchIndex + 1) + " / " + featureSearchTiles.Count
                : "0 / 0",
        EditorStyles.miniLabel, GUILayout.Width(48f));
  }

  // Clear all results and their orange-line overview while preserving keyboard
  // focus for a fresh search. The normal (pre-overview) map zoom returns via
  // RebuildFeatureSearch; no player pose or map data is modified.
  private void ResetFeatureSearch()
  {
    featureSearchText = string.Empty;
    inspectedDoorX = inspectedDoorY = -1;
    RebuildFeatureSearch();
    // Clear IMGUI's cached edit buffer before returning focus; otherwise its
    // previous text can be restored on the next GUI event.
    GUI.FocusControl(null);
    focusSearchOnMouse5 = true; // Reapply TextField focus on the next repaint.
    Repaint();
  }

  private static bool FeatureNameMatches(string value, string query)
  {
    return !string.IsNullOrEmpty(value)
        && value.IndexOf(query, System.StringComparison.OrdinalIgnoreCase) >= 0;
  }

  private void RebuildFeatureSearch()
  {
    featureSearchTiles.Clear();
    featureSearchIndex = -1;
    scrollToSearchTile = false;
    floorSearchOverviewTiles.Clear();
    floorSearchOverviewItem = null;
    wallSearchOverviewTiles.Clear();
    wallSearchOverviewMarker = null;
    searchOverviewActive = false;
    if (map == null || string.IsNullOrWhiteSpace(featureSearchText))
      return;

    string query = featureSearchText.Trim();
    HashSet<int> matched = new HashSet<int>();
    HashSet<int> matchedFloorTiles = new HashSet<int>();
    HashSet<int> matchedWallTiles = new HashSet<int>();
    foreach (var pair in resolvedFloorItems)
    {
      List<FloorItemPlacementRecord> records = pair.Value;
      if (records == null)
        continue;
      foreach (FloorItemPlacementRecord item in records)
      {
        if (item != null && FeatureNameMatches(GetFloorItemDisplayName(item), query)
            && map.IsInside(item.localX, item.localY))
        {
          int tileKey = PackFloorFeatureTile(item.localX, item.localY);
          matched.Add(tileKey);
          matchedFloorTiles.Add(tileKey);
          if (floorSearchOverviewItem == null)
            floorSearchOverviewItem = item;
        }
      }
    }
    if (resolvedWallOrnaments != null)
    {
      foreach (OriginalWallOrnamentMarker ornament in resolvedWallOrnaments)
      {
        if (ornament != null && FeatureNameMatches(ornament.Type, query)
            && map.IsInside(ornament.X, ornament.Y))
        {
          int tileKey = PackFloorFeatureTile(ornament.X, ornament.Y);
          matched.Add(tileKey);
          matchedWallTiles.Add(tileKey);
          if (wallSearchOverviewMarker == null)
            wallSearchOverviewMarker = ornament;
        }
      }
    }
    for (int y = 0; y < map.Height; y++)
    {
      for (int x = 0; x < map.Width; x++)
      {
        int key = PackFloorFeatureTile(x, y);
        if (map.TryGetDoorData(x, y, out var door)
            && (FeatureNameMatches(DoorName(door), query)
                || FeatureNameMatches("Door", query)))
          matched.Add(key);
        if ((FeatureNameMatches("Puddle", query) && resolvedPuddleFloors.Contains(key))
            || (FeatureNameMatches("Moss", query) && resolvedMossFloors.Contains(key)))
          matched.Add(key);
        DungeonTile tile = map.GetTile(x, y);
        if (tile != null && FeatureNameMatches("Stairs", query)
            && tile.TryGetStairsDirection(out bool stairsUp)
            && (FeatureNameMatches(stairsUp ? "Stairs Up" : "Stairs Down", query)))
          matched.Add(key);
      }
    }
    if (currentDungeonLevel == HallOfChampionsLevel)
    {
      foreach (ChampionMirrorMarker champion in ChampionMirrorMarkers)
      {
        if ((FeatureNameMatches(champion.Champion, query)
                || FeatureNameMatches("Champion Mirror", query))
            && map.IsInside(champion.X, champion.Y))
          matched.Add(PackFloorFeatureTile(champion.X, champion.Y));
      }
    }
    // Read the inscriptions file once per search, not once per tile/repaint.
    if (File.Exists(DungeonInscriptionsPath))
    {
      try
      {
        DungeonInscriptionCollection inscriptions =
            JsonUtility.FromJson<DungeonInscriptionCollection>(
                File.ReadAllText(DungeonInscriptionsPath));
        if (inscriptions != null && inscriptions.inscriptions != null)
        {
          foreach (DungeonInscriptionRecord inscription in inscriptions.inscriptions)
          {
            if (inscription != null && inscription.level == currentDungeonLevel
                && map.IsInside(inscription.x, inscription.y)
                && (FeatureNameMatches("Inscription", query)
                    || FeatureNameMatches(inscription.text, query)))
              matched.Add(PackFloorFeatureTile(inscription.x, inscription.y));
          }
        }
      }
      catch (System.Exception ex)
      {
        Debug.LogWarning("Dungeon Features: Search could not read inscriptions: "
            + ex.Message);
      }
    }
    // Stable tile order: top-to-bottom, then left-to-right. A tile with
    // multiple matching items appears once.
    for (int y = 0; y < map.Height; y++)
      for (int x = 0; x < map.Width; x++)
        if (matched.Contains(PackFloorFeatureTile(x, y)))
          featureSearchTiles.Add(new Vector2Int(x, y));
    // Use deterministic map-row order for every orange connector.
    foreach (Vector2Int tile in featureSearchTiles)
    {
      int tileKey = PackFloorFeatureTile(tile.x, tile.y);
      if (matchedFloorTiles.Contains(tileKey))
        floorSearchOverviewTiles.Add(tile);
      if (matchedWallTiles.Contains(tileKey))
        wallSearchOverviewTiles.Add(tile);
    }
    searchOverviewActive = (floorSearchOverviewItem != null
            && floorSearchOverviewTiles.Count > 0)
        || (wallSearchOverviewMarker != null
            && wallSearchOverviewTiles.Count > 0);
    if (searchOverviewActive)
      mapScroll = Vector2.zero; // Fit the whole map instead of following a tile.
    if (featureSearchTiles.Count > 0)
      NavigateFeatureSearch(1);
  }

  private void NavigateFeatureSearch(int delta)
  {
    if (featureSearchTiles.Count == 0)
      return;
    featureSearchIndex = (featureSearchIndex + delta + featureSearchTiles.Count)
        % featureSearchTiles.Count;
    // Restart the bright-green phase for every selected match, especially
    // when Enter wraps e.g. Apple 5/5 -> Apple 1/5.
    selectedConnectorPulseStartTime = EditorApplication.timeSinceStartup;
    Vector2Int tile = featureSearchTiles[featureSearchIndex];
    inspectedDoorX = tile.x;
    inspectedDoorY = tile.y;
    inspectedFloorItemX = tile.x;
    inspectedFloorItemY = tile.y;
    inspectedOrnamentX = tile.x;
    inspectedOrnamentY = tile.y;
    inspectedInscriptionX = tile.x;
    inspectedInscriptionY = tile.y;
    scrollToSearchTile = !searchOverviewActive;
    Repaint();
  }

  private void DrawFeatureSearchHighlight(Rect mapRect)
  {
    if (featureSearchIndex < 0 || featureSearchIndex >= featureSearchTiles.Count)
      return;
    Vector2Int tile = featureSearchTiles[featureSearchIndex];
    if (!map.IsInside(tile.x, tile.y))
      return;
    // 2 GUI-pixel border *inside* the tile: no resizing or map-scale changes.
    Rect rect = new Rect(mapRect.x + tile.x * CellSize,
        mapRect.y + tile.y * CellSize, CellSize, CellSize);
    float thickness = Mathf.Min(2f, rect.width / 2f, rect.height / 2f);
    EditorGUI.DrawRect(new Rect(rect.x, rect.y, rect.width, thickness), FeatureSearchBorderColor);
    EditorGUI.DrawRect(new Rect(rect.x, rect.yMax - thickness, rect.width, thickness), FeatureSearchBorderColor);
    EditorGUI.DrawRect(new Rect(rect.x, rect.y, thickness, rect.height), FeatureSearchBorderColor);
    EditorGUI.DrawRect(new Rect(rect.xMax - thickness, rect.y, thickness, rect.height), FeatureSearchBorderColor);
  }

  private void SetDungeonLevelFromUi(int requestedLevel)
  {
    requestedLevel = Mathf.Clamp(
        requestedLevel,
        HallOfChampionsLevel,
        MaxDungeonLevel);

    if (requestedLevel == currentDungeonLevel)
      return;

    if (!LoadMapForLevel(requestedLevel) || map == null)
      return;

    // LoadMapForLevel seeds the selection from the new map's authored start.
    // Publish the whole pose so ViewEdit can switch level and land on the same
    // tile/facing instead of retaining coordinates from the previous map.
    EditorPrefs.SetInt(ViewEditPreviewLevelKey, currentDungeonLevel);
    EditorPrefs.SetInt(ViewEditPreviewXKey, selectedX);
    EditorPrefs.SetInt(ViewEditPreviewYKey, selectedY);
    EditorPrefs.SetInt(
        ViewEditPreviewFacingKey,
        (int)selectedFacing);

    Repaint();
  }

  private void DrawMapGrid()
  {
    float mapPixelWidth = map.Width * CellSize;
    float mapPixelHeight = map.Height * CellSize;
    List<FloorItemPlacementRecord> previewRecords = GetInspectedFloorItems();
    bool showItemPreview = !searchOverviewActive
        && previewRecords != null && previewRecords.Count > 0;
    // Reserve sufficient horizontal space for one row of item previews.
    List<OriginalWallOrnamentMarker> selectedOrnaments = GetSelectedWallOrnaments();
    float floorReserve = showItemPreview
        ? GetSelectedFloorItemPopupWidth(previewRecords.Count) + 16f
        : 0f;
    float popupReserve = Mathf.Max(floorReserve,
        selectedOrnaments.Count > 0 ? 170f * mapZoom : 0f);
    if (!searchOverviewActive && TryGetInspectedDoor(out var reserveDoor))
      popupReserve = Mathf.Max(popupReserve, GetDoorPopupWidth(reserveDoor) + 16f);
    if (searchOverviewActive)
      popupReserve = Mathf.Max(popupReserve, 170f);
    List<DungeonInscriptionRecord> selectedInscriptions =
        GetInscriptionRecordsAt(inspectedInscriptionX, inspectedInscriptionY);
    if (selectedInscriptions.Count > 0)
      popupReserve = Mathf.Max(popupReserve, 250f);
    float contentWidth =
        LabelLeftMargin * mapZoom
        + Mathf.Max(map.Width, OutsideNameColumnX + 2) * CellSize
        + popupReserve;
    float contentHeight =
        LabelTopMargin * mapZoom
        + OutsideFeatureVerticalMargin * mapZoom
        + mapPixelHeight
        + OutsideFeatureVerticalMargin * mapZoom;
    if (selectedInscriptions.Count > 0)
    {
      // Reserve full-height scrollable space for the unscaled INS panel.
      float inscriptionPanelHeight = 30f;
      foreach (DungeonInscriptionRecord entry in selectedInscriptions)
      {
        int lines = string.IsNullOrEmpty(entry.text) ? 1
            : entry.text.Split('\n').Length;
        inscriptionPanelHeight += (lines + 2) * 16f + 9f;
      }
      contentHeight = Mathf.Max(contentHeight,
          2f * mapZoom + inscriptionPanelHeight + 8f);
    }

    // Apply pending search navigation BEFORE BeginScrollView consumes mapScroll.
    // Updating it inside an already-open scroll view makes the visible map
    // lag one navigation press behind the selected search result.
    if (scrollToSearchTile && featureSearchIndex >= 0
        && featureSearchIndex < featureSearchTiles.Count)
    {
      Vector2Int target = featureSearchTiles[featureSearchIndex];
      float viewWidth = Mathf.Max(1f, position.width - 24f);
      float viewHeight = Mathf.Max(1f, position.height - 125f);
      mapScroll.x = Mathf.Max(0f,
          LabelLeftMargin * mapZoom
          + (target.x + 0.5f) * CellSize - viewWidth * 0.5f);
      mapScroll.y = Mathf.Max(0f,
          (LabelTopMargin + OutsideFeatureVerticalMargin) * mapZoom
          + (target.y + 0.5f) * CellSize - viewHeight * 0.5f);
      scrollToSearchTile = false;
    }

    mapScroll = EditorGUILayout.BeginScrollView(mapScroll);

    Rect contentRect = GUILayoutUtility.GetRect(
        contentWidth,
        contentHeight,
        GUILayout.Width(contentWidth),
        GUILayout.Height(contentHeight),
        GUILayout.ExpandWidth(false),
        GUILayout.ExpandHeight(false)
    );

    Rect mapRect = new Rect(
        contentRect.x + LabelLeftMargin * mapZoom,
        contentRect.y + (LabelTopMargin + OutsideFeatureVerticalMargin) * mapZoom,
        mapPixelWidth,
        mapPixelHeight
    );


    // Consume wheel events only inside the map content; elsewhere the window
    // keeps its normal scrolling behavior.
    HandleMapZoom(contentRect);
    DrawAxisLabels(mapRect);

    for (int y = 0; y < map.Height; y++)
    {
      for (int x = 0; x < map.Width; x++)
      {
        Rect cellRect = new Rect(
            mapRect.x + x * CellSize,
            mapRect.y + y * CellSize,
            CellSize,
            CellSize
        );

        DrawCell(
            cellRect,
            map.GetTile(x, y),
            x == selectedX && y == selectedY);
      }
    }

    // Resolve tile selection before drawing item-count overlays. A full-tile
    // orange count must never obscure inspection or double-click navigation.
    HandleGridClick(mapRect);
    DrawStairDownIcons(mapRect);
    DrawPuddleFloorIcons(mapRect);
    DrawMossFloorIcons(mapRect);
    DrawFloorItemMapIcons(mapRect);
    DrawOriginalWallOrnamentIcons(mapRect);
    DrawVerifiedChampionTileHighlights(mapRect);
    DrawChampionMirrorMarkers(mapRect);
    DrawInscriptionMarkers(mapRect);
    DrawDoorMapMarkers(mapRect);
    // The click may have selected a new tile during this GUI event.
    // Floor-item panels are rendered AFTER EndScrollView, so they can reach
    // the true top of the window without being clipped by its scroll area.
    DungeonMap.DoorData popupDoor;
    bool hasPopupDoor = TryGetInspectedDoor(out popupDoor);
    bool showDoorPopup = !searchOverviewActive && hasPopupDoor;
    bool showFloorPopup = !showDoorPopup && !searchOverviewActive
        && GetInscriptionRecordsAt(
        inspectedInscriptionX, inspectedInscriptionY).Count == 0
        && GetInspectedFloorItems() != null
        && GetInspectedFloorItems().Count > 0;
    if (!showDoorPopup && !showFloorPopup && !searchOverviewActive)
    {
      if (GetInscriptionRecordsAt(inspectedInscriptionX, inspectedInscriptionY).Count > 0)
        DrawSelectedInscriptionPreview(mapRect);
      else
        DrawSelectedWallOrnamentPreview(mapRect);
    }

    // Always paint the player tile LAST: no floor, ornament, champion or
    // preview layer may hide the cyan player location.
    DrawCurrentPlayerTileHighlight(mapRect);
    DrawFeatureSearchHighlight(mapRect);

    EditorGUILayout.EndScrollView();

    if (searchOverviewActive)
    {
      Rect scrollViewport = GUILayoutUtility.GetLastRect();
      if (floorSearchOverviewItem != null && floorSearchOverviewTiles.Count > 0)
        DrawFloorSearchOverview(mapRect, scrollViewport);
      else if (wallSearchOverviewMarker != null && wallSearchOverviewTiles.Count > 0)
        DrawWallSearchOverview(mapRect, scrollViewport);
    }
    else if (showDoorPopup)
    {
      Rect scrollViewport = GUILayoutUtility.GetLastRect();
      Rect popup = new Rect(mapRect.xMax + 8f - mapScroll.x + scrollViewport.x,
          29f, GetDoorPopupWidth(popupDoor), 110f);
      Vector3 center = new Vector3(mapRect.x + (inspectedDoorX + .5f) * CellSize
          - mapScroll.x + scrollViewport.x, mapRect.y + (inspectedDoorY + .5f) * CellSize
          - mapScroll.y + scrollViewport.y, 0f);
      DrawSelectedDoorPopup(popup, center, popupDoor);
    }
    else if (showFloorPopup)
    {
      // After EndScrollView, GUI coordinates refer to the editor window.
      // The popup can occupy the upper-right corner directly below the tab,
      // above the map's scroll viewport, without clipping.
      Rect scrollViewport = GUILayoutUtility.GetLastRect();
      List<FloorItemPlacementRecord> currentPopupRecords = GetInspectedFloorItems();
      if (currentPopupRecords != null && currentPopupRecords.Count > 0)
      {
        Rect popup = GetSelectedFloorItemPopupRect(mapRect,
            currentPopupRecords.Count);
        popup.x = mapRect.xMax + 8f - mapScroll.x + scrollViewport.x;
        popup.y = 29f;
        Vector3 tileCenter = new Vector3(
            mapRect.x + (inspectedFloorItemX + 0.5f) * CellSize
                - mapScroll.x + scrollViewport.x,
            mapRect.y + (inspectedFloorItemY + 0.5f) * CellSize
                - mapScroll.y + scrollViewport.y, 0f);
        DrawSelectedFloorItemsPopup(popup, tileCenter, currentPopupRecords);
      }
    }
  }

  private bool TryGetSelectedSearchTile(out Vector2Int tile)
  {
    if (featureSearchIndex >= 0 && featureSearchIndex < featureSearchTiles.Count)
    {
      tile = featureSearchTiles[featureSearchIndex];
      return true;
    }

    tile = default;
    return false;
  }

  private float GetSelectedSearchConnectorPulse()
  {
    const double pulsePeriodSeconds = 1.2d;
    double elapsed = System.Math.Max(0d,
        EditorApplication.timeSinceStartup - selectedConnectorPulseStartTime);
    double phase = (elapsed % pulsePeriodSeconds) / pulsePeriodSeconds;
    // Cosine starts at maximum brightness and width on selection, rather
    // than inheriting an arbitrary dim phase from the global editor clock.
    return 0.5f + 0.5f * Mathf.Cos((float)(phase * 2d * System.Math.PI));
  }

  // Searching for a floor item shows one item preview at the right and
  // connects EVERY matching floor tile to it. Coordinates remain in GUI
  // space (after EndScrollView), so the panel can sit at the window top.
  private void DrawFloorSearchOverview(Rect mapRect, Rect scrollViewport)
  {
    if (floorSearchOverviewItem == null || floorSearchOverviewTiles.Count == 0)
      return;

    const float panelWidth = 142f;
    const float panelHeight = 112f;
    float mapRight = mapRect.xMax - mapScroll.x + scrollViewport.x;
    Rect panel = new Rect(mapRight + 8f, 29f, panelWidth, panelHeight);
    Vector3 connectorEnd = new Vector3(panel.xMin, panel.center.y, 0f);
    bool hasSelectedTile = TryGetSelectedSearchTile(out Vector2Int selectedTile);
    float pulse = GetSelectedSearchConnectorPulse();
    Handles.BeginGUI();
    Color previousColor = Handles.color;
    Color baseConnectorColor = new Color(1f, 0.55f, 0f, 1f);
    foreach (Vector2Int tile in floorSearchOverviewTiles)
    {
      if (hasSelectedTile && tile == selectedTile)
        continue;

      Vector3 start = new Vector3(
          mapRect.x + (tile.x + 0.5f) * CellSize
              - mapScroll.x + scrollViewport.x,
          mapRect.y + (tile.y + 0.5f) * CellSize
              - mapScroll.y + scrollViewport.y, 0f);
      Handles.color = baseConnectorColor;
      Handles.DrawAAPolyLine(3f, start, connectorEnd);
    }
    if (hasSelectedTile && floorSearchOverviewTiles.Contains(selectedTile))
    {
      Vector3 start = new Vector3(
          mapRect.x + (selectedTile.x + 0.5f) * CellSize
              - mapScroll.x + scrollViewport.x,
          mapRect.y + (selectedTile.y + 0.5f) * CellSize
              - mapScroll.y + scrollViewport.y, 0f);
      // Selected connector stays 5 px wide; only its green brightness pulses.
      Handles.color = Color.Lerp(
          new Color(0f, 0.55f, 0f, 1f),
          new Color(0.25f, 1f, 0.25f, 1f), pulse);
      Handles.DrawAAPolyLine(5f, start, connectorEnd);
    }
    Handles.color = previousColor;
    Handles.EndGUI();

    List<FloorItemPlacementRecord> records = GetFloorSearchOverviewRecords();
    if (records == null || records.Count == 0)
      return;

    string header = records.Count > 1
        ? "(" + inspectedFloorItemX + "," + inspectedFloorItemY + ")  "
            + records.Count + (records.Count == 1 ? " item" : " items")
        : floorSearchOverviewTiles.Count + (floorSearchOverviewTiles.Count == 1
            ? " matching tile" : " matching tiles");
    float width = records.Count > 1
        ? Mathf.Max(142f, GetFloorItemPopupWidthForRecords(records, header))
        : panelWidth;
    panel.width = width;
    DrawFloorItemPopupContents(panel, records, header);
  }

  // Searching for a wall ornament uses the same top-right overview panel and
  // orange connector fan-out as floor-item searches. The map is already in
  // fit-to-window mode while any search overview is active.
  private void DrawWallSearchOverview(Rect mapRect, Rect scrollViewport)
  {
    if (wallSearchOverviewMarker == null || wallSearchOverviewTiles.Count == 0)
      return;

    const float panelWidth = 142f;
    const float panelHeight = 112f;
    float mapRight = mapRect.xMax - mapScroll.x + scrollViewport.x;
    Rect panel = new Rect(mapRight + 8f, 29f, panelWidth, panelHeight);
    Vector3 connectorEnd = new Vector3(panel.xMin, panel.center.y, 0f);
    bool hasSelectedTile = TryGetSelectedSearchTile(out Vector2Int selectedTile);
    float pulse = GetSelectedSearchConnectorPulse();
    Handles.BeginGUI();
    Color previousColor = Handles.color;
    Color baseConnectorColor = new Color(1f, 0.55f, 0f, 1f);
    foreach (Vector2Int tile in wallSearchOverviewTiles)
    {
      if (hasSelectedTile && tile == selectedTile)
        continue;

      Vector3 start = new Vector3(
          mapRect.x + (tile.x + 0.5f) * CellSize
              - mapScroll.x + scrollViewport.x,
          mapRect.y + (tile.y + 0.5f) * CellSize
              - mapScroll.y + scrollViewport.y, 0f);
      Handles.color = baseConnectorColor;
      Handles.DrawAAPolyLine(3f, start, connectorEnd);
    }
    if (hasSelectedTile && wallSearchOverviewTiles.Contains(selectedTile))
    {
      Vector3 start = new Vector3(
          mapRect.x + (selectedTile.x + 0.5f) * CellSize
              - mapScroll.x + scrollViewport.x,
          mapRect.y + (selectedTile.y + 0.5f) * CellSize
              - mapScroll.y + scrollViewport.y, 0f);
      // Selected connector stays 5 px wide; only its green brightness pulses.
      Handles.color = Color.Lerp(
          new Color(0f, 0.55f, 0f, 1f),
          new Color(0.25f, 1f, 0.25f, 1f), pulse);
      Handles.DrawAAPolyLine(5f, start, connectorEnd);
    }
    Handles.color = previousColor;
    Handles.EndGUI();

    EditorGUI.DrawRect(panel, new Color(0.15f, 0.15f, 0.15f, 1f));
    Color border = new Color(0.45f, 0.45f, 0.45f, 1f);
    EditorGUI.DrawRect(new Rect(panel.x, panel.y, panel.width, 1f), border);
    EditorGUI.DrawRect(new Rect(panel.x, panel.yMax - 1f, panel.width, 1f), border);
    EditorGUI.DrawRect(new Rect(panel.x, panel.y, 1f, panel.height), border);
    EditorGUI.DrawRect(new Rect(panel.xMax - 1f, panel.y, 1f, panel.height), border);

    GUIStyle heading = new GUIStyle(EditorStyles.miniBoldLabel)
    {
      alignment = TextAnchor.MiddleCenter
    };
    GUI.Label(new Rect(panel.x + 5f, panel.y + 6f,
        panel.width - 10f, 18f),
        wallSearchOverviewTiles.Count + (wallSearchOverviewTiles.Count == 1
            ? " matching wall" : " matching walls"), heading);
    GUIStyle itemStyle = new GUIStyle(EditorStyles.boldLabel)
    {
      alignment = TextAnchor.MiddleCenter,
      normal = { textColor = Color.green },
      wordWrap = true
    };
    GUI.Label(new Rect(panel.x + 5f, panel.y + 25f,
        panel.width - 10f, 30f),
        wallSearchOverviewMarker.Type, itemStyle);
    Texture2D icon = GetOrnamentMapIcon(wallSearchOverviewMarker.Type);
    if (icon != null)
      GUI.DrawTexture(new Rect(panel.center.x - 16f, panel.y + 62f,
          32f, 32f), icon, ScaleMode.StretchToFill, true);
  }

  // One horizontal row of floor-item previews (including single items). Each item uses a compact
  // mini-block: green name on top, 32x32 icon underneath. Record IDs are
  // omitted here to keep dense multi-item popups readable.
  // Split long multi-word names into two lines to keep an item pile compact.
  private string GetFloorItemPopupName(FloorItemPlacementRecord entry)
  {
    string name = GetFloorItemDisplayName(entry);
    int best = -1;
    int bestDifference = int.MaxValue;
    for (int i = 0; i < name.Length; i++)
    {
      if (name[i] != ' ')
        continue;
      int difference = Mathf.Abs(i - (name.Length - i - 1));
      if (difference < bestDifference)
      {
        bestDifference = difference;
        best = i;
      }
    }
    if (best < 0)
      return name;
    return name.Substring(0, best) + "\n" + name.Substring(best + 1);
  }

  private float GetFloorItemPopupBlockWidth(FloorItemPlacementRecord entry)
  {
    GUIStyle nameStyle = new GUIStyle(EditorStyles.label)
    {
      fontStyle = FontStyle.Bold
    };
    string[] lines = GetFloorItemPopupName(entry).Split('\n');
    float textWidth = 32f;
    for (int i = 0; i < lines.Length; i++)
      textWidth = Mathf.Max(textWidth,
          nameStyle.CalcSize(new GUIContent(lines[i])).x);
    // Allow a little breathing room for the bold label's internal padding.
    return Mathf.Ceil(textWidth) + 8f;
  }

  private float GetFloorItemPopupWidthForRecords(
      List<FloorItemPlacementRecord> records,
      string header)
  {
    if (records == null || records.Count == 0)
      return 0f;

    const float horizontalPadding = 8f;
    const float itemGap = 2f;
    float itemsWidth = Mathf.Max(0, records.Count - 1) * itemGap;
    for (int i = 0; i < records.Count; i++)
      itemsWidth += GetFloorItemPopupBlockWidth(records[i]);

    GUIStyle headingStyle = new GUIStyle(EditorStyles.miniBoldLabel);
    float headingWidth = headingStyle.CalcSize(new GUIContent(header)).x + 8f;
    return Mathf.Ceil(2f * horizontalPadding
        + Mathf.Max(itemsWidth, headingWidth));
  }

  private void DrawFloorItemPopupContents(
      Rect popup,
      List<FloorItemPlacementRecord> records,
      string header)
  {
    if (records == null || records.Count == 0)
      return;

    // Fully opaque backing and thin border.
    EditorGUI.DrawRect(popup, new Color(0.15f, 0.15f, 0.15f, 1f));
    float border = 1f;
    Color borderColor = new Color(0.45f, 0.45f, 0.45f, 1f);
    EditorGUI.DrawRect(new Rect(popup.x, popup.y, popup.width, border), borderColor);
    EditorGUI.DrawRect(new Rect(popup.x, popup.yMax - border, popup.width, border), borderColor);
    EditorGUI.DrawRect(new Rect(popup.x, popup.y, border, popup.height), borderColor);
    EditorGUI.DrawRect(new Rect(popup.xMax - border, popup.y, border, popup.height), borderColor);

    const float unit = 1f;
    float padding = 8f * unit;
    float headingHeight = 18f * unit;
    float iconSize = 32f * unit;
    float itemGap = 2f * unit;
    GUIStyle heading = new GUIStyle(EditorStyles.miniBoldLabel)
    {
      alignment = TextAnchor.MiddleLeft
    };
    GUI.Label(new Rect(popup.x + padding, popup.y + padding,
        popup.width - 2f * padding, headingHeight),
        header, heading);

    GUIStyle nameStyle = new GUIStyle(EditorStyles.label)
    {
      alignment = TextAnchor.MiddleCenter,
      normal = { textColor = Color.green },
      fontStyle = FontStyle.Bold,
      clipping = TextClipping.Clip
    };

    float rowY = popup.y + padding + headingHeight;
    float itemX = popup.x + padding;
    for (int i = 0; i < records.Count; i++)
    {
      FloorItemPlacementRecord entry = records[i];
      float itemWidth = GetFloorItemPopupBlockWidth(entry);
      string itemName = GetFloorItemPopupName(entry);
      GUI.Label(new Rect(itemX, rowY,
          itemWidth, 30f * unit),
          new GUIContent(itemName, GetFloorItemDisplayName(entry)), nameStyle);

      Rect iconRect = new Rect(
          itemX + (itemWidth - iconSize) * 0.5f,
          rowY + 30f * unit + 1f * unit,
          iconSize, iconSize);
      Texture2D texture = GetFloorItemInventoryMapIcon(entry);
      if (texture != null)
        GUI.DrawTexture(iconRect, texture, ScaleMode.StretchToFill, true);

      itemX += itemWidth + itemGap;
    }
  }

  private float GetSelectedFloorItemPopupWidth(int itemCount)
  {
    List<FloorItemPlacementRecord> records = GetInspectedFloorItems();
    if (records == null || records.Count != itemCount)
      return 0f;

    string header = "(" + inspectedFloorItemX + "," + inspectedFloorItemY
        + ")  " + itemCount + (itemCount == 1 ? " item" : " items");
    return GetFloorItemPopupWidthForRecords(records, header);
  }

  private Rect GetSelectedFloorItemPopupRect(Rect mapRect, int itemCount)
  {
    // The map may zoom, but the inspection panel stays at editor GUI 1:1.
    const float unit = 1f;
    float width = GetSelectedFloorItemPopupWidth(itemCount);
    float height = 8f * unit * 2f + 18f * unit + 64f * unit;
    float x = mapRect.xMax + 8f;
    // Default content-space rectangle for measuring popup dimensions.
    // Actual top-right window coordinates are set after EndScrollView.
    float y = mapRect.y;
    return new Rect(x, y, width, height);
  }

  private void DrawSelectedFloorItemsPopup(Rect popup, Vector3 tileCenter,
      List<FloorItemPlacementRecord> records)
  {
    if (records == null || records.Count == 0)
      return;

    Vector3 popupEnd = new Vector3(popup.xMin, popup.center.y, 0f);
    Handles.BeginGUI();
    Color previous = Handles.color;
    Handles.color = new Color(1f, 0.55f, 0f, 1f);
    Handles.DrawAAPolyLine(3f, tileCenter, popupEnd);
    Handles.color = previous;
    Handles.EndGUI();

    string header = "(" + inspectedFloorItemX + "," + inspectedFloorItemY
        + ")  " + records.Count + (records.Count == 1 ? " item" : " items");
    DrawFloorItemPopupContents(popup, records, header);
  }

  private void HandleMapZoom(Rect contentRect)
  {
    Event e = Event.current;
    if (e.type != EventType.ScrollWheel || !contentRect.Contains(e.mousePosition))
      return;
    if (searchOverviewActive)
    {
      e.Use(); // Automatic fit while viewing all matched item tiles.
      return;
    }

    // Wheel down zooms out; wheel up zooms back toward normal 1x size.
    int direction = e.delta.y > 0f ? 1 : -1;
    int nextZoomStep = mapZoomStep;
    float currentZoom = mapZoom;
    // Only two possible zoom positions: 1x and fit-to-window.
    nextZoomStep = Mathf.Clamp(nextZoomStep + direction, 0, MaxMapZoomStep);
    float nextZoom = GetZoomForStep(nextZoomStep);
    if (Mathf.Abs(nextZoom - currentZoom) <= 0.0001f)
    {
      e.Use();
      return;
    }

    float scale = nextZoom / currentZoom;
    // Preserve the point under the pointer in the scroll view while zooming.
    Vector2 anchor = e.mousePosition - contentRect.position;
    mapScroll += anchor * (scale - 1f);
    mapScroll.x = Mathf.Max(0f, mapScroll.x);
    mapScroll.y = Mathf.Max(0f, mapScroll.y);
    // Returning from Fit 32x32 to 100% starts at the first map row,
    // like returning to the top of a worksheet in Excel.
    if (mapZoomStep == MaxMapZoomStep && nextZoomStep == 0)
      mapScroll = Vector2.zero;
    mapZoomStep = nextZoomStep;
    EditorPrefs.SetInt(MapZoomPreferenceKey, mapZoomStep);
    e.Use();
    GUI.changed = true;
    Repaint();
  }

  private void DrawAxisLabels(Rect mapRect)
  {
    GUIStyle labelStyle = new GUIStyle(EditorStyles.miniLabel)
    {
      alignment = TextAnchor.MiddleCenter,
      fontSize = Mathf.Max(1, Mathf.RoundToInt(10f * mapZoom)),
      clipping = TextClipping.Overflow
    };

    GUIStyle yLabelStyle = new GUIStyle(labelStyle)
    {
      alignment = TextAnchor.MiddleRight
    };

    float xLabelWidth = 20f * mapZoom;

    for (int x = 0; x < map.Width; x++)
    {
      float columnCenterX =
          mapRect.x + x * CellSize + CellSize * 0.5f;

      Rect xLabelRect = new Rect(
          columnCenterX - xLabelWidth * 0.5f,
          mapRect.y - LabelTopMargin * mapZoom,
          xLabelWidth,
          LabelTopMargin * mapZoom
      );

      GUI.Label(xLabelRect, x.ToString(), labelStyle);
    }

    for (int y = 0; y < map.Height; y++)
    {
      Rect yLabelRect = new Rect(
          mapRect.x - LabelLeftMargin * mapZoom,
          mapRect.y + y * CellSize,
          (LabelLeftMargin - 2f) * mapZoom,
          CellSize
      );

      GUI.Label(yLabelRect, y.ToString(), yLabelStyle);
    }
  }

  private static void DrawCell(
      Rect cellRect,
      DungeonTile tile,
      bool isSelected)
  {
    EditorGUI.DrawRect(cellRect, CellBorderColor);

    Rect fillRect = new Rect(
        cellRect.x + 1f,
        cellRect.y + 1f,
        cellRect.width - 2f,
        cellRect.height - 2f
    );

    Color fillColor = tile.Type == DungeonTileType.Wall
        ? WallColor
        : FloorColor;

    EditorGUI.DrawRect(fillRect, fillColor);

    if (!isSelected)
      return;

    EditorGUI.DrawRect(fillRect, SelectionFillColor);
    EditorGUI.DrawRect(
        new Rect(cellRect.x, cellRect.y, cellRect.width, 2f),
        SelectionBorderColor);
    EditorGUI.DrawRect(
        new Rect(
            cellRect.x,
            cellRect.yMax - 2f,
            cellRect.width,
            2f),
        SelectionBorderColor);
    EditorGUI.DrawRect(
        new Rect(cellRect.x, cellRect.y, 2f, cellRect.height),
        SelectionBorderColor);
    EditorGUI.DrawRect(
        new Rect(
            cellRect.xMax - 2f,
            cellRect.y,
            2f,
            cellRect.height),
        SelectionBorderColor);
  }

  private static bool IsVerifiedChampionTile(int dungeonLevel, int tileX, int tileY)
  {
    if (dungeonLevel != HallOfChampionsLevel)
      return false;

    for (int i = 0; i < ChampionMirrorMarkers.Length; i++)
    {
      ChampionMirrorMarker marker = ChampionMirrorMarkers[i];
      if (marker.X != tileX || marker.Y != tileY)
        continue;

      for (int nameIndex = 0; nameIndex < VerifiedChampionEquipmentNames.Length; nameIndex++)
      {
        if (string.Equals(
                marker.Champion,
                VerifiedChampionEquipmentNames[nameIndex],
                System.StringComparison.OrdinalIgnoreCase))
          return true;
      }

      return false;
    }

    return false;
  }

  // Final tile highlight pass, drawn above ornaments and beneath champion names/markers.
  // This deliberately uses mirror coordinates (the champion's wall tile), not player coordinates.
  private void DrawVerifiedChampionTileHighlights(Rect mapRect)
  {
    if (currentDungeonLevel != HallOfChampionsLevel)
      return;

    for (int i = 0; i < ChampionMirrorMarkers.Length; i++)
    {
      ChampionMirrorMarker marker = ChampionMirrorMarkers[i];
      if (!IsVerifiedChampionTile(currentDungeonLevel, marker.X, marker.Y))
        continue;

      Rect tileRect = new Rect(
          mapRect.x + marker.X * CellSize + 1f,
          mapRect.y + marker.Y * CellSize + 1f,
          CellSize - 2f,
          CellSize - 2f);
      EditorGUI.DrawRect(tileRect, VerifiedChampionTileColor);
    }
  }

  // The current player tile is always solid cyan, regardless of the tile's
  // ordinary wall/floor color or any ornament, champion or item overlays.
  // ViewEdit's player pose is synchronized in OnInspectorUpdate.
  private void DrawCurrentPlayerTileHighlight(Rect mapRect)
  {
    if (map == null || !map.IsInside(selectedX, selectedY))
      return;

    Rect cell = new Rect(
        mapRect.x + selectedX * CellSize,
        mapRect.y + selectedY * CellSize,
        CellSize,
        CellSize);
    EditorGUI.DrawRect(cell, new Color(0f, 1f, 1f, 1f));

    // The dark arrow is centered on the cyan player tile and follows the
    // same selectedFacing synchronized with ViewEdit. No map data is changed.
    Vector2[] northArrow =
    {
      new Vector2(-0.12f,  0.30f),
      new Vector2( 0.12f,  0.30f),
      new Vector2( 0.12f, -0.06f),
      new Vector2( 0.30f, -0.06f),
      new Vector2( 0.00f, -0.38f),
      new Vector2(-0.30f, -0.06f),
      new Vector2(-0.12f, -0.06f)
    };

    Vector3[] vertices = new Vector3[northArrow.Length];
    for (int i = 0; i < northArrow.Length; i++)
    {
      float x = northArrow[i].x;
      float y = northArrow[i].y;
      float rotatedX = x;
      float rotatedY = y;
      switch (selectedFacing)
      {
        case DungeonFacing.East:
          rotatedX = -y;
          rotatedY = x;
          break;
        case DungeonFacing.South:
          rotatedX = -x;
          rotatedY = -y;
          break;
        case DungeonFacing.West:
          rotatedX = y;
          rotatedY = -x;
          break;
      }
      vertices[i] = new Vector3(
          cell.center.x + rotatedX * CellSize,
          cell.center.y + rotatedY * CellSize,
          0f);
    }

    Handles.BeginGUI();
    Color previousColor = Handles.color;
    Handles.color = new Color(0.05f, 0.15f, 0.20f, 1f);
    Handles.DrawAAConvexPolygon(vertices);
    Handles.color = previousColor;
    Handles.EndGUI();
  }

  private void DrawChampionMirrorMarkers(Rect mapRect)
  {
    // Champion mirrors/names are Hall-of-Champions-only. Other dungeon levels
    // use the all-level feature placement database without this overlay.
    if (currentDungeonLevel != HallOfChampionsLevel)
      return;

    for (int i = 0; i < ChampionMirrorMarkers.Length; i++)
    {
      ChampionMirrorMarker marker = ChampionMirrorMarkers[i];

      Rect cellRect = new Rect(
          mapRect.x + marker.X * CellSize,
          mapRect.y + marker.Y * CellSize,
          CellSize,
          CellSize);

      DrawWallFaceDirectionMarker(cellRect, marker.Side);
      DrawChampionName(mapRect, cellRect, marker);
    }
  }

  // Shared full-edge direction marker for champion mirrors and wall ornaments.
  // Wall face direction comes from each map placement, never from player facing.
  private void DrawWallFaceDirectionMarker(Rect cellRect, WallSide side)
  {
    float lineThickness = 3f * mapZoom;
    float dotSize = 4f * mapZoom;
    Rect lineRect;
    Rect dotRect;

    switch (side)
    {
      case WallSide.North:
      {
        float centerX = cellRect.center.x;
        lineRect = new Rect(
            cellRect.x,
            cellRect.y,
            cellRect.width,
            lineThickness);
        dotRect = new Rect(
            centerX - dotSize * 0.5f,
            cellRect.y - (dotSize - lineThickness) * 0.5f,
            dotSize,
            dotSize);
        break;
      }

      case WallSide.East:
      {
        float centerY = cellRect.center.y;
        lineRect = new Rect(
            cellRect.xMax - lineThickness,
            cellRect.y,
            lineThickness,
            cellRect.height);
        dotRect = new Rect(
            cellRect.xMax - lineThickness
                - (dotSize - lineThickness) * 0.5f,
            centerY - dotSize * 0.5f,
            dotSize,
            dotSize);
        break;
      }

      case WallSide.South:
      {
        float centerX = cellRect.center.x;
        lineRect = new Rect(
            cellRect.x,
            cellRect.yMax - lineThickness,
            cellRect.width,
            lineThickness);
        dotRect = new Rect(
            centerX - dotSize * 0.5f,
            cellRect.yMax - lineThickness
                - (dotSize - lineThickness) * 0.5f,
            dotSize,
            dotSize);
        break;
      }

      default: // West
      {
        float centerY = cellRect.center.y;
        lineRect = new Rect(
            cellRect.x,
            cellRect.y,
            lineThickness,
            cellRect.height);
        dotRect = new Rect(
            cellRect.x - (dotSize - lineThickness) * 0.5f,
            centerY - dotSize * 0.5f,
            dotSize,
            dotSize);
        break;
      }
    }

    EditorGUI.DrawRect(lineRect, ChampionMirrorLineColor);
    EditorGUI.DrawRect(dotRect, ChampionMirrorDotColor);
  }

  private void DrawStairDownIcons(Rect mapRect)
  {
    if (map == null)
      return;

    EnsureOrnamentTexturesResolved();

    float iconInset = 3f * mapZoom;

    for (int y = 0; y < map.Height; y++)
    {
      for (int x = 0; x < map.Width; x++)
      {
        DungeonTile tile = map.GetTile(x, y);
        if (tile == null
            || !tile.TryGetStairsDirection(out bool stairsUp)
            || stairsUp)
        {
          continue;
        }

        Rect cellRect = new Rect(
            mapRect.x + x * CellSize,
            mapRect.y + y * CellSize,
            CellSize,
            CellSize);

        Rect stairFillRect = new Rect(
            cellRect.x + 1f,
            cellRect.y + 1f,
            cellRect.width - 2f,
            cellRect.height - 2f);
        EditorGUI.DrawRect(stairFillRect, StairDownTileColor);

        Rect iconRect = new Rect(
            cellRect.x + iconInset,
            cellRect.y + iconInset,
            cellRect.width - iconInset * 2f,
            cellRect.height - iconInset * 2f);

        if (stairDownMapIcon != null)
        {
          GUI.DrawTexture(
              iconRect,
              stairDownMapIcon,
              ScaleMode.ScaleToFit,
              true);
        }
        else
        {
          ReportMissingMapIcon("Stairs_Down_Icon_20x22", "stairs-down map icon");
        }
      }
    }
  }

  private void DrawPuddleFloorIcons(Rect mapRect)
  {
    if (resolvedPuddleFloors.Count == 0)
      return;

    EnsureOrnamentTexturesResolved();

    float iconInset = 3f * mapZoom;
    for (int y = 0; y < map.Height; y++)
    {
      for (int x = 0; x < map.Width; x++)
      {
        if (!resolvedPuddleFloors.Contains(PackFloorFeatureTile(x, y)))
          continue;

        Rect cellRect = new Rect(
            mapRect.x + x * CellSize,
            mapRect.y + y * CellSize,
            CellSize,
            CellSize);
        Rect iconRect = new Rect(
            cellRect.x + iconInset,
            cellRect.y + iconInset,
            cellRect.width - iconInset * 2f,
            cellRect.height - iconInset * 2f);

        if (puddleMapIcon != null)
        {
          GUI.DrawTexture(
              iconRect,
              puddleMapIcon,
              ScaleMode.ScaleToFit,
              true);
        }
        else
        {
          ReportMissingMapIcon(PuddleF1AssetPath, "puddle map icon");
        }
      }
    }
  }

  // Floor moss has no wall-facing direction. Display it on the exact tile
  // from DungeonFeaturePlacements.json, including the player's own tile.
  private void DrawMossFloorIcons(Rect mapRect)
  {
    if (resolvedMossFloors.Count == 0)
      return;

    EnsureOrnamentTexturesResolved();
    if (mossMapIcon == null)
    {
      ReportMissingMapIcon(MossF1AssetName + ".png", "moss map icon");
      return;
    }

    float iconInset = 3f * mapZoom;
    for (int y = 0; y < map.Height; y++)
    {
      for (int x = 0; x < map.Width; x++)
      {
        if (!resolvedMossFloors.Contains(PackFloorFeatureTile(x, y)))
          continue;

        Rect cellRect = new Rect(
            mapRect.x + x * CellSize,
            mapRect.y + y * CellSize,
            CellSize,
            CellSize);
        Rect iconRect = new Rect(
            cellRect.x + iconInset,
            cellRect.y + iconInset,
            cellRect.width - iconInset * 2f,
            cellRect.height - iconInset * 2f);
        GUI.DrawTexture(iconRect, mossMapIcon, ScaleMode.ScaleToFit, true);
      }
    }
  }

  /// <summary>
  /// Populates Dungeon Features from the generated all-level placement
  /// database for the same active level that ViewEdit is displaying.
  /// Champion mirrors remain a dedicated Hall-of-Champions overlay.
  /// </summary>
  private bool LoadResolvedFeaturesFromDatabase()
  {
    if (!File.Exists(DungeonFeaturePlacementsPath))
      return false;

    try
    {
      DungeonFeaturePlacementDatabase database =
          DungeonFeaturePlacementDatabase.LoadFromFile(
              DungeonFeaturePlacementsPath);
      if (database == null || database.ornamentPlacements == null)
        return false;

      List<OriginalWallOrnamentMarker> wallMarkers =
          new List<OriginalWallOrnamentMarker>();
      resolvedPuddleFloors.Clear();
      resolvedMossFloors.Clear();

      for (int i = 0; i < database.ornamentPlacements.Length; i++)
      {
        DungeonOrnamentPlacement placement =
            database.ornamentPlacements[i];
        if (placement == null
            || placement.level != currentDungeonLevel
            || placement.resolved == null
            || string.IsNullOrEmpty(placement.resolved.type))
        {
          continue;
        }

        if (string.Equals(
                placement.domain,
                "Floor",
                System.StringComparison.OrdinalIgnoreCase))
        {
          if (string.Equals(
                  placement.resolved.type,
                  "Puddle",
                  System.StringComparison.OrdinalIgnoreCase))
          {
            resolvedPuddleFloors.Add(
                PackFloorFeatureTile(
                    placement.normalisedX,
                    placement.normalisedY));
          }
          if (string.Equals(
                  placement.resolved.type,
                  "Moss",
                  System.StringComparison.OrdinalIgnoreCase))
          {
            resolvedMossFloors.Add(
                PackFloorFeatureTile(
                    placement.normalisedX,
                    placement.normalisedY));
          }
          continue;
        }

        if (!string.Equals(
                placement.domain,
                "Wall",
                System.StringComparison.OrdinalIgnoreCase))
        {
          continue;
        }

        // Champion mirrors already have their own blue/yellow wall marker and
        // green champion-name labels in this editor.
        if (string.Equals(
                placement.resolved.type,
                "ChampionMirror",
                System.StringComparison.OrdinalIgnoreCase))
        {
          continue;
        }

        if (!TryParseWallSide(
                placement.normalisedFace,
                out WallSide side))
        {
          continue;
        }

        wallMarkers.Add(
            new OriginalWallOrnamentMarker(
                NormaliseDatabaseFeatureType(placement.resolved.type),
                placement.normalisedX,
                placement.normalisedY,
                side,
                true));
      }

      resolvedWallOrnaments = wallMarkers.ToArray();
      return true;
    }
    catch (System.Exception ex)
    {
      Debug.LogWarning(
          "Dungeon Features database load failed; using Hall fallback: "
          + ex.Message);
      return false;
    }
  }

  private static string NormaliseDatabaseFeatureType(string type)
  {
    if (string.Equals(
            type,
            "WallGrate",
            System.StringComparison.OrdinalIgnoreCase))
      return "Grate";

    return type;
  }

  private static void BuildHallOfChampionsPuddleFloors(
      DungeonMap map,
      HashSet<int> destination)
  {
    destination.Clear();
    if (map == null)
      return;

    int value2 = 3000 + map.Width + map.Height;

    for (int y = 0; y < map.Height; y++)
    {
      for (int x = 0; x < map.Width; x++)
      {
        DungeonTile tile = map.GetTile(x, y);
        if (tile == null
            || tile.SourceType != DungeonSourceTileType.Floor
            || (tile.Raw & 0x08) == 0)
        {
          continue;
        }

        int randomIndex = HallOfChampionsRandomOrnamentHash(
            2000 + (x << 5) + y,
            value2,
            HallOfChampionsRandomOrnamentModulo);

        if (randomIndex >= HallOfChampionsRandomFloorOrnamentCount)
          continue;

        int ordinal = randomIndex + 1;
        if (ordinal == HallOfChampionsPuddleFloorOrnamentOrdinal)
          destination.Add(PackFloorFeatureTile(x, y));
      }
    }
  }

  private static int HallOfChampionsRandomOrnamentHash(
      int value1,
      int value2,
      int modulo)
  {
    if (modulo <= 0)
      return 0;

    unchecked
    {
      uint d0Long = (uint)(ushort)value1 * 31417u;
      ushort d0Word = (ushort)d0Long;
      d0Word = (ushort)((d0Word >> 1) & 0x7FFF);

      uint d1Long = (uint)(ushort)value2 * 11u;
      d0Word = (ushort)(d0Word + (ushort)d1Long);
      d0Word = (ushort)(d0Word + HallOfChampionsDungeonSeed);
      d0Word = (ushort)((d0Word >> 2) & 0x3FFF);

      return d0Word % modulo;
    }
  }

  private static int PackFloorFeatureTile(int x, int y)
  {
    return (y << 8) | (x & 0xFF);
  }

  private void ReportMissingMapIcon(string asset, string description)
  {
    string key = description + ": " + (asset ?? "<null>");
    if (missingMapIconErrors.Add(key))
      Debug.Log("<color=cyan>Dungeon Features: Missing " + description
          + " (" + (asset ?? "<null>") + "). No substitute graphic was drawn.</color>");
  }

  private void DrawOriginalWallOrnamentIcons(Rect mapRect)
  {
    EnsureOrnamentTexturesResolved();
    DrawWallOrnamentIconList(mapRect, resolvedWallOrnaments);
  }

  private static OriginalWallOrnamentMarker[] BuildGreyWallOrnaments(
      DungeonMap map)
  {
    HallWallOrnamentPlacement[] generated =
        HallOfChampionsWallOrnaments.Build(map);
    List<OriginalWallOrnamentMarker> markers =
        new List<OriginalWallOrnamentMarker>();

    if (generated != null)
    {
      for (int i = 0; i < generated.Length; i++)
      {
        HallWallOrnamentPlacement ornament = generated[i];
        if (ornament == null
            || !TryParseWallSide(ornament.Wall, out WallSide side))
        {
          continue;
        }

        markers.Add(
            new OriginalWallOrnamentMarker(
                ornament.Type,
                ornament.X,
                ornament.Y,
                side,
                true));
      }
    }

    return markers.ToArray();
  }

  private static bool TryParseWallSide(string wall, out WallSide side)
  {
    if (!string.IsNullOrEmpty(wall) && wall.Length == 1)
    {
      switch (char.ToUpperInvariant(wall[0]))
      {
        case 'N': side = WallSide.North; return true;
        case 'E': side = WallSide.East; return true;
        case 'S': side = WallSide.South; return true;
        case 'W': side = WallSide.West; return true;
      }
    }

    if (string.Equals(
            wall,
            "North",
            System.StringComparison.OrdinalIgnoreCase))
    {
      side = WallSide.North;
      return true;
    }

    if (string.Equals(
            wall,
            "East",
            System.StringComparison.OrdinalIgnoreCase))
    {
      side = WallSide.East;
      return true;
    }

    if (string.Equals(
            wall,
            "South",
            System.StringComparison.OrdinalIgnoreCase))
    {
      side = WallSide.South;
      return true;
    }

    if (string.Equals(
            wall,
            "West",
            System.StringComparison.OrdinalIgnoreCase))
    {
      side = WallSide.West;
      return true;
    }

    side = WallSide.North;
    return false;
  }

  private void DrawWallOrnamentIconList(
      Rect mapRect,
      OriginalWallOrnamentMarker[] markers)
  {
    if (markers == null)
      return;

    // Large red VI overlay fills the Altar of Vi tile; original art stays beneath.
    GUIStyle viLabelStyle = new GUIStyle(GUI.skin.label)
    {
      alignment = TextAnchor.MiddleCenter,
      fontStyle = FontStyle.Bold,
      fontSize = Mathf.Max(1, Mathf.RoundToInt(20f * mapZoom))
    };
    viLabelStyle.normal.textColor = Color.red;

    GUIStyle lordOrderOutsideLabelStyle = new GUIStyle(GUI.skin.label)
    {
      alignment = TextAnchor.MiddleCenter,
      fontStyle = FontStyle.Bold,
      fontSize = Mathf.Max(1, Mathf.RoundToInt(10f * mapZoom))
    };
    lordOrderOutsideLabelStyle.normal.textColor = Color.white;

    for (int i = 0; i < markers.Length; i++)
    {
      OriginalWallOrnamentMarker marker = markers[i];

      Rect cellRect = new Rect(
          mapRect.x + marker.X * CellSize,
          mapRect.y + marker.Y * CellSize,
          CellSize,
          CellSize);

      // Only wall-attached ornaments have a facing direction. Floor features
      // are drawn separately and intentionally receive no blue marker.
      DrawWallFaceDirectionMarker(cellRect, marker.Side);

      Texture2D texture = GetOrnamentMapIcon(marker.Type);
      // Use the full map-tile interior for wall-item artwork, leaving
      // exactly 1px inward spacing, scaled with the map zoom.
      // No change to cell bounds or blue wall-face direction markers.
      float iconMargin = 1f * mapZoom;
      Rect iconRect = new Rect(
          cellRect.x + iconMargin,
          cellRect.y + iconMargin,
          Mathf.Max(1f, cellRect.width - 2f * iconMargin),
          Mathf.Max(1f, cellRect.height - 2f * iconMargin));

      if (IsLordOrderOutsideOrnamentType(marker.Type))
      {
        EditorGUI.DrawRect(iconRect, LordOrderOutsideMarkerColor);
        GUI.Label(cellRect, "LO", lordOrderOutsideLabelStyle);
        continue;
      }

      if (texture != null)
      {
        if (IsManaclesOrnamentType(marker.Type))
          EditorGUI.DrawRect(iconRect, ManaclesHighlightBackgroundColor);

        GUI.DrawTexture(
            iconRect,
            texture,
            ScaleMode.StretchToFill,
            true);

        if (string.Equals(marker.Type, "ViAltar",
                System.StringComparison.OrdinalIgnoreCase))
          GUI.Label(cellRect, "VI", viLabelStyle);

      }
      else
      {
        ReportMissingMapIcon(marker.Type, "wall ornament map icon");
      }
    }
  }

  // A compact persistent ornament preview, like the multi-item floor popup.
  // The map icon and preview both refer to the same authored wall tile/face.
  private List<OriginalWallOrnamentMarker> GetSelectedWallOrnaments()
  {
    List<OriginalWallOrnamentMarker> matches =
        new List<OriginalWallOrnamentMarker>();
    if (resolvedWallOrnaments == null)
      return matches;
    foreach (OriginalWallOrnamentMarker marker in resolvedWallOrnaments)
    {
      if (marker != null && marker.X == inspectedOrnamentX && marker.Y == inspectedOrnamentY)
        matches.Add(marker);
    }
    return matches;
  }

  private void DrawSelectedWallOrnamentPreview(Rect mapRect)
  {
    List<OriginalWallOrnamentMarker> ornaments = GetSelectedWallOrnaments();
    if (ornaments.Count == 0)
      return;

    EnsureOrnamentTexturesResolved();
    float unit = mapZoom;
    float width = 155f * unit;
    float blockHeight = 90f * unit;
    Rect panel = new Rect(mapRect.xMax + 8f * unit,
        mapRect.y - (LabelTopMargin + OutsideFeatureVerticalMargin) * unit
            + 2f * unit, width,
        20f * unit + ornaments.Count * blockHeight);
    EditorGUI.DrawRect(panel, new Color(0.15f, 0.15f, 0.15f, 1f));
    float border = Mathf.Max(1f, unit);
    Color borderColor = new Color(0.45f, 0.45f, 0.45f, 1f);
    EditorGUI.DrawRect(new Rect(panel.x, panel.y, panel.width, border), borderColor);
    EditorGUI.DrawRect(new Rect(panel.x, panel.yMax - border, panel.width, border), borderColor);
    EditorGUI.DrawRect(new Rect(panel.x, panel.y, border, panel.height), borderColor);
    EditorGUI.DrawRect(new Rect(panel.xMax - border, panel.y, border, panel.height), borderColor);

    GUIStyle titleStyle = new GUIStyle(EditorStyles.miniBoldLabel)
    { normal = { textColor = Color.white } };
    GUI.Label(new Rect(panel.x + 7f * unit, panel.y + 4f * unit,
        panel.width - 14f * unit, 17f * unit),
        "Wall (" + inspectedOrnamentX + "," + inspectedOrnamentY + ")", titleStyle);

    for (int i = 0; i < ornaments.Count; i++)
    {
      OriginalWallOrnamentMarker marker = ornaments[i];
      float y = panel.y + 22f * unit + i * blockHeight;
      GUI.Label(new Rect(panel.x + 6f * unit, y,
          panel.width - 12f * unit, 16f * unit), marker.Type, titleStyle);
      GUI.Label(new Rect(panel.x + 6f * unit, y + 16f * unit,
          panel.width - 12f * unit, 16f * unit),
          "Face: " + marker.Side, EditorStyles.miniLabel);
      Texture2D texture = GetOrnamentMapIcon(marker.Type);
      if (texture != null)
      {
        float imageSize = 52f * unit;
        GUI.DrawTexture(new Rect(panel.center.x - imageSize * 0.5f,
            y + 33f * unit, imageSize, imageSize),
            texture, ScaleMode.ScaleToFit, true);
      }
      else
      {
        ReportMissingMapIcon(marker.Type, "wall ornament preview image");
      }
    }
  }

  private static bool IsTorchHolderOrnamentType(string type)
  {
    return string.Equals(
               type,
               "FullTorchHolder",
               System.StringComparison.OrdinalIgnoreCase)
           || string.Equals(
               type,
               "EmptyTorchHolder",
               System.StringComparison.OrdinalIgnoreCase);
  }

  private static bool IsWoodRingOrnamentType(string type)
  {
    return string.Equals(
               type,
               "WoodRing",
               System.StringComparison.OrdinalIgnoreCase);
  }

  private static bool IsManaclesOrnamentType(string type)
  {
    return string.Equals(
               type,
               "Manacles",
               System.StringComparison.OrdinalIgnoreCase)
           || string.Equals(
               type,
               "WallManacles",
               System.StringComparison.OrdinalIgnoreCase);
  }

  private static bool IsLordOrderOutsideOrnamentType(string type)
  {
    return string.Equals(
               type,
               "LordOrderOutside",
               System.StringComparison.OrdinalIgnoreCase);
  }

  private void EnsureOrnamentTexturesResolved()
  {
    if (ornamentTexturesResolved)
      return;

    ornamentTexturesResolved = true;

    viAltarMapIcon = FindBestOrnamentTexture("ViAltar");
    hookMapIcon = FindBestOrnamentTexture("Hook");
    woodRingMapIcon = FindBestOrnamentTexture("WoodRing");
    slimeMapIcon = FindBestOrnamentTexture("Slime");
    grateMapIcon = FindBestOrnamentTexture("Grate");
    manaclesMapIcon = FindExactTextureByName("Manacles_F1");
    fullTorchHolderMapIcon = FindExactTextureByName("Torch_Lit_16x16");
    puddleMapIcon = AssetDatabase.LoadAssetAtPath<Texture2D>(
        PuddleF1AssetPath);
    mossMapIcon = FindExactTextureByName(MossF1AssetName);
    stairDownMapIcon = FindExactTextureByName("Stairs_Down_Icon_20x22");
  }

  private Texture2D GetOrnamentMapIcon(string type)
  {
    switch (type)
    {
      case "ViAltar":
        return viAltarMapIcon;

      case "Hook":
        return hookMapIcon;

      case "WoodRing":
        return woodRingMapIcon;

      case "Slime":
        return slimeMapIcon;

      case "Grate":
        return grateMapIcon;

      case "Manacles":
      case "WallManacles":
        return manaclesMapIcon;

      case "FullTorchHolder":
      case "EmptyTorchHolder":
        return fullTorchHolderMapIcon;

      default:
        return null;
    }
  }


  private static Texture2D FindExactTextureByName(string assetName)
  {
    if (string.IsNullOrEmpty(assetName))
      return null;

    string[] guids = AssetDatabase.FindAssets(
        assetName + " t:Texture2D",
        new[] { "Assets" });

    for (int i = 0; i < guids.Length; i++)
    {
      string path = AssetDatabase.GUIDToAssetPath(guids[i]);
      if (!string.Equals(
              Path.GetFileNameWithoutExtension(path),
              assetName,
              System.StringComparison.OrdinalIgnoreCase))
      {
        continue;
      }

      Texture2D texture = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
      if (texture != null)
        return texture;
    }

    return null;
  }

  private static Texture2D FindBestOrnamentTexture(string type)
  {
    string[] folders = type == "ViAltar"
        ? new[] { "Assets" }
        : new[] { "Assets/Art/Ornaments" };
    string[] guids = AssetDatabase.FindAssets("t:Texture2D", folders);

    Texture2D best = null;
    int bestScore = int.MinValue;

    for (int i = 0; i < guids.Length; i++)
    {
      string path = AssetDatabase.GUIDToAssetPath(guids[i]);
      string fileName =
          Path.GetFileNameWithoutExtension(path).ToLowerInvariant();

      int score = ScoreOrnamentTexture(type, fileName);
      if (score < 0 || score <= bestScore)
        continue;

      Texture2D candidate =
          AssetDatabase.LoadAssetAtPath<Texture2D>(path);
      if (candidate == null)
        continue;

      best = candidate;
      bestScore = score;
    }

    return best;
  }

  private static int ScoreOrnamentTexture(
      string type,
      string lowerFileName)
  {
    if (string.IsNullOrEmpty(lowerFileName))
      return -1;

    string normalized =
        lowerFileName
            .Replace("_", string.Empty)
            .Replace("-", string.Empty)
            .Replace(" ", string.Empty);

    int score = 0;

    switch (type)
    {
      case "ViAltar":
        if (!(normalized.Contains("altar") && normalized.Contains("vi")))
          return -1;
        score += 100;
        if (normalized.Contains("96x56") || normalized.Contains("9656"))
          score += 25;
        break;

      case "Hook":
        if (!normalized.Contains("hook"))
          return -1;
        score += 100;
        break;

      case "WoodRing":
        if (!(normalized.Contains("woodring")
              || (normalized.Contains("wood")
                  && normalized.Contains("ring"))))
        {
          return -1;
        }

        score += 100;
        break;

      case "Slime":
        if (!normalized.Contains("slime"))
          return -1;
        score += 100;
        break;

      case "Grate":
        if (!normalized.Contains("grate"))
          return -1;
        score += 100;
        if (normalized.Contains("32x28") || normalized.Contains("3228"))
          score += 25;
        break;

      default:
        return -1;
    }

    // Prefer the same frontal artwork used by the first-person renderer.
    if (normalized.Contains("front"))
      score += 50;

    // Prefer a named original-size/front file over side/distance variants.
    if (normalized.Contains("side"))
      score -= 20;
    if (normalized.Contains("f2"))
      score -= 10;
    if (normalized.Contains("f3"))
      score -= 10;

    return score;
  }

  private GUIStyle CreateChampionNameStyle()
  {
    GUIStyle nameStyle = new GUIStyle(GUI.skin.label)
    {
      alignment = TextAnchor.MiddleCenter,
      fontSize = Mathf.Max(1, Mathf.RoundToInt(12f * mapZoom)),
      fontStyle = FontStyle.Bold,
      clipping = TextClipping.Overflow,
      wordWrap = false,
      padding = new RectOffset(0, 0, 0, 0),
      margin = new RectOffset(0, 0, 0, 0)
    };

    Color textColor = new Color(0f, 1f, 0f, 1f);
    nameStyle.normal.textColor = textColor;
    nameStyle.hover.textColor = textColor;
    nameStyle.active.textColor = textColor;
    nameStyle.focused.textColor = textColor;
    nameStyle.onNormal.textColor = textColor;
    nameStyle.onHover.textColor = textColor;
    nameStyle.onActive.textColor = textColor;
    nameStyle.onFocused.textColor = textColor;
    return nameStyle;
  }

  private void DrawChampionName(
      Rect mapRect,
      Rect cellRect,
      ChampionMirrorMarker marker)
  {
    if (marker == null || string.IsNullOrEmpty(marker.Champion))
      return;

    GUIStyle nameStyle = CreateChampionNameStyle();

    int nameCellX = marker.X;
    int nameCellY = marker.Y;

    Vector2 labelCenter = cellRect.center;
    switch (marker.Side)
    {
      case WallSide.North:
        nameCellY -= 1;
        labelCenter.y -= CellSize;
        break;

      case WallSide.East:
        nameCellX += 1;
        labelCenter.x += CellSize;
        break;

      case WallSide.South:
        nameCellY += 1;
        labelCenter.y += CellSize;
        break;

      default: // West
        nameCellX -= 1;
        labelCenter.x -= CellSize;
        break;
    }

    bool labelFallsOnWalkableMap =
        map != null
        && map.IsInside(nameCellX, nameCellY)
        && map.GetTile(nameCellX, nameCellY).Type != DungeonTileType.Wall;

    Color previousContentColor = GUI.contentColor;
    GUI.contentColor = ChampionNameColor;

    bool pairTop =
        marker.Champion == "Tiggy" || marker.Champion == "Wu Tse";
    bool pairBottom =
        marker.Champion == "Wuuf" || marker.Champion == "Leif";
    if (pairTop || pairBottom)
    {
      Rect targetTileRect = new Rect(
          labelCenter.x - CellSize * 0.5f,
          labelCenter.y - CellSize * 0.5f,
          CellSize,
          CellSize);

      GUIStyle pairStyle = new GUIStyle(nameStyle)
      {
        alignment = pairTop
            ? TextAnchor.UpperCenter
            : TextAnchor.LowerCenter,
        clipping = TextClipping.Overflow
      };

      GUI.Label(targetTileRect, marker.Champion, pairStyle);
      GUI.contentColor = previousContentColor;
      return;
    }

    // Hissssa / Gothmog: column x=18, Y centered on the blue/yellow wall marker.
    if (marker.Champion == "Hissssa" || marker.Champion == "Gothmog")
    {
      Vector2 outsideSize = nameStyle.CalcSize(new GUIContent(marker.Champion));
      float outsideWidth = Mathf.Max(outsideSize.x, CellSize);
      float outsideHeight = Mathf.Max(outsideSize.y, 18f);
      const float markerLineThickness = 3f;
      float markerCenterY = marker.Side == WallSide.South
          ? cellRect.yMax - markerLineThickness * 0.5f
          : cellRect.y + markerLineThickness * 0.5f;
      Rect outsideNameRect = new Rect(
          mapRect.xMax,
          markerCenterY - outsideHeight * 0.5f,
          outsideWidth,
          outsideHeight);

      GUIStyle outsideStyle = new GUIStyle(nameStyle)
      {
        alignment = TextAnchor.MiddleLeft,
        clipping = TextClipping.Overflow
      };

      GUI.Label(outsideNameRect, marker.Champion, outsideStyle);
      GUI.contentColor = previousContentColor;
      return;
    }

    if (marker.Champion == "Daroou" || marker.Champion == "Mophus")
    {
      float stackedLineHeight = 9f;
      float stackedCharWidth = 20f;
      float stackedTotalHeight = marker.Champion.Length * stackedLineHeight;
      float stackedStartY = marker.Champion == "Mophus"
          ? cellRect.y + 1f
          : labelCenter.y - stackedTotalHeight * 0.5f;

      GUIStyle stackedStyle = new GUIStyle(nameStyle)
      {
        alignment = TextAnchor.MiddleCenter,
        clipping = TextClipping.Overflow
      };

      for (int i = 0; i < marker.Champion.Length; i++)
      {
        string glyph = marker.Champion[i].ToString();
        Vector2 glyphSize = stackedStyle.CalcSize(new GUIContent(glyph));
        float glyphWidth = Mathf.Max(stackedCharWidth, glyphSize.x);
        float glyphHeight = Mathf.Max(stackedLineHeight, glyphSize.y);

        Rect glyphRect = new Rect(
            labelCenter.x - glyphWidth * 0.5f,
            stackedStartY + i * stackedLineHeight
                + (stackedLineHeight - glyphHeight) * 0.5f,
            glyphWidth,
            glyphHeight);

        GUI.Label(glyphRect, glyph, stackedStyle);
      }

      GUI.contentColor = previousContentColor;
      return;
    }

    if (labelFallsOnWalkableMap)
    {
      float walkableLineHeight = 18f;
      float walkableCharWidth = 20f;
      float walkableTotalHeight = marker.Champion.Length * walkableLineHeight;
      float walkableStartY = labelCenter.y - walkableTotalHeight * 0.5f;

      GUIStyle walkableStyle = new GUIStyle(nameStyle)
      {
        alignment = TextAnchor.MiddleCenter,
        clipping = TextClipping.Overflow
      };

      for (int i = 0; i < marker.Champion.Length; i++)
      {
        string glyph = marker.Champion[i].ToString();
        Vector2 glyphSize = walkableStyle.CalcSize(new GUIContent(glyph));
        float glyphWidth = Mathf.Max(walkableCharWidth, glyphSize.x);
        float glyphHeight = Mathf.Max(walkableLineHeight, glyphSize.y);

        Rect glyphRect = new Rect(
            labelCenter.x - glyphWidth * 0.5f,
            walkableStartY + i * walkableLineHeight
                + (walkableLineHeight - glyphHeight) * 0.5f,
            glyphWidth,
            glyphHeight);

        GUI.Label(glyphRect, glyph, walkableStyle);
      }

      GUI.contentColor = previousContentColor;
      return;
    }

    Vector2 nameSize = nameStyle.CalcSize(new GUIContent(marker.Champion));
    float nameWidth = Mathf.Max(128f, nameSize.x + 4f);
    float nameHeight = Mathf.Max(18f, nameSize.y + 2f);
    Rect nameRect = new Rect(
        labelCenter.x - nameWidth * 0.5f,
        labelCenter.y - nameHeight * 0.5f,
        nameWidth,
        nameHeight);

    GUI.Label(nameRect, marker.Champion, nameStyle);
    GUI.contentColor = previousContentColor;
  }

  private bool TryTeleportToWallOrnament(int tileX, int tileY)
  {
    OriginalWallOrnamentMarker marker =
        FindWallOrnamentAtTile(
            resolvedWallOrnaments,
            tileX,
            tileY);

    if (marker == null)
      return false;

    int targetX = marker.X;
    int targetY = marker.Y;
    DungeonFacing targetFacing;

    if (!marker.WallTilePlacement)
    {
      // Mechanism is stored on the walkable cell itself.
      targetFacing = WallSideToFacing(marker.Side);
    }
    else if (!TryWalkableViewPoseForWallTile(
        marker,
        out targetX,
        out targetY,
        out targetFacing))
    {
      return false;
    }

    if (!map.IsInside(targetX, targetY)
        || !map.CanEnter(targetX, targetY))
    {
      return false;
    }

    selectedX = targetX;
    selectedY = targetY;
    selectedFacing = targetFacing;

    EditorPrefs.SetInt(ViewEditPreviewLevelKey, currentDungeonLevel);
    EditorPrefs.SetInt(ViewEditPreviewXKey, targetX);
    EditorPrefs.SetInt(ViewEditPreviewYKey, targetY);
    EditorPrefs.SetInt(
        ViewEditPreviewFacingKey,
        (int)targetFacing);

    return true;
  }

  private bool TryWalkableViewPoseForWallTile(
      OriginalWallOrnamentMarker marker,
      out int targetX,
      out int targetY,
      out DungeonFacing targetFacing)
  {
    targetX = marker.X;
    targetY = marker.Y;
    targetFacing = WallSideToFacing(marker.Side);

    int sideX;
    int sideY;
    WallSideOffset(marker.Side, out sideX, out sideY);

    // Physical-face convention: stand on the neighbor in Side and look back.
    int physicalX = marker.X + sideX;
    int physicalY = marker.Y + sideY;
    DungeonFacing lookBack = OppositeFacing(WallSideToFacing(marker.Side));
    if (map.IsInside(physicalX, physicalY) && map.CanEnter(physicalX, physicalY))
    {
      targetX = physicalX;
      targetY = physicalY;
      targetFacing = lookBack;
      return true;
    }

    // JSON/sensor-on-wall convention: Side is the look direction, so the
    // walkable cell is behind the camera. (12,3) North views from (12,4).
    int viewX = marker.X - sideX;
    int viewY = marker.Y - sideY;
    if (map.IsInside(viewX, viewY) && map.CanEnter(viewX, viewY))
    {
      targetX = viewX;
      targetY = viewY;
      targetFacing = WallSideToFacing(marker.Side);
      return true;
    }

    return false;
  }

  private static void WallSideOffset(
      WallSide side,
      out int dx,
      out int dy)
  {
    switch (side)
    {
      case WallSide.North:
        dx = 0;
        dy = -1;
        return;
      case WallSide.East:
        dx = 1;
        dy = 0;
        return;
      case WallSide.South:
        dx = 0;
        dy = 1;
        return;
      default:
        dx = -1;
        dy = 0;
        return;
    }
  }

  private static DungeonFacing OppositeFacing(DungeonFacing facing)
  {
    switch (facing)
    {
      case DungeonFacing.North:
        return DungeonFacing.South;
      case DungeonFacing.East:
        return DungeonFacing.West;
      case DungeonFacing.South:
        return DungeonFacing.North;
      default:
        return DungeonFacing.East;
    }
  }

  private static OriginalWallOrnamentMarker FindWallOrnamentAtTile(
      OriginalWallOrnamentMarker[] markers,
      int x,
      int y)
  {
    if (markers == null)
      return null;

    for (int i = 0; i < markers.Length; i++)
    {
      OriginalWallOrnamentMarker marker = markers[i];
      if (marker != null && marker.X == x && marker.Y == y)
        return marker;
    }

    return null;
  }

  private static DungeonFacing WallSideToFacing(WallSide side)
  {
    switch (side)
    {
      case WallSide.North:
        return DungeonFacing.North;
      case WallSide.East:
        return DungeonFacing.East;
      case WallSide.South:
        return DungeonFacing.South;
      default:
        return DungeonFacing.West;
    }
  }

  private bool TryFacingForEnteredCell(
      int x,
      int y,
      out DungeonFacing facing)
  {
    if (TryChampionMirrorFacing(x, y, out facing))
      return true;

    if (TryAdjacentOrnamentFacing(x, y, out facing))
      return true;

    if (TryAdjacentStairsFacing(x, y, out facing))
      return true;

    facing = selectedFacing;
    return false;
  }

  private bool TryChampionMirrorFacing(
      int x,
      int y,
      out DungeonFacing facing)
  {
    for (int i = 0; i < ChampionMirrorMarkers.Length; i++)
    {
      ChampionMirrorMarker marker = ChampionMirrorMarkers[i];
      if (marker != null && marker.X == x && marker.Y == y)
      {
        facing = WallSideToFacing(marker.Side);
        return true;
      }
    }

    facing = selectedFacing;
    return false;
  }

  // Search North, East, South, then West. The ornament side is the wall
  // face that looks back at the entered cell.
  private bool TryAdjacentOrnamentFacing(
      int x,
      int y,
      out DungeonFacing facing)
  {
    if (HasOrnamentFace(x, y - 1, WallSide.South))
    {
      facing = DungeonFacing.North;
      return true;
    }

    if (HasOrnamentFace(x + 1, y, WallSide.West))
    {
      facing = DungeonFacing.East;
      return true;
    }

    if (HasOrnamentFace(x, y + 1, WallSide.North))
    {
      facing = DungeonFacing.South;
      return true;
    }

    if (HasOrnamentFace(x - 1, y, WallSide.East))
    {
      facing = DungeonFacing.West;
      return true;
    }

    facing = selectedFacing;
    return false;
  }

  private bool TryAdjacentStairsFacing(
      int x,
      int y,
      out DungeonFacing facing)
  {
    if (IsUpOrDownStairs(x, y - 1))
    {
      facing = DungeonFacing.North;
      return true;
    }

    if (IsUpOrDownStairs(x + 1, y))
    {
      facing = DungeonFacing.East;
      return true;
    }

    if (IsUpOrDownStairs(x, y + 1))
    {
      facing = DungeonFacing.South;
      return true;
    }

    if (IsUpOrDownStairs(x - 1, y))
    {
      facing = DungeonFacing.West;
      return true;
    }

    facing = selectedFacing;
    return false;
  }

  private bool HasOrnamentFace(int wallX, int wallY, WallSide side)
  {
    if (resolvedWallOrnaments == null)
      return false;

    for (int i = 0; i < resolvedWallOrnaments.Length; i++)
    {
      OriginalWallOrnamentMarker marker = resolvedWallOrnaments[i];
      if (marker != null
          && marker.X == wallX
          && marker.Y == wallY
          && marker.Side == side)
      {
        return true;
      }
    }

    return false;
  }

  private bool IsUpOrDownStairs(int x, int y)
  {
    if (map == null || !map.IsInside(x, y))
      return false;

    DungeonTile tile = map.GetTile(x, y);
    return tile != null && tile.TryGetStairsDirection(out _);
  }

  // A feature clicked during search overview becomes the next search query.
  // Prefer the feature class appropriate to the tile itself, rather than
  // retaining the previous query (for example Hook -> Slime).
  private string GetClickedFeatureSearchName(int x, int y)
  {
    if (map.TryGetDoorData(x,y,out var door)) return DoorName(door);
    DungeonTile tile = map.GetTile(x, y);
    bool isWall = tile != null && tile.Type == DungeonTileType.Wall;
    if (isWall && resolvedWallOrnaments != null)
    {
      foreach (OriginalWallOrnamentMarker marker in resolvedWallOrnaments)
        if (marker != null && marker.X == x && marker.Y == y
            && !string.IsNullOrWhiteSpace(marker.Type))
          return marker.Type;
    }

    if (resolvedFloorItems.TryGetValue(PackFloorFeatureTile(x, y),
            out List<FloorItemPlacementRecord> records) && records != null)
    {
      foreach (FloorItemPlacementRecord record in records)
      {
        if (record == null)
          continue;
        string name = GetFloorItemDisplayName(record);
        if (!string.IsNullOrWhiteSpace(name))
          return name;
      }
    }

    if (resolvedWallOrnaments != null)
      foreach (OriginalWallOrnamentMarker marker in resolvedWallOrnaments)
        if (marker != null && marker.X == x && marker.Y == y
            && !string.IsNullOrWhiteSpace(marker.Type))
          return marker.Type;

    int key = PackFloorFeatureTile(x, y);
    if (resolvedPuddleFloors.Contains(key))
      return "Puddle";
    if (resolvedMossFloors.Contains(key))
      return "Moss";
    return null;
  }

  // Called after mouse hit-testing, avoiding a zoom change within MouseDown.
  private void SetSearchFromClickedFeature(string itemName, int x, int y)
  {
    if (string.IsNullOrWhiteSpace(itemName))
      return;
    featureSearchText = itemName.Length <= 12
        ? itemName : itemName.Substring(0, 12);
    RebuildFeatureSearch();
    for (int i = 0; i < featureSearchTiles.Count; i++)
    {
      if (featureSearchTiles[i].x != x || featureSearchTiles[i].y != y)
        continue;
      featureSearchIndex = i;
      selectedConnectorPulseStartTime = EditorApplication.timeSinceStartup;
      inspectedDoorX = x;
      inspectedDoorY = y;
      inspectedFloorItemX = x;
      inspectedFloorItemY = y;
      inspectedOrnamentX = x;
      inspectedOrnamentY = y;
      break;
    }
    // The focused IMGUI text editor may cache the old query. Release it,
    // then use the existing deferred focus mechanism on the next repaint.
    replaceSearchTextOnNextGui = true;
    focusSearchOnMouse5 = true;
    Repaint();
  }

  private void HandleGridClick(Rect mapRect)
  {
    Event current = Event.current;
    if (current.type != EventType.MouseDown || current.button != 0)
      return;

    Vector2 mouse = current.mousePosition;
    if (!mapRect.Contains(mouse))
      return;

    int x = Mathf.FloorToInt((mouse.x - mapRect.x) / CellSize);
    int y = Mathf.FloorToInt((mouse.y - mapRect.y) / CellSize);

    if (!map.IsInside(x, y))
      return;

    // In overview mode a click on a named feature changes the search query
    // to that feature. Empty tiles still clear the search and expand to 1x.
    // Defer both operations until after hit-testing this MouseDown event.
    if (searchOverviewActive && current.clickCount == 1)
    {
      int clickedX = x;
      int clickedY = y;
      string clickedName = GetClickedFeatureSearchName(x, y);
      EditorApplication.delayCall += () =>
      {
        if (this == null)
          return;
        if (!string.IsNullOrWhiteSpace(clickedName))
        {
          SetSearchFromClickedFeature(clickedName, clickedX, clickedY);
          return;
        }
        ResetFeatureSearch();
        mapZoomStep = 0;
        EditorPrefs.SetInt(MapZoomPreferenceKey, mapZoomStep);
        float width = Mathf.Max(1f, position.width - 24f);
        float height = Mathf.Max(1f, position.height - 125f);
        mapScroll.x = Mathf.Max(0f,
            LabelLeftMargin * mapZoom
            + (clickedX + 0.5f) * CellSize - width * 0.5f);
        mapScroll.y = Mathf.Max(0f,
            (LabelTopMargin + OutsideFeatureVerticalMargin) * mapZoom
            + (clickedY + 0.5f) * CellSize - height * 0.5f);
        Repaint();
      };
    }

    bool doubleClick = current.clickCount == 2;
    inspectedDoorX = x;
    inspectedDoorY = y;
    if (!doubleClick && map.TryGetDoorData(x,y,out _))
    {
      inspectedFloorItemX = inspectedFloorItemY = -1;
      inspectedOrnamentX = inspectedOrnamentY = -1;
      inspectedInscriptionX = inspectedInscriptionY = -1;
      current.Use();
      GUI.changed = true;
      Repaint();
      return;
    }
    // Single-click INS inspection takes precedence over wall ornaments.
    // Double-click behavior remains unchanged.
    if (!doubleClick && GetInscriptionRecordsAt(x, y).Count > 0)
    {
      inspectedInscriptionX = x;
      inspectedInscriptionY = y;
      inspectedOrnamentX = -1;
      inspectedOrnamentY = -1;
      inspectedFloorItemX = -1;
      inspectedFloorItemY = -1;
      current.Use();
      GUI.changed = true;
      Repaint();
      return;
    }
    if (inspectedInscriptionX != x || inspectedInscriptionY != y)
    {
      inspectedInscriptionX = -1;
      inspectedInscriptionY = -1;
    }

    // Single-click inspection must never teleport the player into a wall.
    // A second click retains the original wall-ornament teleport behavior.
    if (!doubleClick && resolvedWallOrnaments != null)
    {
      for (int i = 0; i < resolvedWallOrnaments.Length; i++)
      {
        OriginalWallOrnamentMarker marker = resolvedWallOrnaments[i];
        if (marker == null || marker.X != x || marker.Y != y)
          continue;
        inspectedOrnamentX = x;
        inspectedOrnamentY = y;
        current.Use();
        GUI.changed = true;
        Repaint();
        return;
      }
    }
    if (inspectedOrnamentX != x || inspectedOrnamentY != y)
    {
      inspectedOrnamentX = -1;
      inspectedOrnamentY = -1;
    }
    // An inspection belongs only to its selected tile. Clicking any other
    // tile (including one without items) clears stale details immediately.
    // Preserve the current details when double-clicking the same tile.
    if (inspectedFloorItemX != x || inspectedFloorItemY != y)
    {
      inspectedFloorItemX = -1;
      inspectedFloorItemY = -1;
    }
    // Inspect item records on a SINGLE click only. A second click must
    // remain available for the existing double-click tile navigation.
    if (!doubleClick && showFloorItems
        && resolvedFloorItems.TryGetValue(PackFloorFeatureTile(x, y),
               out List<FloorItemPlacementRecord> clickedItems)
        && clickedItems != null && clickedItems.Count > 0)
    {
      inspectedFloorItemX = x;
      inspectedFloorItemY = y;
      current.Use();
      GUI.changed = true;
      Repaint();
      return;
    }

    // INS markers specify a wall-facing direction. Navigation from these
    // markers must not inherit the previous camera orientation.
    if (doubleClick)
    {
      List<DungeonInscriptionRecord> inscriptionEntries =
          GetInscriptionRecordsAt(x, y);
      if (inscriptionEntries.Count > 0)
      {
        DungeonInscriptionRecord entry = inscriptionEntries[0];
        if (!TryFloorItemFacing(entry.wall, out DungeonFacing inscriptionFacing))
        {
          Debug.LogError("Dungeon Features: Invalid inscription direction at ("
              + x + "," + y + "): " + entry.wall);
          current.Use();
          return;
        }

        int viewX = x;
        int viewY = y;
        DungeonFacing viewFacing = inscriptionFacing;
        if (!map.CanEnter(viewX, viewY))
        {
          // For inscriptions attached to a stone tile, 'wall' describes
          // the physical face. Stand beside that face and look back at it.
          switch (inscriptionFacing)
          {
            case DungeonFacing.North: viewY--; viewFacing = DungeonFacing.South; break;
            case DungeonFacing.East: viewX++; viewFacing = DungeonFacing.West; break;
            case DungeonFacing.South: viewY++; viewFacing = DungeonFacing.North; break;
            case DungeonFacing.West: viewX--; viewFacing = DungeonFacing.East; break;
          }
        }
        if (!map.IsInside(viewX, viewY) || !map.CanEnter(viewX, viewY))
        {
          Debug.LogError("Dungeon Features: No walkable INS viewing tile for ("
              + x + "," + y + ") " + entry.wall + ". Teleport cancelled.");
          current.Use();
          return;
        }

        selectedX = viewX;
        selectedY = viewY;
        selectedFacing = viewFacing;
        EditorPrefs.SetInt(ViewEditPreviewLevelKey, currentDungeonLevel);
        EditorPrefs.SetInt(ViewEditPreviewXKey, viewX);
        EditorPrefs.SetInt(ViewEditPreviewYKey, viewY);
        EditorPrefs.SetInt(ViewEditPreviewFacingKey, (int)viewFacing);
        current.Use();
        GUI.changed = true;
        Repaint();
        CloseAfterGridTeleport();
        return;
      }
    }

    // Double-click navigation only accepts a walkable destination. A single
    // click still permits selecting map walls and inspecting their ornaments.
    if (doubleClick && !map.CanEnter(x, y))
    {
      current.Use();
      return;
    }

    // Floor objects use the CURRENT tile for F1. One tile ahead is F2.
    // Use the placement's own CSBwin cell direction to orient the player.
    // Single-click floor-item inspection is handled above without teleporting.
    if (doubleClick && resolvedFloorItems.TryGetValue(
            PackFloorFeatureTile(x, y), out List<FloorItemPlacementRecord> f1Items)
        && f1Items != null && f1Items.Count > 0)
    {
      // Multiple floor records can share a tile; start with the first one.
      // Their cell directions are supplied by DungeonFeaturePlacements.json.
      if (!TryFloorItemFacing(f1Items[0].direction, out DungeonFacing itemFacing))
      {
        Debug.LogError("Dungeon Features: Invalid floor-item direction for "
            + f1Items[0].id + " at (" + x + "," + y + "): '"
            + f1Items[0].direction + "'. Teleport cancelled.");
        current.Use();
        return;
      }
      selectedX = x;
      selectedY = y;
      selectedFacing = itemFacing;
      EditorPrefs.SetInt(ViewEditPreviewLevelKey, currentDungeonLevel);
      EditorPrefs.SetInt(ViewEditPreviewXKey, x);
      EditorPrefs.SetInt(ViewEditPreviewYKey, y);
      EditorPrefs.SetInt(ViewEditPreviewFacingKey, (int)selectedFacing);
      current.Use();
      GUI.changed = true;
      Repaint();
      CloseAfterGridTeleport();
      return;
    }

    if (TryTeleportToWallOrnament(x, y))
    {
      current.Use();
      GUI.changed = true;
      Repaint();
      if (doubleClick)
        CloseAfterGridTeleport();
      return;
    }

    DungeonFacing previousFacing = selectedFacing;
    selectedX = x;
    selectedY = y;

    if (map.CanEnter(x, y)
        && TryFacingForEnteredCell(x, y, out DungeonFacing enteredFacing))
    {
      selectedFacing = enteredFacing;
    }

    if (doubleClick)
      selectedFacing = previousFacing;

    EditorPrefs.SetInt(ViewEditPreviewLevelKey, currentDungeonLevel);
    EditorPrefs.SetInt(ViewEditPreviewXKey, x);
    EditorPrefs.SetInt(ViewEditPreviewYKey, y);
    EditorPrefs.SetInt(
        ViewEditPreviewFacingKey,
        (int)selectedFacing);

    current.Use();
    GUI.changed = true;
    Repaint();
    if (doubleClick)
      CloseAfterGridTeleport();
  }

  // The selected map pose has already been published to the shared ViewEdit
  // preferences. Close like Escape, then focus the existing ViewEdit window;
  // its normal inspector update applies the requested pose and redraws GameView.
  private static bool TryFloorItemFacing(string direction, out DungeonFacing facing)
  {
    switch (direction)
    {
      case "N": facing = DungeonFacing.North; return true;
      case "E": facing = DungeonFacing.East; return true;
      case "S": facing = DungeonFacing.South; return true;
      case "W": facing = DungeonFacing.West; return true;
      default: facing = DungeonFacing.North; return false;
    }
  }

  private void CloseAfterGridTeleport()
  {
    EditorApplication.delayCall += () =>
    {
      if (this != null)
        Close();
      foreach (ViewportLayoutEditor viewEdit in
          Resources.FindObjectsOfTypeAll<ViewportLayoutEditor>())
      {
        if (viewEdit == null)
          continue;
        viewEdit.Focus();
        viewEdit.Repaint();
        break;
      }
    };
  }

}
