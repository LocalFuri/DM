# Ring G4 — source-offset-aware CSBwin reconstruction

Generated: 2026-11-16T19:08:07+01:00 (Europe/Berlin)

Source: CSBwin_Extractions(7).zip, ordinal G4, graphic IDs 133 (side) and 134 (front).

Results: 9 reconstructed captures, 0 excluded, 0 warnings.

Method:
- Decode four planar bitplanes with MSB-first pixels and 16-pixel groups.
- Respect exported source_offset_x/source_offset_y before cropping to destination rectangle.
- Copy palette index 10 as transparent and preserve index 0 as opaque.
- No resizing of exported PNGs; nearest-neighbor used for preview only.
- Tight crops preserve absolute screen positioning through metadata offsets.

Special right-side offsets: P01 = 12 pixels; P06 = 5 pixels.

Captured: P00 S3_Left, P01 S3_Right, P03 F3_Center, P05 S2_Left, P06 S2_Right, P08 F2_Center, P10 S1_Left, P11 S1_Right, P12 F1_Center.

Not captured: P02 F3_LeftSlice, P04 F3_RightSlice, P07 F2_LeftSlice, P09 F2_RightSlice. Do not infer these captures from neighboring positions.

Verification status: exact pixel selection from recorded pre-blit data, NOT yet verified against live CSBwin viewport. Source's current runtime palette, cache state and source viewport compositing may cause differences. No Unity files changed.

Archive method: copy ZIP to C:\Unity\DM\Research_Results\CSBwin_Ornaments\Ring_G4\ then extract there. Preserve prior ZIP and data. Commit + push separately.
